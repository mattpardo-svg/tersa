Add one new tab "May IOP data: 7 TSOs" to the prototype presentation HTML.

Rules
- Don't change any existing tab: no text, style, script or data changes. The only change outside the new tab is its button/link in the tab bar, placed last.
- Under the tab title, one line: "Real case from the May IOP data set: 7 TSOs, CGM 2025-05-06 00:30Z."
- Reuse the existing styles, components and chart approach. Add no new external library or CDN.
- The numbers come from the DATA part at the end of this prompt. Write them into the HTML as static content, not read from any CSV. Don't save the DATA part anywhere.
- Round every value to 2 decimals; counts stay whole numbers. Use the TSO short names as in the data (ELIA, TTN, D4, TTG, D7, 50Hertz, RTE).

Layout, top to bottom
1. KPI tiles: 7 TSOs | 6,786 buses | 2,686 monitored branches | 1,848 contingencies | run time 7,753 s | peak memory 27.8 GB.
2. Run setup: small table (DATA section 1).
3. Case size: the network line and the per-TSO table with the total row (DATA section 2).
4. Overloads before RAs vs final AC check: one table, rows N-0 / N-X PATL / N-X TATL / N-X scanned. Columns: pre-MILP (XNECs, branches, A) and final (XNECs, branches, A). Pre-MILP values are in DATA section 3, final values in DATA section 5. Show the note under the DATA section 3 table below this table.
5. Remedial actions: the RA table and the balance note under it (DATA section 5).
6. Run performance: horizontal bar chart of time per step (DATA section 4), with the peak memory per step as a label. Show the total under the chart.

Checks
- Open the HTML in a browser: the new tab shows, and each existing tab looks and works as before.
- Show the diff: only the new tab and its one tab-bar entry changed.

Report briefly: the changes outside the new tab (should be only the tab-bar entry), and a screenshot of the new tab.

---------------------------------------------------------------
DATA
---------------------------------------------------------------

# May IOP data: 7 TSOs (data for the new tab)

Source: VM run `output/20250506T0030Z` (run_log.txt, summary.csv, rd_results.csv, ct_results.csv). All values rounded to 2 decimals.

## 1. Run setup
| Item | Value |
|---|---|
| CGM time | 2025-05-06 00:30Z |
| Calculation mode | ac_single_pass |
| RA types | pst + rd + countertrade |
| Iterations | 1 (single pass) |
| Total run time | 7,753.35 s |
| Peak memory | 27,835.37 MB |

## 2. Case size

Network (CGM): 6,786 buses, 9,423 branches (7,199 lines, 1,906 2-winding transformers, 88 PSTs), 4,955 generators, 0 HVDC lines

| TSO (EIC) | Short name | Assessed elements secured | Assessed elements scanned | Assessed elements excluded | Contingencies | Contingencies must-study | PST | RD RAs | RD bids | CT RAs | CT bids |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 10X1001A1001A094 | ELIA | 82 | 0 | 0 | 80 | 80 | 6 | 8 | 11 | 0 | 0 |
| 10X1001A1001A361 | TTN | 1,077 | 62 | 0 | 159 | 159 | 2 | 6 | 72 | 0 | 0 |
| 10XDE-ENBW--TNGX | D4 | 146 | 26 | 0 | 221 | 221 | 2 | 10 | 20 | 0 | 0 |
| 10XDE-EON-NETZ-C | TTG | 306 | 42 | 70 | 482 | 482 | 10 | 20 | 54 | 0 | 0 |
| 10XDE-RWENET---W | D7 | 481 | 0 | 0 | 516 | 516 | 1 | 39 | 70 | 0 | 0 |
| 10XDE-VE-TRANSMK | 50Hertz | 241 | 30 | 0 | 337 | 337 | 4 | 32 | 32 | 0 | 0 |
| 10XFR-RTE------Q | RTE | 141 | 52 | 2,098 | 338 | 271 | 0 | 4 | 8 | 1 | 2 |
| **Total** | | **2,474** | **212** | **2,168** | **2,133** | **2,066** | **25** | **119** | **267** | **1** | **2** |

## 3. Pre-MILP load flow and security analysis
| Check | Overloaded XNECs | Branches | Overload (A) |
|---|---|---|---|
| N-0 | 0 | 0 | 0.00 |
| N-X PATL | 3 | 1 | 117.39 |
| N-X TATL | 0 | 0 | 0.00 |
| N-X scanned | 0 | 0 | 0.00 |

The limit of a scanned element is its flow before any RA, so it cannot be overloaded before the RAs. The RAs bring the one overloaded RTE branch from 104.30 % to 100.01 % (948.13 A to 909.13 A, limit 909.00 A) in all 3 contingencies.

## 4. Run performance
| Step | Time (s) | Peak memory (MiB) |
|---|---|---|
| CGM load + base-case load flow | 64.70 | 1,634 |
| NCP discovery and parsing | 45.50 | 1,403 |
| Inventory, countertrade setup | 6.40 | 1,407 |
| N-0 sensitivity and RA preprocessing | 113.60 | 1,424 |
| N-X security analysis | 481.70 | 5,974 |
| N-X sensitivity | 5,313.50 | 23,462 |
| TATL data | 9.00 | 22,871 |
| Curative preprocessing | 0.90 | 22,872 |
| MILP build | 77.60 | 23,462 |
| MILP solve | 4.10 | 23,535 |
| Apply and AC verification | 443.70 | 27,408 |
| Outputs (N-X loadings, overload metrics, result files) | 1,192.65 | |
| **Total** | **7,753.35** | **27,835** |

## 5. Results

### Remedial actions activated (all preventive)
| Type | TSO | Direction | Volume (MW) | Cost (EUR) | Penalty (EUR) |
|---|---|---|---|---|---|
| RD | ELIA | up | 12.64 | 1,087.41 | 1,264.43 |
| RD | D7 | up | 43.86 | 3,509.04 | 4,386.30 |
| RD | D7 | up | 44.09 | 3,527.36 | 4,409.20 |
| RD | 50Hertz | up | 2.07 | 271.13 | 206.97 |
| RD | RTE | up | 100.00 | 3,745.00 | 10,000.00 |
| CT | RTE (zone 10YFR-RTE------C) | down | 202.67 | 1,013.34 | 20,266.89 |
| PST | – | – | 0 of 25 PSTs moved | | |

RD up (202.67 MW) = CT down (202.67 MW): the balance holds. One RTE unit gets both +100.00 MW RD and −5.09 MW CT, so the net change applied in the AC check is 197.58 MW per side.

### Final AC check
| Check | Overloaded XNECs | Branches | Overload (A) |
|---|---|---|---|
| N-0 | 0 | 0 | 0.00 |
| N-X PATL | 3 | 1 | 0.38 |
| N-X TATL | 0 | 0 | 0.00 |
| N-X scanned | 4 | 3 | 4.11 |
