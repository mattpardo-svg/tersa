"""process_memory.py - the memory of this process (Windows working set), for the log lines of the N-X steps."""

import ctypes
from typing import Optional


def working_set_mb() -> tuple[Optional[float], Optional[float]]:
    """(current, peak) working set of this process in MB (Windows API); (None, None) elsewhere."""
    try:
        from ctypes import wintypes

        class Counters(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD), ("PeakWorkingSetSize", ctypes.c_size_t),
                        ("WorkingSetSize", ctypes.c_size_t), ("a", ctypes.c_size_t), ("b", ctypes.c_size_t), ("c", ctypes.c_size_t),
                        ("d", ctypes.c_size_t), ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]

        counters = Counters()
        counters.cb = ctypes.sizeof(counters)
        process = ctypes.windll.kernel32.GetCurrentProcess()
        if not ctypes.windll.psapi.GetProcessMemoryInfo(ctypes.c_void_p(process), ctypes.byref(counters), counters.cb):
            return None, None
        return counters.WorkingSetSize / 1048576.0, counters.PeakWorkingSetSize / 1048576.0
    except Exception:
        return None, None


def describe(memory: tuple) -> str:
    """"320 MB (peak 340 MB)" or "n/a"."""
    return "n/a" if memory[0] is None else f"{memory[0]:.0f} MB (peak {memory[1]:.0f} MB)"
