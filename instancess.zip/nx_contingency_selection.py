"""nx_contingency_selection.py - which contingencies get N-X sensitivities and N-X constraints.

nx_sensitivity.contingency_min_loading_pct (default 0 = every usable contingency, nothing here is used): with a value > 0
a contingency is selected when at least one monitored branch side has, after it, a current (N-X security analysis) of at
least that percentage of the lowest limit that applies to the side in the MILP: PATL x milp_limit_factor_patl and TATL x
milp_limit_factor_tatl for a secured branch, the effective limit x milp_limit_factor_scanned for a scanned one. A contingency
that is not selected stays in the N-X security analysis, the final AC check and loadings_nx.csv, but has no N-X sensitivities
and no N-X rows in the MILP. In ac_iterative a contingency that overloads at the AC state without being selected is selected
from the next iteration on.
"""

import logging
from typing import Optional

from data_model import AEType, LfNx, select_by_side
from pre_milp import log_summary

log = logging.getLogger(__name__)


def lowest_limits_ampere(limit_by_branch: dict, branch_ae_types: dict, tatl_data: Optional[dict], factors) -> dict[str, float]:
    """{branch: the lowest limit (A) that applies to it in the MILP}: secured: PATL x PATL factor and, with a TATL above the
    PATL, TATL x TATL factor; scanned: effective limit x scanned factor. A branch without a limit > 0 has none."""
    from milp.milp_builder import tatl_is_above_patl

    lowest: dict[str, float] = {}
    for branch_mrid, limit in limit_by_branch.items():
        if not limit or float(limit) <= 0.0:
            continue
        ae_type = branch_ae_types.get(branch_mrid)
        if ae_type == AEType.SECURED:
            candidates = [float(limit) * factors.patl]
            entry = (tatl_data or {}).get(branch_mrid)
            if entry is not None and tatl_is_above_patl(entry["tatl_limit_ampere"], limit):
                candidates.append(float(entry["tatl_limit_ampere"]) * factors.tatl)
            lowest[branch_mrid] = min(candidates)
        elif ae_type == AEType.SCANNED:
            lowest[branch_mrid] = float(limit) * factors.scanned
    return lowest


class ContingencySelection:
    """The selected contingencies of a run (a set that only grows) with what is needed to decide and to check them."""

    def __init__(self, min_loading_pct: float, lowest_limit_ampere: dict, limit_by_branch: dict, branch_sides: dict):
        self.min_loading_pct = float(min_loading_pct)
        self.lowest_limit_ampere, self.limit_by_branch, self.branch_sides = lowest_limit_ampere, limit_by_branch, branch_sides
        self.selected: set[str] = set()
        self.not_selected: set[str] = set()
        self.added_after_overload: set[str] = set()

    def _current(self, per_branch: dict, branch_mrid: str):
        per_side = per_branch.get(branch_mrid)
        return select_by_side(per_side, self.branch_sides.get(branch_mrid, 1), branch_mrid) if per_side else None

    def reaches_threshold(self, per_branch: dict) -> bool:
        """True when one monitored branch side of the contingency is at or above the percentage of its lowest limit."""
        for branch_mrid, limit in self.lowest_limit_ampere.items():
            current = self._current(per_branch, branch_mrid)
            if current is not None and current == current and float(current) / limit * 100.0 >= self.min_loading_pct:
                return True
        return False

    def select_from(self, lf_nx: dict) -> None:
        """Decide every contingency of lf_nx that is not decided yet and log the counts (first call: all of them)."""
        for contingency_mrid, per_branch in lf_nx.items():
            if contingency_mrid in self.selected or contingency_mrid in self.not_selected:
                continue
            (self.selected if self.reaches_threshold(per_branch) else self.not_selected).add(contingency_mrid)
        log_summary.log_ids(
            log, logging.INFO,
            f"N-X contingency selection (contingency_min_loading_pct {self.min_loading_pct:g}): %d of {len(lf_nx)} contingencies "
            f"not selected (no N-X sensitivities, no N-X constraints); {len(self.selected & set(lf_nx))} selected",
            sorted(self.not_selected & set(lf_nx)))

    def restricted(self, lf_nx: Optional[dict]) -> Optional[dict]:
        """lf_nx with the selected contingencies only (the gap records of LfNx are kept), for the MILP."""
        if lf_nx is None:
            return None
        restricted = LfNx({c: v for c, v in lf_nx.items() if c in self.selected})
        for name in ("not_monitored", "tripped", "dropped", "guard_dropped"):
            if hasattr(lf_nx, name):
                setattr(restricted, name, getattr(lf_nx, name))
        return restricted

    def overloads_outside(self, lf_nx: Optional[dict]) -> dict[tuple[str, str], float]:
        """{(branch, contingency): A over its real limit} of the contingencies of lf_nx that are not selected."""
        overloads: dict[tuple[str, str], float] = {}
        for contingency_mrid, per_branch in (lf_nx or {}).items():
            if contingency_mrid in self.selected:
                continue
            for branch_mrid, limit in self.limit_by_branch.items():
                if not limit or float(limit) <= 0.0:
                    continue
                current = self._current(per_branch, branch_mrid)
                if current is not None and current == current and float(current) > float(limit):
                    overloads[(branch_mrid, contingency_mrid)] = float(current) - float(limit)
        return overloads

    def select_overloaded(self, lf_nx: Optional[dict], iteration: int) -> set[str]:
        """Select the contingencies that overload at this AC state without being selected; the ones added."""
        added = {contingency for _branch, contingency in self.overloads_outside(lf_nx)}
        if added:
            self.selected |= added
            self.not_selected -= added
            self.added_after_overload |= added
            log_summary.log_ids(
                log, logging.INFO,
                f"AC verification iteration {iteration}: %d not selected contingency(ies) overload at the AC state - selected "
                "from the next iteration on", sorted(added))
        return added

    def log_final_overloads(self, lf_nx: Optional[dict]) -> None:
        """One line: the overloads of the final AC state that occur in contingencies that were not selected."""
        overloads = self.overloads_outside(lf_nx)
        log.info(
            "Final AC check: %d overload(s) (%.1f A in total) in %d contingency(ies) that were not selected for N-X "
            "(contingency_min_loading_pct %g)", len(overloads), sum(overloads.values()),
            len({contingency for _branch, contingency in overloads}), self.min_loading_pct)
