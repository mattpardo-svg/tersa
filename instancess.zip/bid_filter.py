"""bid_filter.py - bids that cannot be used are dropped right after the NCP parse.

A redispatch or countertrade bid with no volume at the run time (volume 0) or whose lead time is not met at the run time is
dropped; a remedial action left with no usable bid is dropped with them (it has nothing to act with: no sensitivity variable,
no MILP variable). One summary line per TSO and RA type replaces the per-bid and per-RA warnings of the parse.
"""

import logging
from typing import Callable

from pre_milp import log_summary

log = logging.getLogger(__name__)

NO_VOLUME = "volume 0"
LEAD_TIME = "lead time not met"


def _bid_problem(bid, timestamp: str, lead_time_usable: Callable[[float], bool]):
    if float(bid.available_mw.get(timestamp, 0.0)) <= 0.0:
        return NO_VOLUME
    if bid.lead_time_h > 0 and not lead_time_usable(float(bid.lead_time_h)):
        return LEAD_TIME
    return None


def drop_unusable_bids(
    rd_list: list, bid_list: list, ct_ra_list: list, ct_bid_list: list, timestamp: str, lead_time_usable: Callable[[float], bool],
) -> dict:
    """Drop, in place, the unusable bids of bid_list (redispatch) and ct_bid_list (countertrade) and the RAs of rd_list and
    ct_ra_list that had bids and have no usable bid left. Returns {(tso, "RD" | "CT"): {"bids": {reason: [bid ids]}, "ras": [RA ids]}}
    (the dropped ones) and logs one line per TSO and RA type."""
    dropped: dict[tuple[str, str], dict] = {}
    for label, ras, bids in (("RD", rd_list, bid_list), ("CT", ct_ra_list, ct_bid_list)):
        tso_of = {str(ra.mrid): ra.tso for ra in ras}
        original_bids = list(bids)
        kept = []
        for bid in bids:
            reason = _bid_problem(bid, timestamp, lead_time_usable)
            if reason is None:
                kept.append(bid)
                continue
            tso = tso_of.get(str(bid.ra_mrid), "unknown TSO")
            dropped.setdefault((tso, label), {"bids": {}, "ras": []})["bids"].setdefault(reason, []).append(str(bid.mrid))
        bids[:] = kept
        with_bid = {str(bid.ra_mrid) for bid in bids}
        had_bid = {str(bid.ra_mrid) for bid in original_bids}
        left, seen = [], set()
        for ra in ras:
            if str(ra.mrid) in with_bid or str(ra.mrid) not in had_bid:
                left.append(ra)
            elif str(ra.mrid) not in seen:
                seen.add(str(ra.mrid))
                dropped.setdefault((ra.tso, label), {"bids": {}, "ras": []})["ras"].append(str(ra.mrid))
        ras[:] = left
    for (tso, label), what in sorted(dropped.items()):
        _log_summary(tso, label, what)
    return dropped


def _log_summary(tso: str, label: str, what: dict) -> None:
    bid_count = sum(len(ids) for ids in what["bids"].values())
    by_reason = ", ".join(f"{len(ids)} {reason}" for reason, ids in sorted(what["bids"].items())) or "none"
    ids = what["ras"] or [bid for bids in what["bids"].values() for bid in bids]
    first = "RA" if what["ras"] else "bid"
    log_summary.log_ids(
        log, logging.WARNING if what["ras"] else logging.INFO,
        f"{tso}: {label}: {bid_count} unusable bid(s) dropped ({by_reason}), {len(what['ras'])} RA(s) without a usable bid dropped; "
        f"%d {first} id(s)", ids)
