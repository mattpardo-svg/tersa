"""tests/test_rao_ct_weighted_variables.py - a countertrade RA and direction as ONE pypowsybl weighted variable set gives the
weighted sum of the per-unit sensitivities (N-X and N-0), on a small synthetic test network."""

import numpy as np
import pytest

pp = pytest.importorskip("pypowsybl")

from helpers import _make_contingency_nx_sec as _contingency
from pre_milp import ct_sensitivity, n0_sensitivity
from pre_milp.nx_sensitivity import compute_ct_nx

# a variable id -> {unit: weight}; the weights do not add up to 1
WEIGHTS = {"CT|RA1|up": {"B2-G": 0.3, "B3-G": 0.7}, "CT|RA2|down": {"B3-G": 1.0, "B6-G": 2.0}}
BRANCH_SIDES = {"L2-3-1": 1, "L2-4-1": 2, "L3-4-1": 1}


@pytest.fixture(scope="module")
def network():
    return pp.network.create_ieee14()


def _flatten(blocks):
    return {
        (contingency, side, branch, variable): blocks[contingency][side][2][row, column]
        for contingency in blocks for side in blocks[contingency]
        for column, branch in enumerate(blocks[contingency][side][0])
        for row, variable in enumerate(blocks[contingency][side][1])
    }


def test_the_nx_variable_per_ra_and_direction_equals_the_weighted_sum_of_the_units(network, caplog):
    contingencies = [_contingency("co-1", ["L1-2-1"]), _contingency("co-2", ["L1-5-1"])]
    per_unit, _ = compute_ct_nx(network, contingencies, BRANCH_SIDES, WEIGHTS, variable_sets=False)
    weighted, _ = compute_ct_nx(network, contingencies, BRANCH_SIDES, WEIGHTS, variable_sets=True)
    assert "one variable per unit is used instead" not in caplog.text          # the weighted sets worked, no fallback
    a, b = _flatten(per_unit), _flatten(weighted)
    assert a and a.keys() == b.keys()
    for key in a:
        assert b[key] == pytest.approx(a[key], rel=1e-6, abs=1e-9)


def test_the_n0_variable_per_ra_and_direction_equals_the_weighted_sum_of_the_units(network, caplog, monkeypatch):
    monkeypatch.setattr(ct_sensitivity, "WEIGHTED_VARIABLES", True)
    def run(per_unit):
        return n0_sensitivity._injection_sensitivity_n0(
            network, ["B2-G"], BRANCH_SIDES, None, False, None, None, None, None, "ptdf_rd_n0", "RD",
            ct_weights=WEIGHTS, ct_per_unit=per_unit)
    per_unit, weighted = run(True), run(False)
    assert "one variable per unit is used instead" not in caplog.text
    assert per_unit.keys() == weighted.keys()
    assert any(variable.startswith("CT|") for _branch, variable in weighted)
    for key in per_unit:
        assert weighted[key] == pytest.approx(per_unit[key], rel=1e-6, abs=1e-9)

def test_the_weighted_variables_are_off_by_default():
    assert ct_sensitivity.WEIGHTED_VARIABLES is False


def test_a_contingency_that_trips_a_unit_of_the_variables_uses_the_per_unit_variables(network):
    # pypowsybl leaves a tripped member out of the weighted set and renormalises: the weighted sum of the units needs them
    contingencies = [_contingency("co-trip", ["B3-G"]), _contingency("co-line", ["L1-2-1"])]
    per_unit, _ = compute_ct_nx(network, contingencies, BRANCH_SIDES, WEIGHTS, variable_sets=False)
    weighted, _ = compute_ct_nx(network, contingencies, BRANCH_SIDES, WEIGHTS, variable_sets=True)
    a, b = _flatten(per_unit), _flatten(weighted)
    assert a.keys() == b.keys() and a
    for key in a:
        assert b[key] == pytest.approx(a[key], rel=1e-6, abs=1e-9)


def test_a_disconnected_unit_gives_the_per_unit_variables_in_n0_and_n_x(monkeypatch):
    monkeypatch.setattr(ct_sensitivity, "WEIGHTED_VARIABLES", True)
    network = pp.network.create_ieee14()
    network.update_generators(id="B6-G", connected=False)
    assert not ct_sensitivity.all_units_connected(network, {"B2-G", "B6-G"})
    assert ct_sensitivity.all_units_connected(pp.network.create_ieee14(), {"B2-G", "B6-G"})
    calls = []
    real = ct_sensitivity.weighted_zones
    monkeypatch.setattr(ct_sensitivity, "weighted_zones", lambda *a: calls.append(1) or real(*a))
    compute_ct_nx(network, [_contingency("co-1", ["L1-2-1"])], BRANCH_SIDES, WEIGHTS, variable_sets=True)
    assert calls == []                                              # no weighted variable was made

def test_the_config_key_is_false_in_both_files_and_must_be_a_boolean():
    import run_pipeline
    from pathlib import Path
    config_dir = Path(run_pipeline.__file__).parent / "config"
    for name in ("rao_config.yaml", "rao_config.default.yaml"):
        assert "countertrade_weighted_variables: false\n" in (config_dir / name).read_text(encoding="utf-8").replace("\r\n", "\n")
    config = run_pipeline.yaml.safe_load((config_dir / "rao_config.yaml").read_text(encoding="utf-8"))
    config["nx_sensitivity"]["countertrade_weighted_variables"] = "yes"
    with pytest.raises(ValueError, match="nx_sensitivity.countertrade_weighted_variables"):
        run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))
