"""The gate script fails (non-zero) when any one of its stages fails, not only the last one."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "tools" / "golden"))
import run_gate


def _stage(code):
    return ["-c", f"raise SystemExit({code})"]


def test_rao_gate_reports_a_failing_stage_that_is_not_the_last(tmp_path):
    report = tmp_path / "gate.txt"
    failed = run_gate.run_stages([("first", _stage(0)), ("broken", _stage(3)), ("last", _stage(0))], report)
    assert failed == ["broken"]
    text = report.read_text(encoding="utf-8")
    assert "STAGE FAILED (3): broken" in text and "GATE FAILED: broken" in text and text.endswith("GATE DONE\n")


def test_rao_gate_passes_when_all_stages_pass(tmp_path):
    report = tmp_path / "gate.txt"
    assert run_gate.run_stages([("a", _stage(0)), ("b", _stage(0))], report) == []
    assert "GATE PASSED" in report.read_text(encoding="utf-8")


def test_rao_suite_stage_exits_non_zero_when_a_test_fails(tmp_path):
    import run_suite
    repo = tmp_path / "repo"
    (repo / "tests").mkdir(parents=True)
    (repo / "tests" / "test_rao_good.py").write_text("def test_ok():\n    assert True\n", encoding="utf-8")
    (repo / "tests" / "test_rao_bad.py").write_text("def test_bad():\n    assert False\n", encoding="utf-8")
    totals, failed = run_suite.run_suite(repo, tmp_path / "out", 2)
    assert failed == ["test_rao_bad.py"] and totals["failed"] == 1 and totals["passed"] == 1
    (repo / "tests" / "test_rao_bad.py").unlink()
    assert run_suite.run_suite(repo, tmp_path / "out2", 2)[1] == []


def test_rao_gate_main_exit_code_is_non_zero_for_a_failed_stage(tmp_path, monkeypatch):
    monkeypatch.setattr(run_gate, "run_stages", lambda stages, report, env=None, cwd=None: ["suite"])
    assert run_gate.main([str(tmp_path), "t", "none", str(tmp_path)]) == 1
    monkeypatch.setattr(run_gate, "run_stages", lambda stages, report, env=None, cwd=None: [])
    assert run_gate.main([str(tmp_path), "t", "none", str(tmp_path)]) == 0
