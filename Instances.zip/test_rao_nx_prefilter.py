"""tests/test_rao_nx_prefilter.py - the conservative filter that drops N-X rows that can never bind while the sensitivities
are read (NxPrefilter); the exact filter of the model builder is not changed."""

import types

import pytest

from data_model import AEType
from milp.milp_builder import MilpLimitFactors
from milp.nx_constraint_filter import NxPrefilter
from pre_milp.nx_sensitivity import _prefilter_batch

PATL = 1000.0


def _prefilter(enabled=True, margin=1.0, factors=MilpLimitFactors(), pst_taps=None, unit_mw=None):
    return NxPrefilter(
        enabled, margin, min(factors.patl, factors.tatl), factors.scanned,
        pst_taps if pst_taps is not None else {"PST1": 20.0}, {"PST1": 1.0}, unit_mw or {}, {}, {}, set(),
    )


def _never(prefilter, current, sens=-10.0, kind="pst", variable="PST1", ae_type=AEType.SECURED):
    """Branches of one contingency that can never bind: one branch at `current` A with one sensitivity."""
    return prefilter.rows_that_can_never_bind(
        [(kind, {("B1", variable): sens})], lambda b: current,
        lambda b: prefilter.lowest_limit_ampere(b, ae_type, PATL, {"B1": PATL}),
    )


def test_a_row_that_can_bind_is_kept_and_one_that_cannot_is_dropped():
    prefilter = _prefilter()
    assert _never(prefilter, 1100.0) == set()          # 1100 A, a PST that can remove 200 A, but also add 200 A
    assert _never(prefilter, 500.0) == {"B1"}          # 500 + 200 <= 1000 - 1
    assert prefilter.rows_dropped == 1 and prefilter.rows_considered == 2


def test_the_limit_minus_margin_decides():
    assert _never(_prefilter(margin=1.0), 798.0) == {"B1"}
    assert _never(_prefilter(margin=1.0), 800.5) == set()
    assert _never(_prefilter(margin=101.0), 798.0) == set()


def test_a_curative_cap_counts_for_every_contingency_and_a_missing_bound_keeps_the_row():
    with_cap = _prefilter(pst_taps={"PST1": 20.0 + 30.0})       # preventive range 20 taps + curative cap 30
    assert _never(with_cap, 500.0) == set()                     # 500 + 500 > 999
    assert _never(_prefilter(pst_taps={}), 100.0) == set()      # a PST without a tap range: no finite bound


def test_the_lowest_limit_is_used_the_tatl_factor_when_it_is_lower():
    factors = MilpLimitFactors(patl=1.0, tatl=0.5, scanned=1.0)
    assert _never(_prefilter(factors=factors), 500.0) == set()  # limit 500 x ... the TATL factor lowers the limit to 500
    assert _never(_prefilter(factors=MilpLimitFactors(patl=1.0, tatl=1.0)), 500.0) == {"B1"}


def test_scanned_rows_use_their_own_factor_and_a_nan_sensitivity_keeps_the_row():
    prefilter = _prefilter(factors=MilpLimitFactors(patl=1.0, tatl=1.0, scanned=0.5))
    assert _never(prefilter, 100.0, ae_type=AEType.SCANNED) == {"B1"}      # 100 + 200 <= 500 - 1
    assert _never(prefilter, 400.0, ae_type=AEType.SCANNED) == set()
    assert _never(_prefilter(), 0.0, sens=float("nan")) == set()


def test_rd_units_use_the_participation_weighted_volume():
    prefilter = _prefilter(unit_mw={"G1": 300.0})
    assert _never(prefilter, 600.0, sens=0.5, kind="rd", variable="G1") == {"B1"}      # 600 + 150
    assert _never(prefilter, 860.0, sens=0.5, kind="rd", variable="G1") == set()


def test_the_filter_off_keeps_every_row():
    reader = types.SimpleNamespace(
        pending={"CO1": (None, {("B1", "PST1"): -10.0})}, kind="pst", lf_nx={"CO1": {"B1": {1: 100.0}}}, branch_sides={"B1": 1},
        branch_ae_types={"B1": AEType.SECURED}, limit_by_branch={"B1": PATL}, ae_flat_list=[], timestamp="1030Z",
    )
    batch = [types.SimpleNamespace(mrid="CO1")]
    assert _prefilter_batch([reader], batch, _prefilter(enabled=False)) == {}
    assert _prefilter_batch([reader], batch, None) == {}
