﻿"""The test suite in parallel by file: python tests/tools/golden/run_suite.py OUTDIR WORKERS
The exit code is 1 when any test file ends with a non-zero code (failed or erroring tests), otherwise 0."""
import subprocess, sys, pathlib, time, re, concurrent.futures as cf


def run_suite(repo, out, workers):
    """Run every tests/test_rao_*.py of repo by file; print one line per file and the totals. Returns (totals, files whose pytest
    exit code is not 0)."""
    repo, out = pathlib.Path(repo), pathlib.Path(out)
    out.mkdir(parents=True, exist_ok=True)
    files = sorted((repo / "tests").glob("test_rao_*.py"))

    def run(f):
        t = time.time()
        p = subprocess.run([sys.executable, "-m", "pytest", str(f), "-q", "-p", "no:cacheprovider", "--basetemp", str(out / ("tmp_" + f.stem))],
                           cwd=repo, capture_output=True, text=True, encoding="utf-8", errors="replace")
        (out / (f.stem + ".log")).write_text(p.stdout + p.stderr, encoding="utf-8")
        last = [l for l in p.stdout.strip().splitlines() if l.strip()][-1] if p.stdout.strip() else "no output"
        return f.name, p.returncode, last, round(time.time() - t)

    tot = {"passed": 0, "failed": 0, "skipped": 0, "xfailed": 0, "error": 0}
    failed_files = []
    with cf.ThreadPoolExecutor(int(workers)) as ex:
        for name, rc, last, secs in ex.map(run, files):
            print(f"{name:55} rc={rc} {secs:4}s  {last}", flush=True)
            if rc != 0:
                failed_files.append(name)
            for k in tot:
                m = re.search(r"(\d+) " + k, last)
                if m: tot[k] += int(m.group(1))
    print("TOTAL", tot, "files", len(files))
    if failed_files:
        print("FAILED FILES:", ", ".join(failed_files))
    return tot, failed_files


if __name__ == "__main__":
    _, failed = run_suite(pathlib.Path(__file__).resolve().parents[3], sys.argv[1], sys.argv[2])
    sys.exit(1 if failed else 0)
