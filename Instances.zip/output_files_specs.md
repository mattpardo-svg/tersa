# Output files redesign (`output_files_specs.md`)

Status: implemented (DECISIONS 203-205).

> Changed later: nothing; the table of section 2 names the old files on purpose.
Example rows use mock values only.

## 1. Rules

- One folder per run: `output/<CGM time>/` (e.g. `output/20250506T0030Z/`), holding every file below plus `run_log.txt`. A rerun of the same timestamp empties and refills its folder. Runs one after the other only.
- File names: lower case, `_` separated, no `results_` prefix.
- Column names: lower case, `_` separated; the unit is the last part of the name.
  - current `_a` (ampere everywhere; no kA), power `_mw`, money `_eur`, price `_eur_per_mw`, angle `_deg`
  - percent `_pct`
  - durations in the units of the specification: TATL duration `_s`, reaction time `_min`, bid lead time `_h`; run times `_s`
  - sensitivities `_a_per_tap`, `_a_per_mw`
  - identifiers `_id` (never `mrid`), names `_name`; lists in one cell separated by `;`
  - `tso` wherever an object belongs to a TSO (operator from the content, else the file creator)
  - `ra_type` (`pst`, `rd`, `ct`, `hvdc`) wherever several RA types share a file
  - `side` is `1` or `2`; `direction` is `up` or `down`; flags are `true` / `false`
- Column order: `tso` is always the first column; limits before the value: min, max, then the current value (e.g. `p_min_mw, p_max_mw, p_mw`; `tap_min, tap_max, tap`).
- Removed from every file: `timestamp` (in the folder name and `summary.csv`), `ac_verification_status` and `ac_verification_termination_reason` (in `summary.csv` only).
- A file is written only when its feature is on (ra_types, N-X, config switch).
- A file lists what the run used; what was left out (excluded elements, skipped contingencies, ignored RAs or bids) and why is in the log only.

## 2. File list (old -> new) - AGREED

| Group | New file | Replaces |
|---|---|---|
| Input | `assessed_elements.csv` | `scanned_element_list.csv`, `tatl_data.csv` |
| Input | `contingencies.csv` | `co_flat_list.csv`, `results_contingency_status.csv` |
| Input | `generating_units.csv` | input part of `results_generating_units.csv`, `countertrade_glsk_resolved.csv` |
| Input | `pst_ra.csv` | input part of `results_pst.csv` |
| Input | `hvdc_ra.csv` | input part of `results_hvdc.csv` |
| Input | `rd_bids.csv` | input part of `results_preventive_rd.csv`, `results_curative_rd.csv`, `results_lead_times.csv`; `glsk_resolved.csv` |
| Input | `ct_bids.csv` | input part of `results_countertrade.csv`, `results_curative_countertrade.csv` |
| Results | `pst_results.csv` | `results_pst.csv`, `results_curative_pst.csv`, `results_curative_pst_groups.csv` |
| Results | `rd_results.csv` | `results_preventive_rd.csv`, `results_curative_rd.csv` |
| Results | `ct_results.csv` | `results_countertrade.csv`, `results_curative_countertrade.csv` |
| Results | `hvdc_results.csv` | `results_hvdc.csv`, `results_curative_hvdc.csv` |
| Results | `zone_net_positions.csv` | `results_net_positions.csv` |
| Results | `tso_limits.csv` | `results_tso_tap_limits.csv`, `results_preventive_rd_ra_count.csv` |
| Results | `summary.csv` | `results_summary.csv` |
| Flows | `loadings_n0.csv` | `lf_basecase.csv`, `lf_post_n0.csv` |
| Flows | `loadings_nx.csv` | `lf_nx_initial.csv`, `results_nx_loadings.csv`, `results_nx_scanned_elements.csv` |
| Debug | `iterations.csv` (`ac_iterative` only) | `results_iteration_history.csv`, `results_completeness_iterations.csv` |
| Debug | `sensitivity_{pst,rd,ct}_{n0,nx}.csv` (off by default) | `sensitivity_pst_n0/nx.csv`, `sensitivity_rd_n0/nx.csv` |
| Log only | - | `results_preventive_rd_ra_groups.csv`, `pst_/rd_/ct_/hvdc_cra_availability.csv` |
| Dropped | - | `results_zone_exchange.csv` |
| Always | `run_log.txt` | unchanged |

38 CSV files become 17 always-possible files plus 6 optional sensitivity files.

Config keys (new or changed): `outputs.loadings_n0_min_loading_pct` (80), `outputs.loadings_nx_min_loading_pct` (80), `outputs.write_loadings_nx` (true), `outputs.write_sensitivity_csvs` (false; replaces `write_nx_sensitivity_csvs`).

## 3. Columns per file

Each table: new column, old column(s), note. "new" = not in any file today.

### 3.1 `assessed_elements.csv` - one monitored branch side (always) (AGREED)

One row per branch side as the pipeline monitors it. Excluded elements are not listed (the log gives the exclusion reasons). No assessed-element id: an element is traced through the NCP by its branch. When several assessed elements point to the same branch side, the row shows the combined result (the implementation reports the combination rule used). Whether a branch is monitored in N-0 and/or N-X shows in `loadings_n0.csv` and `loadings_nx.csv`.

| New | Old | Note |
|---|---|---|
| tso | tso | |
| branch_id | branch_mrid | |
| branch_name | branch_name | |
| branch_type | - | new: line, transformer, dangling_line, tie_line |
| side | - | new |
| ae_type | - | new: secured, scanned |
| patl_a | patl_cgm_ka | x1000 |
| patl_source | - | new: ncp, cgm, converted_mva |
| tatl_a | tatl_limit_ka (tatl_data) | x1000; N-X runs only |
| tatl_duration_s | tatl_duration_seconds (tatl_data) | N-X runs only |
| tatl_source | was_corrected (tatl_data) | cgm, longest_of_several, fallback_patl, raised_to_patl; N-X runs only |
| effective_limit_a | effective_limit_ka, patl_scanned_ka | x1000; scanned only: max(PATL, flow before any RA), N-0 |

Dropped: `initial_loading_ka` (in `loadings_n0.csv`), `virtual_load_margin_pct` (a config value). `tatl_data.csv` is merged into this file.

Example: `TSO-A,BR_AB1,Line A-B 1,line,1,secured,1200.0,cgm,1440.0,1200,cgm,`

### 3.2 `contingencies.csv` - one contingency used in the run (always) (AGREED)

Only the contingencies actually used (must-study, computed, valid). Skipped or invalid ones are not listed; the log gives one summary line per reason.

| New | Old | Note |
|---|---|---|
| tso | - | new (file creator) |
| contingency_id | contingency_mrid | |
| contingency_name | name | |
| contingency_type | contingency_type | ordinary, exceptional |
| equipment_ids | equipment_mrids | `;` separated, same order as equipment_types |
| equipment_types | equipment_type | `;` separated |

Dropped: `must_study`, `converged`, `skipped_reason`, `included_in_milp`, `sensitivity_valid`, `sensitivity_source`, `timestamp`.

Example: `TSO-B,CO_01,Outage Line C-D,ordinary,BR_CD1,line`
Example with several elements: `TSO-B,CO_07,Tower T12 double circuit,exceptional,BR_CD1;BR_CD2;GU_05,line;line;generator`

### 3.3 `curative_availability.csv` - DROPPED (AGREED)

All inputs are in other files (reaction time and linked contingencies in the RA input files, TATL duration in `assessed_elements.csv`). One log summary per RA type instead (pairs available, not available, and why).

### 3.4 Sensitivity files (AGREED)

| File | Row | Columns |
|---|---|---|
| `sensitivity_pst_n0.csv` | branch x PST | `tso, branch_id, side, pst_id, sensitivity_a_per_tap` |
| `sensitivity_rd_n0.csv` | branch x RD unit | `tso, branch_id, side, unit_id, sensitivity_a_per_mw` |
| `sensitivity_ct_n0.csv` | branch x CT RA x direction | `tso, branch_id, side, ra_id, direction, sensitivity_a_per_mw` |
| `sensitivity_pst_nx.csv` | branch x contingency x PST | `tso, branch_id, side, contingency_id, pst_id, sensitivity_a_per_tap` |
| `sensitivity_rd_nx.csv` | branch x contingency x RD unit | `tso, branch_id, side, contingency_id, unit_id, sensitivity_a_per_mw` |
| `sensitivity_ct_nx.csv` | branch x contingency x CT RA x direction | `tso, branch_id, side, contingency_id, ra_id, direction, sensitivity_a_per_mw` |

- PST N-X in A per tap (today A per degree), the same as N-0.
- The three N-X files list only the rows (branch, contingency) kept by the N-X pre-filter, which drops while the sensitivities are read the rows that can never bind (DECISIONS 211). A branch missing for a contingency was therefore not a possible constraint there, not a missing value.
- Today the RD files also hold the CT rows (`CT|<RA>|<direction>` variables); these move to the CT files. `variable_id`/`variable_type` disappear.
- One switch `outputs.write_sensitivity_csvs` for all six, default false (replaces `write_nx_sensitivity_csvs`).

Example (rd n0): `TSO-A,BR_AB1,1,GU_01,0.42`

### 3.5 `loadings_n0.csv` - one monitored branch side, N-0 (AGREED)

Columns: `tso, branch_id, side, limit_a, current_initial_a, current_milp_a, current_after_pra_a, loading_initial_pct, loading_milp_pct, loading_after_pra_pct`

- `limit_a`: PATL, or the effective limit for scanned elements.
- initial = in the CGM before any RA; after_pra = after the preventive RAs (final AC load flow).
- `current_milp_a`: the value of the flow expression of the N-0 row in the solved MILP (the current of the model plus the sensitivities times the preventive RA changes); in `ac_iterative` the last solve, in `dc` the DC-based model current. `loading_milp_pct` = `current_milp_a` / `limit_a` x 100, always against the real `limit_a` (the MILP margin `thresholds.milp_limit_factor_*` does not enter). Both are empty for a branch side without an N-0 MILP row (left out of the model, for example below `thresholds.min_loading_threshold_pct`). The log gives one line with the rows with and without a MILP value.
- Branch details are in `assessed_elements.csv`.

Example: `TSO-A,BR_AB1,1,1200.0,1250.3,1190.5,1180.0,104.2,99.2,98.3`

Replaces `lf_basecase.csv`, `lf_post_n0.csv` (final state only).

Rows: a branch side is written when its initial loading OR its loading after the preventive RAs is at least `outputs.loadings_n0_min_loading_pct` (default 80) percent of `limit_a`. Its own threshold, separate from the N-X one; validated (number >= 0).

### 3.6 `loadings_nx.csv` - one monitored branch side x contingency (AGREED)

Columns: `tso, branch_id, side, contingency_id, limit_a, tatl_a, current_initial_a, current_milp_a, current_after_pra_cra_a, loading_initial_pct, loading_milp_pct, loading_after_pra_cra_pct`

- initial = after the contingency, before any RA; after_pra_cra = after the contingency with the preventive RAs and, if any, the curative RAs of that contingency (final result only).
- `current_milp_a`: the value of the flow expression of the N-X PATL or scanned row of the pair in the solved MILP (the post-contingency current of the model plus the sensitivities times the preventive and the curative RA changes of that contingency); in `ac_iterative` the last solve. `loading_milp_pct` = `current_milp_a` / `limit_a` x 100 against the real `limit_a`. Both are empty for a pair without an N-X MILP row (not monitored for that contingency, below `thresholds.min_loading_threshold_pct_nx`, or left out by the constraint filter as never binding). The log gives one line with the rows with and without a MILP value.
- Contingency details are in `contingencies.csv`.

Example: `TSO-A,BR_AB1,1,CO_01,1200.0,1440.0,1320.0,1185.0,1190.0,110.0,98.8,99.2`

Replaces `lf_nx_initial.csv`, `results_nx_loadings.csv`, `results_nx_scanned_elements.csv`. Dropped: branch and contingency names, `ae_type`, `converged`, model columns.

Rows (decided): a pair is written when its initial loading OR its loading after the RAs is at least `outputs.loadings_nx_min_loading_pct` (default 80; separate from the N-0 threshold) percent of `limit_a`. The whole file is written only when `outputs.write_loadings_nx` is true (default true). Both keys are validated (bool; number >= 0).

### 3.7 `summary.csv` - one metric (always) (AGREED)

Columns: `metric, value, unit`. Also holds the values of the single solve in `ac_single_pass` and `dc` (no `iterations.csv` there).

| Group | Metrics |
|---|---|
| Run | `cgm_time`, `calculation_mode`, `ra_types`, `status`, `run_time_s`, `peak_memory_mb` |
| Inputs used | `monitored_branches`, `contingencies`, `pst_ras`, `rd_bids`, `ct_bids`, `hvdc_ras` (usable ones only) |
| Objective | `objective_eur`, `rd_cost_eur`, `rd_penalty_eur`, `ct_cost_eur`, `ct_penalty_eur`, `pst_penalty_eur`, `hvdc_penalty_eur`, `overload_penalty_n0_eur`, `overload_penalty_nx_eur`, `overload_penalty_tatl_eur`, `overload_penalty_scanned_eur` |
| Actions | `pst_tap_changes`, `rd_volume_up_mw`, `rd_volume_down_mw`, `ct_volume_up_mw`, `ct_volume_down_mw`, `hvdc_change_mw` |
| Final check (AC) | `overloaded_branches_n0`, `overload_n0_a`, `overloaded_xnecs_nx`, `overloaded_branches_nx`, `overload_nx_a`, `overloaded_xnecs_scanned`, `overloaded_branches_scanned`, `overload_scanned_a` |
| Solve | `iterations`, `converged_by`, `nx_constraints`, `build_s`, `solve_s` |

- `cost_eur` = market cost (bid price x volume, reservation); `penalty_eur` = penalty term; the objective is the sum of the objective group.
- An XNEC is an overloaded (branch, contingency) pair; `overloaded_branches_*` counts distinct branches.

Example (mock values):
```
metric,value,unit
calculation_mode,ac_single_pass,
status,completed,
objective_eur,40000.00,EUR
rd_cost_eur,6000.00,EUR
rd_penalty_eur,12000.00,EUR
ct_cost_eur,600.00,EUR
ct_penalty_eur,12000.00,EUR
overload_penalty_nx_eur,8000.00,EUR
overload_penalty_scanned_eur,1400.00,EUR
rd_volume_up_mw,120.00,MW
ct_volume_down_mw,120.00,MW
overloaded_xnecs_nx,2,count
overloaded_branches_nx,1,count
overload_nx_a,8.00,A
```

Replaces `results_summary.csv` (46 metrics). Dropped: objective residual, stale/invalid sensitivity counters, completeness counters, preventive/curative cost splits per RA type (in the results files), duplicates.

### 3.8 `iterations.csv` - one solve, `ac_iterative` only (AGREED)

Written only in `ac_iterative`; the single solve of `ac_single_pass` and `dc` is in the Solve group of `summary.csv`.

Columns: `iteration, objective_eur, tap_change_sum, rd_ct_change_sum_mw, overload_a, new_nx_constraints, converged, converged_by, build_s, solve_s, ac_check_s`

- `overload_a`: total remaining overload after the AC check of that solve.
- `converged_by`: the criterion that ended the loop (change below threshold, overload criterion, cycle detected, iteration limit).

Example: `3,40000.0,2,240.0,8.0,0,true,change_below_threshold,20.0,5.0,30.0`

Replaces `results_iteration_history.csv`, `results_completeness_iterations.csv`. Dropped: criterion flags, max values, completeness/linearisation counters, cycle columns, stale/invalid sensitivity counts (log), `load_flow_converged`, `solution_applied`.

### 3.9 `pst_ra.csv` - one PST RA usable in the run (AGREED; input, before the optimisation)

| New | Old | Note |
|---|---|---|
| tso | tso | |
| ra_id | - | new: the NCP RA |
| ra_name | - | new |
| kind | - | preventive, curative |
| pst_ids | pst_mrid | `;` separated; several = a group moving together |
| tap_min, tap_max | - | allowed range per PST, same order |
| tap | original_tap_position | per PST, same order |
| penalty_factor | pst_penalty_factor | |
| reaction_time_min | - | curative only |
| contingency_ids | - | curative only; empty = all contingencies |

Results (tap changes, penalties) are in `pst_results.csv` (3.14).

Example: `TSO-B,RA_PST_05,PST group Z,preventive,PST_05;PST_06,-32;-32,32;32,2;2,1.0,,`

### 3.10 `rd_bids.csv` - one usable redispatch bid (AGREED; input, before the optimisation)

One row per bid; the RA attributes (kind, penalty factor, reaction time, contingencies) are repeated on each bid of the RA. Only usable bids (lead time met, units connected, volume above 0); the others are in the log.

| New | Old | Note |
|---|---|---|
| tso | tso | |
| bid_id | bid_mrid | |
| ra_id | ra_mrid | link to the RA profile |
| kind | - | preventive, curative |
| direction | direction | up, down |
| volume_max_mw | max_curative_volume_mw | bid volume at the run time |
| price_eur_per_mw | price_eur_mw | default price if missing, 0 if negative |
| reservation_price_eur_per_mw | reservation_price_eur_mw | curative only |
| lead_time_h | bid_lead_time_hours | |
| unit_ids | gu_mrid (glsk_resolved) | `;` separated |
| participation_factors | participation_factor (glsk_resolved) | same order |
| penalty_factor | rd_penalty_factor | RA attribute |
| reaction_time_min | reaction_time_minutes | RA attribute; curative only |
| contingency_ids | - | RA attribute; curative only; empty = all |

Example: `TSO-A,BID_01,RA_RD_01,preventive,up,100.0,50.0,,1.0,GU_01;GU_02,0.6;0.4,1.0,,`

### 3.11 `ct_bids.csv` - one usable countertrade bid (AGREED; input, before the optimisation)

As `rd_bids.csv`, with the bidding zone instead of units; the unit shares are in `generating_units.csv`.

Columns: `tso, bid_id, ra_id, zone_id, kind, direction, volume_max_mw, price_eur_per_mw, reservation_price_eur_per_mw, lead_time_h, penalty_factor, reaction_time_min, contingency_ids`

Example: `TSO-C,BID_CT1,RA_CT_01,ZONE_C,preventive,down,150.0,5.0,,0.0,1.0,,`

### 3.12 `hvdc_ra.csv` - one HVDC RA usable in the run (AGREED; input, before the optimisation)

Group and injection are traced through the RA profile by `ra_id`.

| New | Old | Note |
|---|---|---|
| tso | tso | |
| ra_id | - | new |
| ra_name | unit_name | |
| kind | - | preventive, curative |
| p_min_mw, p_max_mw | pmin_op_mw, pmax_op_mw | RA range combined with CGM limits |
| p_mw | original_p_mw | set point in the CGM |
| penalty_factor | penalty_factor | |
| reaction_time_min | - | curative only |
| contingency_ids | - | curative only; empty = all |

Example: `TSO-A,RA_HV_01,HVDC Link 1 end A,preventive,-1000.0,1000.0,500.0,1.0,,`

### 3.13 `generating_units.csv` - one generating unit usable by rd or ct (AGREED; input, before the optimisation)

Input summary only, like `assessed_elements.csv` and `contingencies.csv`: no results. Redispatch shares are per bid and are in `rd_bids.csv`. Countertrade shares are per zone (remaining capacity, the same for every countertrade RA and bid of the zone), so one up and one down share per unit.

| New | Old | Note |
|---|---|---|
| tso | tso | |
| unit_id | gu_mrid | |
| unit_name | gu_name | |
| zone_id | zone_mrid (countertrade_glsk_resolved) | |
| p_min_mw, p_max_mw | - | new |
| p_mw | initial_production_mw | output in the CGM |
| on | - | new: running in the CGM |
| ct_participation_factor_up | participation_factor (countertrade_glsk_resolved, direction up) | empty if no countertrade RA in its zone |
| ct_participation_factor_down | participation_factor (countertrade_glsk_resolved, direction down) | |

Dropped: `rd_volume_net_mw`, `ct_volume_net_mw`, `result_production_mw`, `rd_cost_eur`, `rd_penalty_cost_eur` (results are in the RA type files), `ct_ra_id`, `strategy`.

Example: `TSO-C,GU_10,Unit 10,ZONE_C,50.0,400.0,200.0,true,0.04,0.06`

### 3.14 Results files, one per RA type (AGREED)

Only actions that were used. Empty `contingency_id` = preventive; filled = curative for that contingency. Costs: `cost_eur` is the market cost (bid price x volume, plus reservation for curative); `penalty_eur` is the penalty term of the objective (penalty factor x reference x change). PST and HVDC have no market price, so only `penalty_eur`. Run totals and the split per cost kind are in `summary.csv`.

`pst_results.csv` - one row per PST that moved: `tso, ra_id, pst_id, contingency_id, tap_before, tap_change, tap_after, penalty_eur`
Example: `TSO-A,RA_PST_01,PST_01,,0,-3,-3,30.0`

`rd_results.csv` - one row per activated redispatch bid: `tso, bid_id, ra_id, contingency_id, direction, volume_mw, cost_eur, penalty_eur`
Example: `TSO-A,BID_01,RA_RD_01,,up,120.0,6000.0,12000.0`

`ct_results.csv` - one row per activated countertrade bid: `tso, bid_id, ra_id, zone_id, contingency_id, direction, volume_mw, cost_eur, penalty_eur`
Example: `TSO-C,BID_CT1,RA_CT_01,ZONE_C,,down,120.0,600.0,12000.0`

`hvdc_results.csv` - one row per HVDC RA that moved: `tso, ra_id, contingency_id, p_before_mw, p_change_mw, p_after_mw, penalty_eur`
Example: `TSO-A,RA_HV_01,,500.0,-100.0,400.0,1000.0`

Replaces: `results_pst.csv`, `results_curative_pst.csv`, `results_curative_pst_groups.csv`, `results_preventive_rd.csv`, `results_curative_rd.csv`, `results_lead_times.csv` (result part), `results_countertrade.csv`, `results_curative_countertrade.csv`, `results_hvdc.csv`, `results_curative_hvdc.csv`.

### 3.15 `tso_limits.csv` - one TSO (pst or rd) (AGREED)

Columns: `tso, tap_change_max, tap_changes, ra_count_max, ra_count`

- `tap_change_max`, `ra_count_max`: the TSO's limits from the config (empty if none); `tap_changes`, `ra_count`: used.

Example: `TSO-A,6,3,,2`

Replaces `results_tso_tap_limits.csv`, `results_preventive_rd_ra_count.csv`. Dropped: `remaining`, `binding`, `slack_per_timestamp`, `ra_activated_model_binary`.

### 3.16 `ra_groups.csv` - DROPPED (AGREED)

Replaced by one log line per restrictive group with a resolved limit, e.g. "RA group GRP_RD1: up 120 of 200 MW, down 0 of 200 MW". Bid volumes are in `rd_results.csv`.

### 3.17 `zone_net_positions.csv` - one zone (ct) (AGREED)

Columns: `tso, zone_id, rd_change_mw, ct_change_mw, net_change_mw`

Example: `TSO-A,ZONE_A,120.0,-120.0,0.0`

### 3.18 `zone_exchanges.csv` - DROPPED (AGREED)

No file and no log line; the tie-line pairing code across zones is removed. Zone effects are in `zone_net_positions.csv`; monitored tie-line flows in the loadings files.

## 4. Decisions and follow-ups

Decided: ampere everywhere; durations in spec units (TATL s, reaction time min, lead time h); `loadings_n0.csv` final state only; PST N-X sensitivity per tap; HVDC per RA with group and injection traced through the RA profile; `last_solve_*` columns dropped; files list what was used, the log explains the rest; `tso` first; min, max, then value.

Follow-ups:
1. GUI update to the new file and column names (the GUI reads today `results_pst.csv`, `results_preventive_rd.csv`, `results_preventive_rd_ra_count.csv`).
2. The golden baseline is replaced in full; values are proven equal per mapped column before the replacement.
3. When implementing, each new column is mapped from the old one (section 3 "Old" columns) and the value is checked equal before the golden baseline is replaced.
