"""nx_constraint_filter.py - N-X flow rows that can never bind are not built (exact model reduction).

For a row  I + sum(coefficient x variable) <= limit + slack  the largest possible |flow| over all feasible
variable values follows from the variable bounds:  |I| + sum |coefficient| x (largest change the bounds allow).
When that bound is at most limit - margin the row is slack at every feasible point, so the row and its slack
variable leave the optimum, the objective and every variable unchanged. A variable without a finite bound
(None here) disables the skip for the row. A term with coefficient 0 is not a term.
"""

import logging
import math
from typing import Iterable, Optional

log = logging.getLogger(__name__)

KINDS = ("nx_patl", "nx_tatl", "nx_scanned")


def empty_skipped_pairs() -> dict[str, set]:
    return {kind: set() for kind in KINDS}


def flow_upper_bound_ampere(current_ampere: float, terms: Iterable[tuple[float, Optional[float]]]) -> Optional[float]:
    """|current| + sum |coefficient| x max_change over (coefficient, max_change) terms; None when a term with a
    non-zero coefficient has no finite max_change (variable without a finite bound)."""
    bound = abs(float(current_ampere))
    for coefficient, max_change in terms:
        if coefficient == 0.0:
            continue
        if max_change is None or not math.isfinite(max_change):
            return None
        bound += abs(float(coefficient)) * float(max_change)
    return bound


def can_never_bind(bound_ampere: Optional[float], limit_ampere: float, margin_ampere: float) -> bool:
    return bound_ampere is not None and bound_ampere <= float(limit_ampere) - float(margin_ampere)


class NxPrefilter:
    """The conservative form of the constraint filter that runs while the N-X sensitivities are read, before any model exists.
    A (branch, contingency) row is dropped with its sensitivities only when it cannot bind even with bounds that are never
    smaller than the ones of the exact filter (milp_builder): the full tap range of every PST from its start tap plus the
    curative cap, the full volume of every bid (preventive and curative, every contingency, every unit of its GLSK), the
    full range of every HVDC unit, and the lowest limit that can apply to the row (secured: PATL x the smaller of the PATL
    and TATL factors; scanned: its PATL x the scanned factor). A term without a finite bound keeps the row. The exact filter
    of the model builder is not changed and still decides the rows of the model; a row dropped here is one it would also skip.

    pst_taps: {PST: the most taps it can move}; unit_mw: {unit: sum of participation x volume over all bids that are not
    countertrade}; ct_bids: {variable id: (weights, largest volume)}; hvdc_mw: {EI: largest change}; hvdc_curative_eis: the EIs
    of curative units (no bound). degrees_per_tap: {PST: degrees per tap}."""

    RELATIVE_SLACK = 1e-9

    def __init__(self, enabled, margin_ampere, secured_factor, scanned_factor, pst_taps, degrees_per_tap, unit_mw, ct_bids,
                 hvdc_mw, hvdc_curative_eis):
        self.enabled, self.margin_ampere = bool(enabled), float(margin_ampere)
        self.secured_factor, self.scanned_factor = float(secured_factor), float(scanned_factor)
        self.pst_taps, self.degrees_per_tap, self.unit_mw, self.ct_bids = pst_taps, degrees_per_tap, unit_mw, ct_bids
        self.hvdc_mw, self.hvdc_curative_eis = hvdc_mw, set(hvdc_curative_eis)
        self.rows_considered = self.rows_dropped = 0

    def lowest_limit_ampere(self, branch_mrid, ae_type, limit_ampere, scanned_patl_ampere) -> Optional[float]:
        """The lowest limit the rows of a branch can have in the model (None: unknown, the row is kept)."""
        from data_model import AEType
        if ae_type == AEType.SECURED and limit_ampere:
            return float(limit_ampere) * self.secured_factor
        if ae_type == AEType.SCANNED and scanned_patl_ampere.get(branch_mrid):
            return float(scanned_patl_ampere[branch_mrid]) * self.scanned_factor
        return None

    def _term(self, kind: str, variable, value: float) -> float:
        """The largest |change of the current| the variable can cause on the branch (inf when it has no finite bound)."""
        if kind == "pst":
            degrees = self.degrees_per_tap.get(str(variable))
            if degrees is None:
                return 0.0                                   # the builder does not use a PST without degrees per tap
            taps = self.pst_taps.get(str(variable))
            return math.inf if taps is None else abs(value) * abs(float(degrees)) * taps
        if kind == "hvdc":
            if variable in self.hvdc_curative_eis and value != 0.0:
                return math.inf
            return abs(value) * self.hvdc_mw.get(variable, 0.0)
        if str(variable).startswith("CT|"):
            return 0.0                                       # added through ct_bids
        return abs(value) * self.unit_mw.get(variable, 0.0)

    def rows_that_can_never_bind(self, tables, current_of, limit_of) -> set:
        """The branches of one contingency whose rows can never bind. tables: [(kind, table)] with kind pst, rd or hvdc (the
        tables after Filter 1 and the threshold); current_of(branch) -> the N-X current (A) or None; limit_of(branch) ->
        the lowest limit (A) or None."""
        from pre_milp import ct_sensitivity
        bounds: dict[str, float] = {}
        branches_of_rd: set = set()
        for kind, table in tables:
            for (branch_mrid, variable), value in table.items():
                value = float(value)
                if value != value:
                    bounds[branch_mrid] = math.inf           # a NaN sensitivity keeps the row (the builder skips it for that)
                    continue
                bounds[branch_mrid] = bounds.get(branch_mrid, 0.0) + self._term(kind, variable, value)
                if kind == "rd":
                    branches_of_rd.add(branch_mrid)
        for kind, table in tables:
            if kind != "rd":
                continue
            for branch_mrid in branches_of_rd:
                for variable_id, (weights, volume_mw) in self.ct_bids.items():
                    bounds[branch_mrid] += abs(ct_sensitivity.coefficient(table, branch_mrid, variable_id, weights)) * volume_mw
        never = set()
        for branch_mrid, extra in bounds.items():
            current, limit = current_of(branch_mrid), limit_of(branch_mrid)
            if current is None or limit is None or current != current or not math.isfinite(extra):
                continue
            if (abs(float(current)) + extra) * (1.0 + self.RELATIVE_SLACK) <= float(limit) - self.margin_ampere:
                never.add(branch_mrid)
        self.rows_considered += len(bounds)
        self.rows_dropped += len(never)
        return never


def build_prefilter(
    enabled, margin_ampere, factors, timestamp, pst_list, pst_tap_bounds, pst_degrees_per_tap, pst_cra_availability, rd_inputs,
    hvdc_inputs,
) -> NxPrefilter:
    """The NxPrefilter of a run from the parsed RA and bid data (not from the model). factors: milp_builder.MilpLimitFactors."""
    from data_model import RAKind
    from milp.milp_builder import _ct_ra_mrids, _participation_of_bid
    from pre_milp import ct_sensitivity

    curative_cap: dict[str, float] = {}
    for (pst_mrid, _xne, _co), entry in (pst_cra_availability or {}).items():
        cap = entry.get("max_curative_taps")
        curative_cap[str(pst_mrid)] = max(curative_cap.get(str(pst_mrid), 0.0), float(cap) if cap is not None else 0.0)
    pst_taps: dict[str, float] = {}
    for pst in pst_list:
        mrid = str(pst.mrid)
        moves = pst_taps.get(mrid, 0.0)
        if pst.kind == RAKind.PREVENTIVE:
            bounds = (pst_tap_bounds or {}).get(mrid)
            if bounds is None:
                moves = math.inf
            else:
                low, high, start = int(bounds[0]), int(bounds[1]), int(getattr(pst, "r0", 0))
                moves += float(max(high - low, high - start, start - low, 0))
        pst_taps[mrid] = moves
    for mrid, cap in curative_cap.items():
        pst_taps[mrid] = pst_taps.get(mrid, 0.0) + cap

    unit_mw: dict[str, float] = {}
    ct_bids: dict[str, tuple[dict, float]] = {}
    if rd_inputs is not None:
        ct_ras = _ct_ra_mrids(rd_inputs)
        for bid in rd_inputs.bid_list:
            volume_mw = float(bid.available_mw.get(timestamp, 0.0))
            participation = _participation_of_bid(rd_inputs, bid)
            if str(bid.ra_mrid) in ct_ras:
                variable_id = ct_sensitivity.ct_variable_id(bid.ra_mrid, bid.direction)
                previous = ct_bids.get(variable_id)
                ct_bids[variable_id] = (participation, max(volume_mw, previous[1]) if previous else volume_mw)
                continue
            for unit, factor in participation.items():
                unit_mw[str(unit)] = unit_mw.get(str(unit), 0.0) + abs(float(factor)) * volume_mw

    hvdc_mw: dict[str, float] = {}
    hvdc_curative_eis: set = set()
    if hvdc_inputs is not None:
        for unit in hvdc_inputs.units:
            if unit.kind == RAKind.CURATIVE:
                hvdc_curative_eis.add(unit.ei_mrid)
                continue
            low, high = hvdc_inputs.limits[unit.mrid] if unit.mrid in hvdc_inputs.limits else (None, None)
            if low is None:
                hvdc_curative_eis.add(unit.ei_mrid)          # no known range: no bound, the rows of its EI are kept
                continue
            at = float(hvdc_inputs.original_p_mw.get(unit.ei_mrid, 0.0))
            hvdc_mw[unit.ei_mrid] = max(float(high) - float(low), float(high) - at, at - float(low), 0.0)
    return NxPrefilter(
        enabled, margin_ampere, min(factors.patl, factors.tatl), factors.scanned, pst_taps, pst_degrees_per_tap, unit_mw, ct_bids,
        hvdc_mw, hvdc_curative_eis,
    )


def pairs_with_skipped(model, kind: str) -> set:
    """The pairs of a kind that were evaluated: the ones with a row plus the ones skipped as never binding."""
    names = {
        "nx_patl": "nx_branch_contingency_pairs",
        "nx_tatl": "nx_tatl_branch_contingency_pairs",
        "nx_scanned": "nx_scanned_branch_contingency_pairs",
    }
    pairs = set(getattr(model, names[kind], ()))
    pairs |= getattr(model, "nx_skipped_pairs", {}).get(kind, set())
    return pairs


def log_filter_summary(considered: int, added: int, enabled: bool, margin_ampere: float) -> None:
    skipped = considered - added
    share = (100.0 * skipped / considered) if considered else 0.0
    log.info(
        "N-X constraint filter (%s, margin %.1f A): considered %d, added %d, skipped %d (%.1f%%) N-X rows that can never bind",
        "on" if enabled else "off", margin_ampere, considered, added, skipped, share,
    )
