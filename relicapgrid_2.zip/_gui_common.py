"""src/rao_pages/_gui_common.py

Shared helper module for the Closed RAO GUI's 3 pages (1_Main.py,
2_Load_Flow_Settings.py, 3_RAO_Settings.py). NOT a page itself — no
st.Page() reference to this file in app.py, and it deliberately has no
Streamlit UI calls of its own (st.write, st.button, etc.) — every
function here is plain Python, independently testable without a running
Streamlit session, matching this whole project's own established
"verify against real logic, not just trust the UI" discipline.

Rule: run_pipeline.py is NEVER
modified by the GUI. Every function below either prepares inputs for it (temp
directory, config files, uploaded zips) or reads its outputs (results
CSVs) — none of them import run_pipeline.py itself, since it is launched
as an isolated subprocess, not called in-process.

This module's own logging goes through the logger of the GUI pages (_logger.py), not a
separate mechanism — kept deliberately distinct from the PIPELINE
SUBPROCESS's own, independent logging system (src/rao/config/rao_config.yaml's
own debug_log_mode, output/run_log.txt), which is untouched by this file
and continues to work exactly as already built and verified.
"""

from __future__ import annotations

import importlib.util
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Iterator, Optional

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))          # the logger sits next to this file
from _logger import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Locating the pipeline source and the top-level repo root.
#
# THIRD CORRECTION to this section's own history, recorded plainly rather
# than silently overwritten — see the two corrections still recorded
# below for the full history of how this resolution logic got here.
#
# NOW: config/ has moved to src/rao/config/ (Option B — run_pipeline.py's own
# two hardcoded config paths were updated directly to match, an explicit,
# deliberate exception to that file's normal "never modified" rule,
# confirmed and approved before making this change). This actually
# SIMPLIFIES what was previously a real complication: config-reading no
# longer needs a separate ACTUAL_REPO_ROOT-based path distinct from
# SRC_ROOT — both the pipeline source and its config now live under the
# same src/ directory, alongside rao_pages/ itself. ACTUAL_REPO_ROOT
# still exists below, kept for the one thing that's still genuinely
# top-level and unrelated to the pipeline's own config:
# .rao_gui_settings.json (this GUI's own settings-persistence file).
#
# SECOND CORRECTION (kept for history): the first version assumed
# rao_pages/ was a sibling of src/rao/ under a shared src/. That was
# wrong at the time — app.py lived at the actual repo root, and
# st.Page() resolves relative to app.py's own directory (confirmed
# directly from Streamlit's own source: streamlit/navigation/page.py),
# so rao_pages/ had to be a repo-root-level sibling of app.py instead.
# That was fixed accordingly, then app.py itself later moved to
# src/app.py (alongside .streamlit/, static/ and rao_pages/, all moving
# together, confirmed consistent via the same Streamlit-source-level checks), making rao_pages/ genuinely a
# sibling of src/rao/ again — the ORIGINAL assumption, now actually
# correct for a different reason than before.
# ---------------------------------------------------------------------------
_THIS_FILE = Path(__file__).resolve()
RAO_PAGES_DIR = _THIS_FILE.parent          # .../src/rao_pages/
SRC_ROOT = RAO_PAGES_DIR.parent            # .../src/  (rao_pages/, rao/, and now config/ are siblings here)
PIPELINE_SRC_DIR = SRC_ROOT / "rao"        # .../src/rao/
ACTUAL_REPO_ROOT = SRC_ROOT.parent         # the real top-level repo root — where app.py, input/, output/, .rao_gui_settings.json live


def _pipeline_text_encoding() -> str:
    """TEXT_ENCODING of src/rao/text_encoding.py (the one encoding rule of the pipeline and its
    GUI: UTF-8 without BOM), loaded by file path because the GUI does not put src/rao on sys.path."""
    spec = importlib.util.spec_from_file_location("rao_text_encoding", PIPELINE_SRC_DIR / "text_encoding.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.TEXT_ENCODING


TEXT_ENCODING = _pipeline_text_encoding()


# ---------------------------------------------------------------------------
# Confirmed exact defaults — read directly from the real config files at
# import time, NOT hand-copied constants that could silently drift out of
# sync with the actual codebase. If src/rao/config/rao_config.default.yaml
# or src/rao/config/load_flow_config.yaml themselves change, these follow
# automatically without this file needing an edit.
#
# CORRECTED placement: config/ nests under src/rao/ specifically (not
# src/ directly) — matching run_pipeline.py's own updated
# RAO_CONFIG_PATH/LOAD_FLOW_CONFIG_PATH. Reads via PIPELINE_SRC_DIR
# (src/rao/), not SRC_ROOT (src/), since config/ is now a direct sibling
# of run_pipeline.py itself, one level deeper than the first version of
# this move placed it.
# ---------------------------------------------------------------------------

def _default_rao_config() -> dict:
    path = PIPELINE_SRC_DIR / "config" / "rao_config.default.yaml"
    if not path.exists():
        path = PIPELINE_SRC_DIR / "config" / "rao_config.yaml"
    with open(path, encoding=TEXT_ENCODING) as f:
        config = yaml.safe_load(f)
    # the correction factors of calculation_mode dc are edited in the config file only: a GUI run uses
    # the table of the active file (the user's entries), not the default file's
    active_path = PIPELINE_SRC_DIR / "config" / "rao_config.yaml"
    if active_path.exists():
        with open(active_path, encoding=TEXT_ENCODING) as f:
            active = yaml.safe_load(f) or {}
        if isinstance(active.get("dc_mode"), dict):
            config["dc_mode"] = active["dc_mode"]
    return config


def _default_load_flow_config() -> dict:
    path = PIPELINE_SRC_DIR / "config" / "load_flow_config.yaml"
    with open(path, encoding=TEXT_ENCODING) as f:
        return yaml.safe_load(f)


DEFAULT_RAO_CONFIG = _default_rao_config()
DEFAULT_LOAD_FLOW_CONFIG = _default_load_flow_config()

# Safety net against config drift — found directly from a real failure:
# a KeyError crash when the user's own on-disk config/rao_config.yaml
# predates a section this GUI code expects (logging_options, added
# alongside debug_log_mode). Rather than let a config file that's simply
# a few changes behind hard-crash the whole page, any top-level section
# missing from what was actually loaded off disk is filled in here from
# a hardcoded, known-correct minimal shape — the GUI stays usable, and a
# warning is logged so the real fix (updating the on-disk config file)
# doesn't go unnoticed.
_HARDCODED_SECTION_FALLBACKS = {
    "workflow_toggles": {
        "ra_types": ["pst", "rd"], "calculation_mode": "ac_iterative",
        "enable_nx_analysis": False, "pst_taping_discrete": True,
        "ra_limit_constraint_hard": True, "scanned_element_constraint_hard": True,
    },
    "thresholds": {
        "min_loading_threshold_pct": 0.0, "min_loading_threshold_pct_nx": 0.0,
        "sensitivity_threshold_pct_pst": 0.0, "sensitivity_threshold_pct_rd": 0.0,
        "sensitivity_threshold_pct_pst_nx": 0.0, "sensitivity_threshold_pct_rd_nx": 0.0,
        "max_change_ra_sum_threshold": 1.0, "max_change_ra": 1.0, "max_change_overload": 1.0,
        "milp_limit_factor_patl": 1.0, "milp_limit_factor_tatl": 1.0, "milp_limit_factor_scanned": 1.0,
    },
    "iteration_caps": {
        "max_linearisation_iterations": 10, "max_completeness_iterations": 5,
        "incremental_ac_fallback_max_steps": 5,
    },
    "ra_limits": {
        "max_ra_count_per_timestamp_tso": None,
        "ra_limit_penalty": 100.0, "max_taps_per_tso": 6,
    },
    "penalty_costs": {
        "penalty_reference_pst_pra": 100.0, "penalty_reference_rd_pra": 100.0,
        "penalty_reference_hvdc_pra": 100.0, "penalty_reference_hvdc_cra": 100.0,
        "penalty_reference_ct_pra": 100.0, "penalty_reference_ct_cra": 100.0,
        "penalty_cost_overload_n0": 10000.0, "penalty_cost_overload_nx_patl": 10000.0,
        "penalty_cost_overload_nx_tatl": 100000.0, "penalty_cost_overload_nx_scanned": 10000.0,
        "scanned_element_penalty_eur_per_a": 0.0,
    },
    "curative_ra": {"tatl_fallback_factor": 1.0},
    "logging_options": {"debug_log_mode": False},
    "dc_mode": {"current_factor_by_nominal_voltage_kv": {"default": 1.0}},
}
_missing_keys_found: list[str] = []
for _section, _fallback_values in _HARDCODED_SECTION_FALLBACKS.items():
    if _section not in DEFAULT_RAO_CONFIG:
        DEFAULT_RAO_CONFIG[_section] = dict(_fallback_values)
        _missing_keys_found.append(f"{_section} (entire section)")
        continue
    # Section exists but may itself be missing individual keys — found
    # directly from a real second failure: 'thresholds' was present, but
    # missing max_change_ra/max_change_overload specifically (added by
    # the R1.7 criteria 3/4 work). Whole-section-only checking missed
    # this entirely; merge key-by-key within every existing section too.
    for _key, _fallback_value in _fallback_values.items():
        if _key not in DEFAULT_RAO_CONFIG[_section]:
            DEFAULT_RAO_CONFIG[_section][_key] = _fallback_value
            _missing_keys_found.append(f"{_section}.{_key}")

if _missing_keys_found:
    logger.warning(
        "src/rao/config/rao_config.yaml on disk is missing %d key(s) the code "
        "expects: %s — the on-disk config file is behind the code and "
        "should be updated. Using hardcoded fallback values for these "
        "so the GUI stays usable in the meantime.",
        len(_missing_keys_found), ", ".join(_missing_keys_found),
    )

# Same class of protection, same reasoning, for load_flow_config.yaml —
# no confirmed real failure here yet, but the same drift risk applies
# equally, and closing it off now is cheap versus discovering it one
# missing key at a time the way rao_config.yaml's gaps were found.
_LOAD_FLOW_CONFIG_FALLBACKS = {
    "use_reactive_limits": False, "voltage_init_mode": "UNIFORM_VALUES",
    "transformer_voltage_control_on": False, "phase_shifter_regulation_on": False,
    "twt_split_shunt_admittance": False, "shunt_compensator_voltage_control_on": False,
    "read_slack_bus": True, "write_slack_bus": True, "distributed_slack": True,
    "balance_type": "PROPORTIONAL_TO_GENERATION_P_MAX", "component_mode": "MAIN_SYNCHRONOUS",
    "hvdc_ac_emulation": True, "dc_power_factor": 1.0,
}
_missing_lf_keys = [k for k in _LOAD_FLOW_CONFIG_FALLBACKS if k not in DEFAULT_LOAD_FLOW_CONFIG]
if _missing_lf_keys:
    logger.warning(
        "src/rao/config/load_flow_config.yaml on disk is missing %d key(s) the "
        "code expects: %s — using hardcoded fallback values so the GUI "
        "stays usable in the meantime.",
        len(_missing_lf_keys), ", ".join(_missing_lf_keys),
    )
    for _key in _missing_lf_keys:
        DEFAULT_LOAD_FLOW_CONFIG[_key] = _LOAD_FLOW_CONFIG_FALLBACKS[_key]

# Confirmed via pypowsybl directly (not guessed) — see this module's own
# development notes: pp.loadflow.VoltageInitMode, .BalanceType,
# .ComponentMode. ComponentMode is the RIGHT enum for the
# "component_mode" LoadFlowParameters field specifically — a genuinely
# different, easily-confused sibling enum, pp.loadflow.ConnectedComponentMode
# (values ALL / MAIN), exists too but is NOT what this field uses.
VOLTAGE_INIT_MODE_OPTIONS = ["DC_VALUES", "PREVIOUS_VALUES", "UNIFORM_VALUES"]
BALANCE_TYPE_OPTIONS = [
    "PROPORTIONAL_TO_CONFORM_LOAD",
    "PROPORTIONAL_TO_GENERATION_P",
    "PROPORTIONAL_TO_GENERATION_PARTICIPATION_FACTOR",
    "PROPORTIONAL_TO_GENERATION_P_MAX",
    "PROPORTIONAL_TO_GENERATION_REMAINING_MARGIN",
    "PROPORTIONAL_TO_LOAD",
]
COMPONENT_MODE_OPTIONS = ["ALL_CONNECTED", "MAIN_CONNECTED", "MAIN_SYNCHRONOUS"]

# ---------------------------------------------------------------------------
# Settings persistence — confirmed design: survives a full app restart,
# single local user, no concurrency concerns (Section 6).
# ---------------------------------------------------------------------------

SETTINGS_FILE_PATH = ACTUAL_REPO_ROOT / ".rao_gui_settings.json"


def migrate_saved_load_flow_config(saved_load_flow_config: dict) -> tuple[dict, list[str]]:
    """Settings saved while the Load Flow page still accepted dc_power_factor 0.0 (minimum 0.0) hold
    a value the page (minimum 0.01) and a calculation_mode dc run reject. A saved dc_power_factor
    that is not a number > 0 becomes the default 1.0. Returns (migrated settings, notes for the
    pages; empty when nothing changed)."""
    migrated = dict(saved_load_flow_config)
    if "dc_power_factor" not in migrated:
        return migrated, []
    value = migrated["dc_power_factor"]
    if not isinstance(value, bool) and isinstance(value, (int, float)) and value > 0:
        return migrated, []
    default = _LOAD_FLOW_CONFIG_FALLBACKS["dc_power_factor"]
    migrated["dc_power_factor"] = default
    return migrated, [
        f"The saved load flow setting dc_power_factor = {value!r} is not a number greater than 0; the "
        f"default {default} is used. Save the load flow settings to keep it."
    ]


# The calculation mode chosen on the Main page for the next run. Kept under a plain (non-widget)
# session-state key: Streamlit deletes the state of a widget that is not rendered in a run, so the
# selectbox's own key is gone on the RAO Settings page and after returning to Main.
CALCULATION_MODE_STATE_KEY = "selected_calculation_mode"
CALCULATION_MODE_OPTIONS = ["ac_iterative", "ac_single_pass", "dc"]
# the modes that run one pass: they ignore the iteration caps and the convergence thresholds
ONE_PASS_CALCULATION_MODES = ("ac_single_pass", "dc")


def ignores_loop_settings(calculation_mode: str) -> bool:
    """True for the one-pass modes (ac_single_pass, dc): the RAO Settings page greys out the iteration
    caps and the convergence thresholds."""
    return calculation_mode in ONE_PASS_CALCULATION_MODES


def selected_calculation_mode(session_state, workflow_toggles: dict) -> str:
    """The calculation mode of the next run: the one chosen on the Main page in this session,
    else the saved / default setting."""
    return session_state.get(CALCULATION_MODE_STATE_KEY, workflow_toggles["calculation_mode"])


def load_settings() -> dict:
    """Loads persisted settings from disk. Falls back to the codebase's
    own real defaults (read from the actual config files, not
    hand-copied) if the settings file is absent or unreadable — never
    raises for a missing/corrupt settings file, since that would block
    the GUI from starting at all over a recoverable condition.
    "notes": what a migration of the saved settings changed (each page shows them).
    """
    # the RAO config is src/rao/config/rao_config.yaml itself (the RAO Settings page edits that file); a key the file
    # lacks takes the documented default
    rao_config = {
        section: {**default_values, **((current_rao_config().get(section) or {}) if isinstance(default_values, dict) else {})}
        for section, default_values in DEFAULT_RAO_CONFIG.items()
    }
    defaults = {"rao_config": rao_config, "load_flow_config": DEFAULT_LOAD_FLOW_CONFIG, "notes": []}
    if not SETTINGS_FILE_PATH.exists():
        return defaults
    try:
        with open(SETTINGS_FILE_PATH, encoding=TEXT_ENCODING) as f:
            saved = json.load(f)
        merged = {"rao_config": rao_config, "load_flow_config": {}, "notes": []}
        saved_load_flow_config, merged["notes"] = migrate_saved_load_flow_config(saved.get("load_flow_config", {}))
        merged["load_flow_config"] = {**DEFAULT_LOAD_FLOW_CONFIG, **saved_load_flow_config}
        return merged
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Could not read settings file (%s) — using defaults: %s", SETTINGS_FILE_PATH, e)
        return defaults


def save_settings(load_flow_config: dict) -> None:
    """Saves the load flow settings of the GUI. The RAO config is not kept here: the RAO Settings page writes
    src/rao/config/rao_config.yaml itself (save_rao_config)."""
    payload = {"load_flow_config": load_flow_config}
    with open(SETTINGS_FILE_PATH, "w", encoding=TEXT_ENCODING) as f:
        json.dump(payload, f, indent=2)


# ---------------------------------------------------------------------------
# CGM upload validation (Section 2) — light, advisory structural check.
# pypowsybl's own loading remains the real authority; this only exists to
# turn a cryptic deep pypowsybl error into an early, readable one for the
# common case (empty zip, obviously wrong file type).
# ---------------------------------------------------------------------------

def validate_cgm_upload(zip_bytes: bytes) -> tuple[bool, list[str]]:
    """Returns (is_valid, messages). Advisory only — a pass here does not
    guarantee pypowsybl will accept the file; a failure here means
    something is obviously, cheaply wrong before even trying.
    """
    messages: list[str] = []
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            names = zf.namelist()
    except zipfile.BadZipFile:
        return False, ["Not a valid zip file."]

    if not names:
        return False, ["Zip file is empty."]

    eq_files = [n for n in names if re.search(r"_EQ_", n, re.IGNORECASE)]
    if not eq_files:
        messages.append(
            "No file matching the expected *_EQ_*.xml naming pattern was found. "
            "This may not be a valid CGM package — pypowsybl's own loading is the "
            "final authority, but this is worth checking before running."
        )
        return False, messages

    messages.append(f"{len(names)} file(s) found, including {len(eq_files)} EQ profile(s).")
    return True, messages


# ---------------------------------------------------------------------------
# NCP upload validation (Section 3) — CONFIRMED to reuse the pipeline's
# own real ncp_loader functions directly, NOT a separate re-implementation
# of the same rules. Found directly in ncp_loader.py's own docstring:
# classify_extracted_ncp_files's validation is explicitly "the same rules
# agreed for the equivalent GUI-facing design" — meaning the pipeline
# code already IS this validation; calling it directly here gives
# genuine, accurate "will this actually work" validation rather than a
# second implementation that could silently drift out of sync with the
# real one.
# ---------------------------------------------------------------------------

def validate_ncp_upload(zip_bytes: bytes) -> tuple[bool, list[str], Optional[dict]]:
    """Returns (is_valid, messages, ncp_files_or_None).

    Extracts to a scratch temp directory, runs the REAL
    ncp_loader.extract_ncp_zip / classify_extracted_ncp_files against it,
    and reports whatever those real functions find — including their own
    hard-error conditions (duplicate TSO+profile, missing required
    profile) surfaced as validation failures here, not just at Run time.
    """
    sys.path.insert(0, str(PIPELINE_SRC_DIR)) if str(PIPELINE_SRC_DIR) not in sys.path else None
    from pre_milp import ncp_loader, tso_name_resolver  # local import: only needed here

    messages: list[str] = []
    with tempfile.TemporaryDirectory(prefix="rao_gui_ncp_validate_") as scratch:
        scratch_path = Path(scratch)
        zip_path = scratch_path / "ncp_upload.zip"
        zip_path.write_bytes(zip_bytes)
        extract_dir = scratch_path / "_extracted_ncp"
        try:
            org_cd_path = ncp_loader.extract_ncp_zip(zip_path, extract_dir)
        except FileNotFoundError as e:
            return False, [str(e)], None
        except ValueError as e:
            return False, [f"Duplicate file basename in upload: {e}"], None

        try:
            tso_name_map = tso_name_resolver.build_tso_name_map(org_cd_path)
        except Exception as e:  # noqa: BLE001 — surfaced as a validation message either way
            return False, [f"Could not resolve TSO names from Organisation profile: {e}"], None

        try:
            ncp_files = ncp_loader.classify_extracted_ncp_files(extract_dir, tso_name_map)
        except ValueError as e:
            # Real hard-error conditions from the pipeline's own logic —
            # duplicate (TSO, profile) or a TSO missing a required
            # profile — surfaced exactly as the pipeline itself would
            # raise them.
            return False, [str(e)], None

        messages.append(f"{len(ncp_files)} TSO(s) recognized: {sorted(ncp_files.keys())}")
        for tso, profiles in sorted(ncp_files.items()):
            missing_optional = {"SHS", "SIS"} - profiles.keys()
            if missing_optional:
                messages.append(
                    f"{tso}: missing optional profile(s) {sorted(missing_optional)} — "
                    f"not an error, matches existing pipeline behaviour."
                )
        return True, messages, ncp_files


# ---------------------------------------------------------------------------
# Subprocess isolation (Section 1) — run_pipeline.py itself is NEVER
# modified. This builds a temp directory shaped exactly as REPO_ROOT
# resolution requires it (confirmed directly from run_pipeline.py's own
# _find_repo_root: walks UPWARD from wherever run_pipeline.py itself
# physically lives on disk until it finds src/rao/data_model.py — NOT
# based on cwd at all), copies the real pipeline source into it, writes
# the config files run_pipeline.py already reads unmodified from fixed,
# REPO_ROOT-relative paths, and launches it by its own absolute path.
# ---------------------------------------------------------------------------

def build_temp_run_dir(cgm_zip_bytes: bytes, ncp_zip_bytes: bytes, rao_config: dict, load_flow_config: dict) -> Path:
    """The temporary folder of a run: only the uploaded packages (input/) and the config of the run (config/, the two
    YAML files the pipeline reads, with the per-run choices of the page). The pipeline itself is the one in src/rao and
    writes into the output/ of the repository (run_pipeline_subprocess)."""
    tmpdir = Path(tempfile.mkdtemp(prefix="rao_gui_run_"))

    config_dir = tmpdir / "config"
    config_dir.mkdir(parents=True)
    with open(config_dir / "rao_config.yaml", "w", encoding=TEXT_ENCODING) as f:
        yaml.safe_dump(rao_config, f, default_flow_style=False, sort_keys=False)
    with open(config_dir / "load_flow_config.yaml", "w", encoding=TEXT_ENCODING) as f:
        yaml.safe_dump(load_flow_config, f, default_flow_style=False, sort_keys=False)

    # the pipeline matches the files by the PREFIX of the name ("cgm", "ncp"), see _find_unique_zip_by_prefix
    input_dir = tmpdir / "input"
    input_dir.mkdir(parents=True)
    (input_dir / "cgm_package.zip").write_bytes(cgm_zip_bytes)
    (input_dir / "ncp_upload.zip").write_bytes(ncp_zip_bytes)
    return tmpdir


def run_pipeline_subprocess(tmpdir: Path, output_base: Optional[Path] = None, pipeline_script: Optional[Path] = None) -> Iterator[str]:
    """Runs the pipeline (src/rao/run_pipeline.py of the repository) as a subprocess and yields its combined
    stdout/stderr, one line at a time, as it arrives, for the live log of the page. The run reads the inputs and the config
    of the temporary folder and writes output/<CGM time>/ into output_base (default: the output/ of the repository), the same
    folder a run from the command line writes; the locations are given by the environment variables RAO_INPUT_DIR,
    RAO_CONFIG_DIR and RAO_OUTPUT_DIR (see run_pipeline.py)."""
    script = PIPELINE_SRC_DIR / "run_pipeline.py" if pipeline_script is None else Path(pipeline_script)
    base = Path(OUTPUT_ROOT if output_base is None else output_base)
    base.mkdir(parents=True, exist_ok=True)
    # the pipeline's console output (stdout and the logging stream on stderr) is written and read
    # as TEXT_ENCODING: a pipe would otherwise use the locale codepage on both sides
    env = dict(
        os.environ, PYTHONIOENCODING=TEXT_ENCODING, RAO_INPUT_DIR=str(Path(tmpdir) / "input"),
        RAO_CONFIG_DIR=str(Path(tmpdir) / "config"), RAO_OUTPUT_DIR=str(base),
    )
    process = subprocess.Popen(
        [sys.executable, str(script)],
        cwd=str(tmpdir),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding=TEXT_ENCODING,
        bufsize=1,
        env=env,
    )
    assert process.stdout is not None
    for line in process.stdout:
        yield line.rstrip("\n")
    process.wait()
    yield f"__RAO_GUI_PROCESS_EXIT_CODE__:{process.returncode}"


def cleanup_temp_run_dir(tmpdir: Path) -> None:
    """Removes the temporary folder (the uploaded packages and the config of the run). The results are in the output/ of
    the repository and stay."""
    shutil.rmtree(tmpdir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Inventory reporting (Section 7) — Tier 1 ("Parsed") and Tier 2 ("Passed
# to MILP").
# ---------------------------------------------------------------------------

def compute_tier1_inventory(ncp_zip_bytes: bytes) -> dict:
    """Tier 1 — "Parsed", shown before Run.

    Returns raw, file-level counts: how many of each recognised CIM element type exist per TSO's XML
    files, by direct XML parsing, with no classification into PRA/CRA or SECURED/SCANNED and no CGM
    cross-reference. The classified counts of inventory_summary.print_inventory_summary() need the
    parsers (parse_assessed_elements, parse_psts, parse_rd_units), which require CGM-derived arguments
    (cgm_static_patl, cgm_tap_changers, cgm_generating_units), so they exist only after the expensive
    CGM load of the pipeline; computing them here would load the CGM a second time before Run or show
    numbers that differ from what the run uses.

    The raw counts answer "did the upload look structurally right"; they do not say how many
    PST/RD/bids the MILP will use (Tier 2 shows that, from the finished run's own output).
    """
    import xml.etree.ElementTree as ET

    sys.path.insert(0, str(PIPELINE_SRC_DIR)) if str(PIPELINE_SRC_DIR) not in sys.path else None
    from pre_milp import ncp_loader, tso_name_resolver

    with tempfile.TemporaryDirectory(prefix="rao_gui_tier1_") as scratch:
        scratch_path = Path(scratch)
        ncp_zip_path = scratch_path / "ncp.zip"
        ncp_zip_path.write_bytes(ncp_zip_bytes)
        extract_dir = scratch_path / "_extracted_ncp"
        org_cd_path = ncp_loader.extract_ncp_zip(ncp_zip_path, extract_dir)
        tso_name_map = tso_name_resolver.build_tso_name_map(org_cd_path)
        ncp_files = ncp_loader.classify_extracted_ncp_files(extract_dir, tso_name_map)

        per_tso: dict[str, dict] = {}
        for tso, profiles in sorted(ncp_files.items()):
            counts = {"profiles_present": sorted(profiles.keys())}
            ae_path = profiles.get("AE")
            if ae_path is not None:
                tree = ET.parse(ae_path)
                ns = {"cim": "http://iec.ch/TC57/2013/CIM-schema-cim16#"}
                # Tag-name count only (no ae_type classification, which
                # requires cross-referencing CO_flat_list — CGM-adjacent
                # data this function deliberately does not load).
                counts["assessed_element_tag_count"] = len(
                    tree.getroot().findall(".//cim:AssessedElement", ns)
                ) or len(tree.getroot().findall(".//{*}AssessedElement"))
            ra_path = profiles.get("RA")
            if ra_path is not None:
                tree = ET.parse(ra_path)
                counts["tap_position_action_tag_count"] = len(
                    tree.getroot().findall(".//{*}TapPositionAction")
                )
                counts["rotating_machine_action_tag_count"] = len(
                    tree.getroot().findall(".//{*}RotatingMachineAction")
                )
            sis_path = profiles.get("SIS")
            if sis_path is not None:
                tree = ET.parse(sis_path)
                counts["power_bid_schedule_tag_count"] = len(
                    tree.getroot().findall(".//{*}PowerBidSchedule")
                )
            per_tso[tso] = counts
        return per_tso


def read_tier2_inventory(run_folder: Path) -> dict:
    """Tier 2 — the real numbers after a completed run: the rows of the input files of the run folder (what the run used),
    read from the files themselves, not re-derived. A file that was not written (its feature was off) counts 0."""
    import csv

    def _count_rows(csv_path: Path) -> int:
        if not csv_path.exists():
            return 0
        with open(csv_path, newline="", encoding=TEXT_ENCODING) as f:
            return sum(1 for _ in csv.DictReader(f))

    return {
        "monitored_branches": _count_rows(run_folder / "assessed_elements.csv"),
        "contingencies": _count_rows(run_folder / "contingencies.csv"),
        "pst_ras": _count_rows(run_folder / "pst_ra.csv"),
        "rd_bids": _count_rows(run_folder / "rd_bids.csv"),
        "ct_bids": _count_rows(run_folder / "ct_bids.csv"),
        "hvdc_ras": _count_rows(run_folder / "hvdc_ra.csv"),
    }


# ---------------------------------------------------------------------------
# The output folder of the GUI and the run folder of a CGM time
# ---------------------------------------------------------------------------

OUTPUT_ROOT = ACTUAL_REPO_ROOT / "output"          # output/<CGM time>/ of the repository: where every run writes, from the GUI or the command line


# ---------------------------------------------------------------------------
# The RAO config file as the RAO Settings page shows it: every key of every section with its comment
# ---------------------------------------------------------------------------

RAO_CONFIG_PATH = PIPELINE_SRC_DIR / "config" / "rao_config.yaml"
_KEY_LINE = re.compile(r"^  ([A-Za-z_][A-Za-z0-9_]*):(?:[ \t]+(.*?))?[ \t]*$")
_SECTION_LINE = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*):[ \t]*$")


def current_rao_config(path: Path = None) -> dict:
    """The content of the RAO config file ({} when it cannot be read)."""
    path = RAO_CONFIG_PATH if path is None else Path(path)
    try:
        with open(path, encoding=TEXT_ENCODING) as f:
            return yaml.safe_load(f) or {}
    except (OSError, yaml.YAMLError):
        return {}


def config_fields(text: str) -> list[dict]:
    """Every key of the config text, section by section, in file order: {"section", "key", "value", "help"}. help is the
    comment lines directly above the key (without the '#'), joined by spaces. The values are those of the YAML."""
    values = yaml.safe_load(text) or {}
    fields: list[dict] = []
    section = None
    comment: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        section_match = _SECTION_LINE.match(line)
        if section_match:
            section, comment = section_match.group(1), []
            continue
        if stripped.startswith("#"):
            comment.append(stripped.lstrip("#").strip())
            continue
        key_match = _KEY_LINE.match(line)
        if key_match and section is not None:
            key = key_match.group(1)
            if isinstance(values.get(section), dict) and key in values[section]:
                fields.append({"section": section, "key": key, "value": values[section][key], "help": " ".join(c for c in comment if c)})
        comment = [] if not stripped.startswith("#") else comment
        if stripped == "" or key_match:
            comment = []
    return fields


def _yaml_value_text(value) -> str:
    """One value as it is written on a key line of the config file."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return repr(value)
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(_yaml_value_text(v) for v in value) + "]"
    return yaml.safe_dump(value, default_flow_style=True).replace("\n...", "").strip()


def update_config_text(text: str, changes: dict) -> str:
    """The config text with the values of changes {(section, key): value} replaced. Only the value on the key line changes:
    every comment, every other key and a comment at the end of the changed line stay as they are. A key that is not in
    the text raises KeyError."""
    newline = "\r\n" if "\r\n" in text else "\n"
    lines = text.split(newline)
    remaining = dict(changes)
    section = None
    for i, line in enumerate(lines):
        section_match = _SECTION_LINE.match(line)
        if section_match:
            section = section_match.group(1)
            continue
        key_match = _KEY_LINE.match(line)
        if key_match and (section, key_match.group(1)) in remaining:
            key = key_match.group(1)
            rest = line[len("  " + key + ":"):]
            tail_match = re.search(r"\s+#.*$", rest)
            tail = tail_match.group(0) if tail_match else ""
            lines[i] = f"  {key}: {_yaml_value_text(remaining.pop((section, key)))}{tail}"
    if remaining:
        raise KeyError(f"not in the config file: {sorted('.'.join(k) for k in remaining)}")
    return newline.join(lines)


def save_rao_config(changes: dict, path: Path = None) -> None:
    """Writes changes {(section, key): value} into the RAO config file, keeping its comments and every other key."""
    path = RAO_CONFIG_PATH if path is None else Path(path)
    with open(path, encoding=TEXT_ENCODING, newline="") as f:
        text = f.read()
    new_text = update_config_text(text, changes)
    with open(path, "w", encoding=TEXT_ENCODING, newline="") as f:
        f.write(new_text)


def validate_rao_config(config: dict, path: Path = None) -> list[str]:
    """The messages of the pipeline's own config check (run_pipeline.validate_config_ranges, the same function the run
    calls) for this config; empty when it passes. The pipeline module is loaded here, not re-implemented."""
    path = RAO_CONFIG_PATH if path is None else Path(path)
    sys.path.insert(0, str(PIPELINE_SRC_DIR)) if str(PIPELINE_SRC_DIR) not in sys.path else None
    import run_pipeline
    try:
        run_pipeline.validate_config_ranges(config, path)
    except (ValueError, KeyError) as error:
        return [str(error)]
    return []

