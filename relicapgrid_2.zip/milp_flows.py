"""milp_flows.py - the flow of the solved MILP for the loadings files.

The builder keeps, for every N-0 row (model.milp_flow_n0) and every N-X PATL or scanned row (model.milp_flow_nx), the
expression on the left side of the row: the current of the model plus the sensitivities times the changes of the remedial
actions (preventive and, for N-X, the curative ones of the contingency). The value of that expression in the solved model
is current_milp_a; loading_milp_pct is relative to the real limit_a of the row. A row without a MILP constraint (left out of
the model, or filtered as never binding) has no value (empty cell).
"""

import logging
from typing import Iterable, Optional

log = logging.getLogger(__name__)


def _value(expression) -> Optional[float]:
    """The value of a number or a Pyomo expression; None when a variable of it has no value (a model that was not solved)."""
    import pyomo.environ as pyo
    try:
        return float(pyo.value(expression))
    except (ValueError, TypeError):
        return None


def milp_current_n0(model, branch_id: str) -> Optional[float]:
    """The MILP current (A) of the N-0 row of a branch; None without a row."""
    expression = getattr(model, "milp_flow_n0", {}).get(branch_id)
    return None if expression is None else _value(expression)


def milp_current_nx(model, branch_id: str, contingency_id: str) -> Optional[float]:
    """The MILP current (A) of the N-X PATL or scanned row of a (branch, contingency) pair; None without a row."""
    expression = getattr(model, "milp_flow_nx", {}).get((branch_id, contingency_id))
    return None if expression is None else _value(expression)


def add_milp_currents(rows: Iterable[dict], model, kind: str = "n0", file_name: Optional[str] = None) -> tuple[int, int]:
    """Set current_milp_a and loading_milp_pct (against row["limit_a"]) on each row: kind "n0" rows have a branch_id, kind
    "nx" rows a branch_id and a contingency_id. A row without a MILP value gets None in both. Returns (rows with, rows without
    a value); with file_name one INFO line gives the two counts."""
    with_value = without_value = 0
    for row in rows:
        current = (
            milp_current_n0(model, row["branch_id"]) if kind == "n0"
            else milp_current_nx(model, row["branch_id"], row["contingency_id"])
        )
        limit_a = float(row["limit_a"])
        if current is None or limit_a <= 0.0:
            row["current_milp_a"] = row["loading_milp_pct"] = None
            without_value += 1
            continue
        row["current_milp_a"] = current
        row["loading_milp_pct"] = current / limit_a * 100.0
        with_value += 1
    if file_name is not None:
        log.info("%s: %d row(s) with a MILP value, %d without (no MILP constraint)", file_name, with_value, without_value)
    return with_value, without_value
