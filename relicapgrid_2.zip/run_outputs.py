"""run_outputs.py - the output files of a run (docs/specs/output_files_specs.md).

Every function builds the rows of one file from the data the pipeline already has and writes them; no value is
calculated here that the pipeline did not already have, only units change (kA -> A, A per degree -> A per tap) and
the rows follow the row rules of the spec. Columns: `tso` first, limits before the value, the unit last in a name.
What a file leaves out goes to the log (see pre_milp/parse_summaries.py and the callers).
"""

from __future__ import annotations

import csv
import logging
from pathlib import Path
from typing import Iterable, Optional

from data_model import (
    AEType, AssessedElement, BidDirection, Contingency, ContingencyType, PowerBid, RAKind, effective_linked_contingencies,
    select_by_side,
)
from pre_milp import ct_sensitivity
from text_encoding import TEXT_ENCODING

log = logging.getLogger(__name__)

# a change at or below these counts as "not used" (taps, MW, A)
ZERO_TAPS = 1e-6
ZERO_MW = 1e-9
ZERO_AMPERE = 1e-6

# file names (the registry lists them; see output_file_registry.py)
ASSESSED_ELEMENTS = "assessed_elements.csv"
CONTINGENCIES = "contingencies.csv"
GENERATING_UNITS = "generating_units.csv"
PST_RA = "pst_ra.csv"
HVDC_RA = "hvdc_ra.csv"
RD_BIDS = "rd_bids.csv"
CT_BIDS = "ct_bids.csv"
PST_RESULTS = "pst_results.csv"
RD_RESULTS = "rd_results.csv"
CT_RESULTS = "ct_results.csv"
HVDC_RESULTS = "hvdc_results.csv"
ZONE_NET_POSITIONS = "zone_net_positions.csv"
TSO_LIMITS = "tso_limits.csv"
SUMMARY = "summary.csv"
LOADINGS_N0 = "loadings_n0.csv"
LOADINGS_NX = "loadings_nx.csv"
ITERATIONS = "iterations.csv"
SENSITIVITY_FILES = {
    ("pst", "n0"): "sensitivity_pst_n0.csv", ("rd", "n0"): "sensitivity_rd_n0.csv", ("ct", "n0"): "sensitivity_ct_n0.csv",
    ("pst", "nx"): "sensitivity_pst_nx.csv", ("rd", "nx"): "sensitivity_rd_nx.csv", ("ct", "nx"): "sensitivity_ct_nx.csv",
}

HEADERS = {
    ASSESSED_ELEMENTS: [
        "tso", "branch_id", "branch_name", "branch_type", "side", "ae_type", "patl_a", "patl_source", "tatl_a",
        "tatl_duration_s", "tatl_source", "effective_limit_a",
    ],
    CONTINGENCIES: ["tso", "contingency_id", "contingency_name", "contingency_type", "equipment_ids", "equipment_types"],
    GENERATING_UNITS: [
        "tso", "unit_id", "unit_name", "zone_id", "p_min_mw", "p_max_mw", "p_mw", "on", "ct_participation_factor_up",
        "ct_participation_factor_down",
    ],
    PST_RA: [
        "tso", "ra_id", "ra_name", "kind", "pst_ids", "tap_min", "tap_max", "tap", "penalty_factor", "reaction_time_min",
        "contingency_ids",
    ],
    HVDC_RA: [
        "tso", "ra_id", "ra_name", "kind", "p_min_mw", "p_max_mw", "p_mw", "penalty_factor", "reaction_time_min",
        "contingency_ids",
    ],
    RD_BIDS: [
        "tso", "bid_id", "ra_id", "kind", "direction", "volume_max_mw", "price_eur_per_mw", "reservation_price_eur_per_mw",
        "lead_time_h", "unit_ids", "participation_factors", "penalty_factor", "reaction_time_min", "contingency_ids",
    ],
    CT_BIDS: [
        "tso", "bid_id", "ra_id", "zone_id", "kind", "direction", "volume_max_mw", "price_eur_per_mw",
        "reservation_price_eur_per_mw", "lead_time_h", "penalty_factor", "reaction_time_min", "contingency_ids",
    ],
    PST_RESULTS: ["tso", "ra_id", "pst_id", "contingency_id", "tap_before", "tap_change", "tap_after", "penalty_eur"],
    RD_RESULTS: ["tso", "bid_id", "ra_id", "contingency_id", "direction", "volume_mw", "cost_eur", "penalty_eur"],
    CT_RESULTS: ["tso", "bid_id", "ra_id", "zone_id", "contingency_id", "direction", "volume_mw", "cost_eur", "penalty_eur"],
    HVDC_RESULTS: ["tso", "ra_id", "contingency_id", "p_before_mw", "p_change_mw", "p_after_mw", "penalty_eur"],
    ZONE_NET_POSITIONS: ["tso", "zone_id", "rd_change_mw", "ct_change_mw", "net_change_mw"],
    TSO_LIMITS: ["tso", "tap_change_max", "tap_changes", "ra_count_max", "ra_count"],
    SUMMARY: ["metric", "value", "unit"],
    LOADINGS_N0: [
        "tso", "branch_id", "side", "limit_a", "current_initial_a", "current_milp_a", "current_after_pra_a",
        "loading_initial_pct", "loading_milp_pct", "loading_after_pra_pct",
    ],
    LOADINGS_NX: [
        "tso", "branch_id", "side", "contingency_id", "limit_a", "tatl_a", "current_initial_a", "current_milp_a",
        "current_after_pra_cra_a", "loading_initial_pct", "loading_milp_pct", "loading_after_pra_cra_pct",
    ],
    ITERATIONS: [
        "iteration", "objective_eur", "tap_change_sum", "rd_ct_change_sum_mw", "overload_a", "new_nx_constraints",
        "converged", "converged_by", "build_s", "solve_s", "ac_check_s",
    ],
    SENSITIVITY_FILES[("pst", "n0")]: ["tso", "branch_id", "side", "pst_id", "sensitivity_a_per_tap"],
    SENSITIVITY_FILES[("rd", "n0")]: ["tso", "branch_id", "side", "unit_id", "sensitivity_a_per_mw"],
    SENSITIVITY_FILES[("ct", "n0")]: ["tso", "branch_id", "side", "ra_id", "direction", "sensitivity_a_per_mw"],
    SENSITIVITY_FILES[("pst", "nx")]: ["tso", "branch_id", "side", "contingency_id", "pst_id", "sensitivity_a_per_tap"],
    SENSITIVITY_FILES[("rd", "nx")]: ["tso", "branch_id", "side", "contingency_id", "unit_id", "sensitivity_a_per_mw"],
    SENSITIVITY_FILES[("ct", "nx")]: [
        "tso", "branch_id", "side", "contingency_id", "ra_id", "direction", "sensitivity_a_per_mw",
    ],
}


# ---------------------------------------------------------------------------
# writing
# ---------------------------------------------------------------------------

def cell(value):
    """One csv cell: a flag is true / false, None is empty."""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    return value


def join_ids(values: Iterable) -> str:
    """A list in one cell: ';' separated."""
    return ";".join(str(v) for v in values)


def write_table(output_dir: Path, file_name: str, rows: Iterable[dict]) -> int:
    """Write file_name into output_dir with the header of HEADERS and the given rows (dicts by column); a missing key
    is an empty cell. Returns the number of rows."""
    header = HEADERS[file_name]
    path = Path(output_dir) / file_name
    path.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with open(path, "w", newline="", encoding=TEXT_ENCODING) as handle:
        writer = csv.writer(handle)
        writer.writerow(header)
        for row in rows:
            writer.writerow([cell(row.get(column)) for column in header])
            count += 1
    log.info("Written %s (%d rows)", file_name, count)
    return count


def _by_tso_then(*keys):
    return lambda row: tuple(str(row.get(key, "")) for key in ("tso", *keys))


# ---------------------------------------------------------------------------
# assessed elements
# ---------------------------------------------------------------------------

def branch_types(network) -> dict[str, str]:
    """{branch id: line, transformer, dangling_line or tie_line} of the network (a dangling line that is a half of a
    tie line is a tie_line)."""
    types: dict[str, str] = {}
    for method, name in (("get_lines", "line"), ("get_2_windings_transformers", "transformer")):
        try:
            for branch_id in getattr(network, method)().index:
                types[str(branch_id)] = name
        except Exception:                                   # a network without this kind of element
            continue
    boundary = getattr(network, "get_boundary_lines", None) or getattr(network, "get_dangling_lines", None)
    try:
        if boundary is not None:
            for branch_id in boundary().index:
                types[str(branch_id)] = "dangling_line"
    except Exception:
        pass
    try:
        tie_lines = network.get_tie_lines()
        for tie_id, row in tie_lines.iterrows():
            types[str(tie_id)] = "tie_line"
            for column in ("dangling_line1_id", "dangling_line2_id", "boundary_line1_id", "boundary_line2_id"):
                if column in tie_lines.columns and isinstance(row[column], str):
                    types[row[column]] = "tie_line"
    except Exception:
        pass
    return types


def monitored_branches(
    ae_flat_list: list[AssessedElement], timestamp: str, lf_initial: Optional[dict],
) -> dict[str, dict]:
    """{branch: record} of the branch sides the pipeline monitors: the SECURED and SCANNED elements with a PATL at the
    timestamp. The pipeline keeps one limit per branch, so when several elements point to the same branch the last one
    in the list decides side, type, TSO and PATL (the combination rule of assessed_elements.csv). record: element,
    side, ae_type, patl_a, limit_a (PATL, or for a scanned element max(PATL, flow before any RA) of its side),
    elements (how many elements point to the branch)."""
    records: dict[str, dict] = {}
    for ae in ae_flat_list:
        if ae.ae_type not in (AEType.SECURED, AEType.SCANNED) or not ae.branch_mrid:
            continue
        patl_ka = ae.patl_ka.get(timestamp)
        if patl_ka is None:
            continue
        branch = str(ae.branch_mrid)
        side = int(getattr(ae, "branch_side", 1))
        limit_ka = float(patl_ka)
        if ae.ae_type == AEType.SCANNED:
            sides = lf_initial.get(branch) if lf_initial else None
            current = select_by_side(sides, side, branch) if sides else None
            if current is not None:
                limit_ka = max(float(patl_ka), float(current) / 1000.0)
        previous = records.get(branch)
        records[branch] = {
            "element": ae, "side": side, "ae_type": ae.ae_type, "patl_a": float(patl_ka) * 1000.0,
            "limit_a": limit_ka * 1000.0, "elements": (previous["elements"] if previous else 0) + 1,
        }
    return records


def assessed_element_rows(
    records: dict[str, dict], tatl_data: Optional[dict], branch_names: dict, types: dict,
) -> list[dict]:
    """One row per monitored branch side. tatl_*: secured branches of an N-X run only (tatl_data is None otherwise);
    effective_limit_a: scanned elements only."""
    rows = []
    for branch, record in records.items():
        ae = record["element"]
        tatl = (tatl_data or {}).get(branch) if record["ae_type"] == AEType.SECURED else None
        rows.append({
            "tso": ae.tso, "branch_id": branch, "branch_name": branch_names.get(branch, ae.name),
            "branch_type": types.get(branch, ""), "side": record["side"], "ae_type": record["ae_type"].value,
            "patl_a": record["patl_a"], "patl_source": getattr(ae, "patl_source", "ncp"),
            "tatl_a": None if tatl is None else float(tatl["tatl_limit_ampere"]),
            "tatl_duration_s": None if tatl is None else tatl["tatl_duration_seconds"],
            "tatl_source": None if tatl is None else tatl.get("source"),
            "effective_limit_a": record["limit_a"] if record["ae_type"] == AEType.SCANNED else None,
        })
    return sorted(rows, key=_by_tso_then("branch_id"))


# ---------------------------------------------------------------------------
# contingencies
# ---------------------------------------------------------------------------

_CONTINGENCY_TYPE = {
    ContingencyType.ORDINARY: "ordinary", ContingencyType.EXCEPTIONAL: "exceptional",
    ContingencyType.OUT_OF_RANGE: "out_of_range",
}


def contingency_rows(
    co_flat_list: list[Contingency], timestamp: str, lf_nx: Optional[dict], invalid: Optional[dict],
) -> list[dict]:
    """The contingencies the run used: must-study at the timestamp, computed (in lf_nx) and with valid sensitivities.
    Without N-X (lf_nx None) no contingency is used."""
    if lf_nx is None:
        return []
    invalid = invalid or {}
    rows = [
        {
            "tso": co.tso, "contingency_id": co.mrid, "contingency_name": co.name,
            "contingency_type": _CONTINGENCY_TYPE.get(co.contingency_type, str(co.contingency_type)),
            "equipment_ids": join_ids(co.equipment_mrids), "equipment_types": join_ids(co.equipment_types),
        }
        for co in co_flat_list
        if co.must_study.get(timestamp, False) and co.mrid in lf_nx and co.mrid not in invalid
    ]
    return sorted(rows, key=_by_tso_then("contingency_id"))


# ---------------------------------------------------------------------------
# remedial action inputs
# ---------------------------------------------------------------------------

def _contingency_cell(obj, kind: RAKind, all_contingency_ids: list[str]) -> str:
    """Curative RAs only: the contingencies the RA acts in; empty = all."""
    if kind != RAKind.CURATIVE:
        return ""
    if obj.excluded_contingency_mrids:
        return join_ids(effective_linked_contingencies(obj.linked_contingency_mrids, obj.excluded_contingency_mrids, all_contingency_ids))
    return join_ids(obj.linked_contingency_mrids)


def _reaction_cell(obj, kind: RAKind):
    return obj.reaction_time_minutes if kind == RAKind.CURATIVE else None


def pst_ra_rows(
    pst_list: list, all_contingency_ids: list[str], curative_bounds: Optional[dict] = None, pst_names: Optional[dict] = None,
) -> list[dict]:
    """One row per PST RA usable in the run (available); the PSTs of a group are in one row, same order in every list.
    curative_bounds {pst: (min, max)}: the bounds of curative RAs (else the operating bounds). ra_name: the name of the RA
    in the RA profile (the parser keeps the RA's mRID as the name when the RA has none: then the name of the first PST,
    from pst_names, is used)."""
    groups: dict[tuple, list] = {}
    for pst in pst_list:
        if not pst.available:
            continue
        ra_id = pst.group_id or pst.ra_mrid or pst.mrid
        groups.setdefault((str(ra_id), pst.kind), []).append(pst)
    rows = []
    for (ra_id, kind), members in groups.items():
        members = sorted(members, key=lambda p: str(p.mrid))
        first = members[0]
        bounds = [
            (curative_bounds or {}).get(str(p.mrid), (p.operating_tap_min, p.operating_tap_max)) if kind == RAKind.CURATIVE
            else (p.operating_tap_min, p.operating_tap_max)
            for p in members
        ]
        rows.append({
            "tso": first.tso, "ra_id": ra_id,
            "ra_name": (pst_names or {}).get(str(first.mrid), first.name) if first.name in (first.ra_mrid, "") else first.name,
            "kind": kind.value, "pst_ids": join_ids(p.mrid for p in members),
            "tap_min": join_ids(b[0] for b in bounds), "tap_max": join_ids(b[1] for b in bounds),
            "tap": join_ids(int(p.r0) for p in members), "penalty_factor": float(first.penalty_factor),
            "reaction_time_min": _reaction_cell(first, kind), "contingency_ids": _contingency_cell(first, kind, all_contingency_ids),
        })
    return sorted(rows, key=_by_tso_then("ra_id", "kind"))


def hvdc_ra_rows(hvdc_inputs, all_contingency_ids: list[str]) -> list[dict]:
    """One row per HVDC RA usable in the run (hvdc_inputs.units): the operating range of the RA and the set point."""
    if hvdc_inputs is None:
        return []
    rows = []
    for unit in hvdc_inputs.units:
        low, high = hvdc_inputs.limits[unit.mrid]
        rows.append({
            "tso": unit.tso, "ra_id": unit.mrid, "ra_name": unit.name, "kind": unit.kind.value,
            "p_min_mw": float(low), "p_max_mw": float(high), "p_mw": float(hvdc_inputs.original_p_mw[unit.ei_mrid]),
            "penalty_factor": float(unit.penalty_factor), "reaction_time_min": _reaction_cell(unit, unit.kind),
            "contingency_ids": _contingency_cell(unit, unit.kind, all_contingency_ids),
        })
    return sorted(rows, key=_by_tso_then("ra_id"))


def usable_bid_ids(bid_list: list[PowerBid], rd_by_ra: dict, timestamp: str, lead_time_usable, participation_of) -> list[PowerBid]:
    """The bids of available RAs with a volume above 0 at the timestamp, a met lead time and at least one unit."""
    usable = []
    for bid in bid_list:
        ra = rd_by_ra.get(str(bid.ra_mrid))
        if ra is None or not ra.available:
            continue
        if float(bid.available_mw.get(timestamp, 0.0)) <= 0.0:
            continue
        if bid.lead_time_h > 0 and not lead_time_usable(float(bid.lead_time_h)):
            continue
        if not participation_of(bid):
            continue
        usable.append(bid)
    return usable


def _bid_common(bid: PowerBid, ra, timestamp: str, all_contingency_ids: list[str], reservation_price: float) -> dict:
    return {
        "tso": ra.tso, "bid_id": str(bid.mrid), "ra_id": str(bid.ra_mrid), "kind": ra.kind.value,
        "direction": bid.direction.value, "volume_max_mw": float(bid.available_mw.get(timestamp, 0.0)),
        "price_eur_per_mw": float(bid.price_eur_mw),
        "reservation_price_eur_per_mw": reservation_price if ra.kind == RAKind.CURATIVE else None,
        "lead_time_h": float(bid.lead_time_h), "penalty_factor": float(ra.penalty_factor),
        "reaction_time_min": _reaction_cell(ra, ra.kind), "contingency_ids": _contingency_cell(ra, ra.kind, all_contingency_ids),
    }


def rd_bid_rows(
    bids: list[PowerBid], rd_by_ra: dict, participation_of, timestamp: str, all_contingency_ids: list[str], reservation_of,
) -> list[dict]:
    """One row per usable redispatch bid; the units and their shares in the same order."""
    rows = []
    for bid in bids:
        participation = participation_of(bid)
        units = sorted(participation)
        row = _bid_common(bid, rd_by_ra[str(bid.ra_mrid)], timestamp, all_contingency_ids, reservation_of(bid))
        row.update(unit_ids=join_ids(units), participation_factors=join_ids(participation[u] for u in units))
        rows.append(row)
    return sorted(rows, key=_by_tso_then("bid_id"))


def ct_bid_rows(
    bids: list[PowerBid], ct_by_ra: dict, timestamp: str, all_contingency_ids: list[str], reservation_of,
) -> list[dict]:
    """One row per usable countertrade bid; the zone of its RA."""
    rows = []
    for bid in bids:
        ra = ct_by_ra[str(bid.ra_mrid)]
        row = _bid_common(bid, ra, timestamp, all_contingency_ids, reservation_of(bid))
        row["zone_id"] = ra.zone_mrid
        rows.append(row)
    return sorted(rows, key=_by_tso_then("bid_id"))


def generating_unit_rows(
    rd_unit_ids: dict[str, str], ct_units: list, generator_data: dict, zone_of_unit: Optional[dict] = None,
) -> list[dict]:
    """One row per generating unit usable by redispatch or countertrade. rd_unit_ids {unit: TSO} of the units in the
    shift keys of usable redispatch bids; ct_units: the RDUnit objects of the countertrade RAs (shares per
    direction in ct_weight_up / ct_weight_down; one up and one down share per unit and zone); zone_of_unit {unit: zone}.
    The set point, range and state come from the CGM (generator_data)."""
    rows: dict[str, dict] = {}
    for unit_id, tso in rd_unit_ids.items():
        rows[unit_id] = {"tso": tso, "unit_id": unit_id}
    for rd in ct_units:
        unit_id = str(rd.gu_mrid)
        row = rows.setdefault(unit_id, {"tso": rd.tso, "unit_id": unit_id})
        row["zone_id"] = (zone_of_unit or {}).get(unit_id) or None
        row["ct_participation_factor_up"] = float(rd.ct_weight_up)
        row["ct_participation_factor_down"] = float(rd.ct_weight_down)
    for unit_id, row in rows.items():
        data = generator_data.get(unit_id, {})
        row["unit_name"] = data.get("name", unit_id)
        row["p_min_mw"], row["p_max_mw"] = data.get("min_p"), data.get("max_p")
        target = data.get("target_p")
        row["p_mw"] = None if target is None else float(target)
        row["on"] = bool(data.get("connected", True)) and target is not None and float(target) > 0.0
    return sorted(rows.values(), key=_by_tso_then("unit_id"))


# ---------------------------------------------------------------------------
# results of the remedial actions (only the actions that were used)
# ---------------------------------------------------------------------------

def pst_result_rows(final_pst_results: dict, curative_delta_rows: list, pst_list: list) -> list[dict]:
    """One row per PST that moved: preventive (contingency_id empty) from the final PST results, curative per
    contingency from the curative delta rows. A curative move starts at the tap after the preventive moves."""
    ra_of_pst = {
        str(p.mrid): str(p.group_id or p.ra_mrid or p.mrid) for p in pst_list if p.kind == RAKind.PREVENTIVE
    }
    curative_ra_of_pst = {
        str(p.mrid): str(p.group_id or p.ra_mrid or p.mrid) for p in pst_list if p.kind == RAKind.CURATIVE
    }
    current_tap = {str(p.mrid): int(p.r0) for p in pst_list}
    rows = []
    tap_after_preventive: dict[str, float] = {}
    for pst_id, row in sorted(final_pst_results.items()):
        before = row.get("original_tap_position", row.get("current_tap_position"))
        tap_after_preventive[str(pst_id)] = row["result_tap_position"]
        if abs(float(row["tap_change_result"])) <= ZERO_TAPS:
            continue
        rows.append({
            "tso": row["tso"], "ra_id": ra_of_pst.get(str(pst_id), str(pst_id)), "pst_id": str(pst_id), "contingency_id": None,
            "tap_before": before, "tap_change": row["tap_change_result"], "tap_after": row["result_tap_position"],
            "penalty_eur": row["penalty_cost_eur"],
        })
    for row in curative_delta_rows:
        change = float(row["curative_delta_taps_net"])
        if abs(change) <= ZERO_TAPS:
            continue
        pst_id = str(row["pst_mrid"])
        before = tap_after_preventive.get(pst_id, current_tap.get(pst_id, 0))
        rows.append({
            "tso": row["tso"], "ra_id": curative_ra_of_pst.get(pst_id, pst_id), "pst_id": pst_id,
            "contingency_id": str(row["contingency_mrid"]), "tap_before": before, "tap_change": change,
            "tap_after": before + change, "penalty_eur": row["penalty_cost_eur"],
        })
    return sorted(rows, key=_by_tso_then("ra_id", "pst_id", "contingency_id"))


def _first_row_costs(key: str, cost: float, penalty: float, seen: set) -> tuple:
    """The cost and penalty of a curative bid or unit are one term of the objective (on its maximum over the
    contingencies): they are written once, on its first row."""
    if key in seen:
        return 0.0, 0.0
    seen.add(key)
    return cost, penalty


def rd_result_rows(rd_results: dict, curative_rd_rows: list, bid_by_id: dict) -> list[dict]:
    """One row per activated redispatch bid: preventive (contingency_id empty) and curative per contingency.
    Preventive cost_eur = price x volume, penalty_eur = penalty factor x reference x volume. Curative: reservation
    price x maximum volume and penalty per MW x maximum volume, on the first row of the bid."""
    rows = []
    for bid_id, row in sorted(rd_results.items()):
        volume = float(row["rd_volume_net_mw"])
        if abs(volume) <= ZERO_MW:
            continue
        bid = bid_by_id.get(str(bid_id))
        rows.append({
            "tso": row["tso"], "bid_id": str(bid_id), "ra_id": row["ra_mrid"], "contingency_id": None,
            "direction": bid.direction.value if bid is not None else ("up" if volume > 0 else "down"),
            "volume_mw": abs(volume), "cost_eur": float(row["price_eur_mw"]) * abs(volume), "penalty_eur": row["penalty_cost_eur"],
        })
    seen: set = set()
    for row in curative_rd_rows:
        if float(row["curative_volume_mw"]) <= ZERO_MW:
            continue
        maximum = float(row["max_curative_volume_mw"])
        cost, penalty = _first_row_costs(
            row["bid_mrid"], float(row["reservation_price_eur_mw"]) * maximum,
            float(row["penalty_cost_eur_per_mw"]) * maximum, seen,
        )
        rows.append({
            "tso": row["tso"], "bid_id": row["bid_mrid"], "ra_id": row["ra_mrid"], "contingency_id": row["contingency_mrid"],
            "direction": row["direction"], "volume_mw": float(row["curative_volume_mw"]), "cost_eur": cost, "penalty_eur": penalty,
        })
    return sorted(rows, key=_by_tso_then("bid_id", "contingency_id"))


def ct_result_rows(preventive_rows: list, curative_rows: list) -> list[dict]:
    """One row per activated countertrade bid: preventive cost_eur = price cost + activation cost; curative cost_eur =
    reservation cost, on the first row of the bid with its penalty."""
    rows = []
    for row in preventive_rows:
        if float(row["volume_mw"]) <= ZERO_MW:
            continue
        rows.append({
            "tso": row["tso"], "bid_id": row["bid_mrid"], "ra_id": row["ra_mrid"], "zone_id": row["zone_mrid"],
            "contingency_id": None, "direction": row["direction"], "volume_mw": row["volume_mw"],
            "cost_eur": float(row["price_cost_eur"]) + float(row["activation_cost_eur"]), "penalty_eur": row["penalty_cost_eur"],
        })
    seen: set = set()
    for row in curative_rows:
        if float(row["curative_volume_mw"]) <= ZERO_MW:
            continue
        cost, penalty = _first_row_costs(row["bid_mrid"], float(row["reservation_cost_eur"]), float(row["penalty_cost_eur"]), seen)
        rows.append({
            "tso": row["tso"], "bid_id": row["bid_mrid"], "ra_id": row["ra_mrid"], "zone_id": row["zone_mrid"],
            "contingency_id": row["contingency_mrid"], "direction": row["direction"],
            "volume_mw": row["curative_volume_mw"], "cost_eur": cost, "penalty_eur": penalty,
        })
    return sorted(rows, key=_by_tso_then("bid_id", "contingency_id"))


def hvdc_result_rows(preventive: dict, curative_rows: list) -> list[dict]:
    """One row per HVDC RA that moved: preventive (contingency_id empty) and curative per contingency; the curative
    penalty of a unit is on its first row."""
    rows = []
    for unit_id, row in sorted(preventive.items()):
        if abs(float(row["change_mw"])) <= ZERO_MW:
            continue
        rows.append({
            "tso": row["tso"], "ra_id": unit_id, "contingency_id": None, "p_before_mw": row["original_p_mw"],
            "p_change_mw": row["change_mw"], "p_after_mw": row["result_p_mw"], "penalty_eur": row["penalty_cost_eur"],
        })
    seen: set = set()
    for row in curative_rows:
        if abs(float(row["curative_change_mw"])) <= ZERO_MW:
            continue
        _cost, penalty = _first_row_costs(row["unit_mrid"], 0.0, float(row["penalty_cost_eur"]), seen)
        rows.append({
            "tso": row["tso"], "ra_id": row["unit_mrid"], "contingency_id": row["contingency_mrid"],
            "p_before_mw": row["p_after_preventive_mw"], "p_change_mw": row["curative_change_mw"],
            "p_after_mw": row["p_after_curative_mw"], "penalty_eur": penalty,
        })
    return sorted(rows, key=_by_tso_then("ra_id", "contingency_id"))


def net_position_rows(rows: list[dict]) -> list[dict]:
    """One row per zone: the change of the net injection from redispatch and from countertrade."""
    return sorted(
        ({
            "tso": row["tso"], "zone_id": row["zone_mrid"], "rd_change_mw": row["rd_change_mw"],
            "ct_change_mw": row["ct_change_mw"], "net_change_mw": row["total_change_mw"],
        } for row in rows),
        key=_by_tso_then("zone_id"),
    )


def tso_limit_rows(tap_rows: list[dict], ra_count_results: dict) -> list[dict]:
    """One row per TSO: its limits (empty when none) and what was used (taps, activated RAs)."""
    rows: dict[str, dict] = {}
    for row in tap_rows:
        rows.setdefault(row["tso"], {"tso": row["tso"]}).update(tap_change_max=row["max_taps_per_tso"], tap_changes=row["tap_total"])
    for tso, row in ra_count_results.items():
        rows.setdefault(tso, {"tso": tso}).update(ra_count_max=row["limit_per_timestamp"], ra_count=row["activated_ra_count"])
    return sorted(rows.values(), key=_by_tso_then())


# ---------------------------------------------------------------------------
# loadings
# ---------------------------------------------------------------------------

def loading_pct(current_a: float, limit_a: float) -> float:
    return float(current_a) / float(limit_a) * 100.0


def loadings_n0_rows(
    records: dict[str, dict], not_in_base_case: set, lf_initial: dict, lf_after: Optional[dict], min_loading_pct: float,
) -> list[dict]:
    """One row per branch side monitored in N-0 whose loading before any RA or after the preventive RAs is at least
    min_loading_pct of its limit. lf_after None: nothing was applied, the state after is the initial one."""
    rows = []
    for branch, record in records.items():
        if branch in not_in_base_case or record["limit_a"] <= 0.0:
            continue
        side = record["side"]
        initial = select_by_side(lf_initial.get(branch, {}), side, branch)
        if initial is None:
            continue
        after = select_by_side((lf_after or lf_initial).get(branch, {}), side, branch)
        after = initial if after is None else after
        initial_pct, after_pct = loading_pct(initial, record["limit_a"]), loading_pct(after, record["limit_a"])
        if max(initial_pct, after_pct) < float(min_loading_pct):
            continue
        rows.append({
            "tso": record["element"].tso, "branch_id": branch, "side": side, "limit_a": record["limit_a"],
            "current_initial_a": float(initial), "current_after_pra_a": float(after),
            "loading_initial_pct": initial_pct, "loading_after_pra_pct": after_pct,
        })
    return sorted(rows, key=_by_tso_then("branch_id"))


# ---------------------------------------------------------------------------
# summary and iterations
# ---------------------------------------------------------------------------

SUMMARY_UNITS = {
    "run_time_s": "s", "peak_memory_mb": "MB", "build_s": "s", "solve_s": "s",
    "pst_tap_changes": "tap", "rd_volume_up_mw": "MW", "rd_volume_down_mw": "MW", "ct_volume_up_mw": "MW",
    "ct_volume_down_mw": "MW", "hvdc_change_mw": "MW",
    "monitored_branches": "count", "contingencies": "count", "pst_ras": "count", "rd_bids": "count", "ct_bids": "count",
    "hvdc_ras": "count", "iterations": "count", "nx_constraints": "count",
}
SUMMARY_ORDER = [
    "cgm_time", "calculation_mode", "ra_types", "status", "run_time_s", "peak_memory_mb",
    "monitored_branches", "contingencies", "pst_ras", "rd_bids", "ct_bids", "hvdc_ras",
    "objective_eur", "rd_cost_eur", "rd_penalty_eur", "ct_cost_eur", "ct_penalty_eur", "pst_penalty_eur", "hvdc_penalty_eur",
    "overload_penalty_n0_eur", "overload_penalty_nx_eur", "overload_penalty_tatl_eur", "overload_penalty_scanned_eur",
    "activation_cost_eur", "startup_cost_eur", "shutdown_cost_eur", "ra_count_penalty_eur",
    "pst_tap_changes", "rd_volume_up_mw", "rd_volume_down_mw", "ct_volume_up_mw", "ct_volume_down_mw", "hvdc_change_mw",
    "overloaded_branches_n0", "overload_n0_a", "overloaded_xnecs_nx", "overloaded_branches_nx", "overload_nx_a",
    "overloaded_xnecs_tatl", "overloaded_branches_tatl", "overload_tatl_a",
    "overloaded_xnecs_scanned", "overloaded_branches_scanned", "overload_scanned_a",
    "iterations", "converged_by", "nx_constraints", "build_s", "solve_s",
]


def summary_unit(metric: str) -> str:
    if metric in SUMMARY_UNITS:
        return SUMMARY_UNITS[metric]
    if metric.endswith("_eur"):
        return "EUR"
    if metric.endswith("_a"):
        return "A"
    if metric.startswith(("overloaded_",)):
        return "count"
    return ""


def summary_rows(values: dict) -> list[dict]:
    """The metrics of SUMMARY_ORDER that have a value (None = not applicable to this run), in that order."""
    unknown = set(values) - set(SUMMARY_ORDER)
    if unknown:
        raise ValueError(f"summary metrics without a place in SUMMARY_ORDER: {sorted(unknown)}")
    return [
        {"metric": name, "value": values[name], "unit": summary_unit(name)}
        for name in SUMMARY_ORDER if values.get(name) is not None
    ]


def overload_metrics(loadings_n0: list[dict], nx_pairs: list[dict]) -> dict:
    """The final check from the loadings after the RAs: branch sides over their limit in N-0, and (branch,
    contingency) pairs over theirs in N-X, split into secured and scanned elements. Each overload is in A.
    loadings_n0: all monitored N-0 rows (before the threshold); nx_pairs: dicts with branch_id, contingency_id,
    limit_a, current_after_pra_cra_a and scanned (bool)."""
    values: dict = {}
    over_n0 = [row["current_after_pra_a"] - row["limit_a"] for row in loadings_n0 if row["current_after_pra_a"] - row["limit_a"] > ZERO_AMPERE]
    values["overloaded_branches_n0"] = len(over_n0)
    values["overload_n0_a"] = sum(over_n0)
    # TATL: the AC state after the preventive RAs (the curative RAs act after the TATL, as in the final check of the
    # single pass) against the TATL of the secured branches that have one
    over_tatl = [
        (pair["branch_id"], pair["current_after_pra_a"] - pair["tatl_a"]) for pair in nx_pairs
        if not pair["scanned"] and pair["tatl_a"] is not None and pair["current_after_pra_a"] - pair["tatl_a"] > ZERO_AMPERE
    ]
    values["overloaded_xnecs_tatl"] = len(over_tatl)
    values["overloaded_branches_tatl"] = len({branch for branch, _ in over_tatl})
    values["overload_tatl_a"] = sum(amount for _, amount in over_tatl)
    for scanned, suffix in ((False, "nx"), (True, "scanned")):
        over = [
            (pair["branch_id"], pair["current_after_pra_cra_a"] - pair["limit_a"]) for pair in nx_pairs
            if bool(pair["scanned"]) == scanned and pair["current_after_pra_cra_a"] - pair["limit_a"] > ZERO_AMPERE
        ]
        values[f"overloaded_xnecs_{suffix}"] = len(over)
        values[f"overloaded_branches_{suffix}"] = len({branch for branch, _ in over})
        values[f"overload_{suffix}_a"] = sum(amount for _, amount in over)
    return values


def iteration_rows(solve_history: list[dict]) -> list[dict]:
    """One row per solve of the nested loop (ac_iterative)."""
    rows = []
    for record in solve_history:
        rows.append({
            "iteration": record.get("solve_index"), "objective_eur": record.get("objective_value"),
            "tap_change_sum": record.get("sum_abs_tap_change"), "rd_ct_change_sum_mw": record.get("sum_abs_rd_change_mw"),
            "overload_a": record.get("total_overload"), "new_nx_constraints": record.get("new_constraints_added"),
            "converged": record.get("converged"), "converged_by": record.get("converged_by") or None,
            "build_s": record.get("seconds_build"),
            "solve_s": (
                None if record.get("seconds_build_and_solve") is None
                else float(record["seconds_build_and_solve"]) - float(record.get("seconds_build") or 0.0)
            ),
            "ac_check_s": record.get("seconds_load_flow"),
        })
    return rows


# ---------------------------------------------------------------------------
# sensitivities (optional, off by default)
# ---------------------------------------------------------------------------

def split_variable(variable_id: str) -> Optional[tuple[str, str]]:
    """(RA id, direction) of a countertrade variable 'CT|<RA>|<direction>', None for a unit."""
    if not variable_id.startswith(ct_sensitivity.CT_VARIABLE_PREFIX):
        return None
    _, ra_id, direction = variable_id.split("|", 2)
    return ra_id, direction


def sensitivity_n0_rows(
    kind: str, matrix: dict, branch_sides: dict, branch_tso: dict,
) -> list[dict]:
    """Rows of sensitivity_<kind>_n0.csv from {(branch, variable): A per tap or A per MW}. kind: pst, rd (the unit
    entries) or ct (the countertrade entries, one per RA and direction)."""
    rows = []
    for (branch, variable), value in sorted(matrix.items()):
        base = {"tso": branch_tso.get(branch, ""), "branch_id": branch, "side": branch_sides.get(branch, 1)}
        ct = split_variable(str(variable))
        if kind == "pst":
            rows.append({**base, "pst_id": variable, "sensitivity_a_per_tap": value})
        elif kind == "rd" and ct is None:
            rows.append({**base, "unit_id": variable, "sensitivity_a_per_mw": value})
        elif kind == "ct" and ct is not None:
            rows.append({**base, "ra_id": ct[0], "direction": ct[1], "sensitivity_a_per_mw": value})
    return rows
