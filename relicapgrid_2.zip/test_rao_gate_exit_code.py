"""The gate script fails (non-zero) when any one of its stages fails, not only the last one."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "tools" / "golden"))
import run_gate


def _stage(code):
    return ["-c", f"raise SystemExit({code})"]


def test_rao_gate_reports_a_failing_stage_that_is_not_the_last(tmp_path):
    report = tmp_path / "gate.txt"
    failed = run_gate.run_stages([("first", _stage(0)), ("broken", _stage(3)), ("last", _stage(0))], report)
    assert failed == ["broken"]
    text = report.read_text(encoding="utf-8")
    assert "STAGE FAILED (3): broken" in text and "GATE FAILED: broken" in text and text.endswith("GATE DONE\n")


def test_rao_gate_passes_when_all_stages_pass(tmp_path):
    report = tmp_path / "gate.txt"
    assert run_gate.run_stages([("a", _stage(0)), ("b", _stage(0))], report) == []
    assert "GATE PASSED" in report.read_text(encoding="utf-8")


def test_rao_gate_main_exit_code_is_non_zero_for_a_failed_stage(tmp_path, monkeypatch):
    monkeypatch.setattr(run_gate, "run_stages", lambda stages, report, env=None, cwd=None: ["suite"])
    assert run_gate.main([str(tmp_path), "t", "none", str(tmp_path)]) == 1
    monkeypatch.setattr(run_gate, "run_stages", lambda stages, report, env=None, cwd=None: [])
    assert run_gate.main([str(tmp_path), "t", "none", str(tmp_path)]) == 0
