﻿"""The gate: python tests/tools/golden/run_gate.py OUTDIR TAG SECTIONS [BASELINE_DIR ...]

1. the test suite in parallel by file (run_suite.py, 4 workers)
2. the 52-run golden matrix (run_matrix.py, 5 workers) into OUTDIR/mx_TAG
3. the matrix against each BASELINE_DIR (compare_runs.py); without a BASELINE_DIR the stored golden/baseline.zip is
   extracted to OUTDIR/baseline and used
4. the MILP fingerprints of the mock converted with SECTIONS ('none' = the shipped mock as it is)
5. the link check of the documentation (tests/tools/check_doc_links.py: 0 dead links in live files; history files and a small
   whitelist are exempt)
The report is written to OUTDIR/gate_TAG.txt (it ends with GATE DONE). Every stage is run; the exit code is 1 when any
stage exited with a non-zero code (the report then ends with GATE FAILED: the failed stages), otherwise 0."""
import subprocess, sys, os, pathlib, zipfile
here = pathlib.Path(__file__).resolve().parent
repo = here.parents[2]


def run_stages(stages, report_path, env=None, cwd=None):
    """Run each (label, argument list) with this interpreter, write the report and return the labels of the failed stages."""
    failed = []
    with open(report_path, "w", encoding="utf-8") as out:
        for label, args in stages:
            p = subprocess.run([sys.executable] + list(args), capture_output=True, text=True, encoding="utf-8",
                               errors="replace", env=env, cwd=cwd)
            out.write(f"=== {label}\n{p.stdout}\n{p.stderr[-1500:] if p.returncode else ''}\n")
            if p.returncode:
                failed.append(label)
                out.write(f"STAGE FAILED ({p.returncode}): {label}\n")
            out.flush()
        out.write("GATE FAILED: " + "; ".join(failed) + "\n" if failed else "GATE PASSED\n")
        out.write("GATE DONE\n")
    return failed


def main(argv):
    out_dir = pathlib.Path(argv[0]); tag = argv[1]; sections = argv[2]
    baselines = [pathlib.Path(p) for p in argv[3:]]
    out_dir.mkdir(parents=True, exist_ok=True)
    if not baselines:
        target = out_dir / "baseline"
        if not target.exists():
            with zipfile.ZipFile(here / "baseline.zip") as zf:
                zf.extractall(target)
        baselines = [target]
    stages = [("suite", [str(here / "run_suite.py"), str(out_dir / f"suite_{tag}"), "4"]),
              ("matrix runs", [str(here / "run_matrix.py"), str(out_dir / f"mx_{tag}"), "5"])]
    for number, baseline in enumerate(baselines, 1):
        stages.append((f"matrix vs baseline {number} ({baseline.name})",
                       [str(here / "compare_runs.py"), str(baseline), str(out_dir / f"mx_{tag}")]))
    stages.append((f"fingerprints {sections}", [str(here / "fp_check.py"), sections]))
    stages.append(("link check", [str(repo / "tests" / "tools" / "check_doc_links.py"), "--live-only"]))
    failed = run_stages(stages, out_dir / f"gate_{tag}.txt", env=dict(os.environ, PYTHONHASHSEED="0"), cwd=repo)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
