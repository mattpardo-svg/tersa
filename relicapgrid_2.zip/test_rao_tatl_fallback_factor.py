"""tests/test_rao_tatl_fallback_factor.py - curative_ra.tatl_fallback_factor: a branch side without a TATL in the CGM gets
TATL = PATL x factor (>= 1), with the duration tatl_fallback_duration_s; the other TATL rules stay as they are."""

import logging
from pathlib import Path

import pytest

from helpers import _make_ae_nx_filters as _ae, _make_pst_nx_filters as _pst
from milp import milp_builder
from milp.milp_builder import NxMilpInputs, PstMilpInputs, build_n0_milp_model
from pre_milp.nx_security_analysis import compute_tatl_data
from test_rao_nx_security_analysis import DummyNetworkForOperationalLimits, _make_ae, _make_operational_limits_df


def _limits(*rows):
    return DummyNetworkForOperationalLimits(_make_operational_limits_df(list(rows)))


def _permanent(branch, value=1000.0):
    return dict(element_id=branch, side="ONE", type="CURRENT", acceptable_duration=-1, group_name="g1",
                element_type="LINE", name="permanent_limit", value=value)


def _temporary(branch, value, duration=1200):
    return dict(element_id=branch, side="ONE", type="CURRENT", acceptable_duration=duration, group_name="g1",
                element_type="LINE", name="tatl", value=value)


def test_a_side_without_a_tatl_gets_patl_times_the_factor_with_the_fallback_duration():
    network = _limits(_permanent("b1"))
    result = compute_tatl_data(network, [_make_ae("ae-1", "b1", branch_side=1, patl_ka=1.2)], "1030Z",
                               fallback_duration_seconds=900, fallback_factor=1.25)
    assert result == {"b1": {"tatl_limit_ampere": pytest.approx(1500.0), "tatl_duration_seconds": 900, "side": 1,
                             "was_corrected": False, "source": "fallback_patl"}}


def test_the_default_factor_is_one_and_gives_tatl_equal_to_patl():
    network = _limits(_permanent("b1"))
    ae = [_make_ae("ae-1", "b1", branch_side=1, patl_ka=1.574)]
    assert compute_tatl_data(network, ae, "1030Z")["b1"]["tatl_limit_ampere"] == 1574.0
    assert compute_tatl_data(network, ae, "1030Z", fallback_factor=1.0)["b1"]["tatl_limit_ampere"] == 1574.0


def test_the_other_tatl_rules_do_not_use_the_factor():
    network = _limits(_permanent("b1"), _temporary("b2", 1500.0, 600), _temporary("b3", 500.0, 600),
                      _temporary("b4", 1100.0, 300), _temporary("b4", 1300.0, 900))
    aes = [_make_ae(f"ae-{i}", f"b{i}", branch_side=1, patl_ka=1.0) for i in (1, 2, 3, 4)]
    result = compute_tatl_data(network, aes, "1030Z", fallback_factor=2.0)
    assert result["b1"]["tatl_limit_ampere"] == pytest.approx(2000.0)               # no TATL: PATL x factor
    assert result["b2"]["tatl_limit_ampere"] == 1500.0 and result["b2"]["source"] == "cgm"
    assert result["b3"]["tatl_limit_ampere"] == 1000.0 and result["b3"]["was_corrected"]      # below the PATL: raised to it
    assert result["b4"]["tatl_limit_ampere"] == 1300.0 and result["b4"]["tatl_duration_seconds"] == 900   # the longest


def test_a_branch_without_a_patl_still_has_no_entry():
    network = _limits(_permanent("b1"))
    ae = _make_ae("ae-1", "b1", branch_side=1, patl_ka=1.0)
    ae.patl_ka = {}
    assert compute_tatl_data(network, [ae], "1030Z", fallback_factor=1.5) == {}


def test_one_line_counts_the_branch_sides_with_a_fallback_tatl(caplog):
    network = _limits(_permanent("b1"), _permanent("b2"), _temporary("b3", 1500.0))
    aes = [_make_ae(f"ae-{i}", f"b{i}", branch_side=1, patl_ka=1.0) for i in (1, 2, 3)]
    with caplog.at_level(logging.INFO, logger="pre_milp.nx_security_analysis"):
        compute_tatl_data(network, aes, "1030Z", fallback_duration_seconds=600, fallback_factor=1.5)
    lines = [r.getMessage() for r in caplog.records if "fallback TATL" in r.getMessage()]
    assert len(lines) == 1
    assert "2 branch side(s)" in lines[0] and "PATL x 1.5" in lines[0] and "600 s" in lines[0]


def _model(tatl_limit, i_nx=1100.0):
    pst_inputs = PstMilpInputs(
        pst_list=[_pst("PST1")], pst_tap_bounds={"PST1": (-10, 10)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={}, pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: i_nx}}}, sensitivity_pst_nx={"CO1": {("B1", "PST1"): 0.0}}, sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=10_000.0, penalty_cost_overload_nx_tatl=10_000.0,
        tatl_data={"B1": {"tatl_limit_ampere": tatl_limit, "tatl_duration_seconds": 600, "side": 1,
                          "was_corrected": False, "source": "fallback_patl"}},
    )
    return build_n0_milp_model([_ae("a1", "B1")], "1030Z", {"B1": {1: 500.0}}, 1000.0, pst_inputs=pst_inputs,
                              nx_inputs=nx_inputs)


def test_a_fallback_tatl_above_the_patl_gets_a_tatl_constraint_and_one_equal_to_it_none():
    assert list(_model(1000.0).nx_tatl_branch_contingency_pairs) == []          # factor 1.0: TATL = PATL, no constraint
    assert list(_model(1250.0).nx_tatl_branch_contingency_pairs) == [("B1", "CO1")]   # factor 1.25


def test_the_log_gives_the_number_of_tatl_constraints_added(caplog):
    milp_builder.reset_run_log_state()
    with caplog.at_level(logging.INFO, logger="milp.milp_builder"):
        _model(1250.0)
    lines = [r.getMessage() for r in caplog.records if "TATL constraint" in r.getMessage()]
    assert any("1 TATL constraint(s) added" in line for line in lines)
    milp_builder.reset_run_log_state()
    caplog.clear()
    with caplog.at_level(logging.INFO, logger="milp.milp_builder"):
        _model(1000.0)
    assert any("0 TATL constraint(s) added" in r.getMessage() for r in caplog.records)


def _config(name="rao_config.yaml"):
    import yaml
    import run_pipeline
    return yaml.safe_load((Path(run_pipeline.__file__).parent / "config" / name).read_text(encoding="utf-8"))


@pytest.mark.parametrize("name", ["rao_config.yaml", "rao_config.default.yaml"])
def test_both_config_files_have_the_factor_at_one(name):
    assert _config(name)["curative_ra"]["tatl_fallback_factor"] == 1.0


@pytest.mark.parametrize("value", [0.99, 0, -1, "1.2", True, None])
def test_the_config_check_refuses_a_factor_below_one_or_not_a_number(value):
    import run_pipeline
    config = _config()
    config["curative_ra"]["tatl_fallback_factor"] = value
    with pytest.raises(ValueError, match="curative_ra.tatl_fallback_factor"):
        run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))
    for fine in (1, 1.0, 1.3, 2):
        config["curative_ra"]["tatl_fallback_factor"] = fine
        run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))


def test_the_pipeline_passes_the_factor_to_the_tatl_data():
    import inspect
    import run_pipeline
    assert run_pipeline.TATL_FALLBACK_FACTOR == 1.0
    assert "fallback_factor=TATL_FALLBACK_FACTOR" in inspect.getsource(run_pipeline)
