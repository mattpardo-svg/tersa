"""tests/test_rao_milp_limit_factor.py - milp_limit_factor_{patl,tatl,scanned}: the MILP constraints use limit x factor,
the N-X constraint filter uses the same reduced limit, everything else keeps the real limit."""

import logging
from pathlib import Path

import pyomo.environ as pyo
import pytest

from data_model import AEType
from helpers import _make_ae_nx_filters as _ae, _make_pst_nx_filters as _pst
from milp import milp_builder
from milp.milp_builder import MilpLimitFactors, NxMilpInputs, PstMilpInputs, build_n0_milp_model

TS = "1030Z"
NO_RA = {"PST1": 0.0}


def _pst_inputs():
    return PstMilpInputs(
        pst_list=[_pst("PST1")], pst_tap_bounds={"PST1": (-10, 10)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={}, pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=10.0,
    )


def _build(factors=None, n0=900.0, nx=900.0, tatl=None, scanned_n0=None, scanned_nx=None, enabled=False, margin=1.0,
           sens=0.0, hard=False, with_nx=True):
    """B1 secured (PATL 1000 A), B3 scanned (PATL 1000 A); no remedial action acts on them (sensitivity `sens`)."""
    branches = [_ae("a1", "B1")]
    lf_initial = {"B1": {1: n0}}
    lf_nx = {"CO1": {"B1": {1: nx}}}
    if scanned_n0 is not None:
        branches.append(_ae("a3", "B3", ae_type=AEType.SCANNED))
        lf_initial["B3"] = {1: scanned_n0}
        lf_nx["CO1"]["B3"] = {1: scanned_nx}
    sensitivities = {("B1", "PST1"): sens, ("B3", "PST1"): sens}
    nx_inputs = NxMilpInputs(
        lf_nx=lf_nx, sensitivity_pst_nx={"CO1": sensitivities}, sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=10_000.0, penalty_cost_overload_nx_scanned=10_000.0,
        penalty_cost_overload_nx_tatl=10_000.0,
        tatl_data=({"B1": {"tatl_limit_ampere": tatl, "tatl_duration_seconds": 1200, "side": 1, "was_corrected": False}}
                   if tatl else None),
        constraint_filter_enabled=enabled, constraint_filter_margin_ampere=margin,
    ) if with_nx else None
    pst_inputs = PstMilpInputs(
        pst_list=[_pst("PST1")], pst_tap_bounds={"PST1": (-10, 10)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("B1", "PST1"): sens, ("B3", "PST1"): sens}, pst_degrees_per_tap={"PST1": 1.0},
        penalty_reference_pst_pra=10.0,
    )
    extra = {} if factors is None else {"milp_limit_factors": factors}
    return build_n0_milp_model(
        branches, TS, lf_initial, 1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
        scanned_element_constraint_hard=hard, scanned_element_penalty_eur_per_a=1000.0, **extra,
    )


def _solve(model):
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model


def test_the_default_factors_leave_every_limit_as_it_is():
    default, explicit = _solve(_build(nx=1100.0, tatl=1200.0)), _solve(_build(MilpLimitFactors(), nx=1100.0, tatl=1200.0))
    assert pyo.value(default.nx_patl_overload_slack["B1", "CO1"]) == pytest.approx(100.0)
    assert pyo.value(default.objective) == pytest.approx(pyo.value(explicit.objective))
    assert MilpLimitFactors() == MilpLimitFactors(patl=1.0, tatl=1.0, scanned=1.0)


def test_the_patl_factor_reduces_the_n0_patl_limit():
    # 900 A against 1000 A x 0.8 = 800 A
    model = _solve(_build(MilpLimitFactors(patl=0.8), with_nx=False))
    assert pyo.value(model.overload_slack_n0["B1"]) == pytest.approx(100.0)
    assert pyo.value(_solve(_build(MilpLimitFactors(tatl=0.5, scanned=0.5), with_nx=False)).overload_slack_n0["B1"]) == pytest.approx(0.0)


def test_the_patl_factor_reduces_the_n_x_patl_limit_and_only_that_one():
    model = _solve(_build(MilpLimitFactors(patl=0.8), nx=900.0, tatl=1200.0))
    assert pyo.value(model.nx_patl_overload_slack["B1", "CO1"]) == pytest.approx(100.0)
    assert pyo.value(model.nx_tatl_overload_slack["B1", "CO1"]) == pytest.approx(0.0)       # TATL 1200 A, factor 1
    other = _solve(_build(MilpLimitFactors(tatl=0.8, scanned=0.8), nx=900.0, tatl=1200.0))
    assert pyo.value(other.nx_patl_overload_slack["B1", "CO1"]) == pytest.approx(0.0)


def test_the_tatl_factor_reduces_the_n_x_tatl_limit():
    # 1100 A against 1200 A x 0.5 = 600 A; the PATL row stays at 1000 A (slack 100)
    model = _solve(_build(MilpLimitFactors(tatl=0.5), nx=1100.0, tatl=1200.0))
    assert pyo.value(model.nx_tatl_overload_slack["B1", "CO1"]) == pytest.approx(500.0)
    assert pyo.value(model.nx_patl_overload_slack["B1", "CO1"]) == pytest.approx(100.0)


def test_the_scanned_factor_reduces_the_n0_and_the_n_x_scanned_limits():
    # N-0 effective limit max(1000, 800) = 1000 A -> 500 A; N-X pair limit max(1000, 900) = 1000 A -> 500 A
    model = _solve(_build(MilpLimitFactors(scanned=0.5), scanned_n0=800.0, scanned_nx=900.0))
    assert pyo.value(model.scanned_overload_slack["B3"]) == pytest.approx(300.0)
    assert pyo.value(model.nx_scanned_overload_slack["B3", "CO1"]) == pytest.approx(400.0)
    # the pair limit kept for the outputs and the final check is the real one
    assert model.nx_scanned_pair_limit_ampere[("B3", "CO1")] == pytest.approx(1000.0)
    plain = _solve(_build(MilpLimitFactors(patl=0.5, tatl=0.5), scanned_n0=800.0, scanned_nx=900.0))
    assert pyo.value(plain.scanned_overload_slack["B3"]) == pytest.approx(0.0)
    assert pyo.value(plain.nx_scanned_overload_slack["B3", "CO1"]) == pytest.approx(0.0)


def test_the_monitoring_for_the_convergence_check_keeps_the_real_limits():
    model = _build(MilpLimitFactors(patl=0.5, tatl=0.5, scanned=0.5), nx=1100.0, tatl=1200.0, scanned_n0=800.0, scanned_nx=900.0)
    assert model.overload_monitoring["n0"]["B1"] == (1, 1000.0)
    assert model.overload_monitoring["nx_patl"][("B1", "CO1")] == (1, 1000.0)
    assert model.overload_monitoring["nx_tatl"][("B1", "CO1")] == (1, 1200.0)


def _filtered(factor, i_b1=300.0):
    """B1 at i_b1 after CO1; PST1 moves it by 10 A per tap over 10 taps (bound i_b1 + 100 A); PATL 1000 A."""
    return _build(MilpLimitFactors(patl=factor), nx=i_b1, sens=10.0, enabled=True, margin=1.0, with_nx=True)


def test_the_filter_uses_the_reduced_limit_so_it_never_drops_a_row_that_can_now_bind():
    # bound 400 A: never binding against 1000 A (and 500 A), binding against 400 A x 1.0 - margin
    assert ("B1", "CO1") in _filtered(1.0).nx_skipped_pairs["nx_patl"]
    assert ("B1", "CO1") in _filtered(0.5).nx_skipped_pairs["nx_patl"]           # limit 500 A: 400 <= 499
    kept = _filtered(0.4)                                                         # limit 400 A: 400 > 399
    assert ("B1", "CO1") in list(kept.nx_branch_contingency_pairs)
    assert not kept.nx_skipped_pairs["nx_patl"]


def test_the_filter_uses_the_reduced_tatl_and_scanned_limits():
    base = dict(nx=300.0, tatl=1200.0, sens=10.0, enabled=True)
    assert ("B1", "CO1") in _build(MilpLimitFactors(tatl=0.5), **base).nx_skipped_pairs["nx_tatl"]           # 600 A
    assert ("B1", "CO1") in list(_build(MilpLimitFactors(tatl=0.3), **base).nx_tatl_branch_contingency_pairs)  # 360 A
    scanned = dict(scanned_n0=200.0, scanned_nx=300.0, sens=10.0, enabled=True)
    assert ("B3", "CO1") in _build(MilpLimitFactors(scanned=0.5), **scanned).nx_skipped_pairs["nx_scanned"]
    assert ("B3", "CO1") in list(_build(MilpLimitFactors(scanned=0.3), **scanned).nx_scanned_branch_contingency_pairs)


def test_the_filtered_and_the_unfiltered_solution_agree_with_a_factor():
    filtered = _solve(_build(MilpLimitFactors(patl=0.5), nx=450.0, sens=-1.0, enabled=True))
    full = _solve(_build(MilpLimitFactors(patl=0.5), nx=450.0, sens=-1.0, enabled=False))
    assert pyo.value(filtered.objective) == pytest.approx(pyo.value(full.objective), abs=1e-9)


def test_one_log_line_gives_the_three_factors(caplog):
    milp_builder.reset_run_log_state()
    with caplog.at_level(logging.INFO, logger="milp.milp_builder"):
        _build(MilpLimitFactors(patl=0.9, tatl=0.8, scanned=1.0))
    lines = [r.getMessage() for r in caplog.records if "MILP limit factors" in r.getMessage()]
    assert len(lines) == 1 and "PATL 0.9" in lines[0] and "TATL 0.8" in lines[0] and "scanned 1" in lines[0]


def test_a_scanned_factor_below_one_with_a_hard_scanned_constraint_warns(caplog):
    milp_builder.reset_run_log_state()
    with caplog.at_level(logging.WARNING, logger="milp.milp_builder"):
        _build(MilpLimitFactors(scanned=0.9), scanned_n0=100.0, scanned_nx=100.0, hard=True)
    assert any("infeasible" in r.getMessage() for r in caplog.records)
    caplog.clear()
    milp_builder.reset_run_log_state()
    with caplog.at_level(logging.WARNING, logger="milp.milp_builder"):
        _build(MilpLimitFactors(scanned=0.9), scanned_n0=100.0, scanned_nx=100.0, hard=False)
        _build(MilpLimitFactors(), scanned_n0=100.0, scanned_nx=100.0, hard=True)
    assert not any("infeasible" in r.getMessage() for r in caplog.records)


def _config(name="rao_config.yaml"):
    import yaml
    import run_pipeline
    return yaml.safe_load((Path(run_pipeline.__file__).parent / "config" / name).read_text(encoding="utf-8"))


@pytest.mark.parametrize("name", ["rao_config.yaml", "rao_config.default.yaml"])
def test_both_config_files_have_the_factors_at_one(name):
    thresholds = _config(name)["thresholds"]
    assert [thresholds[k] for k in ("milp_limit_factor_patl", "milp_limit_factor_tatl", "milp_limit_factor_scanned")] == [1.0] * 3


@pytest.mark.parametrize("key", ["milp_limit_factor_patl", "milp_limit_factor_tatl", "milp_limit_factor_scanned"])
@pytest.mark.parametrize("value", [0, 0.0, -0.1, 1.5, True, "0.9", None])
def test_the_config_check_refuses_a_factor_outside_zero_to_one(key, value):
    import run_pipeline
    config = _config()
    config["thresholds"][key] = value
    with pytest.raises(ValueError, match=f"thresholds.{key}"):
        run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))
    config["thresholds"][key] = 0.85
    run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))
    config["thresholds"][key] = 1
    run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))


def test_the_pipeline_hands_the_configured_factors_to_every_calculation_mode():
    import run_pipeline
    from milp import ac_convergence_loop, dc_pass, single_pass
    import inspect
    assert run_pipeline.MILP_LIMIT_FACTORS == MilpLimitFactors()
    for function in (ac_convergence_loop.build_model_at_state, ac_convergence_loop.run_post_rao_ac_verification_loop,
                     single_pass.run_single_pass, dc_pass.run_dc_pass):
        assert "milp_limit_factors" in inspect.signature(function).parameters
    assert "milp_limit_factors=MILP_LIMIT_FACTORS" in inspect.getsource(run_pipeline)


@pytest.mark.parametrize("bad", [0.0, -0.5, 1.01, True, "0.9", None])
def test_a_factor_outside_zero_to_one_is_refused(bad):
    with pytest.raises(ValueError):
        MilpLimitFactors(patl=bad)
