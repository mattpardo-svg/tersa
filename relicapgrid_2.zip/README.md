# Golden matrix and gate

The golden matrix is a fixed set of 52 full runs of `run_pipeline.main()`. Its files are compared with a stored baseline, so a change that should not move results is proven not to move them. Scripts only; nothing in `src/` imports this folder.

## The 52 runs
Case name: `INPUT__MODE__RATYPES__nx0|nx1` (`nx1` = N-X analysis on). MODE is `ac_iterative`, `ac_single_pass` or `dc`, so each input/RA-type pair gives 3 modes x 2 = 6 runs.

| Input (`run_case.py`) | RA types | Runs |
|---|---|---|
| `mock` (the shipped standard-form mock P) | `pst+rd`, `rd`, `pst+rd+countertrade` | 18 |
| `generic` (the official sample G) | `pst+rd` | 6 |
| `ct` (countertrade mock) | `countertrade`, `countertrade+rd` | 12 |
| `hvdc` (HVDC mock) | `hvdc` | 6 |
| `cthvdc` (countertrade + HVDC mock) | `countertrade+hvdc` | 6 |
| `mockpruned` (P with the N-X PST threshold at 0.02 % per tap and the N-X RD threshold at 2.0 % per 100 MW, the same pruning as 0.02 % per MW before DECISIONS 187; DECISIONS 142) | `pst+rd`, `pst+rd+countertrade`; `ac_iterative` and `dc`, `nx1` only | 4 |

Each run copies all its output files (CSV and others, 8 to 36 per run) to `OUTROOT/CASE`. A run is compared file by file with the same case in the baseline; `run_log.txt` and the `seconds_*` columns are not compared.

## Baselines
- `baseline.zip` (6.5 MB, 55 MB unpacked): the output files of the 52 cases (646 files since the output redesign, 1031 before it, one folder per case, no `run_log.txt`), written from a `run_matrix.py` run.
- `mxA` and `mxB`: two earlier full matrices kept outside the repository and passed to the gate as `BASELINE_DIR`; they are not needed (the gate uses `baseline.zip` when none is given).
- DECISIONS 172: `co_flat_list.csv` (all cases, one row per contingency instead of four) and `results_preventive_rd_ra_count.csv` (the cases that have it, without the two per-timeframe columns) were replaced; every other file of the baseline is as before.
- DECISIONS 171: the cases `ct` and `cthvdc` now run on standard-form builder data (no `gLSKStrategy`, no `BidDirectionKind`); every result file is equal within the tolerance, nothing is re-baselined.
- DECISIONS 169: the two files sensitivity_rd_n0.csv and sensitivity_rd_nx.csv of the cases with countertrade were replaced (they list one row per countertrade RA and direction instead of one per countertrade-only unit); every other file of the baseline is as before. DECISIONS 170: `sensitivity_rd_nx.csv` of the two `mockpruned` countertrade cases was replaced the same way (CT rows instead of per-unit rows).
- DECISIONS 175: the PST thresholds became per tap; only the four mockpruned cases moved and 20 of their result files were replaced (not the sensitivity CSVs); every other file is as before.
- Output files redesign (DECISIONS 205): the baseline was replaced in full, with the files of the new output set (646 files in 52 case folders: the files of `docs/specs/output_files_specs.md`, no `run_log.txt`). Every mapped value was proven equal to the old files first. `compare_runs.py` skips the run-time and memory rows of `summary.csv` and the time columns of `iterations.csv`.
- Loadings files with the MILP current (DECISIONS 209): `loadings_n0.csv` and `loadings_nx.csv` of all cases were replaced (two new columns, `current_milp_a` and `loading_milp_pct`). Proof before the replacement: the run with those two columns removed was compared with the old baseline, 646 files, 0 differences; the other 566 files of the baseline are byte-for-byte as before.
- New baseline on purpose (a change that is meant to move results, with a DECISIONS entry): run the matrix, check with `compare_runs.py` that only the expected cases moved (and that objective and activated RAs are as intended), then replace only those case folders in `baseline.zip` (the folders of the other cases stay byte-for-byte). Examples: DECISIONS 141 (three generic cases) and 140 / 142 (new cases added).

## Comparison rule (implemented in `compare_runs.py`)
Text, statuses and integer cells are exact. Other numbers are equal if |a - b| <= 1e-8 x max(|a|, |b|) or <= 1e-8 x the largest absolute value of their column (column-scaled; 1e-9 until DECISIONS 161); columns named `*_model_diff_pct` and `last_solve_*` get 1e-6 absolute instead (differences of nearly equal loadings; last solve ends in one of several vertices, DECISIONS 140); two values both <= 1e-9 in absolute value are equal (numerical dust floor, DECISIONS 112).

## The gate
`python tests/tools/golden/run_gate.py OUTDIR TAG none [BASELINE_DIR ...]` (about 25 minutes) runs, in this order, and writes `OUTDIR/gate_TAG.txt`:
1. `run_suite.py`: the test suite in parallel by file (4 workers; about 9 minutes alone). The suite includes the byte-equality test of P (`test_rao_the_shipped_mock_is_the_generated_standard_mock`).
2. `run_matrix.py`: the 52 runs (5 workers) into `OUTDIR/mx_TAG`.
3. `compare_runs.py` against each baseline (default: `baseline.zip` extracted to `OUTDIR/baseline`).
4. `fp_check.py`: MILP fingerprints of the mock against `tests/fixtures/milp_model_fingerprints.json`.
5. The link check of the docs (`tests/tools/check_doc_links.py`); a dead link in a live file fails the gate.

Pass = every test file `rc=0`, `diff` 0 and `problems 0` per baseline, `FINGERPRINTS IDENTICAL`, `LINKS OK`. Known noise: `mock__ac_iterative__pst+rd+countertrade__nx1` ends in one of several solver vertices (DECISIONS 140); under load it once differed by 1.55e-9 relative in the curative volume columns, and three isolated reruns matched. Rerun that case alone (below) before treating such a difference as real.

## Scripts
- `run_case.py CASE OUTROOT`: one run in a temporary folder, outputs copied to `OUTROOT/CASE`.
- `run_matrix.py OUTROOT WORKERS [ONLY]`: the 52 runs; `ONLY` keeps the cases whose name contains the text.
- `run_suite.py OUTDIR WORKERS`: the suite by file, logs per file.
- `compare_runs.py A_ROOT B_ROOT`: the rule above; prints counts and the first 40 problems.
- `fp_check.py SECTIONS`: fingerprints (`none` = the shipped mock).
- `run_gate.py`: all of the above.
- `timing.py [--repeat N] CASE ...`: wall time and peak memory (Windows API) of single cases, each in its own process; compare a change with the previous state back to back (machine speed drifts by tens of percent). Reference cases: `mock__ac_iterative__pst+rd__nx1`, `mock__ac_iterative__pst+rd+countertrade__nx1`.

## Commands (repo root, Windows, venv; set the hash seed first)
```
$env:PYTHONHASHSEED = "0"
.venv\Scripts\python.exe tests\tools\golden\run_gate.py OUTDIR TAG none [BASELINE_DIR ...]
.venv\Scripts\python.exe tests\tools\golden\run_matrix.py OUTROOT 5 [ONLY]
.venv\Scripts\python.exe tests\tools\golden\run_case.py mock__ac_iterative__pst+rd__nx1 OUTROOT
.venv\Scripts\python.exe tests\tools\golden\compare_runs.py BASELINE_ROOT OUTROOT
.venv\Scripts\python.exe tests\tools\golden\fp_check.py none
.venv\Scripts\python.exe tests\tools\golden\run_suite.py OUTDIR 4
.venv\Scripts\python.exe tests\tools\golden\timing.py --repeat 3 mock__ac_iterative__pst+rd__nx1
```