"""zipio.py - zip helpers shared by the generators."""
import zipfile


def fixed_entry(name):
    """A zip entry with a fixed time stamp and attributes, so two builds of the same mock are byte-identical
    (writestr with a plain name stamps the current time)."""
    entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    entry.external_attr = 0o644 << 16
    return entry


def zip_members(path):
    """{member name: content bytes} of a zip. Compare zips with this, not by raw bytes: the compressed bytes of the
    same content depend on the zlib version."""
    with zipfile.ZipFile(path) as z:
        return {name: z.read(name) for name in z.namelist()}


def same_zip_content(a, b):
    """True when two zips have the same member names and the same content per member."""
    return zip_members(a) == zip_members(b)


def zip_content_digest(path):
    """SHA-256 over the sorted member names and contents of a zip (independent of the compression)."""
    import hashlib
    digest = hashlib.sha256()
    for name, content in sorted(zip_members(path).items()):
        digest.update(name.encode("utf-8") + b"\0" + hashlib.sha256(content).digest())
    return digest.hexdigest()


def write_zip(files, dest):
    """Write {name: bytes} to dest (a path or a binary file object): names sorted, deflated, fixed time stamps, the
    same layout as the converter, so equal content gives equal bytes."""
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as out:
        for name in sorted(files):
            info = fixed_entry(name)
            info.compress_type = zipfile.ZIP_DEFLATED
            out.writestr(info, files[name])
