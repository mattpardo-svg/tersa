"""The command line of the fixture tool (python tests/tools/fixture_cli.py): the standard-form mock equals the shipped one, check passes."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "tools"))
import fixture_cli as cli
from mock_builders import paths, zipio


def test_rao_mock_data_standard_command_writes_the_shipped_standard_mock(tmp_path):
    out = tmp_path / "standard.zip"
    assert cli.main(["standard", "--out", str(out)]) == 0
    assert zipio.same_zip_content(out, paths.STANDARD_ZIP)


def test_rao_mock_data_base_command_writes_the_frozen_base(tmp_path):
    out = tmp_path / "base.zip"
    assert cli.main(["base", "--out", str(out)]) == 0
    assert zipio.same_zip_content(out, paths.STANDARD_BASE_ZIP)


def test_rao_mock_data_check_command_passes_on_the_shipped_fixtures(capsys):
    assert cli.main(["check"]) == 0
    printed = capsys.readouterr().out
    assert "standard = base + countertrade: yes" in printed
    assert paths.CGM_ZIP.name in printed and paths.STANDARD_BASE_ZIP.name in printed
