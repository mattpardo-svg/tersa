"""tests/test_rao_loadings_milp_current.py - loadings_n0.csv and loadings_nx.csv carry current_milp_a and loading_milp_pct:
the value of the flow expression of the solved MILP (initial current + sensitivities x the RA changes, preventive and, for
N-X, the curative ones of the contingency), against the real limit; empty where the row has no MILP constraint."""

import csv
import logging

import pyomo.environ as pyo
import pytest

from data_model import AEType
from helpers import _make_ae_nx_filters as _ae, _make_pst_nx_filters as _pst
from milp.milp_builder import NxMilpInputs, PstMilpInputs, build_n0_milp_model
from post_milp import milp_flows, nx_results_export, run_outputs

TS = "1030Z"


def _solved_model(milp_factors=None, enabled=False):
    """B1 (secured, PATL 1000 A): 1100 A in N-0 and 1500 A after CO1; PST1 moves both by -10 A per tap (taps -10..10).
    B2 (secured): far below its limit, filtered out of the N-X rows. B3 scanned (limit 1000 A)."""
    branches = [_ae("a1", "B1"), _ae("a2", "B2"), _ae("a3", "B3", ae_type=AEType.SCANNED)]
    lf_initial = {"B1": {1: 1100.0}, "B2": {1: 100.0}, "B3": {1: 900.0}}
    lf_nx = {"CO1": {"B1": {1: 1500.0}, "B2": {1: 150.0}, "B3": {1: 950.0}}}
    n0_sens = {("B1", "PST1"): -10.0, ("B2", "PST1"): 1.0, ("B3", "PST1"): -1.0}
    pst_inputs = PstMilpInputs(
        pst_list=[_pst("PST1")], pst_tap_bounds={"PST1": (-10, 10)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned=n0_sens, pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=1.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx=lf_nx, sensitivity_pst_nx={"CO1": n0_sens}, sensitivity_rd_nx={}, penalty_cost_overload_nx_patl=10_000.0,
        penalty_cost_overload_nx_scanned=10_000.0, constraint_filter_enabled=enabled, constraint_filter_margin_ampere=1.0,
    )
    model = build_n0_milp_model(
        branches, TS, lf_initial, 10_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs, scanned_element_constraint_hard=False,
        scanned_element_penalty_eur_per_a=1000.0, **({"milp_limit_factors": milp_factors} if milp_factors else {}),
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model


def _taps(model):
    return pyo.value(model.tap_change_upward["PST1"]) - pyo.value(model.tap_change_downward["PST1"])


def test_the_n0_value_is_the_initial_current_plus_the_effect_of_the_solved_actions():
    model = _solved_model()
    taps = _taps(model)
    assert taps == pytest.approx(6.0)                                   # B1 is relieved up to the cap of 6 taps per TSO
    assert milp_flows.milp_current_n0(model, "B1") == pytest.approx(1100.0 - 10.0 * taps)
    assert milp_flows.milp_current_n0(model, "B2") == pytest.approx(100.0 + 1.0 * taps)
    assert milp_flows.milp_current_n0(model, "B3") == pytest.approx(900.0 - 1.0 * taps)       # a scanned branch too


def test_the_n_x_value_is_the_post_contingency_current_plus_the_effect_of_the_solved_actions():
    model = _solved_model()
    taps = _taps(model)
    assert milp_flows.milp_current_nx(model, "B1", "CO1") == pytest.approx(1500.0 - 10.0 * taps)
    assert milp_flows.milp_current_nx(model, "B3", "CO1") == pytest.approx(950.0 - 1.0 * taps)      # scanned pair


def test_a_row_without_a_milp_constraint_has_no_value():
    model = _solved_model(enabled=True)                                  # the filter drops the far B2 row of the pair
    assert ("B2", "CO1") in model.nx_skipped_pairs["nx_patl"]
    assert milp_flows.milp_current_nx(model, "B2", "CO1") is None
    assert milp_flows.milp_current_nx(model, "B1", "CO9") is None
    assert milp_flows.milp_current_n0(model, "B9") is None


def test_the_value_does_not_depend_on_the_limit_factors():
    plain, reduced = _solved_model(), _solved_model(milp_factors=__import__("milp.milp_builder", fromlist=["x"]).MilpLimitFactors(patl=0.5))
    # the factor moves the limit, not the current of the expression: the same taps (up to the bound) give the same value
    assert milp_flows.milp_current_n0(plain, "B2") == pytest.approx(100.0 + _taps(plain))
    assert milp_flows.milp_current_n0(reduced, "B2") == pytest.approx(100.0 + _taps(reduced))


def test_a_constant_row_without_any_action_gives_the_current_itself():
    # no PST sensitivity on the branch: the left side is the constant current
    model = _solved_model()
    model.milp_flow_n0["BX"] = 321.0
    assert milp_flows.milp_current_n0(model, "BX") == 321.0


def test_an_unsolved_model_gives_no_value():
    import pyomo.environ as pyomo_env
    model = build_n0_milp_model(
        [_ae("a1", "B1")], TS, {"B1": {1: 1100.0}}, 10_000.0,
        pst_inputs=PstMilpInputs(
            pst_list=[_pst("PST1")], pst_tap_bounds={"PST1": (-10, 10)}, pst_group_equality_pairs=[],
            sensitivity_pst_n0_pruned={("B1", "PST1"): -10.0}, pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=1.0,
        ),
    )
    assert milp_flows.milp_current_n0(model, "B1") is None
    assert pyomo_env is not None


# --- the files ---------------------------------------------------------------------------------------------

def test_the_headers_have_the_two_columns_in_the_agreed_order():
    assert run_outputs.HEADERS[run_outputs.LOADINGS_N0] == [
        "tso", "branch_id", "side", "limit_a", "current_initial_a", "current_milp_a", "current_after_pra_a",
        "loading_initial_pct", "loading_milp_pct", "loading_after_pra_pct",
    ]
    assert run_outputs.HEADERS[run_outputs.LOADINGS_NX] == [
        "tso", "branch_id", "side", "contingency_id", "limit_a", "tatl_a", "current_initial_a", "current_milp_a",
        "current_after_pra_cra_a", "loading_initial_pct", "loading_milp_pct", "loading_after_pra_cra_pct",
    ]


def _records(model_branches):
    return run_outputs.monitored_branches([_ae(f"a{b}", b) for b in model_branches], TS, {})


def test_the_n0_rows_get_the_milp_current_and_its_loading_against_the_real_limit():
    model = _solved_model()
    records = _records(["B1", "B2", "B3"])
    lf = {"B1": {1: 1100.0}, "B2": {1: 100.0}, "B3": {1: 900.0}}
    rows = run_outputs.loadings_n0_rows(records, set(), lf, None, 0.0)
    milp_flows.add_milp_currents(rows, model)
    by_branch = {r["branch_id"]: r for r in rows}
    taps = _taps(model)
    assert by_branch["B1"]["current_milp_a"] == pytest.approx(1100.0 - 10.0 * taps)
    assert by_branch["B1"]["loading_milp_pct"] == pytest.approx((1100.0 - 10.0 * taps) / by_branch["B1"]["limit_a"] * 100.0)
    # every other value of the row is as it was
    assert by_branch["B1"]["current_initial_a"] == 1100.0 and by_branch["B1"]["current_after_pra_a"] == 1100.0


def test_the_loading_uses_the_real_limit_when_the_model_was_built_with_a_factor():
    from milp.milp_builder import MilpLimitFactors
    model = _solved_model(milp_factors=MilpLimitFactors(patl=0.5))
    rows = run_outputs.loadings_n0_rows(_records(["B1"]), set(), {"B1": {1: 1100.0}}, None, 0.0)
    milp_flows.add_milp_currents(rows, model)
    assert rows[0]["limit_a"] == 1000.0
    assert rows[0]["loading_milp_pct"] == pytest.approx(rows[0]["current_milp_a"] / 1000.0 * 100.0)


def test_the_n_x_pairs_get_the_value_and_a_pair_without_a_row_stays_empty(tmp_path):
    model = _solved_model(enabled=True)
    records = _records(["B1", "B2", "B3"])
    lf_nx = {"CO1": {"B1": {1: 1500.0}, "B2": {1: 150.0}, "B3": {1: 950.0}}}
    pairs = nx_results_export.nx_loading_pairs(model, records, lf_nx, {}, {}, {"PST1": 1.0}, None, None)
    milp_flows.add_milp_currents(pairs, model, kind="nx")
    by_branch = {p["branch_id"]: p for p in pairs}
    taps = _taps(model)
    assert by_branch["B1"]["current_milp_a"] == pytest.approx(1500.0 - 10.0 * taps)
    assert by_branch["B1"]["loading_milp_pct"] == pytest.approx(by_branch["B1"]["current_milp_a"] / by_branch["B1"]["limit_a"] * 100.0)
    assert by_branch["B2"]["current_milp_a"] is None and by_branch["B2"]["loading_milp_pct"] is None
    run_outputs.write_table(tmp_path, run_outputs.LOADINGS_NX, pairs)
    with open(tmp_path / run_outputs.LOADINGS_NX, newline="", encoding="utf-8") as handle:
        rows = {r["branch_id"]: r for r in csv.DictReader(handle)}
    assert rows["B2"]["current_milp_a"] == "" and rows["B2"]["loading_milp_pct"] == ""
    assert float(rows["B1"]["current_milp_a"]) == pytest.approx(1500.0 - 10.0 * taps)


def test_the_row_rule_does_not_use_the_milp_value():
    # a branch below the threshold before and after the RAs is not written, whatever the MILP says
    records = _records(["B1", "B2"])
    lf = {"B1": {1: 1100.0}, "B2": {1: 100.0}}
    rows = run_outputs.loadings_n0_rows(records, set(), lf, None, 80.0)
    assert [r["branch_id"] for r in rows] == ["B1"]


def test_one_count_line_per_file(caplog):
    model = _solved_model(enabled=True)
    pairs = nx_results_export.nx_loading_pairs(
        model, _records(["B1", "B2", "B3"]), {"CO1": {"B1": {1: 1500.0}, "B2": {1: 150.0}, "B3": {1: 950.0}}}, {}, {},
        {"PST1": 1.0}, None, None,
    )
    with caplog.at_level(logging.INFO, logger="post_milp.milp_flows"):
        counts = milp_flows.add_milp_currents(pairs, model, kind="nx", file_name="loadings_nx.csv")
    assert counts == (1, 2)
    lines = [r.getMessage() for r in caplog.records if "loadings_nx.csv" in r.getMessage()]
    assert len(lines) == 1 and "1 row(s) with a MILP value" in lines[0] and "2 without" in lines[0]


# --- end to end --------------------------------------------------------------------------------------------

@pytest.mark.parametrize("mode", ["ac_iterative", "ac_single_pass", "dc"])
def test_the_pipeline_writes_the_columns_and_the_values_of_its_final_model(tmp_path, mode):
    from helpers import _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs
    models = []

    def customize(rp, monkeypatch):
        monkeypatch.setattr(rp, "LOADINGS_N0_MIN_LOADING_PCT", 0)
        monkeypatch.setattr(rp, "LOADINGS_NX_MIN_LOADING_PCT", 0)
        build = rp.ac_convergence_loop.build_n0_milp_model

        def keeping(*args, **kwargs):
            models.append(build(*args, **kwargs))
            return models[-1]

        monkeypatch.setattr(rp.ac_convergence_loop, "build_n0_milp_model", keeping)

    run = run_pipeline_on_fixture_inputs(
        tmp_path, _MOCK_NX_NCP_ZIP, enable_nx_analysis=True, ra_types=("pst", "rd"), calculation_mode=mode,
        customize_pipeline=customize,
    )
    last = models[-1]                                                      # the last solve is the final model
    for name, key in (("loadings_n0.csv", "n0"), ("loadings_nx.csv", "nx")):
        with open(run.output_dir / name, newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        assert rows and "current_milp_a" in rows[0] and "loading_milp_pct" in rows[0]
        filled = [r for r in rows if r["current_milp_a"] != ""]
        assert filled, name
        for r in filled:
            assert float(r["loading_milp_pct"]) == pytest.approx(float(r["current_milp_a"]) / float(r["limit_a"]) * 100.0, rel=1e-9)
        if key == "n0":
            for r in filled:
                assert float(r["current_milp_a"]) == pytest.approx(milp_flows.milp_current_n0(last, r["branch_id"]), rel=1e-9)
        else:
            for r in filled:
                assert float(r["current_milp_a"]) == pytest.approx(
                    milp_flows.milp_current_nx(last, r["branch_id"], r["contingency_id"]), rel=1e-9)
        assert all((r["current_milp_a"] == "") == (r["loading_milp_pct"] == "") for r in rows)
