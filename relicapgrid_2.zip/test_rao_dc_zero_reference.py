"""tests/test_rao_dc_zero_reference.py - calculation_mode dc, N-X guard: a pair whose sensitivity reference current is exactly
0 A while its load-flow current is not is kept (and counted in one summary warning) when the load-flow current is at most
sensitivity_guard.absolute_floor_ampere; above it the contingency stays invalid. A contingency whose sensitivities are all
zero keeps its failure check. The AC modes and N-0 do not change. Synthetic values only."""

import logging

import pytest

from data_model import LfNx
from helpers import _make_ae_nx_filters as _ae
from pre_milp import nx_sensitivity, sensitivity_checks as sv

TS = "1030Z"
SIDES = {"L1": 1, "L2": 1}


def _lf(**per_branch):
    return {name: {1: value, 2: value} for name, value in per_branch.items()}


def _reader(dc: bool, l1_current: float):
    """A reader of the PST kind with a guard; L1 is a connected branch with the given load-flow current after C1."""
    return nx_sensitivity._NxKindReader(
        "pst", "pst", ["P1"], None, [], branch_sides=SIDES, ae_flat_list=[_ae("a1", "L1"), _ae("a2", "L2")], timestamp=TS,
        lf_nx=LfNx({"C1": _lf(L1=l1_current, L2=50.0)}), lf_initial={"L1": {1: 10.0}, "L2": {1: 50.0}},
        min_loading_threshold_pct_nx=0.0, guard_out={}, dc_converter=object() if dc else None,
    )


def _guard(reader, reference_l1=0.0, all_zero=()):
    reader._guard_batch({"C1": {"L1": reference_l1, "L2": 50.0}}, set(all_zero))
    reader._finish_guard()
    return reader


def _warnings(caplog):
    return [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]


def test_dc_keeps_a_zero_reference_pair_with_a_load_flow_current_of_about_one_ampere(caplog):
    with caplog.at_level(logging.WARNING):
        reader = _guard(_reader(dc=True, l1_current=1.2))
    assert reader.invalid == {}
    assert "L1" in reader.lf_nx["C1"]                                       # the pair stays in the load flow set
    lines = [m for m in _warnings(caplog) if "zero reference" in m]
    assert len(lines) == 1 and "1 (branch, contingency) pair(s) in 1 contingency(ies)" in lines[0] and "C1/L1" in lines[0]
    assert "5 A" in lines[0] and "kept" in lines[0]


def test_the_ac_modes_keep_the_failure_for_the_same_pair():
    reader = _guard(_reader(dc=False, l1_current=1.2))
    assert list(reader.invalid) == ["C1"] and "zero reference" in reader.invalid["C1"]


@pytest.mark.parametrize("current, kept", [(1.0, True), (4.9, True), (5.0, True), (5.01, False), (88.9, False)])
def test_the_limit_is_the_absolute_floor_of_the_guard(current, kept):
    reader = _guard(_reader(dc=True, l1_current=current))
    assert (reader.invalid == {}) is kept


def test_a_negative_load_flow_current_is_judged_by_its_magnitude():
    assert _guard(_reader(dc=True, l1_current=-3.0)).invalid == {}
    assert list(_guard(_reader(dc=True, l1_current=-30.0)).invalid) == ["C1"]


def test_the_floor_is_the_configured_one(monkeypatch):
    monkeypatch.setattr(sv, "ABSOLUTE_FLOOR_AMPERE", 2.0)
    assert _guard(_reader(dc=True, l1_current=1.9)).invalid == {}
    assert list(_guard(_reader(dc=True, l1_current=2.1)).invalid) == ["C1"]


def test_a_contingency_with_all_sensitivities_zero_keeps_the_failure_check():
    reader = _guard(_reader(dc=True, l1_current=1.2), all_zero={"C1"})
    assert list(reader.invalid) == ["C1"] and "all sensitivities are exactly zero" in reader.invalid["C1"]


def test_a_nonzero_reference_is_judged_as_before_in_dc():
    reader = _guard(_reader(dc=True, l1_current=1000.0), reference_l1=1030.0)
    assert reader.invalid == {}                                            # 3 % within the DC tolerance of 5 %


def test_the_summary_counts_every_kept_pair_once_per_run_of_the_guard(caplog):
    reader = _reader(dc=True, l1_current=1.2)
    reader.lf_nx["C2"] = _lf(L1=2.0, L2=50.0)
    reader._guard_batch({"C1": {"L1": 0.0, "L2": 50.0}, "C2": {"L1": 0.0, "L2": 50.0}}, set())
    with caplog.at_level(logging.WARNING):
        reader._finish_guard()
    lines = [m for m in _warnings(caplog) if "zero reference" in m]
    assert len(lines) == 1 and "2 (branch, contingency) pair(s) in 2 contingency(ies)" in lines[0]
    assert reader.invalid == {}


def test_the_function_keeps_the_ac_default_without_the_new_arguments():
    invalid = sv.find_invalid_nx_contingencies(
        {"C1": {"L1": 0.0, "L2": 50.0}}, set(), {"C1": _lf(L1=1.2, L2=50.0)}, SIDES, deviating_out={}, absolute_floor_ampere=5.0)
    assert list(invalid) == ["C1"]
    kept = {}
    invalid = sv.find_invalid_nx_contingencies(
        {"C1": {"L1": 0.0, "L2": 50.0}}, set(), {"C1": _lf(L1=1.2, L2=50.0)}, SIDES, deviating_out={}, absolute_floor_ampere=5.0,
        zero_reference_floor_ampere=5.0, zero_reference_kept_out=kept)
    assert invalid == {} and kept == {"C1": ["L1"]}


def test_n0_keeps_its_zero_reference_failure():
    invalid = sv.find_invalid_n0_branches({"L1": 0.0}, {"L1": {1: 1.2}}, SIDES, absolute_floor_ampere=5.0)
    assert list(invalid) == ["L1"] and "zero reference" in invalid["L1"]


def test_only_the_dc_reader_passes_the_zero_reference_arguments():
    assert nx_sensitivity._guard_zero_reference_arguments(None, {}) == {}
    assert nx_sensitivity._guard_tolerance(None) == {}
    kept = {}
    dc = nx_sensitivity._guard_zero_reference_arguments(object(), kept)
    assert dc["zero_reference_floor_ampere"] == sv.ABSOLUTE_FLOOR_AMPERE and dc["zero_reference_kept_out"] is kept
