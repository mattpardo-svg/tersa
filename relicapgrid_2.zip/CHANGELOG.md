# Changelog

Newest first. One short entry per change: date, what changed, tests, open items.

## 2026-11-18 - DC mode: zero reference current of a small N-X pair

- `calculation_mode` dc, N-X guard: a pair whose sensitivity reference current is exactly 0 A while its load-flow current is not, but at most `sensitivity_guard.absolute_floor_ampere`, is kept (not an invalid contingency) and counted in one summary warning; above the floor, with all-zero sensitivities, in the AC modes and in N-0 the failure stays (DECISIONS 178, rule 3). No new config key. Code: `find_invalid_nx_contingencies(zero_reference_floor_ampere=, zero_reference_kept_out=)`, `nx_sensitivity._guard_zero_reference_arguments`.
- Tests: `test_rao_dc_zero_reference.py` (written before the change; the DC case failed on the old code).

## 2026-11-18 - MILP current in the loadings files

- `loadings_n0.csv` and `loadings_nx.csv` get `current_milp_a` and `loading_milp_pct` (order in `output_files_specs.md` 3.5 and 3.6): the value of the flow expression of the row in the solved final model (the last solve), against the real `limit_a`; empty where the row has no MILP constraint. One log line per file counts the rows with and without a value. The row rule is unchanged (DECISIONS 209). Code: `post_milp/milp_flows.py`; the builder keeps `model.milp_flow_n0` and `model.milp_flow_nx`.
- Tests: `test_rao_loadings_milp_current.py`. Golden baseline replaced: every other column is unchanged (checked against the old baseline with the two new columns removed).

## 2026-11-18 - TATL fallback as a factor

- New key `curative_ra.tatl_fallback_factor` (default 1.0, number >= 1): a branch side without a TATL in the CGM gets TATL = PATL x factor, with the duration `tatl_fallback_duration_s` as before; the other TATL rules are unchanged. Two log lines: branch sides with a fallback TATL, TATL constraints added (DECISIONS 208). Code: `compute_tatl_data(fallback_factor=)`.
- Tests: `test_rao_tatl_fallback_factor.py`. Default: no result changes.

## 2026-11-18 - MILP margin on the limits

- New keys `thresholds.milp_limit_factor_patl`, `milp_limit_factor_tatl`, `milp_limit_factor_scanned` (default 1.0, 0 < factor <= 1): the MILP rows (N-0 and N-X PATL, N-X TATL, N-0 and N-X scanned) are built against limit x factor; the N-X constraint filter uses the same reduced limit; the final AC check, the outputs, the sensitivity and loading thresholds, the overload diagnosis and the convergence check keep the real limit. One INFO line with the factors, a warning when the scanned factor is below 1 with a hard scanned constraint (DECISIONS 207). Code: `MilpLimitFactors` in `milp/milp_builder.py`.
- Tests: `test_rao_milp_limit_factor.py`. Defaults: no result changes (golden matrix 0 differences).

## 2026-11-14 - Bid direction from the name, pooled readers, parse log summaries

- Bid direction: the property wins, else the last token of the name (split on whitespace, `_`, `-`) must be up or down, else skipped (DECISIONS 199). Code: `ncp_parser.direction_word_of_name`.
- Readers of the pool (DECISIONS 200): a legacy link and its schedule in different files, an RA under its rdf:ID and its mRID, a strategy in another RA file; `ra_pool` and `ae_pool` for the links of PSTs, RD, CT, HVDC, groups, curative tap bounds and assessed elements; unit costs from the whole pools.
- Logs (DECISIONS 201): `pre_milp/parse_summaries.py` (excluded elements by reason, RAs without a usable bid, bids parsed per TSO), contingencies dropped by reason, ignored RAs by cause, reworded NCP-switch lines, scanned-list line, inventory columns CT, CT-bids, HVDC.
- Decisions recorded (DECISIONS 202).
- Tests: `test_rao_bid_direction_name.py`, `test_rao_pooled_readers.py`, `test_rao_parse_log_summaries.py`; the tests of the changed log lines were updated.

## 2026-11-14 - Config key checks, overload diagnosis with the shared balance

- The decision-point key is read, validated and passed on correctly in every mode (a config with 12 gives a decision point 12 h before the run). What was missing: a key that nothing reads (top level, wrong section, misspelt) or written twice was ignored silently. One warning per such key at the start of a run (DECISIONS 197). Code: `run_pipeline.unknown_config_keys`, `duplicate_config_keys`, `warn_config_key_problems`.
- Overload diagnosis: one more line per pair with the best relief of redispatch and countertrade within the shared balance, the binding limit and the useful room per side (DECISIONS 198). Synthetic check: with the RD down bid blocked by its lead time and the countertrade down bid at its volume limit, the solved N-X PATL slack equals the overload minus the relief within the balance. Code: `overload_diagnosis._within_balance`, `_balance_line`; `milp_builder` keeps `rd_lead_time_blocked_bid_ids`.
- Tests: `test_rao_config_key_checks.py`, `test_rao_lead_time_decision_point.py`, `test_rao_overload_diagnosis.py`.

## 2026-11-14 - Lead-time decision point, N-X sensitivities in batches, slack analysis

- New config `lead_time.decision_point_hours_before_run` (default 1.0, >= 0): a bid (redispatch and countertrade, preventive and curative) is usable when its lead time is shorter than this distance (strict, as before); the decision point may fall on the previous day. One INFO summary per run and scope (decision point, count, first 5 ids, all at DEBUG) replaces the line per bid (DECISIONS 193). Code: `milp_builder._lead_time_is_usable`, `describe_decision_point`, `_log_lead_time_blocked`, `RdMilpInputs.decision_point_hours_before_run`, passed through `build_model_at_state`, `dc_pass`, `single_pass`, `ac_convergence_loop`, `extract_lead_time_results`.
- New config `nx_sensitivity.contingency_batch_size` (default 200, integer >= 1): the PST, redispatch, countertrade-unit and HVDC N-X analyses run per batch of contingencies, each read, guarded, filtered and released before the next; the result is that of one analysis (DECISIONS 194). Code: `nx_sensitivity._NxKindReader`, `_run_in_batches`, `_contingency_batches`; `sensitivity_checks.apply_guard_drops`, `log_guard_drops`, `restore_guard_drops`, `find_invalid_nx_contingencies(apply_global_rule=, without_valid_branch_out=)`. Equal to the former single call on a synthetic case (tables, guard, lf_nx, dropped pairs, log lines) for batch sizes 1, 2, 3, 99 and none.
- Recorded without code change: one shared balance for redispatch and countertrade; units not connected in the CGM stay excluded (DECISIONS 195, 196).
- Tests: `test_rao_lead_time_decision_point.py`, `test_rao_nx_sensitivity_batches.py`.
- Open: the remaining N-X slack of a large run is explained structurally (the preventive RAs act on every contingency and the scanned limit allows no worsening; PATL and scanned penalties are equal), not measured on non-public data.

## 2026-11-13 - Negative bid prices: reason recorded, one summary warning

- No behaviour change: a negative energy price or reservePrice is still 0. Decision (DECISIONS 28): every bid price is a cost; a negative cost would let the optimiser activate or reserve bids without any overload, only to lower the objective.
- `ncp_parser.parse_power_bids`: the per-bid negative-price and negative-reservePrice warnings are now one summary warning each per file (count, first 5 ids, all ids at DEBUG); the value is at DEBUG per bid. Comments give the reason.
- Spec_Coverage: line reference of the bid price row updated.
- Tests: 3 added in `test_rao_bid_default_price.py` (price summary, reservePrice summary, no warning without a negative); 2 message texts updated in `test_rao_ncp_dataset_variants.py`.
- Open: other `ncp_parser.py:line` references in Spec_Coverage.md are stale.

## 2026-11-13 - Redispatch and countertrade on non-public multi-TSO data

- New config bids.default_price_eur_per_mwh (default 0.0): the price of a bid with no price at the run time (DECISIONS 186).
- sensitivity_threshold_pct_rd_nx is now percent of the limit per 100 MW (was per MW) and is applied per contingency while reading, for redispatch and for the countertrade units before their sum (187). The golden case mockpruned uses 2.0 (= 0.02 per MW before); no golden moved.
- One id comparison (id_key) for the bid -> RA link, the shift-key routes and the unmatched-reference warning: any case, #, urn:uuid:, any number of leading _, rdf:ID / rdf:about / mRID (188). A machine named in a shift key is mapped to its GeneratingUnit through the CGM EQ (189).
- Log only: the cause of a bid with no generating unit of its GLSK in the model, one summary per cause (190); redispatch and countertrade lines and a closing best-RA-type line in the overload diagnosis (191); count-plus-first-5-ids summaries for bid attributes, prices, time points, ignored RAs, participation sums, unconnected units, blocked bids and missing penalty factors; the bid direction summary once per pool (192).
- Tests: test_rao_ncp_id_matching.py, test_rao_shift_key_machines.py, test_rao_bid_default_price.py, test_rao_nx_rd_threshold.py, test_rao_empty_glsk_causes.py, test_rao_penalty_and_blocked_summaries.py, test_rao_overload_diagnosis.py (extended).
- Open: batching the N-X analysis by contingencies would lower the peak memory; the threshold alone does not (DECISIONS 187).
## 2026-11-11 - Scanned N-X limit per pair, overload diagnosis, overload counts, N-X rows that cannot bind

- The N-X limit of a scanned element is `max(PATL, its original post-contingency loading of the pair)`; before, a scanned pair paid a slack with no PST move (DECISIONS 182).
- Log only: one overload diagnosis block per overloaded N-X pair after the final check (183); the solver line counts N-0, N-X PATL, TATL and scanned overloads separately (184).
- New config `nx_constraint_filter.enabled` (default true) and `margin_ampere` (default 1.0): N-X rows that can never bind are not built (185). Result files unchanged.
- Tests: `test_rao_scanned_nx_limit.py`, `test_rao_nx_constraint_filter.py`, `test_rao_overload_diagnosis.py`.
## 2026-11-07 - NCP files as one pool per profile, the TSO of an object from its content

- All files of a profile are read together whatever their creator; the same object id in two files stops the run naming both files and the id (DECISIONS 173).
- The TSO of an assessed element and of a remedial action is its operator in the content (EIC URI, local id through the CD file, else the TSO of its file); per-TSO settings, the inventory summary and the TSO columns use it. One log line per profile with the files and the objects per TSO.
- Tests: `test_rao_ncp_pools.py` (operator forms, pools, duplicate ids, one-creator run equal to the plain run); the loader tests use the pool shape. Golden matrix diff 0, fingerprints identical.

## 2026-11-07 - One timestamp: the CGM scenario time

- The run uses one timestamp. Removed: the 4-entry timestamp list and its helper, the timestamp-list parameters of the readers, the per-timeframe RA-count limit (constraint, slack, penalty, config key, two result columns). A removed config key with a value gives one warning "no longer used, ignored". `results_lead_times.csv` reports the run timestamp or a blank. `co_flat_list.csv` and `scanned_element_list.csv` have one row per element.
- Golden: `co_flat_list.csv` (52 cases) and `results_preventive_rd_ra_count.csv` (34 cases) re-baselined for the removed rows and columns only, proven; every other file equal within 1e-8; fingerprints identical. Tests `test_rao_one_timestamp.py`. DECISIONS 172.

## 2026-11-06 - Old mock form removed; the test suite stands on src/, tests/ and tests/fixtures

- Removed from the readers: the non-profile bid attributes and their `PowerBid` fields, a generator id as shift-key unit, the declared-value branch and the `powerShiftKey` / `method` attributes of the countertrade RA, group limits linked directly from the time point, the plain dependency predicate. Each gives one summary warning per file, "not supported, ignored" (`test_rao_unsupported_elements.py`). The `RotatingMachineAction` redispatch form stays: it is the form of the official 2.4 sample.
- Deleted: the old-form mock zip, `convert_ncp_to_standard.py` and its harness. The standard mock without countertrade is the frozen fixture `NCP_mock_standard_base.zip`; the builders moved to `tests/mock_builders/`; `tests/tools/` keeps the CLI, the golden matrix and the gate. `test_rao_suite_independence.py` guards that no test reads outside `src/`, `tests/`, `tests/fixtures`; the full suite passed with the folders outside `src/` and `tests/` renamed. Golden results equal within 1e-8, fingerprints identical. DECISIONS 171.

## 2026-11-06 - Countertrade sensitivity exact by construction

- The countertrade variables are summed from the per-unit sensitivities in batches of contingencies (`compute_ct_nx`, `ct_sensitivity.aggregate_units`); zones, probe branches, the cut-off rule and the second analysis are removed; pruning equals the per-unit formulation (N-X per unit value before the sum, N-0 branch maximum over the units); the `aggregate_countertrade` exception is removed. Time is about 6 times the zone approach (the engine solves every unit). Tests `test_rao_ct_sensitivity.py`. DECISIONS 170.

## 2026-11-04 - Countertrade sensitivity per RA and direction
- One sensitivity variable per countertrade RA and direction (a pypowsybl zone with the weights; ct_sensitivity, N-0 and N-X, AC and DC), 2 terms per RA in every flow row instead of one per unit; countertrade-only units get no sensitivity of their own. Exact against the per-unit sum: units a contingency cuts off, units pypowsybl leaves out of a zone (second small analysis), pruning by entry (units keep their own sensitivities). sensitivity_rd_n0.csv / sensitivity_rd_nx.csv of countertrade runs list the RA-direction variables (re-baselined, these two files only); MILP fingerprints of the countertrade cases re-baselined. NaN-sensitivity warning: count and first 5 ids. Synthetic 300 units / 57 contingencies: peak memory 2184 -> 449 MB, 271 -> 10 s. Tests 	est_rao_ct_sensitivity.py. DECISIONS 169.

## 2026-11-04 - NCP 2.2 legacy form: topology RAs
- `note_topology_remedial_actions`: one info line per RA file with the number of topology RAs (no per-RA line); no other warning is triggered by them (test). All sections of the legacy harness pass now. Tests `test_rao_ncp_legacy_topology.py`. DECISIONS 168.

## 2026-11-04 - NCP 2.2 legacy form: countertrade
- A strategy value or `shiftMethod` of a countertrade RA is ignored with one warning per RA, the RA is kept (before: ignored); `countertrade_ra_specs.md` C2.2 and the table updated.; and `ct_units.read_control_areas` / `zones_from_control_areas`: without an Organisation file the zone EIC is matched to the CGM ControlArea with that EIC (units via ControlAreaGeneratingUnit, else the EQ file); `resolve_zone_units(zone_source=...)`. Harness section "countertrade" must pass; 14 existing tests of the old rule adapted. Tests `test_rao_ncp_legacy_countertrade.py`. DECISIONS 167.

## 2026-11-04 - NCP 2.2 legacy form: legacy shift key chain
- `_use_current_shift_key_chain` in `_load_graph`: GLSKSchedule / ParticipationFactorTimePoint.GLSKSchedule / GLSKBidActionDistribution become the PowerShiftKey chain for the bids the current chain does not cover; one info line per file. Harness sections "redispatch units" and "glsk" must pass (the harness sorts list fields: rdflib hash order). Tests `test_rao_ncp_legacy_shift_keys.py`. DECISIONS 166.

## 2026-11-04 - NCP 2.2 legacy form: bid direction
- `parse_power_bids`: direction from the literal, else from the name suffix `_UP` / `_DOWN`, else the bid is skipped (one summary warning per file); the sign-of-p cross-check is removed. Harness section "bids" must pass (all 56 bids of the legacy mock equal the current ones). Tests `test_rao_ncp_legacy_bids.py`; four existing tests adapted to the removed cross-check and the name fallback. DECISIONS 165.

## 2026-11-04 - NCP 2.2 legacy form: N-X gaps
- `LfNx` (dict with `not_monitored`, `tripped`, `dropped`) from `compute_lf_nx`; the MILP builder skips known gaps silently and gives one summary per cause and constraint type (own equipment: debug); a contingency that islands a monitored branch is evaluated without it (no more "likely network split" skip), one summary per run; skipped contingencies carry the real reason (`no impact: equipment already disconnected` as INFO, failed load flow as WARNING), one INFO line counts the security analysis status; the applied-state skipped dict is debug; `results_contingency_status.csv` keeps its header (dropped branches in `skipped_reason`). The NaN N-0 sensitivity warning names the branch type, state, side and what the analysis returned (not reproduced). `tests/conftest.py` resets the once-per-run warnings per test. Tests `test_rao_nx_gaps.py`. DECISIONS 164.

## 2026-11-03 - NCP 2.2 legacy form: MVA limits, ae_contingency_combination, contingencies without equipment
- `build_branch_limits` converts the APPARENT_POWER limits (MVA) of a side without a CURRENT limit to amperes (PATL and TATL, one summary line); the side of an `ApparentPowerLimit` is read like a `CurrentLimit`'s. New `workflow_toggles.ae_contingency_combination` (`standard` | `all_contingencies`, `ConfigKeyError` on a bad value, one warning per run; both config files and the User Guide). A contingency without equipment is not sent to the security analysis and is listed as skipped (the parser keeps it, coverage C8); the equipment not in the CGM and the excluded contingencies are one summary each. The N-0 warning for a branch without a result names the branch type and its connected state. Dangling lines in N-0 / N-X could not be reproduced on a CGMES network (tests added, no change). Secured / scanned rule described only. Tests `test_rao_cgm_limits_and_combination.py`. DECISIONS 163.

## 2026-11-03 - NCP 2.2 legacy form: single-TSO CGMES 2.4.15 CGM
- Dangling lines and tie lines are branches everywhere a branch is resolved (names, equipment types, currents AC and DC, static PATL, TATL, DC converter, zone exchange names); side 1 for a dangling line. N-X split check only for branches that the N-0 result has. `exclude_without_usable_patl` (PATL 0 or none is never used). `parse_psts` accepts a PowerTransformer in `TapPositionAction.TapChanger` (`add_transformer_references` in the tap changer map). `pre_milp/log_summary.py`: count and first 5 ids for the skipped N-X contingencies, the PATL warnings, "missing or invalid PATL", "limit of 0.0 A", "switched off or restricted by NCP switches". Tests `test_rao_cgm_branches.py`. Transformer PATL (cause C) was not confirmed in the code. DECISIONS 162.

## 2026-11-03 - Golden matrix tolerance 1e-9 -> 1e-8
- `tests/tools/golden/compare_runs.py`: relative (and column-scaled) tolerance 1e-8 (DECISIONS 161): the same cases differed by 1.2e-9 to 1.5e-9 in parallel gates and by 0 alone. README of the golden folder updated. Nothing else changed; no baseline touched.

## 2026-11-01 - NCP 2.2 legacy form: NCP namespaces
- `ncp_parser._load_graph` rewrites the legacy `nc` / `cim` namespaces of an NCP file to the current ones (only for a namespace the file declares, triple order kept; CGM loads untouched). Legacy mock: the declared namespaces, `eu`, `xml:base`, full enum URIs. Harness compares parsed lists order-insensitively; tests `test_rao_ncp_legacy_ncp_namespaces.py`. A legacy-mock run parses 29 AEs, 16 contingencies, 12 PSTs (RD units and bids need their own readers). DECISIONS 160.

## 2026-11-01 - NCP 2.2 legacy form: header by local name, namespaces
- `ncp_header` reads creator / conformsTo / keyword by local name (legacy headers declare `dcterms` and `dc` with a trailing `#`). `pre_milp/cgm_namespaces.py` lists the CGMES 3.0 and 2.4.15 (cim16) namespaces and the entsoe extension forms; `ncp_parser._eq_terms`, `eq_stream`, `tso_name_resolver` use them, so tap changer, current limit and control-area readers resolve a 2.4.15 EQ file. Mock: `#` namespaces in the headers, a PST and a current limit in the 2.4.15 snippet. Tests `test_rao_ncp_legacy_namespaces.py`. DECISIONS 159.

## 2026-11-01 - NCP 2.2 legacy form: creator and nested CGM
- `ncp_header` reads the creator as text or `rdf:resource`, any EIC base, hyphens kept, and says why a creator is unreadable (logged by `ncp_loader` with the file name); `cgmes_loader.extract_cgm_zip` extracts inner zips, `find_eq_files` searches sub-folders and decides by the header profile (CGMES 3.0 and 2.4.15); the control-area and HVDC readers use it. Countertrade unit log line: counts and first 5 ids, full list at debug. Legacy mock: real header form, 16-character EICs, two zone bases. Tests `test_rao_ncp_legacy_blockers.py`. Timestamp list unchanged (golden outputs hold entries 2 to 4). DECISIONS 158.

## 2026-11-01 - PST rows: one per transformer and kind
- `ncp_parser.check_unique_pst_rows` (called in `run_pipeline` after the per-TSO parse): two available PST rows of the same kind on one transformer stop the run with a clear error (DECISIONS 157); `PST.ra_mrid` added (not compared). Tests `test_rao_pst_duplicate_rows.py`. Test fix: `test_rao_ncp_leading_underscore.py` compares fingerprints by structure and result files with the golden tolerance (the pypowsybl / solver noise made it flaky in the parallel suite).

## 2026-11-01 - NCP 2.2 legacy form: files and TSO
- `pre_milp/ncp_header.py` reads profile and creator from the header; `ncp_loader` classifies by header (name rule only for a file whose header names no profile), looks in sub-folders, finds the organisation file by header, logs the unused profiles SSI / IAM / PS once each; `extract_ncp_zip(require_organisation=False)`; `run_pipeline` runs without a CD file (TSO = creator EIC, one warning). Tests `test_rao_ncp_legacy_files.py`; harness section "files" passes. Current form unchanged. Decisions (DECISIONS 156): EQ maps from all EQ files, per-TSO setting keys by name or EIC (`resolve_tso_keyed_setting`), extraction folders emptied per run, writer moved to `tests/mock_builders/legacy_writer.py`, zone as EIC URI in the mock.

## 2026-11-01 - NCP 2.2 legacy form: mock and harness
- Spec: section 13 of `specs/ncp_data_requirements.md`, DECISIONS 155, ASSUMPTIONS. `tests/mock_builders/legacy_writer.py` writes the mock in the legacy form (`ncp22-legacy OUT.zip` of the fixture tool) and a small CGMES 2.4.15 EQ snippet. Harness `tests/test_rao_ncp_legacy_equivalence.py`: AE, CO, PST sections pass, files / bids / shift keys / countertrade are strict xfail until their readers exist. No change in `src/`.

## 2026-10-28 - Curative PST taps are integer (DECISIONS 154)

- `milp_builder`: the curative tap variables use the domain of the preventive taps (integer when `pst_taping_discrete`). Two new tests, one test setup changed (it relied on a tie). 9 of 52 golden baseline folders replaced (8 tie-breaks, 1 real change: one case, objective +57.67 EUR). Docs updated.

## 2026-10-26 - The HVDC mock pair in `input/` (DECISIONS 147)

- `input/` holds `CGM_package_hvdc.zip` and `NCP_mock_hvdc.zip`; the previous pair is in `tests/fixtures/`. New User Guide section "HVDC use case". Defaults unchanged (objective 0 with them); with `ra_types` pst+rd+hvdc and N-1 on the objective is 158,953 (AC) and 101,820 (DC). Gate unchanged.

## 2026-10-26 - A leading "_" in NCP ids and references is ignored (DECISIONS 146)

- `ncp_parser.ncp_id` (one helper, used by `_frag` and by every `IdentifiedObject.mRID` read from an NCP file) removes one leading `_`; HVDC RA files written that way now give 2 units in 1 balanced group. New `tests/test_rao_ncp_leading_underscore.py` (29 tests, 24 failed before). Gate unchanged.

## 2026-10-26 - Shared-bid redispatch cases (DECISIONS 118-125)

- Test data on P: shared-bid cases A, A_strategy, B, C and the preventive twins `B_preventive`, `C_preventive` (the curative B and C were dropped again, they cannot move because of the curative balance); case D on four units at four substations, with two preventive and two curative shared RAs that are all activated in a full run. New warning `warn_curative_no_net_movement` (one per contingency in which the curative RD RAs have only one direction or one common key); the model is unchanged. 54 tests in `test_rao_rd_shared_bid.py`. Decisions recorded: surplus above the first unit limit accepted, one price per bid.

## 2026-10-25 - Golden matrix README (docs only)

- New README of the golden matrix: the 52 runs by pattern, baselines, comparison rule, gate steps, scripts and commands.

## 2026-10-25 - Link check in the gate (DECISIONS 145)

- `check_doc_links.py` is the last step of the gate (a dead link in a live file fails it; history files and a small whitelist are exempt). 6 tests of the checker. No behaviour change.

## 2026-10-25 - Docs reorganisation (DECISIONS 144)

- The feature specs moved to `docs/specs/`, the NCP data files to `docs/data/`; 93 references re-pointed; `docs/README.md` index updated. Files byte-identical, no behaviour change.

## 2026-10-25 - Assessed-element combination switches (DECISIONS 143)

- `isCombinableWithContingency=false` is applied: the element is assessed after the contingencies with an `included` link only. A link with a missing, unknown or `considered` kind is treated as absent (counting warning); a disabled link stays ignored; `inBaseCase=false` with a `BaseCaseCurrentLimit` is scanned in the base case. `isCombinableWithRemedialAction` and the remedial-action links stay warn-only (ASSUMPTIONS OPEN-33). Mock and golden matrix unchanged; 5 new tests, 3 adapted.

## 2026-10-24 - Zero-sensitivity terms left out of the N-X rows; pruning cases in the golden matrix (DECISIONS 142)

- Only with an N-X pruning threshold above 0 (default 0: nothing changes). Countertrade mock with 0.02 %: 10.9 s to 9.2 s, 394 to 377 MB, same optimum. Four cases `mockpruned__*` join the matrix (52 runs); the 48 old cells are unchanged. 5 new tests.

## 2026-10-24 - Golden matrix cases with countertrade on (DECISIONS 140)

- Six cases `mock__*__pst+rd+countertrade__nx*` join the matrix. The `last_solve_*` columns get an absolute tolerance of 1e-6 in `compare_runs.py` (solver tolerance in a diagnostic column made one case not reproduce). 2 new tests; the old cells are unchanged.

## 2026-10-24 - Assessed-element switches and links are applied (DECISIONS 141)

- `normalEnabled` / `enabled` at the run time (element not monitored), `inBaseCase` (no N-0 row) and links to contingencies (included / excluded) are applied; every element switched off or restricted is logged. `isCombinableWith*` stay warn-only and the warning says why (OPEN-31). Existing cases unchanged. 24 new tests.

## 2026-10-24 - The run time comes from the CGM (DECISIONS 138)

- The CGM scenario time selects every time-dependent NCP value (bids, PATL, participation factors, unit costs, group limits) when the NCP has points on its date; otherwise the start hour 1030Z and the per-reader fallbacks as before, logged. A series of one point exactly at the CGM date and hour counts (4 tests). Existing cases unchanged; 16 new tests. Open (ASSUMPTIONS OPEN-32): whether a CGM without scenario time should stop with an error.

## 2026-10-24 - Performance: N-X sensitivity table, curative RD rows, N-0 guard (DECISIONS 132-134)

- `SensitivityTable` replaces the dict of tuples per contingency in the AC mode (same keys, values and order; 18 times less memory on a synthetic set). The curative RD rows use pairs grouped once by contingency and unit (480 contingencies: build 19.0 s to 1.7 s). `resolve_n0` groups by branch once (129000 entries: 12.7 s to 0.02 s). 28 new tests; matrix and fingerprints unchanged.

## 2026-10-24 - Performance: parse once, stream the EQ files, read solved values once (DECISIONS 135-137)

- `graph_cache()` keeps the NCP graphs for the run (countertrade mock 20.8 s to 16.0 s); `eq_stream.stream_eq` answers the EQ map readers without rdflib, with rdflib as the fall-back (pst+rd run 10.7 s to 6.8 s); `_SolvedValues` evaluates each solved value once in the N-X exports (3000 rows x 600 units 4.5 s to 0.25 s). 24 new tests; matrix and fingerprints unchanged.

## 2026-10-24 - Review fixes: warnings, bid lookup, bid days, curative limits (DECISIONS 128-131)

- Counting warnings for unread data (countertrade shift keys, contingencies without `normalMustStudy`, non-restrictive dependencies, disabled alterations, assessed-element switches); the countertrade "ignored" line names its real reason; bids and bid-route distributions are found by rdf:ID; a bid schedule with points on several days is read by date and time. Curative Pmin/Pmax stays one row pair per unit over the maxima, as the spec requires. `compare_runs.py` compares integer cells exactly. DECISIONS 20, 31, 37 marked superseded and old paths corrected. 25 new tests.

## 2026-10-24 - Fixture tool, countertrade bids in P, renamed zips and cleanup (DECISIONS 126, 127)

- The mock-data generators and the golden-run scripts moved into one fixture tool (`paths`, converter, `standard`, `countertrade_p`, `ct_mock`, `hvdc_mock`, `ncp_dataset`, `zipio`, command line, golden matrix, gate, `baseline.zip`); no behaviour change, no generated zip changed by a byte.
- P carries 8 countertrade RAs (a preventive and a curative one per region); the other mocks start from the base without them, so their matrix cases are unchanged. With the default `ra_types` every run on P logs 8 "countertrade RA ... IGNORED" lines. Zips renamed (`NCP_mock_standard.zip`, `NCP_mock_legacy.zip`, `NCP_sample_generic_2_4.zip`). Docs reorganised; open items moved into ASSUMPTIONS. 55 test files, 2085 passed, 6 skipped, 1 xfailed; matrix 0 differences; fingerprints identical.

## 2026-10-23 - NCP standard form: readers (DECISIONS 106-117)

- Standard-form readers: group limits through the schedule chain; countertrade without a strategy attribute; HVDC penalty default 1.0 and warnings for per-RA caps, bid dependencies and availability schedules; bid direction literal, sign cross-check, `interpolationKind`; `combinationConstraintKind`; shift keys with CIM generating units, both unit routes; redispatch as `RedispatchRemedialAction` with units from the shift keys. Old forms are fallbacks with one deprecation warning per file.
- The `*_model_diff_pct` tolerance is 1e-6 absolute and numeric columns get a dust floor of 1e-9 absolute (DECISIONS 112). The generic sample's second redispatch RA is now recognised, still without units. `NCP_pst_fallback_scenario.zip` regenerated in the standard form. New test files for the combination kind, standard shift keys and standard redispatch; golden matrix of the P cases and fingerprints unchanged. Open: disabled assessed elements, the old forms to be removed in the next release.

## 2026-10-23 - NCP standard form: converter and equivalence harness (no parser change)

- A converter rewrites the old-form mock NCP into the standard form (deterministic, values and signs unchanged, every change logged), and `test_rao_ncp_standard_equivalence.py` compares both zips parsed with the current parser; sections without a reader were strict xfails until their readers existed. Decisions 85-105 recorded; the official sample's licence is unclear, so only its structure is used, with own ids. 22 passed and 6 xfailed new; suite 1888 -> 1910. Open: bid sign (OPEN-30), disabled assessed element (OPEN-29).

## 2026-10-22 - Empty curative PST range ignored with a warning (DECISIONS 84)

- `build_pst_tap_bounds_curative`: a curative range whose lower bound is above its upper bound gives a warning naming the PST and both bounds and is ignored (the PST falls back to its operating range); lower = upper stays valid. Before, Pyomo refused to build the row and the run stopped. Tests: the variant test changed, new variant `fixed_curative_tap_range`, an `ac_iterative` run with the inverted range; mutation checks kill both. Suite 1888 passed; golden matrix unchanged apart from timing columns and run-to-run noise.

## 2026-10-22 - Run-to-run variation located; out-of-reach curative range recorded (ASSUMPTIONS 16, 17; docs only)

- The variation of about 1e-11 relative comes from OpenLoadFlow (last bits of the sensitivities for double-line outages); discrete results are unaffected (100 runs). The comparison rule is: equal within 1e-9 relative or 1e-9 of the column maximum, text, statuses and counts exact, timing columns skipped. A non-empty curative range that no allowed tap can reach makes the MILP infeasible; decided not to fix, to count on non-public data.

## 2026-10-21 - NCP test dataset and two input fixes (DECISIONS 81-83)

- `parse_psts`: a zero or unreadable `timePerStage` is left unset with a warning instead of a division by zero. New `warn_unmatched_ra_references` (one warning per contingency link and per bid whose RA reference matches no RA of the file). The PST range direction (`up` / `upAndDown` upper, `down` lower) is recorded as intended.
- Generated NCP test dataset on `CGM_package.zip` with its coverage file (102 rows: 2 fixes, 47 valid-package rows, 53 invalid or warning variants); the valid package runs in the three modes with all four RA types and N-X on. New dataset test files (104 mutations all caught); targeted tests 566 passed; golden matrix unchanged within 1e-9 relative apart from timing columns; fingerprints unchanged.

## 2026-10-20 - Countertrade: unit file with RD and CT apart, CT-only units (DECISIONS 79, 80)

- In a run with countertrade `result_production_mw` is the final dispatch (initial + RD + CT), the RD columns stay the RD part and a new column `ct_volume_net_mw` holds the CT part; every CT unit in no RD glsk gets its own row. Without countertrade the file is unchanged. New mock scenario with CT and HVDC acting together; each new assertion fails under a mutation. Suite 1753 -> 1759; golden matrix no difference above 1e-9.

## 2026-10-20 - Countertrade review fixes (DECISIONS 76, 77)

- The RD columns of the unit file are summed from the cumulative RD bid volumes (before, the build baseline carried countertrade moves of earlier iterations into a shared unit); the CT glsk file is written only with a usable CT RA; the limit log uses the final combined dispatch; one log line per RA and direction for an empty direction. Mock zip byte-identical between builds; new behavioural tests, each failing under a mutation. Suite 1730 -> 1753.

## 2026-10-20 - Countertrade remedial actions (`ra_types: countertrade`, DECISIONS 69-78)

- New RA type: a bid per bidding zone whose volume is spread over the zone's generators by remaining-capacity weights (up: Pmax - PROD, down: PROD - Pmin, normalised after the exclusion, computed once from the original set points), preventive and curative, in all three modes, with or without `rd`. CT is in the global and per-contingency balance with RD; hard Pmin/Pmax rows on the RD + CT total; one-sided on/off rows; cost = penaltyFactor x `penalty_reference_ct_pra` / `_cra` x volume plus bid price and activation cost. New modules for CT parsing, weights and results export; the milp builder takes `CtMilpInputs`; GUI toggle and two reference inputs. Without `countertrade` nothing changes (golden matrix of 9 runs: 0 differences).
- Outputs only with `countertrade`: CT results, curative CT results, CT glsk, CT availability, net positions, zone exchange, six summary rows; the RD result files stay RD-only. The input data has no valid CT RA, so the feature is tested on a generated mock. Tests: 8 new files (about 210 tests); suite 1523 -> 1730. Open: the `gLSKStrategy` predicate names are an implementation choice.

## 2026-10-20 - Docs refresh and a scanned-row test

- Citations in the validation reference, the MILP formulation and `Spec_Coverage.md` re-mapped to the code; new test for a hard N-0 scanned row with only curative RD (N-X on). Suite 1759 -> 1760.

## 2026-10-19 - HVDC review fixes (DECISIONS 68)

- A CGM set point outside the resolved range widens the range to include it, with a warning (before, the hard bounds forced a paid move or made the model infeasible). A `balanced` group without any HVDC unit is skipped with a log line; the unit-in-two-groups check runs over all groups first; only HVDC ranges are read and warned about. EquivalentInjection minP/maxP stay in generation sign (pinned by a test). Tests for the new rules and for three breaks the review found uncaught (N-X HVDC sensitivities refreshed every iteration, outage-element gate wired from the pipeline, initial N-X zero units in single pass and dc). Suite 1501 -> 1523; golden matrix without `hvdc` (24 runs): 0 differences.

## 2026-10-19 - HVDC remedial actions (`ra_types: hvdc`, DECISIONS 60-67)

- New RA type: two generating-like EquivalentInjection units per link in a `balanced` group, preventive and curative, in all three modes. Balance dg1 + dg2 = 0, range = the most restrictive `RangeConstraint` capped by the technical limits, exact curative bound per contingency, cost = penaltyFactor x reference x change. New `hvdc_units` module, HVDC sensitivities and guards, `HvdcMilpInputs` with preventive and curative blocks, loop changes (write-back through the RD `target_p`, criteria 1 and 3), config keys `penalty_reference_hvdc_pra` / `_cra`, GUI toggle. Without `hvdc` nothing changes (21 combinations: 0 differences); documented exception: restrictive groups with `DependingRemedialActionGroup` are now found, and a hard scanned N-0 row without any variable now builds.
- Outputs only with `hvdc`: HVDC results, curative HVDC results, availability, three summary rows. Tests: 6 new files (about 250 tests) and the generated HVDC mock; suite 1233 -> 1501. Open: HVDC link contingencies (converters, DC line) are not modelled; the validation reference citations were not re-checked.

## 2026-10-18 - Text encoding: UTF-8 without BOM, explicit everywhere (DECISIONS 59)

- New `text_encoding.TEXT_ENCODING`, used at every text read and write of the pipeline (29 CSV writers, run log, YAML), the GUI and the tests; the GUI pipe is decoded as UTF-8 and the child gets `PYTHONIOENCODING`. A config file that is not valid UTF-8 stops the run naming the file. Before, the platform default (cp1252) was used, and a name outside it would have stopped the run. 7 new tests (AST scan for calls without an encoding, a run with non-Latin line names, the GUI pipe); golden outputs identical apart from one file whose bytes changed by the encoding alone. Suite 1226 -> 1233.

## 2026-10-18 - calculation_mode dc: review fixes

- A failed final AC check keeps the DC solution and the N-X loadings show the model's prediction (DECISIONS 51); the factor table and `dc_power_factor` are validated only in `dc` (57); a saved `dc_power_factor` that is not > 0 becomes 1.0 with a note (58); `dc_mode` is no longer written into the GUI settings (56); the separate DC backend is removed (50). Tests: factors against the pypowsybl i1/i2, N-X sensitivities by finite difference, migration, dc-only validation; 10 breaks all detected. AC modes unchanged (8 of 8 golden comparisons identical). Suite 1204 -> 1226.

## 2026-10-18 - calculation_mode dc

- New `dc` mode: DC load flow, DC security analysis and DC sensitivities, one MILP solve, one apply, one final AC check. Config `dc_mode.current_factor_by_nominal_voltage_kv` and `dc_power_factor`; new `dc_conversion.DcCurrentConverter`; DC primitives take an optional `dc_converter` (None = the unchanged AC path); new `dc_pass.run_dc_pass`; summary rows in `dc` only; GUI selection. The N-X deviation check of the sensitivity guard uses 5 % in `dc` (DECISIONS 55). New tests for the conversion (19), the mode and 12 runs of the pass; AC modes unchanged (176 files, 262,525 cells: 0 differences). Suite 1125 -> 1204.

## 2026-10-17 - ra_types and calculation_mode: review fixes

- The final check of `ac_single_pass` covers every pair of the refreshed N-X analysis, not only the pairs in the model, and reports without adding pairs; `ra_types` with a nested list gives the normal error; the GUI keeps the chosen mode in a non-widget session key. New tests for pairs outside the model and for the GUI pages. Suite 1106 -> 1125.

## 2026-10-17 - ra_types and calculation_mode

- `workflow_toggles.ra_types` (`pst`, `rd`) replaces the two enable keys (no alias; the old keys give an error naming `ra_types`); `calculation_mode` is `ac_iterative` (default) or `ac_single_pass` (`dc` stopped at startup then). Both are validated at the start of `main()`. A disabled type leaves no file. New `single_pass` module (one build, solve, apply and final check) and `build_model_at_state` / `apply_solution_and_refresh` cut out of the loop. New status `SINGLE_PASS`, summary rows, GUI toggles with caps and thresholds greyed out in single pass. 60 new tests; suite 1046 -> 1106. Open: DC (then still reserved).

## 2026-10-16 - Docs tidy (docs only)

- Duplicate spec copy removed, the curative RD / TATL spec moved next to the other specs, `Spec_Coverage.md` paths updated with 8 deferred rows, comment and name clean-ups in `src/app.py` and one test.

## 2026-10-12 - Coverage check and data-validation reference (docs only)

- Coverage checklist filled from the code and tests (72 rows: 31 built, 6 partly, 6 deviation, 29 not built) and a data-validation reference (checks per area, 78 silent drops and defaults). No source or test change. Open: the Partly rows (SAR cross-check, operating tap limits, RA count for preventive RD only, continuous curative taps, per-contingency Pmax/Pmin).

## 2026-10-11 - Performance quick wins (results identical)

- Mock N-X case 16.0 s -> 10.5 s, generic 12.5 s -> 7.9 s, outputs byte-identical (timing columns excluded). Each EQ file is parsed once (RDF parsing 9.05 s -> 4.80 s); `compute_lf_nx` reads the security analysis in one pass (0.92 s -> 0.22 s); N-X sensitivities use one factor matrix per side for all contingencies with a numpy read-back (1.19 s -> 0.61 s); PST and RD N-X sensitivities come from one analysis (0.61 s -> 0.48 s). Summing only non-zero sensitivities was not kept (outputs differed in the last digits).
- New config keys `performance.lf_thread_count`, `performance.solver_time_limit_seconds`, `performance.solver_mip_rel_gap` and `outputs.write_nx_sensitivity_csvs` (defaults keep the earlier behaviour). Found: a run-to-run variation in the last digits that exists with the old code too (ASSUMPTIONS 16). Suite 908 -> 947 passed.

## 2026-10-11 - Tests and code no longer need the data folder; smoke tests removed

- A tree shaped like the dataset instance is built once per session from `tests/fixtures`, so the 41 tests that skipped without the data folder now run on the fixtures (no assertion changed, no test deleted). `load_cgm` needs the zip path (no default source). The data folder, the smoke tests and their comments are removed; `requirements.txt` also holds the GUI packages. Suite 908 passed, also with the data folder renamed.

## 2026-10-11 - Follow-ups, comment clean-up and code review fixes

- Comments and docstrings of `src/rao` and `tests/` describe the current code (history, requirement ids and document references removed; comment lines `src/rao` 5267 -> 1720); the AST without docstrings is identical. Requirement ids removed from code strings and config comments. Code review fixes: a stop in a later completeness iteration returns the last applied model; `remaining_overload_count` reads secured branches only; a non-optimal solve ends the loop with `SOLVER_NON_OPTIMAL`; NaN Pmax/Pmin, NaN N-0 sensitivity and missing N-0 current are excluded with a warning; PST and RD `penaltyFactor` default 1.0 with a warning; bid price missing or negative = 0 with a warning. Dead helpers removed. Suite 908 passed.

## 2026-10-11 - Test merge: one test file per source module

- Test files merged to mirror the modules (ncp_parser, glsk_resolver, sensitivity_checks, lf_parameters, n0 and nx results export, milp_builder in four files, cra_preprocessing, ac_convergence_loop, post_ra_congestion_check, output file registry, run_pipeline split into a fast file and an end-to-end file). Tests moved, not rewritten; 4 deleted (source-text tests or removed code); tests named `t1`..`t7` renamed after what they check. Suite 892 -> 888.

## 2026-10-11 - Source cleanup: dead code, duplicate helpers, merged modules

- Dead code removed (6 unused functions and their tests); one `select_by_side` in `data_model` replaces five copies; shared helpers imported instead of copied; `sensitivity_validation` and `sensitivity_reuse` merged into `sensitivity_checks`, `curative_pst_groups` into `cra_preprocessing`; `src/rao` has 26 modules. New `tests/helpers.py` for the builders test files used to import from each other, and `test_rao_frozen_imports.py` (17 tests) for the names the GUI imports. No behaviour change. Suite 884 -> 901 -> 892.

## 2026-10-10 - Docs in place, README matched to the repo

- Working documents and background documents split into two folders; instructions for contributors in one file. Three tests that read documents removed; comments no longer cite document files. README matched to the repo (Python 3.12.9, pinned requirements, code layout). Suite 884 passed.

## 2026-10-10 - Validation fix pass

- AE with no region code and no exclusion reason is excluded; scanned-only AE stays secured; PST with an empty tap range is dropped consistently; PATL <= 0 is excluded on the N-X side; missing or NaN N-X currents and sensitivities skip the pair with a warning; the export uses the builder's own curative effect; Pmax/Pmin default warns; `completeness_iteration_limit_reached` flag; skipped-contingency reasons in the contingency status file; config range checks. Suite 846 passed, 41 skipped. Open: NaN in N-0 sensitivities.
