# Specs

One row per file in this folder. Status: **current** = matches the code; **partly changed** = parts are changed by the named DECISIONS.md entries or later spec; **design as first built** = the original design, later changes are in `DECISIONS.md` and `Spec_Coverage.md`.

| File | Topic | Status |
|---|---|---|
| `functional_specs_25_1.md` | The functional specification (CORNET / BUC requirements) | Read-only functional specification; code tasks never change it |
| `calculation_mode_specs.md` | Calculation modes `ac_iterative`, `ac_single_pass`, `dc` and `ra_types` | Partly changed: DC is in `dc_mode_specs.md` (DECISIONS 46-57); GUI part DECISIONS 56, 206; one timestamp DECISIONS 172; output files DECISIONS 203-205 |
| `dc_mode_specs.md` | DC calculation mode | Partly changed: DECISIONS 46-57, one timestamp 172, output files 203-205 |
| `hvdc_ra_specs.md` | HVDC remedial action (`ra_types: hvdc`) | Partly changed: DECISIONS 108, 171, 172, 193, 203-205 |
| `countertrade_ra_specs.md` | Countertrade remedial action | Partly changed: DECISIONS 107, 167, 169-171, 173, 193, 203-205; legacy zones in `ncp_data_requirements.md` section 13 |
| `curative_rd_tatl_specs.md` | Curative redispatch, TATL, generator on/off, objective | Partly changed: DECISIONS 130, 154, 172, 182, 203-205 |
| `ncp_data_requirements.md` | What the parser reads from the NCP files and does with bad input | Partly changed: DECISIONS 109-111, 171, 173, 188, 199; legacy form in section 13 |
| `output_files_specs.md` | Output files of a run (names, columns, units) | Current (DECISIONS 203-205) |
| `data_ingestion_specs.md` | CGM and NCP loading | Design as first built |
| `pst_pra_specs.md` | N-0 MILP with preventive PSTs | Design as first built |
| `rd_pra_specs.md` | Preventive redispatch | Design as first built |
| `nx_cra_specs.md` | N-X constraints and curative PST / RD | Design as first built |
