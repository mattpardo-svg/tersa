# RAO prototype

Iterative MILP remedial action optimisation (security-constrained, N-0 and N-X) on CGMES data.
Stack: Python, pypowsybl (load flow, sensitivities, security analysis), Pyomo (`ConcreteModel`), HiGHS (`appsi_highs`).

## Scope
- Single timestamp: preventive PST, redispatch and HVDC set points (`ra_types: hvdc`, two EquivalentInjection units per link in a balanced group), N-X security constraints (secured and scanned elements), curative PST, redispatch and HVDC.
- Multi-timestamp work is out of scope here.

## Flow
1. Load the grid model (CGMES), parse the NCP files (assessed elements, contingencies, remedial actions, bids).
2. Initial load flow and N-X security analysis; sensitivities (PST, redispatch, HVDC) for N-0 and N-X.
3. Build and solve the MILP; apply the result to the grid model; new load flow.
4. Convergence check; refresh baselines and sensitivities; repeat (inner loop).
5. Completeness check for newly congested pairs (outer loop).
6. Write results (CSV files, run log).

## Run and test (from the repo root)
- Run: `python src/rao/run_pipeline.py`. Modules import each other flat, so `python -m` does not apply. The GUI: `streamlit run src/app.py`. The optional environment variables `RAO_INPUT_DIR`, `RAO_CONFIG_DIR` and `RAO_OUTPUT_DIR` set the input, config and output folders (the GUI uses them for its runs).
- Non-public data means any grid or market data that is not part of the public mock data in tests/fixtures/.
- Input: non-public data goes into `input/` (one `cgm*.zip` and one `ncp*.zip`), placed by hand; prefix match, case-insensitive, exactly one of each. They are extracted to `input/_extracted_cgm` and `input/_extracted_ncp`. `input/` holds the HVDC mock case: `CGM_package_hvdc.zip` and `NCP_mock_hvdc.zip` (DECISIONS 147). The previous pair, `CGM_package.zip` and `NCP_mock_standard.zip`, is in `tests/fixtures/`; to use it, copy the two old zips into `input/` and move the two HVDC zips out (exactly one cgm* and one ncp* zip must stay). For a run on non-public data replace both by hand.
- Output: one folder per run, `output/<CGM time>/` (UTC, `YYYYMMDDTHHMMZ`), with the CSV files and `run_log.txt`; a rerun with the same CGM time empties its folder first and other run folders stay. `summary.csv` carries the run status (including `SOLVER_NON_OPTIMAL`); the files only describe what was applied to the network (`docs/User_Guide.md`, `docs/specs/output_files_specs.md`).
- Config: `src/rao/config/rao_config.yaml` and `load_flow_config.yaml`. The `*.default.yaml` files hold the documented defaults; a missing key raises `ConfigKeyError`. Performance keys (defaults keep the earlier behaviour): `performance.lf_thread_count` (OpenLoadFlow threads of the security and sensitivity analyses, 1), `performance.solver_time_limit_seconds` and `performance.solver_mip_rel_gap` (HiGHS, null = not set; a stop at the time limit ends the run as `SOLVER_NON_OPTIMAL`), `outputs.write_sensitivity_csvs` (false by default; true writes the six sensitivity files).
- Tests: `python -m pytest tests -q`. They need nothing outside `tests/`: the ReliCapGrid case is built from `tests/fixtures/CGM_package.zip` and `NCP_sample_generic_2_4.zip` (`tests/helpers.py`, `fixture_instance_root`, `build_fixture_input_folder`); no test reads `input/`.

## Environment
Python 3.12.9 (first line of `requirements.txt`). Install with `pip install -r requirements.txt` (pinned versions, GUI packages in their own section at the end; known good: pypowsybl 1.15.0, Pyomo 6.10.1, highspy 1.15.1 (solver `appsi_highs`), rdflib 7.6.0, PyYAML 6.0.3, pandas 3.0.3, numpy 2.5.1).
pypowsybl quirks: the permanent-limit sentinel is -1 in `get_operational_limits()` but 2147483647 in security-analysis violations; a cold-start load flow can fail where a warm start converges.

## Code layout (`src/rao`)
- `run_pipeline.py`: orchestrator (config, input zips, phases, exports). `data_model.py`: dataclasses, enums and `select_by_side` (the one per-side value picker). `output_file_registry.py`: the output file names and the delete of stale files.
- `pre_milp/`: `cgmes_loader`, `ncp_loader`, `ncp_parser`, `tso_name_resolver`, `glsk_resolver`, `scanned_elements`, `n0_sensitivity`, `nx_security_analysis` (N-X load flow, TATL), `nx_sensitivity`, `cra_preprocessing` (curative PST availability and curative PST groups), `pst_bounds`, `pst_groups`, `sensitivity_checks` (guard and reuse of the last valid sensitivities), `lf_parameters`, `inventory_summary`, `workflow_gates`, `dc_conversion` (the one MW to ampere conversion of calculation mode `dc`: factor table, `dc_power_factor`), `hvdc_units` (HVDC units and groups: structure checks, operating limits, solved-network check, EI description warning).
- `milp/`: `milp_builder` (Pyomo model), `milp_solver`, `ac_convergence_loop` (nested loops, convergence, cycle exit, and the build and apply steps both calculation modes share), `single_pass` (calculation mode `ac_single_pass` and its final check), `dc_pass` (calculation mode `dc`: one pass, final AC check), `operating_point_state`, `post_ra_congestion_check`.
- `post_milp/`: `n0_results_export`, `nx_results_export`.
- `src/rao_pages/`: Streamlit pages of the RAO GUI (main run page, load flow settings, RAO settings) that prepare inputs and config for `run_pipeline.py` and show its outputs; they never modify it. `src/app.py` lists only these three pages; the other pages of the platform and `src/core` are removed, and the one thing the pages took from `src/core`, the logger, is `src/rao_pages/_logger.py`.
- `tests/` (`fixtures/`; `conftest.py` has the fixtures, `helpers.py` the shared test builders, `mock_builders/` the builders of the mock data): one `test_rao_<module>.py` per source module, so the test layout mirrors the code layout. The `milp_builder` tests are split by model block (`test_rao_milp_builder*.py`); `test_rao_run_pipeline.py` has the fast `run_pipeline` tests and `test_rao_run_pipeline_end_to_end.py` the tests that run `main()`; `test_rao_single_pass.py` covers `single_pass` and the `ra_types` / `calculation_mode` runs; the `test_rao_dc_*.py` files cover calculation mode `dc`; the `test_rao_hvdc_*.py` files cover `ra_types: hvdc` on the mock NCP of `tests/mock_builders/hvdc_mock.py`; the `test_rao_ct_*.py` files cover `ra_types: countertrade` on the mock NCP of `tests/mock_builders/ct_mock.py`; the `test_rao_ncp_dataset_*.py` files cover the NCP test dataset of `tests/mock_builders/ncp_dataset.py` (runs of `main()` in the three modes with every RA type, and the invalid and warning variants read by the parsers); `test_rao_frozen_imports.py` checks the frozen names (the GUI imports some of them).

## Docs
- `docs/DECISIONS.md`: decisions and reasons. `docs/ASSUMPTIONS.md`: assumptions and what is still to verify on non-public data. `docs/CHANGELOG.md`: what changed. `docs/User_Guide.md`: how to run and what the output files contain. `docs/Spec_Coverage.md`: spec coverage per CORNET / BUC item, deviations and deferred items.
- `tests/tools/`: generators of the mock and test data (`python tests/tools/fixture_cli.py`; the standard-form mock NCP, the countertrade, HVDC and dataset mocks, the shared-bid cases) and the golden-run scripts (`tests/tools/golden/run_gate.py`: suite, golden matrix, fingerprints); see `tests/tools/README.md`. Nothing in `src/` imports it.
- `docs/specs/`: the requirement specs of the later features: `calculation_mode_specs.md`, `dc_mode_specs.md`, `hvdc_ra_specs.md`, `countertrade_ra_specs.md`, `output_files_specs.md` and the first-built designs `data_ingestion_specs.md`, `pst_pra_specs.md`, `rd_pra_specs.md`, `nx_cra_specs.md` (index in `docs/specs/README.md`).
- `docs/specs/ncp_data_requirements.md`: the NCP data rules (what the parser reads and what it does with bad input).
- Paths in `CHANGELOG.md` and `DECISIONS.md` are quoted as they were when written (the specs and data files have moved since).
- `tests/tools/check_doc_links.py`: checks that the relative links and the `docs/...` paths named in the docs, comments and docstrings exist.
- `docs/specs/functional_specs_25_1.md`: the functional specification; contributors may read it. `docs/specs/functional_specs_25_1.md` is read-only: code tasks never change it.
