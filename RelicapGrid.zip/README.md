# rao-prototype
RAO prototype using ReliCapGrid CGMES + NCP, pypowsybl, HiGHS

- `docs/README.md`: scope, flow, how to run and test, code layout, document index.
- `tests/tools/README.md`: generators of the mock and test data, the golden-run gate.
- Mock run: `python src/rao/run_pipeline.py` (`input/` holds the HVDC pair `CGM_package_hvdc.zip` + `NCP_mock_hvdc.zip`; the previous pair is in `tests/fixtures/`; see the User Guide, "HVDC use case"). Tests: `python -m pytest tests -q`.
