"""
test_rao_ct_outputs.py — the countertrade result files and summary rows (docs/specs/countertrade_ra_specs.md C11):
file contents against the MILP results, the registry, no CT files without countertrade, the zone exchange
(pairing of the five GA_BO ties, DC flows in the dc mode, an unpaired tie skipped) and the summary residual.
"""
import csv
import logging
from types import SimpleNamespace

import pyomo.environ as pyo
import pytest

from mock_builders import ct_mock
from helpers import FIXTURE_CGM_ZIP, run_pipeline_on_fixture_inputs
from post_milp import ct_results_export
from pre_milp.ct_units import CtZone

CT_FILES = {
    "results_countertrade.csv", "results_curative_countertrade.csv", "countertrade_glsk_resolved.csv",
    "ct_cra_availability.csv", "results_net_positions.csv", "results_zone_exchange.csv",
}
CO = ct_mock.CONTINGENCY_GA_BO5


def _read_csv(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _summary(output_dir):
    from helpers import read_summary
    return read_summary(output_dir)


def _run(tmp_path, mode="ac_single_pass", ra_types=("countertrade",), nx=False, prepare_output_dir=None, **mock_kwargs):
    tmp_path.mkdir(parents=True, exist_ok=True)
    ncp = ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip", **mock_kwargs)
    models, applied = [], []

    def keep_models(rp, monkeypatch):
        loop = rp.ac_convergence_loop
        build, apply = loop.build_n0_milp_model, loop.apply_preventive_solution_to_network

        def keeping_build(*args, **kwargs):
            model = build(*args, **kwargs)
            models.append(model)
            return model

        def recording_apply(network, pst_tap_solution, rd_target_p_solution):
            applied.append(dict(rd_target_p_solution))
            return apply(network, pst_tap_solution=pst_tap_solution, rd_target_p_solution=rd_target_p_solution)

        monkeypatch.setattr(loop, "build_n0_milp_model", keeping_build)
        monkeypatch.setattr(loop, "apply_preventive_solution_to_network", recording_apply)

    run = run_pipeline_on_fixture_inputs(
        tmp_path / "run", ncp, enable_nx_analysis=nx, ra_types=ra_types, calculation_mode=mode,
        customize_pipeline=keep_models, prepare_output_dir=prepare_output_dir,
    )
    return SimpleNamespace(output_dir=run.output_dir, models=models, applied=applied)


@pytest.fixture(scope="module")
def preventive(tmp_path_factory):
    return _run(tmp_path_factory.mktemp("ct_out_prev"))


@pytest.fixture(scope="module")
def curative(tmp_path_factory):
    return _run(
        tmp_path_factory.mktemp("ct_out_cur"), ras=ct_mock.curative_ras(), nx=True, patl_a=ct_mock.CURATIVE_PATL_A,
        contingencies=[ct_mock.ga_bo5_outage()],
    )


def _names(output_dir):
    return {p.name for p in output_dir.glob("*")}


# ---------------------------------------------------------------------------
# which files exist
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# results_countertrade.csv, the weights, the net positions
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# summary
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# curative files
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# zone exchange
# ---------------------------------------------------------------------------

BELGOVIA_AREA = "50487bb8-be6d-42a8-9358-cc0bbfe6cfa7"       # the CGM ControlAreas of the two zones
GALIA_AREA = "b20c892a-a5d2-4378-8744-c2cfea79d0be"


def _ga_bo_exchange(mode, set_points=None):
    """The exchange Galia -> Belgovia over the five GA_BO ties from a fresh network (with the generator set points
    `set_points` {generator: MW} written first, None: the original ones) and the load flow of `mode`: per tie the mean
    of the flow entering Belgovia and the negative of the flow entering Galia."""
    import run_pipeline
    from pre_milp import cgmes_loader

    network = cgmes_loader.load_cgm(FIXTURE_CGM_ZIP)
    for gu, target_p in (set_points or {}).items():
        network.update_generators(id=gu, target_p=float(target_p))
    if mode == "dc":
        cgmes_loader.run_initial_dc_loadflow(
            network, use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS)
    else:
        cgmes_loader.run_initial_loadflow(
            network, use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS)
    by_name = {}
    for row in ct_results_export.read_area_boundaries(network):
        if row["name"].startswith("TieLine_GA_BO"):
            by_name.setdefault(row["name"], {})[row["area"]] = row["p"]
    assert sorted(by_name) == [f"TieLine_GA_BO{i}" for i in range(1, 6)]
    assert all(set(halves) == {BELGOVIA_AREA, GALIA_AREA} for halves in by_name.values())
    return sum((halves[BELGOVIA_AREA] - halves[GALIA_AREA]) / 2.0 for halves in by_name.values())


def _zones():
    return {
        "Z1": CtZone("Z1", "BZ-One", ["A1"]), "Z2": CtZone("Z2", "BZ-Two", ["A2"]), "Z3": CtZone("Z3", "BZ-Three", ["A3"]),
    }


def _boundary(area, name, p):
    return {"area": area, "element": f"E-{area}-{name}", "name": name, "p": p}


# ---------------------------------------------------------------------------
# units at their limits (C5.2)
# ---------------------------------------------------------------------------

def test_a_unit_that_reaches_its_limit_with_countertrade_is_logged(caplog):
    from test_rao_milp_builder_ct import _generators, _inputs, _solved

    rd_inputs = _inputs(generators=_generators(A1={"target_p": 60.0, "min_p": 50.0}))
    model = _solved(rd_inputs)
    with caplog.at_level(logging.INFO):
        hits = ct_results_export.log_units_at_limits(model, rd_inputs)
    assert hits == [("A1", "Pmin")]
    assert sum("A1 reaches Pmin" in r.getMessage() for r in caplog.records) == 1


def test_a_unit_that_reached_its_limit_in_an_earlier_iteration_is_still_logged(caplog):
    # a later build of ac_iterative: 12.5 MW of the A-down / B-up pair are already applied (A1 at its Pmin 50, from
    # 60), the current set points hold them and the last solve moves nothing more; the final combined dispatch
    # (original + cumulative movement) is at Pmin
    from test_rao_milp_builder_ct import _generators, _inputs, _solve, _build

    used = 12.5
    current = _generators(A1={"target_p": 60.0 - 0.8 * used, "min_p": 50.0})
    current["A2"]["target_p"] -= 0.2 * used
    for gu in ("B1", "B2"):
        current[gu]["target_p"] += 0.5 * used
    rd_inputs = _inputs(
        generators=current, original_target_p_mw={"A1": 60.0, "A2": 300.0, "B1": 100.0, "B2": 100.0},
        cumulative_signed_volume_mw={"BID_A_DOWN": -used, "BID_B_UP": used},
    )
    model = _build(rd_inputs, loading=1100.0 - 0.46 * used)
    _solve(model)
    assert pyo.value(model.rd_net_injection_g["A1"]) == pytest.approx(0.0, abs=1e-6)       # the last solve: no move
    with caplog.at_level(logging.INFO):
        hits = ct_results_export.log_units_at_limits(model, rd_inputs)
    assert hits == [("A1", "Pmin")]
    assert sum("A1 reaches Pmin" in r.getMessage() for r in caplog.records) == 1


def test_no_unit_is_logged_when_no_limit_is_reached(caplog):
    from test_rao_milp_builder_ct import _inputs, _solved

    rd_inputs = _inputs()
    assert ct_results_export.log_units_at_limits(_solved(rd_inputs), rd_inputs) == []


def test_the_net_positions_show_the_rd_part_separately(tmp_path):
    result = _run(tmp_path, ra_types=("rd", "countertrade"), patl_a=60.0)
    rows = _read_csv(result.output_dir / "zone_net_positions.csv")
    assert all(abs(float(r["rd_change_mw"]) + float(r["ct_change_mw"]) - float(r["net_change_mw"])) < 1e-6 for r in rows)
    assert sum(float(r["net_change_mw"]) for r in rows) == pytest.approx(0.0, abs=1e-6)

