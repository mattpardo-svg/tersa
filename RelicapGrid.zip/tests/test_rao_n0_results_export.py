"""tests/test_rao_n0_results_export.py - tests for n0_results_export.py (result files of the preventive and curative solve).

Sections: results summary, RA count, curative RD, generating units, curative PST, files written by the mock pipeline run, lead times, the AC verification status columns, and the iteration and completeness files.
"""

import csv
import pyomo.environ as pyo
import pytest
import sys

from data_model import AcVerificationStatus, BidDirection, RAKind, AEType, AssessedElement, PowerBid, RDUnit
from milp.milp_builder import NxMilpInputs, PstMilpInputs, RdMilpInputs, build_n0_milp_model
from post_milp.n0_results_export import (
    extract_curative_rd_results,
    extract_rd_results,
    extract_results_summary,
    RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW,
    extract_ra_count_results,
    extract_curative_pst_delta_results,
    extract_curative_pst_results,
    )
from helpers import (
    _make_ae,
    _make_pst,
    REFERENCE_PST,
    REFERENCE_RD,
    _all_terms_scenario,
    BIDS,
    PENALTY_FACTOR,
    REFERENCE,
    _bid_rd_cost as _bid_curative_rd_results,
    _solved_model,
    _unit,
    _make_ae_mb_results as _make_ae_generating_units_results,
    _make_bid,
    _make_rd_unit,
    GROUP,
    _solve_group_model,
    _three_psts,
)
from pathlib import Path
from post_milp import n0_results_export
from text_encoding import TEXT_ENCODING  # noqa: E402

# ===========================================================================
# Results summary
# ===========================================================================

def _summary(model, pst_inputs, rd_inputs, **kwargs):
    rd_results = extract_rd_results(
        model, rd_inputs.rd_list, rd_inputs.bid_list, REFERENCE_RD,
        )
    curative_rows = extract_curative_rd_results(model, rd_inputs.rd_list, rd_inputs.bid_list, REFERENCE_RD)
    return extract_results_summary(
        model, objective_value=pyo.value(model.objective), pst_list=pst_inputs.pst_list,
        penalty_reference_pst_pra=REFERENCE_PST, rd_results=rd_results,
        curative_rd_results=curative_rows, **kwargs,
    )


def test_every_component_is_non_zero_and_they_add_up_to_the_objective():
    model, pst_inputs, rd_inputs = _all_terms_scenario()
    summary = _summary(model, pst_inputs, rd_inputs)
    components = [
        "sum_pst_penalty_cost_eur", "sum_curative_pst_penalty_cost_eur", "sum_rd_cost_eur",
        "sum_curative_rd_cost_eur", "sum_ra_count_penalty_eur",
        "sum_overload_slack_penalty_n0_eur", "sum_overload_slack_penalty_nx_patl_eur",
    ]
    for name in components:
        assert summary[name] > 1e-6, name              # scenario really exercises every term
    total = sum(summary[name] for name in components) + sum(
        summary[name] for name in (
            "sum_overload_slack_penalty_n0_scanned_eur", "sum_overload_slack_penalty_nx_tatl_eur",
            "sum_overload_slack_penalty_nx_scanned_eur",
        )
    )
    assert total == pytest.approx(summary["objective_value"], abs=1e-6)
    assert summary["objective_unaccounted_eur"] == pytest.approx(0.0, abs=1e-6)


def test_rd_penalty_is_not_added_a_second_time():
    """sum_rd_penalty_cost_eur is part of sum_rd_cost_eur: adding it would break the identity."""
    model, pst_inputs, rd_inputs = _all_terms_scenario()
    summary = _summary(model, pst_inputs, rd_inputs)
    assert summary["sum_rd_penalty_cost_eur"] > 0.0
    assert summary["objective_unaccounted_eur"] == pytest.approx(0.0, abs=1e-6)


def test_residual_detects_a_missing_component():
    """Without the curative RD rows the identity must visibly fail (residual = that cost)."""
    model, pst_inputs, rd_inputs = _all_terms_scenario()
    rd_results = extract_rd_results(
        model, rd_inputs.rd_list, rd_inputs.bid_list, REFERENCE_RD, )
    without = extract_results_summary(
        model, objective_value=pyo.value(model.objective), pst_list=pst_inputs.pst_list,
        penalty_reference_pst_pra=REFERENCE_PST, rd_results=rd_results,
    )
    full = _summary(model, pst_inputs, rd_inputs)
    assert without["objective_unaccounted_eur"] == pytest.approx(full["sum_curative_rd_cost_eur"], abs=1e-6)
    assert full["sum_curative_rd_cost_eur"] > 0.0


def test_duplicate_preventive_ras_on_one_transformer_are_costed_once():
    model, pst_inputs, rd_inputs = _all_terms_scenario()
    reference = _summary(model, pst_inputs, rd_inputs)["sum_pst_penalty_cost_eur"]
    duplicate = _make_pst("P1", RAKind.PREVENTIVE)
    pst_inputs.pst_list.append(duplicate)
    assert _summary(model, pst_inputs, rd_inputs)["sum_pst_penalty_cost_eur"] == pytest.approx(reference)


def test_pst_only_summary_has_zero_not_absent_rd_and_slack_metrics():
    pst = _make_pst("P1", RAKind.PREVENTIVE)
    pst_inputs = PstMilpInputs(
        pst_list=[pst], pst_tap_bounds={"P1": (-10, 10)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("B1", "P1"): -10.0}, pst_degrees_per_tap={"P1": 1.0},
        penalty_reference_pst_pra=REFERENCE_PST,
    )
    model = build_n0_milp_model(
        [_make_ae("B1")], "1030Z", lf_initial={"B1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )
    pyo.SolverFactory("appsi_highs").solve(model)
    summary = extract_results_summary(
        model, objective_value=pyo.value(model.objective), pst_list=[pst], penalty_reference_pst_pra=REFERENCE_PST,
    )
    assert summary["sum_curative_rd_cost_eur"] == 0.0 and summary["sum_ra_count_penalty_eur"] == 0.0
    assert summary["sum_overload_slack_penalty_nx_patl_eur"] == 0.0
    assert summary["objective_unaccounted_eur"] == pytest.approx(0.0, abs=1e-6)


# ===========================================================================
# RA count
# ===========================================================================

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


TIMESTAMP = "1030Z"


CONVERGED = AcVerificationStatus.CONVERGED


def _ae(branch_mrid: str) -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=branch_mrid, tso="TSO_A", ae_type=AEType.SECURED,
        branch_mrid=branch_mrid, secured_for_region=None, scanned_for_region=None,
        exclusion_reason=None, patl_ka={TIMESTAMP: 1.0}, branch_side=1,
    )


def _rd_unit(mrid: str, gu_mrid: str, tso: str) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso=tso, gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=1000.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _bid(mrid: str, ra_mrid: str, direction: BidDirection) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw={TIMESTAMP: 20.0},
        price_eur_mw=1.0, lead_time_h=0.0,
        activation_cost_eur=None, 
    )


def _solved_model_without_dispatch():
    """Two TSOs: TSO_A owns RA1 (UP) and RA2 (DOWN), TSO_B owns RA3 (UP).
    The branch is not overloaded, so the optimiser dispatches nothing."""
    rd_list = [_rd_unit("RA1", "GU1", "TSO_A"), _rd_unit("RA2", "GU2", "TSO_A"), _rd_unit("RA3", "GU3", "TSO_B")]
    bid_list = [
        _bid("BID1", "RA1", BidDirection.UP),
        _bid("BID2", "RA2", BidDirection.DOWN),
        _bid("BID3", "RA3", BidDirection.UP),
    ]
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list,
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 1.0}, "RA3": {"GU3": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            f"GU{i}": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": f"GU{i}"} for i in (1, 2, 3)
        },
    )
    model = build_n0_milp_model(
        [_ae("BRANCH1")], TIMESTAMP, lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )
    pyo.SolverFactory("appsi_highs").solve(model)
    return model, rd_list, bid_list


def _force_all_binaries_to_one(model) -> None:
    for ra_mrid in model.ra_mrids:
        model.ra_activated[ra_mrid].value = 1


def _extract(model, rd_list, bid_list, output_path=None):
    return extract_ra_count_results(
        model, rd_list=rd_list, bid_list=bid_list,
        )


def test_binary_one_with_zero_volume_gives_count_zero_and_raw_column_shows_one():
    """Given every ra_activated binary left at 1 while no volume is
    dispatched, When the RA counts are extracted, Then activated_ra_count
    is 0 for every TSO and the raw binary column still shows the model's 1s."""
    model, rd_list, bid_list = _solved_model_without_dispatch()
    _force_all_binaries_to_one(model)

    results = _extract(model, rd_list, bid_list)

    assert results["TSO_A"]["activated_ra_count"] == 0
    assert results["TSO_B"]["activated_ra_count"] == 0
    assert results["TSO_A"]["ra_activated_model_binary"] == 2
    assert results["TSO_B"]["ra_activated_model_binary"] == 1


def test_count_follows_net_volume_for_upward_and_downward_bids():
    """Given an upward volume on RA1 and a downward volume on RA2 (TSO_A)
    and nothing on TSO_B, When extracted, Then TSO_A counts 2 and TSO_B
    counts 0 even though all three binaries are 1."""
    model, rd_list, bid_list = _solved_model_without_dispatch()
    _force_all_binaries_to_one(model)
    model.rd_volume_upward["BID1"].value = 7.0
    model.rd_volume_downward["BID2"].value = 3.0

    results = _extract(model, rd_list, bid_list)

    assert results["TSO_A"]["activated_ra_count"] == 2
    assert results["TSO_B"]["activated_ra_count"] == 0
    assert results["TSO_B"]["ra_activated_model_binary"] == 1


def test_count_per_tso_is_consistent_with_preventive_rd_rows():
    """Given a mixed dispatch, When both extractors run on the same model,
    Then for every TSO the activated_ra_count equals the number of distinct
    RAs having a non-zero rd_volume_net_mw in the preventive RD results."""
    model, rd_list, bid_list = _solved_model_without_dispatch()
    _force_all_binaries_to_one(model)
    model.rd_volume_upward["BID3"].value = 4.0
    model.rd_volume_downward["BID2"].value = 3.0

    counts = _extract(model, rd_list, bid_list)
    rd_rows = extract_rd_results(
        model, rd_list=rd_list, bid_list=bid_list, penalty_reference_rd_pra=0.0,
        )

    for tso, row in counts.items():
        active_ras_in_rd_rows = {
            r["ra_mrid"] for r in rd_rows.values()
            if r["tso"] == tso and abs(r["rd_volume_net_mw"]) > RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW
        }
        assert row["activated_ra_count"] == len(active_ras_in_rd_rows), tso
    assert counts["TSO_A"]["activated_ra_count"] == 1
    assert counts["TSO_B"]["activated_ra_count"] == 1


def test_tolerance_constant_is_one_micro_mw_and_decides_the_boundary():
    """The named tolerance is 1e-6 MW: a net volume of 5e-7 MW is not an
    activation, 2e-6 MW is."""
    assert RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW == 1e-6

    model, rd_list, bid_list = _solved_model_without_dispatch()
    _force_all_binaries_to_one(model)
    model.rd_volume_upward["BID1"].value = 5e-7
    model.rd_volume_upward["BID3"].value = 2e-6

    results = _extract(model, rd_list, bid_list)

    assert results["TSO_A"]["activated_ra_count"] == 0
    assert results["TSO_B"]["activated_ra_count"] == 1


def test_net_volume_at_the_edge_of_the_tolerance_decides_the_count():
    """Given net volumes 1 % below and 1 % above the named tolerance, When
    the RA counts are extracted, Then only the one above counts as an
    activation (the extractor reads the named constant, not a copy of it)."""
    model, rd_list, bid_list = _solved_model_without_dispatch()
    _force_all_binaries_to_one(model)
    model.rd_volume_upward["BID1"].value = RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW * 0.99
    model.rd_volume_upward["BID3"].value = RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW * 1.01

    results = _extract(model, rd_list, bid_list)

    assert results["TSO_A"]["activated_ra_count"] == 0
    assert results["TSO_B"]["activated_ra_count"] == 1


# ===========================================================================
# Curative RD results
# ===========================================================================

NEED = {b[0]: {"CO1": b[3], "CO2": b[4]} for b in BIDS}


PRICE = {b[0]: b[2] for b in BIDS}


DIRECTION = {b[0]: b[1] for b in BIDS}


def _lists():
    rd_list = [_unit(f"RD_{b[0].removeprefix('BID_')}", "GU") for b in BIDS]
    bid_list = [_bid_curative_rd_results(b[0], f"RD_{b[0].removeprefix('BID_')}", b[1], b[2]) for b in BIDS]
    return rd_list, bid_list


def _rows(per_tso=None):
    model = _solved_model(per_tso)
    rd_list, bid_list = _lists()
    rows = extract_curative_rd_results(model, rd_list, bid_list, REFERENCE, per_tso)
    return model, rows


def test_one_row_per_bid_and_contingency_with_own_direction_volume():
    _model, rows = _rows()
    assert len(rows) == 8
    assert sorted((r["bid_mrid"], r["contingency_mrid"]) for r in rows) == sorted(
        (b, co) for b in NEED for co in ("CO1", "CO2"))
    for r in rows:
        need = NEED[r["bid_mrid"]][r["contingency_mrid"]]
        maximum = max(NEED[r["bid_mrid"]].values())
        assert r["direction"] == DIRECTION[r["bid_mrid"]].value
        assert r["curative_volume_mw"] >= need - 1e-6          # must clear its own contingency
        assert r["curative_volume_mw"] <= maximum + 1e-6       # never above the per-bid max
        assert r["max_curative_volume_mw"] == pytest.approx(maximum, abs=1e-6)
        if need == maximum:                                     # the binding contingency is exact
            assert r["curative_volume_mw"] == pytest.approx(need, abs=1e-6)


def test_inactive_direction_volume_is_not_reported():
    """curative_volume_mw is the variable of the bid's OWN direction: a DOWN bid
    must not report its (zero) upward variable."""
    _model, rows = _rows()
    for r in rows:
        assert r["curative_volume_mw"] > 0.0 or NEED[r["bid_mrid"]][r["contingency_mrid"]] == 0.0


def test_price_and_penalty_cost_per_mw_columns():
    _model, rows = _rows()
    for r in rows:
        assert r["price_eur_mw"] == PRICE[r["bid_mrid"]]
        assert r["penalty_cost_eur_per_mw"] == pytest.approx(PENALTY_FACTOR * REFERENCE)
        assert r["tso"] == "TestTSO" and r["ra_mrid"] == f"RD_{r['bid_mrid'].removeprefix('BID_')}"


def test_per_tso_override_is_used_for_penalty_and_cost():
    _model, rows = _rows({"TestTSO": 3.0})
    assert {r["penalty_cost_eur_per_mw"] for r in rows} == {3.0}
    first = {r["bid_mrid"]: r for r in rows if r["curative_cost_eur"] != 0.0}
    for bid, r in first.items():
        assert r["curative_cost_eur"] == pytest.approx((3.0 + PRICE[bid]) * max(NEED[bid].values()), abs=1e-6)


def test_cost_is_on_the_first_row_of_each_bid_and_sums_to_the_objective():
    model, rows = _rows()
    for bid in NEED:
        bid_rows = sorted((r for r in rows if r["bid_mrid"] == bid), key=lambda r: r["contingency_mrid"])
        assert bid_rows[0]["curative_cost_eur"] == pytest.approx(
            (PENALTY_FACTOR * REFERENCE + PRICE[bid]) * max(NEED[bid].values()), abs=1e-6)
        assert all(r["curative_cost_eur"] == 0.0 for r in bid_rows[1:])
    assert sum(r["curative_cost_eur"] for r in rows) == pytest.approx(pyo.value(model.objective), abs=1e-6)


def test_extractor_returns_empty_without_curative_rd_in_the_model():
    assert extract_curative_rd_results(object(), [], [], REFERENCE) == []


# ===========================================================================
# Generating units results
# ===========================================================================

REPO_ROOT = Path(__file__).resolve().parents[1]


TOLERANCE_MW = 1e-6


EXPECTED_HEADER = [
    "gu_mrid", "gu_name", "tso", "initial_production_mw", "rd_volume_net_mw", "result_production_mw",
    "rd_cost_eur", "rd_penalty_cost_eur", "timestamp",
    "ac_verification_status", "ac_verification_termination_reason",
]


def _gu(target_p: float, name: str) -> dict:
    return {"target_p": target_p, "max_p": 500.0, "min_p": 0.0, "name": name}


def _solved_three_ra_model(target_p_by_gu=None):
    """RA1 (UP bid) -> GU1 alone; RA2 (DOWN bid) -> GU2 (25 %) and GU3 (75 %).
    BRANCH1 is overloaded by 50 A and RA1 relieves it, RA2 absorbs the
    balance (Σ net injection = 0), so both bids carry volume."""
    target_p_by_gu = target_p_by_gu or {"GU1": 50.0, "GU2": 60.0, "GU3": 70.0}
    rd_list = [_make_rd_unit("RA1", "GU1"), _make_rd_unit("RA2", "GU2"), _make_rd_unit("RA2", "GU3")]
    bid_list = [
        _make_bid("BID1", "RA1", BidDirection.UP, {"1030Z": 100.0}, price_eur_mw=10.0),
        _make_bid("BID2", "RA2", BidDirection.DOWN, {"1030Z": 100.0}, price_eur_mw=5.0),
    ]
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list,
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 0.25, "GU3": 0.75}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={gu: _gu(p, gu) for gu, p in target_p_by_gu.items()},
    )
    model = build_n0_milp_model(
        [_make_ae_generating_units_results("BRANCH1", side=1, patl_ka=1.0)], "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model, rd_inputs


def _rd_results(model, rd_inputs):
    return extract_rd_results(
        model, rd_list=rd_inputs.rd_list, bid_list=rd_inputs.bid_list, penalty_reference_rd_pra=0.0,
        )


def _extract_generating_units_results(model, rd_inputs, output_path=None, generator_data=None):
    return extract_results_generating_units(
        model, rd_list=rd_inputs.rd_list, generator_data=generator_data, glsk=rd_inputs.glsk,
        rd_results=_rd_results(model, rd_inputs),
        ac_verification_status=CONVERGED, ac_verification_termination_reason="test",
        timestamp="1030Z", output_path=output_path,
    )


# ---------------------------------------------------------------------------
# baseline travels with the model
# ---------------------------------------------------------------------------

def test_builder_records_the_baseline_target_p_the_model_was_built_on():
    model, _ = _solved_three_ra_model()
    assert model.rd_baseline_target_p_mw == {"GU1": 50.0, "GU2": 60.0, "GU3": 70.0}


# ---------------------------------------------------------------------------
# columns
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# conservation
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# pipeline level (shared mock N-X run)
# ---------------------------------------------------------------------------

def _rows_generating_units_results(path: Path) -> list[dict]:
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.DictReader(f))


# ===========================================================================
# Curative PST results
# ===========================================================================

PENALTY_REFERENCE = 10.0


EXPECTED_HEADER_curative_pst_results_file = [
    "tso", "pst_mrid", "contingency_mrid", "timestamp",
    "curative_delta_taps_up", "curative_delta_taps_down", "curative_delta_taps_net",
    "curative_tap_lower_bound", "curative_tap_upper_bound", "available", "penalty_cost_eur",
    "ac_verification_status", "ac_verification_termination_reason",
]


def _solve_two_psts_two_contingencies(penalty_factor=3.0):
    """CO1: 1050 A on a 1000 A branch, UP_PST relieves 10 A per tap upward, so
    it must move UP 5 taps. CO2: same overload but the sensitivity of DOWN_PST
    has the opposite sign, so it must move DOWN 5 taps. Both PSTs are
    available in both contingencies (UP_PST has no effect in CO2 and DOWN_PST
    none in CO1, so they stay at 0 there)."""
    psts = [
        _make_pst("UP_PST", RAKind.CURATIVE, penalty_factor=penalty_factor),
        _make_pst("DOWN_PST", RAKind.CURATIVE, penalty_factor=penalty_factor),
    ]
    bounds = {"UP_PST": (-7, 9), "DOWN_PST": (-8, 6)}
    pst_inputs = PstMilpInputs(
        pst_list=psts, pst_tap_bounds={}, pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={},
        pst_degrees_per_tap={"UP_PST": 1.0, "DOWN_PST": 1.0}, penalty_reference_pst_pra=PENALTY_REFERENCE,
    )
    availability = {
        (pst, "BRANCH1", co): {"max_curative_taps": 10, "available": True}
        for pst in ("UP_PST", "DOWN_PST") for co in ("CO1", "CO2")
    }
    nx_inputs = NxMilpInputs(
        lf_nx={co: {"BRANCH1": {1: 1050.0}} for co in ("CO1", "CO2")},
        sensitivity_pst_nx={
            "CO1": {("BRANCH1", "UP_PST"): -10.0, ("BRANCH1", "DOWN_PST"): 0.0},
            "CO2": {("BRANCH1", "UP_PST"): 0.0, ("BRANCH1", "DOWN_PST"): 10.0},
        },
        sensitivity_rd_nx={}, penalty_cost_overload_nx_patl=1000.0,
        pst_cra_availability=availability, pst_tap_bounds_curative=bounds,
    )
    model = build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model, psts, nx_inputs


def _extract_curative_pst_results_file(model, psts, nx_inputs):
    return extract_curative_pst_delta_results(
        model, psts, nx_inputs.pst_tap_bounds_curative, nx_inputs.pst_cra_availability, PENALTY_REFERENCE,
    )


def test_one_row_per_available_pair_with_deltas_bounds_flag_and_penalty():
    model, psts, nx_inputs = _solve_two_psts_two_contingencies()

    rows = _extract_curative_pst_results_file(model, psts, nx_inputs)

    by_pair = {(r["pst_mrid"], r["contingency_mrid"]): r for r in rows}
    assert sorted(by_pair) == [("DOWN_PST", "CO1"), ("DOWN_PST", "CO2"), ("UP_PST", "CO1"), ("UP_PST", "CO2")]
    up_co1 = by_pair[("UP_PST", "CO1")]
    assert (up_co1["curative_delta_taps_up"], up_co1["curative_delta_taps_down"]) == pytest.approx((5.0, 0.0))
    assert up_co1["curative_delta_taps_net"] == pytest.approx(5.0)
    assert (up_co1["curative_tap_lower_bound"], up_co1["curative_tap_upper_bound"]) == (-7, 9)
    assert up_co1["available"] is True
    assert up_co1["tso"] == "TestTSO"
    assert up_co1["penalty_cost_eur"] == pytest.approx(3.0 * PENALTY_REFERENCE * 5.0)
    down_co2 = by_pair[("DOWN_PST", "CO2")]
    assert (down_co2["curative_delta_taps_up"], down_co2["curative_delta_taps_down"]) == pytest.approx((0.0, 5.0))
    assert down_co2["curative_delta_taps_net"] == pytest.approx(-5.0)
    assert (down_co2["curative_tap_lower_bound"], down_co2["curative_tap_upper_bound"]) == (-8, 6)
    for pair in (("UP_PST", "CO2"), ("DOWN_PST", "CO1")):
        assert by_pair[pair]["curative_delta_taps_net"] == pytest.approx(0.0)
        assert by_pair[pair]["penalty_cost_eur"] == pytest.approx(0.0)


def test_available_flag_is_read_from_the_availability_map():
    """Every pair that has variables is available, so the flag is True; it is
    taken from pst_cra_availability (not hard-coded) and blank without a map."""
    model, psts, nx_inputs = _solve_two_psts_two_contingencies()
    flagged_off = dict(nx_inputs.pst_cra_availability)
    flagged_off[("UP_PST", "BRANCH1", "CO1")] = {"max_curative_taps": 10, "available": False}

    rows = extract_curative_pst_delta_results(
        model, psts, nx_inputs.pst_tap_bounds_curative, flagged_off, PENALTY_REFERENCE,
    )
    by_pair = {(r["pst_mrid"], r["contingency_mrid"]): r["available"] for r in rows}
    assert by_pair[("UP_PST", "CO1")] is False
    assert by_pair[("UP_PST", "CO2")] is True

    no_map = extract_curative_pst_delta_results(
        model, psts, nx_inputs.pst_tap_bounds_curative, None, PENALTY_REFERENCE,
    )
    assert all(r["available"] is None for r in no_map)


def test_row_count_equals_number_of_available_pst_contingency_pairs():
    model, psts, nx_inputs = _solve_two_psts_two_contingencies()
    available_pairs = {
        (pst, co) for (pst, _xne, co), entry in nx_inputs.pst_cra_availability.items() if entry["available"]
    }
    assert len(_extract_curative_pst_results_file(model, psts, nx_inputs)) == len(available_pairs) == 4


def test_net_equals_up_minus_down_for_every_row():
    model, psts, nx_inputs = _solve_two_psts_two_contingencies()
    rows = _extract_curative_pst_results_file(model, psts, nx_inputs)
    assert len(rows) == 4
    for r in rows:
        assert r["curative_delta_taps_net"] == pytest.approx(r["curative_delta_taps_up"] - r["curative_delta_taps_down"])


# ---------------------------------------------------------------------------
# pipeline level (shared mock N-X run)
# ---------------------------------------------------------------------------

def _rows_curative_pst_results_file(path: Path) -> list[dict]:
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.DictReader(f))


# ===========================================================================
# Files written by the mock pipeline run
# ===========================================================================

def _read_rows(path: Path) -> list[dict]:
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.DictReader(f))


# ---------------------------------------------------------------------------
# glsk_resolved.csv holds ALL RAs of ALL TSOs
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# lf_post_n0.csv holds EVERY AC iteration, the final one identifiable
# ---------------------------------------------------------------------------

def _summary_metrics(output_dir: Path) -> dict[str, str]:
    from helpers import read_summary
    return read_summary(output_dir)


# ===========================================================================
# Lead times
# ===========================================================================

def _rows_output_renames(path: Path) -> list[dict]:
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.DictReader(f))


# ---------------------------------------------------------------------------
# results_lead_times.csv phase column
# ---------------------------------------------------------------------------

def _rd_unit_output_renames(mrid: str, kind: RAKind) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="T", gu_mrid="G", gu_name="G", available=True, kind=kind,
        initial_p=0.0, max_p=1.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _bid_output_renames(mrid: str, ra_mrid: str) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=BidDirection.UP, available_mw={"1030Z": 1.0},
        price_eur_mw=1.0, lead_time_h=0.0,
        activation_cost_eur=None, 
    )


# ===========================================================================
# AC verification status columns of the result writers
# ===========================================================================

ALL_STATUSES = [
    (AcVerificationStatus.CONVERGED, "remedial action movement and congestion levels stabilized between iterations"),
    (AcVerificationStatus.REVERTED_NON_CONVERGENT, "load flow non-convergent"),
    (AcVerificationStatus.REVERTED_TO_LAST_CONVERGED_STATE,
     "load flow non-convergent - reverted to last converged state"),
    (AcVerificationStatus.MAX_ITERATIONS_REACHED, "max iterations reached"),
    (AcVerificationStatus.CYCLIC_REPETITION, "cyclic repetition of results"),
]


class TestRevertedRunIsHonestlyFlagged:
    """A REVERTED_NON_CONVERGENT run's CSV marks the failure while keeping the proposed
    (never applied) values for diagnostics."""

# ===========================================================================
# Cyclic repetition status
# ===========================================================================

CYCLIC_REASON = "cyclic repetition of results"


# ================================================================ (f) status mapping and outputs
class TestCyclicRepetitionStatus:
    def test_the_termination_reason_maps_to_its_own_status(self):
        assert AcVerificationStatus["CYCLIC_REPETITION"] is AcVerificationStatus.from_termination_reason(CYCLIC_REASON)

    def test_an_unknown_reason_is_still_rejected(self):
        with pytest.raises(ValueError):
            AcVerificationStatus.from_termination_reason("cyclic repetition")

# ===========================================================================
# Completeness iterations file
# ===========================================================================

# ---------------------------------------------------------------------------
# write_completeness_iterations_csv
# ---------------------------------------------------------------------------

# ===========================================================================
# Completeness limit flag and iteration history column
# ===========================================================================

# ===========================================================================
# Remaining overload count with a scanned branch in the model
# ===========================================================================

def test_remaining_overload_count_counts_secured_branches_only_when_a_scanned_branch_is_modelled():
    import pyomo.environ as pyo
    from data_model import AEType
    from helpers import _make_ae_mb_scanned, _make_pst_mb_scanned
    from milp.milp_builder import PstMilpInputs, build_n0_milp_model
    from milp.milp_solver import solve_n0_milp_model
    ae = [_make_ae_mb_scanned("SEC", AEType.SECURED, 1, 1.0), _make_ae_mb_scanned("SCAN", AEType.SCANNED, 1, 1.0)]
    pst = _make_pst_mb_scanned("PST1")
    pst_inputs = PstMilpInputs(
        pst_list=[pst], pst_tap_bounds={"PST1": (0, 0)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("SEC", "PST1"): 5.0, ("SCAN", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5}, penalty_reference_pst_pra=10.0,
    )
    # SEC: 1200 A against 1000 A, no tap headroom -> overloaded; SCAN is in branch_ids too
    model = build_n0_milp_model(ae, "1030Z", {"SEC": {1: 1200.0}, "SCAN": {1: 500.0}}, 1000.0, pst_inputs=pst_inputs)
    assert "SCAN" in set(model.branch_ids)
    solve_n0_milp_model(model, [pst], 10.0)
    summary = n0_results_export.extract_results_summary(
        model, objective_value=float(pyo.value(model.objective)), pst_list=[pst], penalty_reference_pst_pra=10.0,
    )
    assert summary["remaining_overload_count"] == 1


def test_penalty_sum_equals_results_pst_curative_cost_and_summary_metric():
    """The per-row penalties add up to the curative_penalty_cost_eur column
    of results_pst.csv (same figures, computed by the existing per-PST
    extractor) and to sum_curative_pst_penalty_cost_eur of results_summary."""
    model, psts, nx_inputs = _solve_two_psts_two_contingencies()

    rows = _extract_curative_pst_results_file(model, psts, nx_inputs)
    per_pst = extract_curative_pst_results(model, psts, PENALTY_REFERENCE)
    summary = extract_results_summary(
        model, objective_value=pyo.value(model.objective), pst_list=psts,
        penalty_reference_pst_pra=PENALTY_REFERENCE,
    )

    row_sum = sum(r["penalty_cost_eur"] for r in rows)
    assert row_sum == pytest.approx(sum(v["curative_penalty_cost_eur"] for v in per_pst.values()))
    assert row_sum == pytest.approx(summary["sum_curative_pst_penalty_cost_eur"])
    assert row_sum == pytest.approx(2 * 3.0 * PENALTY_REFERENCE * 5.0)
    for pst_mrid, totals in per_pst.items():
        assert sum(r["penalty_cost_eur"] for r in rows if r["pst_mrid"] == pst_mrid) == pytest.approx(
            totals["curative_penalty_cost_eur"]
        )


def test_glsk_resolved_csv_holds_every_resolved_ra_of_every_tso(mock_nx_pipeline_run):
    """GLSK is resolved per TSO; rd_bids.csv lists the usable bids of the RAs that a TSO resolved, each row with its TSO and
    the units and shares of the shift key."""
    per_tso_results = mock_nx_pipeline_run.records.glsk_results_per_tso
    resolved_ra_mrids = {ra for result in per_tso_results for ra in result}
    assert len(per_tso_results) >= 2, "test needs several TSOs to be meaningful"
    assert len(resolved_ra_mrids) == sum(len(r) for r in per_tso_results)

    rows = _read_rows(mock_nx_pipeline_run.output_dir / "rd_bids.csv")

    assert rows and {row["ra_id"] for row in rows} <= resolved_ra_mrids
    assert all(row["tso"] and row["unit_ids"] for row in rows)
    assert all(sum(float(f) for f in row["participation_factors"].split(";")) == pytest.approx(1.0) for row in rows)
    assert len({row["tso"] for row in rows}) >= 2

