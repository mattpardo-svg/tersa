"""tests/test_rao_config_key_checks.py - a key of rao_config.yaml that the code never reads (misplaced, misspelt, written
twice) is reported instead of silently leaving the default in force. Synthetic values only."""

import logging
from pathlib import Path

import pytest
import yaml

import run_pipeline

CONFIG_DIR = Path(run_pipeline.__file__).parent / "config"
CONFIG_PATH = Path("rao_config.yaml")


def _config(name="rao_config.yaml"):
    return yaml.safe_load((CONFIG_DIR / name).read_text(encoding="utf-8"))


def test_rao_the_shipped_config_and_its_default_have_no_unknown_key():
    assert run_pipeline.unknown_config_keys(_config(), _config("rao_config.default.yaml")) == []
    assert run_pipeline.unknown_config_keys(_config("rao_config.default.yaml"), _config()) == []


def test_rao_a_key_at_the_top_level_instead_of_in_its_section_is_unknown():
    config = _config()
    config["decision_point_hours_before_run"] = 12.0
    assert run_pipeline.unknown_config_keys(config, _config("rao_config.default.yaml")) == ["decision_point_hours_before_run"]


def test_rao_a_misspelt_or_misplaced_key_in_a_section_is_unknown():
    config = _config()
    config["lead_time"]["decision_point_hours_before_the_run"] = 12.0
    config["bids"]["decision_point_hours_before_run"] = 12.0
    assert run_pipeline.unknown_config_keys(config, _config("rao_config.default.yaml")) == [
        "bids.decision_point_hours_before_run", "lead_time.decision_point_hours_before_the_run"]


def test_rao_the_entries_of_a_per_tso_map_are_not_checked():
    config = _config()
    config["curative_ra"]["pst_group_kind_per_tso"] = {"TSO-A": "reducedGroup"}
    assert run_pipeline.unknown_config_keys(config, _config("rao_config.default.yaml")) == []


def test_rao_a_key_written_twice_is_found_with_the_value_that_wins():
    text = "lead_time:\n  decision_point_hours_before_run: 12.0\nlead_time:\n  decision_point_hours_before_run: 1.0\n"
    assert run_pipeline.duplicate_config_keys(text) == ["lead_time"]
    text = "lead_time:\n  decision_point_hours_before_run: 12.0\n  decision_point_hours_before_run: 1.0\n"
    assert run_pipeline.duplicate_config_keys(text) == ["lead_time.decision_point_hours_before_run"]
    assert run_pipeline.duplicate_config_keys((CONFIG_DIR / "rao_config.yaml").read_text(encoding="utf-8")) == []


def test_rao_the_warning_names_each_key_and_says_it_is_ignored(caplog):
    config = _config()
    config["decision_point_hours_before_run"] = 12.0
    text = "lead_time:\n  a: 1\nlead_time:\n  a: 2\n"
    with caplog.at_level(logging.WARNING):
        run_pipeline.warn_config_key_problems(config, text, CONFIG_PATH, _config("rao_config.default.yaml"))
    messages = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert any("decision_point_hours_before_run" in m and "never read" in m for m in messages)
    assert any("'lead_time'" in m and "more than once" in m and "last" in m for m in messages)


def test_rao_a_clean_config_gives_no_warning(caplog):
    text = (CONFIG_DIR / "rao_config.yaml").read_text(encoding="utf-8")
    with caplog.at_level(logging.WARNING):
        run_pipeline.warn_config_key_problems(_config(), text, CONFIG_PATH, _config("rao_config.default.yaml"))
    assert not caplog.records


def test_rao_the_old_name_of_the_scanned_element_penalty_gives_an_error_that_names_the_new_key():
    config = _config()
    assert "scanned_element_penalty_eur_per_a" in config["penalty_costs"]
    config["penalty_costs"]["scanned_element_penalty_eur_per_ka"] = config["penalty_costs"].pop("scanned_element_penalty_eur_per_a")
    with pytest.raises(ValueError, match="scanned_element_penalty_eur_per_a"):
        run_pipeline.validate_config_ranges(config, CONFIG_PATH)
