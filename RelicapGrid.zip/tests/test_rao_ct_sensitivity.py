"""
tests/test_rao_ct_sensitivity.py - one sensitivity variable per countertrade RA and direction (DECISIONS 169, 170):
sens_ct(branch, state, RA, direction) = sum over the units of weight x sens(branch, state, unit). pypowsybl computes the
sensitivity of each unit, in batches of contingencies; each batch is aggregated at once and its per-unit values are
dropped, so the result is the per-unit one by construction (no zones, no repair step). The MILP flow rows carry 2 terms
per RA and direction, not one per unit.
"""
import dataclasses
import logging
from types import SimpleNamespace

import numpy as np
import pyomo.environ as pyo
import pytest
from pyomo.core.expr.visitor import identify_variables

import run_pipeline
import test_rao_milp_builder_ct as ct_builder_tests
from data_model import AEType, AssessedElement, BidDirection, Contingency, ContingencyType, RAKind, RDUnit
from helpers import _MOCK_NX_CGM_ZIP, _solve
from mock_builders.hvdc_mock import EI_SD_BO3, EI_SD_EH1
from milp.milp_builder import RdMilpInputs, build_n0_milp_model
from pre_milp import cgmes_loader, ct_sensitivity, n0_sensitivity, nx_sensitivity
from pre_milp.dc_conversion import DcCurrentConverter
from pre_milp.lf_parameters import build_loadflow_parameters
from pre_milp.nx_security_analysis import compute_lf_nx

UP, DOWN = BidDirection.UP, BidDirection.DOWN
TS = "1030Z"
CO_A, CO_B, CO_ISLAND = "7e253493-0bb4-4306-95b3-374075834b98", "b85e5fb8-7e2b-4264-a059-edab9a838116", "CO-ISLAND"
UP_ID, DOWN_ID = "CT|CT_RA_1|up", "CT|CT_RA_1|down"
# pypowsybl returns values that differ by about 1e-11 between two runs of the same analysis, so a comparison with a separate
# per-unit analysis uses the column-scaled tolerance of the golden matrix (compare_runs.py); the arithmetic of the sum
# itself is checked to 1e-12 on the very values it received (recorded below)
ENGINE_TOLERANCE = 1e-8


def _rd(mrid, gu, ct=False, kind=RAKind.PREVENTIVE, up=0.0, down=0.0, available=True):
    return RDUnit(
        mrid=mrid, name=mrid, tso="T", gu_mrid=gu, gu_name=gu, available=available, kind=kind, initial_p=100.0, max_p=400.0,
        min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None, countertrade=ct, ct_weight_up=up, ct_weight_down=down,
    )


# ---------------------------------------------------------------------------
# the variables and the aggregation (no network)
# ---------------------------------------------------------------------------

def test_the_variable_of_a_ct_ra_and_direction_carries_its_weights():
    weights_up, weights_down = {"G1": 0.7, "G2": 0.3}, {"G1": 0.2, "G2": 0.8}
    rd_list = [_rd("CT_RA_1", gu, True, up=weights_up[gu], down=weights_down[gu]) for gu in weights_up]
    weights = ct_sensitivity.ct_weights(rd_list)
    assert set(weights) == {UP_ID, DOWN_ID} and weights[UP_ID] == weights_up and weights[DOWN_ID] == weights_down
    assert ct_sensitivity.ct_variable_id("CT_RA_1", UP) == UP_ID and ct_sensitivity.ct_variable_id("CT_RA_1", DOWN) == DOWN_ID
    assert ct_sensitivity.countertrade_unit_ids(weights) == ["G1", "G2"]


def test_a_zero_weight_is_left_out_and_an_unavailable_or_curative_ra_only_where_asked():
    rd_list = [_rd("CT_RA_1", "G1", True, up=1.0, down=0.0), _rd("CT_RA_2", "G2", True, up=1.0, down=1.0, available=False),
               _rd("CT_RA_3", "G3", True, RAKind.CURATIVE, up=0.0, down=1.0)]
    assert ct_sensitivity.ct_weights(rd_list) == {"CT|CT_RA_1|up": {"G1": 1.0}, "CT|CT_RA_3|down": {"G3": 1.0}}
    assert ct_sensitivity.ct_weights(rd_list, preventive_only=True) == {"CT|CT_RA_1|up": {"G1": 1.0}}


def test_the_individual_units_leave_out_the_countertrade_only_units():
    rd_list = [_rd("CT_RA_1", "G1", True, up=1.0, down=1.0), _rd("RD_1", "G1"), _rd("RD_2", "OTHER", kind=RAKind.CURATIVE)]
    assert ct_sensitivity.individual_unit_ids(rd_list) == ["G1", "OTHER"]            # a unit that is also an RD unit stays
    assert ct_sensitivity.individual_unit_ids(rd_list[:1] + rd_list[2:]) == ["OTHER"]
    assert ct_sensitivity.individual_unit_ids(rd_list, preventive_only=True) == ["G1"]


def test_the_zone_machinery_is_gone():
    for name in ("ct_zones", "lost_units", "zone_weight_sums", "alive_weight_sums", "probe_branch_sides"):
        assert not hasattr(ct_sensitivity, name), name
    for name in ("_ct_scale_of_contingency", "_dropped_unit_corrections", "_ct_variable_sets"):
        assert not hasattr(nx_sensitivity, name), name


def test_aggregate_units_is_the_weighted_sum_over_the_member_units_only():
    values = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])                         # (branches, units)
    variables, aggregate = ct_sensitivity.aggregate_units(
        values, ["U1", "U2", "U3"], {"CT|A|up": {"U1": 0.5, "U3": 0.25}, "CT|A|down": {"U2": 2.0}})
    assert variables == ["CT|A|down", "CT|A|up"]
    np.testing.assert_array_equal(aggregate, np.array([[4.0, 0.5 + 0.75], [10.0, 2.0 + 1.5]]))


def test_a_nan_unit_value_makes_the_pair_nan_for_the_ras_that_use_the_unit_only():
    values = np.array([[1.0, np.nan, 3.0], [4.0, 5.0, 6.0]])
    variables, aggregate = ct_sensitivity.aggregate_units(
        values, ["U1", "U2", "U3"], {"CT|A|up": {"U1": 0.5, "U3": 0.5}, "CT|A|down": {"U1": 0.5, "U2": 0.5}})
    assert variables == ["CT|A|down", "CT|A|up"]
    assert np.isnan(aggregate[0, 0]) and aggregate[0, 1] == 2.0 and not np.isnan(aggregate[1]).any()


def test_a_unit_pruned_on_a_branch_contributes_zero_and_a_nan_is_never_pruned():
    values = np.array([[1.0, 2.0, np.nan], [4.0, 0.1, 6.0]])
    _variables, aggregate = ct_sensitivity.aggregate_units(
        values, ["U1", "U2", "U3"], {"CT|A|up": {"U1": 1.0, "U2": 1.0, "U3": 1.0}}, thresholds=np.array([1.5, 0.5]))
    assert np.isnan(aggregate[0, 0])                                              # U1 pruned (1 < 1.5), NaN stays
    assert aggregate[1, 0] == 4.0 + 0.0 + 6.0                                     # U2 pruned (0.1 < 0.5)
    _variables, aggregate = ct_sensitivity.aggregate_units(
        values[:, :2], ["U1", "U2"], {"CT|A|up": {"U1": 1.0, "U2": 1.0}}, thresholds=np.array([1.5, 0.5]))
    assert aggregate[0, 0] == 2.0


def test_a_weight_of_a_unit_without_a_value_counts_as_zero_and_the_branch_maximum_ignores_nan():
    assert ct_sensitivity.branch_maximum(np.zeros((2, 0))).tolist() == [0.0, 0.0]
    variables, aggregate = ct_sensitivity.aggregate_units(
        np.array([[2.0]]), ["U1"], {"CT|A|up": {"U1": 0.5, "U9": 0.5}})
    assert aggregate[0, 0] == 1.0
    np.testing.assert_array_equal(
        ct_sensitivity.branch_maximum(np.array([[1.0, -3.0, np.nan], [np.nan, np.nan, np.nan]])), np.array([3.0, np.nan]))


def test_the_batch_has_a_bounded_number_of_values_and_at_least_one_contingency():
    assert ct_sensitivity.batch_size(unit_count=300, branch_count=1000, budget=3_000_000) == 10
    assert ct_sensitivity.batch_size(unit_count=300, branch_count=100000, budget=3_000_000) == 1
    assert ct_sensitivity.batch_size(unit_count=0, branch_count=0) >= 1


# ---------------------------------------------------------------------------
# pypowsybl: the aggregate against the weighted sum of the per-unit sensitivities
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def env():
    network = cgmes_loader.load_cgm(_MOCK_NX_CGM_ZIP)
    cgmes_loader.run_initial_loadflow(network, run_pipeline.USE_REACTIVE_LIMITS, run_pipeline.EXTRA_LF_PARAMS)
    lf_initial = cgmes_loader.build_lf_initial(network)
    branches = sorted(b for b, sides in lf_initial.items() if all(v == v for v in sides.values()))
    ae_flat_list = [
        AssessedElement(mrid=f"AE-{b}", name=b, tso="T", ae_type=AEType.SECURED, branch_mrid=b, secured_for_region=None,
                        scanned_for_region=None, exclusion_reason=None, patl_ka={TS: 100.0}, branch_side=1)
        for b in branches
    ]
    contingencies = [
        Contingency(mrid=co, name=co, tso="T", contingency_type=ContingencyType.ORDINARY, must_study={TS: True},
                    equipment_mrids=[co], equipment_types=["line"]) for co in (CO_A, CO_B)
    ]
    # both circuits that connect the bus of EI_SD_BO3: together they island that unit
    contingencies.append(Contingency(
        mrid=CO_ISLAND, name=CO_ISLAND, tso="T", contingency_type=ContingencyType.ORDINARY, must_study={TS: True},
        equipment_mrids=["536f4b84-db4c-4545-96e9-bb5a87f65d13", "d9622e7f-5bf0-4e7e-b766-b8596c6fe4ae"],
        equipment_types=["line", "line"]))
    units = [str(g) for g in network.get_generators().index[:3]] + [EI_SD_EH1, EI_SD_BO3]      # five units, one islanded
    weights_up = dict(zip(units, (0.1, 0.2, 0.3, 0.15, 0.25)))
    weights_down = dict(zip(units, (0.4, 0.05, 0.15, 0.1, 0.3)))
    return SimpleNamespace(network=network, lf_initial=lf_initial, ae_flat_list=ae_flat_list, contingencies=contingencies,
                           units=units, weights_up=weights_up, weights_down=weights_down)


def _ct_ra(env, kind=RAKind.PREVENTIVE):
    return [_rd("CT_RA_1", gu, True, kind, env.weights_up[gu], env.weights_down[gu]) for gu in env.units]


def _per_unit_ras(env, kind=RAKind.PREVENTIVE):
    """The units as plain RD units, each with its own sensitivity: the per-unit formulation."""
    return [_rd(f"RD_{position}", gu, kind=kind) for position, gu in enumerate(env.units)]


def _weighted(sensitivity, branch, weights):
    return sum(weight * sensitivity[(branch, unit)] for unit, weight in weights.items())


def _assert_aggregate_is_weighted_sum(env, per_unit, aggregated, branches=None, minimum_checked=10):
    checked = 0
    scale = max(abs(v) for v in per_unit.values() if v == v)
    for branch in branches or {b for b, _u in per_unit}:
        for variable, weights in ((UP_ID, env.weights_up), (DOWN_ID, env.weights_down)):
            expected = _weighted(per_unit, branch, weights)
            got = aggregated[(branch, variable)]
            if expected != expected:
                assert got != got                                                # NaN in both
                continue
            assert got == pytest.approx(expected, rel=ENGINE_TOLERANCE, abs=ENGINE_TOLERANCE * scale)
            checked += abs(expected) > 1e-6
    assert checked >= minimum_checked


def _n0(env, rd_list, network=None, dc_converter=None, lf_initial=None, **kwargs):
    return n0_sensitivity.compute_sensitivity_rd_n0(
        network or env.network, rd_list, env.ae_flat_list, TS, lf_initial=lf_initial or env.lf_initial,
        use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        dc_converter=dc_converter, **kwargs,
    )


@pytest.fixture
def recorded(monkeypatch):
    """The arguments and result of every ct_sensitivity.aggregate_units call."""
    calls = []
    original = ct_sensitivity.aggregate_units

    def record(values, unit_ids, weights, thresholds=None):
        result = original(values, unit_ids, weights, thresholds)
        calls.append((values.copy(), list(unit_ids), weights, thresholds, result))
        return result

    monkeypatch.setattr(ct_sensitivity, "aggregate_units", record)
    return calls


def _assert_sum_is_exact(calls, minimum_checked=50):
    """Every aggregate equals the weighted sum of the per-unit values it was given, to 1e-12 of the size of its terms."""
    checked = 0
    for values, unit_ids, weights, _thresholds, (variables, aggregate) in calls:
        for position, variable in enumerate(variables):
            for row in range(values.shape[0]):
                terms = [weight * values[row, unit_ids.index(unit)] for unit, weight in weights[variable].items()]
                got = aggregate[row, position]
                if any(t != t for t in terms):
                    assert got != got
                    continue
                assert got == pytest.approx(sum(terms), rel=1e-12, abs=1e-12 * sum(abs(t) for t in terms))
                checked += abs(got) > 1e-9
    assert checked >= minimum_checked


def test_the_sum_is_exact_on_the_per_unit_values_n0_and_nx_ac_and_dc(env, recorded):
    _n0(env, _ct_ra(env))
    _nx(env, _ct_ra(env, RAKind.CURATIVE))
    network, converter, lf_initial = _dc_env(env)
    _n0(env, _ct_ra(env), network, converter, lf_initial)
    _nx(env, _ct_ra(env, RAKind.CURATIVE), network, converter, lf_initial)
    assert len(recorded) == 2 * (1 + 3)                      # per run: N-0 once, N-X once per contingency (all branches on side 1)
    _assert_sum_is_exact(recorded)


def test_n0_the_ct_variable_is_the_weighted_sum_of_the_unit_sensitivities_and_the_units_have_no_entry(env):
    per_unit = _n0(env, _per_unit_ras(env))
    aggregated = _n0(env, _ct_ra(env))
    assert {unit for _b, unit in aggregated} == {UP_ID, DOWN_ID}                     # no entry of a countertrade-only unit
    assert len(aggregated) == len({b for b, _u in per_unit}) * 2
    _assert_aggregate_is_weighted_sum(env, per_unit, aggregated)


def test_n0_a_unit_that_is_also_an_rd_unit_keeps_its_own_sensitivity(env):
    per_unit = _n0(env, _per_unit_ras(env))
    both = _n0(env, _ct_ra(env) + [_rd("RD_1", EI_SD_EH1)])
    assert {unit for _b, unit in both} == {UP_ID, DOWN_ID, EI_SD_EH1}
    assert all(both[(b, EI_SD_EH1)] == pytest.approx(per_unit[(b, EI_SD_EH1)], rel=ENGINE_TOLERANCE, abs=1e-9)
               or both[(b, EI_SD_EH1)] != both[(b, EI_SD_EH1)] for b, u in both if u == EI_SD_EH1)
    _assert_aggregate_is_weighted_sum(env, per_unit, both)                           # the CT variable is the same


def _dc_env(env):
    import pypowsybl as pp
    network = cgmes_loader.load_cgm(_MOCK_NX_CGM_ZIP)
    result = pp.loadflow.run_dc(network, parameters=build_loadflow_parameters(run_pipeline.USE_REACTIVE_LIMITS, run_pipeline.EXTRA_LF_PARAMS))
    assert "CONVERGED" in str(result[0].status)
    converter = DcCurrentConverter.from_network(network, 1.0, {"default": 1.0})
    return network, converter, cgmes_loader.build_lf_initial(network, converter)


def test_n0_dc_the_ct_variable_is_the_weighted_sum_of_the_unit_sensitivities(env):
    network, converter, lf_initial = _dc_env(env)
    per_unit = _n0(env, _per_unit_ras(env), network, converter, lf_initial)
    aggregated = _n0(env, _ct_ra(env), network, converter, lf_initial)
    _assert_aggregate_is_weighted_sum(env, per_unit, aggregated)


def test_n0_the_branch_maximum_is_over_the_per_unit_values(env):
    # the N-0 branch rule (max |sensitivity| over the matrix) must see the units, not the aggregated variables
    per_unit = _n0(env, _per_unit_ras(env))
    maximum_out = {}
    _n0(env, _ct_ra(env), branch_max_out=maximum_out)
    finite = {}
    for (branch, _unit), value in per_unit.items():
        finite.setdefault(branch, []).extend([abs(value)] if value == value else [])
    expected = {branch: max(values) if values else float('nan') for branch, values in finite.items()}
    assert set(maximum_out) == set(expected) and len(expected) > 10
    for branch, value in expected.items():                                           # an all-NaN branch stays NaN
        assert (maximum_out[branch] != maximum_out[branch] and value != value) or maximum_out[branch] == pytest.approx(
            value, rel=ENGINE_TOLERANCE, abs=ENGINE_TOLERANCE * max(v for v in expected.values() if v == v))


def test_n0_the_branch_rule_with_the_maximum_keeps_the_branches_the_per_unit_matrix_keeps(env):
    per_unit = _n0(env, _per_unit_ras(env))
    maximum_out = {}
    aggregated = _n0(env, _ct_ra(env), branch_max_out=maximum_out)
    threshold = 1.0                                                                   # percent of the limit: prunes some branches
    kept_per_unit = {b for b, _u in n0_sensitivity.prune_sensitivity_by_threshold(per_unit, env.ae_flat_list, TS, env.lf_initial, threshold)}
    kept_aggregated = {b for b, _u in n0_sensitivity.prune_sensitivity_by_threshold(
        aggregated, env.ae_flat_list, TS, env.lf_initial, threshold, branch_max=maximum_out)}
    assert kept_aggregated == kept_per_unit


def _lf_nx(env, network=None, dc_converter=None, lf_initial=None):
    lf_nx, _skipped = compute_lf_nx(
        network or env.network, env.contingencies, env.ae_flat_list, TS, lf_initial=lf_initial or env.lf_initial,
        use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        dc_converter=dc_converter,
    )
    return lf_nx


def _nx(env, rd_list, network=None, dc_converter=None, lf_initial=None, **kwargs):
    return nx_sensitivity.compute_sensitivities_nx(
        network or env.network, env.contingencies, [], rd_list, env.ae_flat_list, TS,
        _lf_nx(env, network, dc_converter, lf_initial), lf_initial or env.lf_initial, with_pst=False,
        use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        dc_converter=dc_converter, **kwargs,
    )[1]


def _assert_nx_aggregate(env, per_unit, aggregated, contingencies=(CO_A, CO_B, CO_ISLAND)):
    assert set(per_unit) == set(aggregated) == set(contingencies)
    for contingency in contingencies:
        assert {unit for _b, unit in aggregated[contingency]} == {UP_ID, DOWN_ID}
        _assert_aggregate_is_weighted_sum(env, per_unit[contingency], aggregated[contingency], minimum_checked=5)


def test_nx_the_ct_variable_is_the_weighted_sum_of_the_unit_sensitivities_in_every_contingency(env):
    per_unit = _nx(env, _per_unit_ras(env, RAKind.CURATIVE))
    aggregated = _nx(env, _ct_ra(env, RAKind.CURATIVE))
    _assert_nx_aggregate(env, per_unit, aggregated)


def test_nx_a_contingency_that_islands_a_unit_needs_no_special_case(env):
    # the islanded unit has the sensitivity 0 on its own, and so contributes 0 to the sum
    per_unit = _nx(env, _per_unit_ras(env, RAKind.CURATIVE))[CO_ISLAND]
    assert all(per_unit[(b, EI_SD_BO3)] == 0.0 for b, u in per_unit if u == EI_SD_BO3 and per_unit[(b, u)] == per_unit[(b, u)])
    aggregated = _nx(env, _ct_ra(env, RAKind.CURATIVE))[CO_ISLAND]
    _assert_aggregate_is_weighted_sum(env, per_unit, aggregated, minimum_checked=5)


def test_nx_dc_the_ct_variable_is_the_weighted_sum_of_the_unit_sensitivities(env):
    network, converter, lf_initial = _dc_env(env)
    per_unit = _nx(env, _per_unit_ras(env, RAKind.CURATIVE), network, converter, lf_initial)
    aggregated = _nx(env, _ct_ra(env, RAKind.CURATIVE), network, converter, lf_initial)
    _assert_nx_aggregate(env, per_unit, aggregated)


def test_nx_the_result_does_not_depend_on_the_batch_size(env, monkeypatch):
    whole = _nx(env, _ct_ra(env, RAKind.CURATIVE))
    runs = []
    original = nx_sensitivity._run_nx_sensitivity_analysis

    def counting(network, contingencies, *args, **kwargs):
        runs.append(len(contingencies))
        return original(network, contingencies, *args, **kwargs)

    monkeypatch.setattr(nx_sensitivity, "_run_nx_sensitivity_analysis", counting)
    monkeypatch.setattr(ct_sensitivity, "BATCH_BUDGET", 1)                              # one contingency per batch
    single = _nx(env, _ct_ra(env, RAKind.CURATIVE))
    assert runs.count(1) == 3                                                          # the CT analyses; the units' one has all 3
    for contingency, values in whole.items():
        for key, value in values.items():
            other = single[contingency][key]
            assert (other != other and value != value) or other == pytest.approx(value, rel=ENGINE_TOLERANCE, abs=1e-9)


def test_nx_a_unit_that_is_also_an_rd_unit_keeps_its_own_entries(env):
    own = _nx(env, [_rd("RD_1", EI_SD_EH1, kind=RAKind.CURATIVE)])
    both = _nx(env, _ct_ra(env, RAKind.CURATIVE) + [_rd("RD_1", EI_SD_EH1, kind=RAKind.CURATIVE)])
    for contingency, values in both.items():
        assert {unit for _b, unit in values} == {UP_ID, DOWN_ID, EI_SD_EH1}
        for branch in {b for b, _u in own[contingency]}:
            a, b = own[contingency][(branch, EI_SD_EH1)], values[(branch, EI_SD_EH1)]
            assert (a != a and b != b) or a == pytest.approx(b, rel=ENGINE_TOLERANCE, abs=1e-9)


def test_nx_with_magnitude_pruning_the_unit_values_are_pruned_before_the_sum(env):
    # Filter 2 as it was applied to the units: an entry below the threshold counts as 0 in the weighted sum
    limits = {b: 1000.0 for b in env.lf_initial}
    percent = 0.02
    per_unit = nx_sensitivity.prune_sensitivity_rd_nx(_nx(env, _per_unit_ras(env, RAKind.CURATIVE)), limits, percent)
    aggregated = _nx(env, _ct_ra(env, RAKind.CURATIVE), ct_prune_limits=limits, ct_prune_threshold_pct=percent)
    pruned_count = 0
    for contingency in (CO_A, CO_B, CO_ISLAND):
        branches = {b for b, _u in per_unit[contingency]}
        for branch in branches:
            for variable, weights in ((UP_ID, env.weights_up), (DOWN_ID, env.weights_down)):
                kept = [(unit, w) for unit, w in weights.items() if (branch, unit) in per_unit[contingency]]
                pruned_count += len(kept) < len(weights)
                expected = sum(w * per_unit[contingency][(branch, unit)] for unit, w in kept)
                got = aggregated[contingency][(branch, variable)]
                assert (got != got and expected != expected) or got == pytest.approx(expected, rel=ENGINE_TOLERANCE, abs=1e-9)
    assert pruned_count > 0                                                           # the threshold does prune something
    again = nx_sensitivity.prune_sensitivity_rd_nx(aggregated, limits, percent)       # the later Filter 2 leaves the CT rows alone
    assert all(again[co][key] == aggregated[co][key] or aggregated[co][key] != aggregated[co][key]
               for co in aggregated for key in aggregated[co])
    assert all(len(again[co]) == len(aggregated[co]) for co in aggregated)


# ---------------------------------------------------------------------------
# the MILP: old per-unit formulation (the units as plain RD) against the aggregated one
# ---------------------------------------------------------------------------

def _plain_rd(rd_inputs, curative=False):
    """The same inputs with the countertrade RAs as plain RD RAs: one term per unit in every row (the per-unit formulation);
    the RD penalty reference is the countertrade one, so the costs are the same."""
    reference = rd_inputs.penalty_reference_ct_cra if curative else rd_inputs.penalty_reference_ct_pra
    bids = {str(b.mrid): b for b in rd_inputs.bid_list}
    glsk = {**rd_inputs.glsk, **{str(bids[b].ra_mrid): dict(w) for b, w in rd_inputs.bid_participation.items() if b in bids}}
    return dataclasses.replace(
        rd_inputs, rd_list=[dataclasses.replace(rd, countertrade=False) for rd in rd_inputs.rd_list],
        penalty_reference_rd_pra=reference, glsk=glsk,
    )


def _zone_sensitivity(per_unit, rd_inputs):
    """The zone-keyed form of a per-unit sensitivity dict {(branch, unit): A per MW}: the units of the countertrade bids are
    replaced by one entry per RA and direction."""
    ct_units = {gu for weights in rd_inputs.bid_participation.values() for gu in weights}
    zone = {k: v for k, v in per_unit.items() if k[1] not in ct_units}
    bids = {str(b.mrid): b for b in rd_inputs.bid_list}
    for bid_mrid, weights in rd_inputs.bid_participation.items():
        variable = ct_sensitivity.ct_variable_id(bids[bid_mrid].ra_mrid, bids[bid_mrid].direction)
        for branch in {b for b, _u in per_unit}:
            zone[(branch, variable)] = sum(w * per_unit.get((branch, gu), 0.0) for gu, w in weights.items())
    return zone


def _flows(model):
    values = {}
    for name in ("xne_loading_n0", "nx_patl_loading", "nx_tatl_loading", "nx_scanned_loading", "scanned_element_n0"):
        if hasattr(model, name):
            component = getattr(model, name)
            values.update({(name, str(k)): pyo.value(component[k].body) for k in component})
    return values


def _volumes(model):
    return {
        (name, str(k)): pyo.value(v[k]) for name in (
            "rd_volume_upward", "rd_volume_downward", "curative_rd_volume_upward", "curative_rd_volume_downward")
        if hasattr(model, name) for v in [getattr(model, name)] for k in v
    }


def _both(new_inputs, per_unit_n0, per_unit_nx, nx_inputs_of, ae_list, lf_initial, curative=False):
    old_inputs = _plain_rd(new_inputs, curative)
    old_inputs = dataclasses.replace(old_inputs, sensitivity_rd_n0_pruned=dict(per_unit_n0))
    new_inputs = dataclasses.replace(new_inputs, sensitivity_rd_n0_pruned=_zone_sensitivity(per_unit_n0, new_inputs))
    models = []
    for rd_inputs, nx_sens in ((old_inputs, per_unit_nx), (new_inputs, {co: _zone_sensitivity(s, new_inputs) for co, s in per_unit_nx.items()})):
        nx_inputs = nx_inputs_of(nx_sens)
        models.append(_solve(build_n0_milp_model(ae_list, TS, lf_initial=lf_initial, penalty_cost_overload_n0=1e6,
                                                 rd_inputs=rd_inputs, nx_inputs=nx_inputs)))
    return models


def _assert_same(old, new):
    assert pyo.value(new.objective) == pytest.approx(pyo.value(old.objective), rel=1e-8)
    old_volumes, new_volumes = _volumes(old), _volumes(new)
    assert old_volumes.keys() == new_volumes.keys() and any(v > 1.0 for v in new_volumes.values())
    for key, value in old_volumes.items():
        assert new_volumes[key] == pytest.approx(value, rel=1e-6, abs=1e-6), key
    old_flows, new_flows = _flows(old), _flows(new)
    assert old_flows.keys() == new_flows.keys() and len(new_flows) >= 3
    for key, value in old_flows.items():
        assert new_flows[key] == pytest.approx(value, rel=1e-8, abs=1e-6), key


def test_the_aggregated_preventive_model_equals_the_per_unit_model_in_objective_volumes_and_flows():
    per_unit = {**ct_builder_tests.SENSITIVITY, **ct_builder_tests.SENSITIVITY_S1}
    nx = {"CO1": dict(per_unit)}
    old, new = _both(
        ct_builder_tests._inputs(), per_unit, nx, lambda sens: ct_builder_tests._rows_nx(sens["CO1"]) if "CO1" in sens else None,
        [ct_builder_tests._ae(), ct_builder_tests._scanned_ae()], {"B1": {1: 1100.0}, "S1": {1: 600.0}},
    )
    _assert_same(old, new)


def test_the_aggregated_curative_model_equals_the_per_unit_model_in_objective_volumes_and_flows():
    per_unit = dict(ct_builder_tests.SENSITIVITY)
    nx = {co: dict(per_unit) for co in ("CO1", "CO2")}

    def nx_inputs_of(sens):
        inputs = ct_builder_tests._cur_nx()
        return dataclasses.replace(inputs, sensitivity_rd_nx=sens)

    old, new = _both(ct_builder_tests._cur_inputs(), per_unit, nx, nx_inputs_of, [ct_builder_tests._ae()], {"B1": {1: 500.0}}, True)
    _assert_same(old, new)


def test_a_unit_shared_with_rd_keeps_its_own_term_for_the_rd_part_only():
    # A1 is in the weights of the countertrade bid and the unit of an RD bid: the RD volume acts with the unit's own
    # sensitivity, the countertrade volume with the variable of its RA and direction, and no volume is counted twice
    units, bids, glsk = ct_builder_tests._rd_pair()
    per_unit = dict(ct_builder_tests.SENSITIVITY)
    new_inputs = ct_builder_tests._inputs(units, bids, glsk, penalty_reference_rd_pra=5.0)
    old_inputs = dataclasses.replace(_plain_rd(new_inputs), sensitivity_rd_n0_pruned=dict(per_unit))
    new_inputs = dataclasses.replace(new_inputs, sensitivity_rd_n0_pruned=_zone_sensitivity(per_unit, new_inputs))
    # the zone-keyed form drops the shared unit's own entries: put the RD units' ones back
    new_inputs.sensitivity_rd_n0_pruned.update({("B1", "A1"): 0.4, ("B1", "B1"): -0.1})
    old, new = (ct_builder_tests._solved(inputs) for inputs in (old_inputs, new_inputs))
    assert pyo.value(new.rd_effect_on_branch["B1"]) == pytest.approx(pyo.value(old.rd_effect_on_branch["B1"]), rel=1e-8)
    assert pyo.value(new.objective) == pytest.approx(pyo.value(old.objective), rel=1e-8)


# ---------------------------------------------------------------------------
# size: 2 terms per RA in a flow row, whatever the number of units
# ---------------------------------------------------------------------------

def _many_units_inputs(unit_count):
    gus = [f"U{i}" for i in range(unit_count)]
    weight = 1.0 / unit_count
    units = [ct_builder_tests._units("CT_A", gus, True)[i] for i in range(unit_count)]
    up_units = [dataclasses.replace(u, mrid="CT_B") for u in units]
    bids = [ct_builder_tests._bid("BID_A_DOWN", "CT_A", DOWN, 300.0, 8.0), ct_builder_tests._bid("BID_B_UP", "CT_B", UP, 300.0, 20.0)]
    participation = {"BID_A_DOWN": {g: weight for g in gus}, "BID_B_UP": {g: weight for g in gus}}
    generators = {g: {"target_p": 200.0, "max_p": 400.0, "min_p": 0.0, "connected": True, "name": g} for g in gus}
    zone = {("B1", "CT|CT_A|down"): -0.3, ("B1", "CT|CT_B|up"): 0.1}
    return RdMilpInputs(
        rd_list=units + up_units, bid_list=bids, glsk={}, sensitivity_rd_n0_pruned=zone, generator_data=generators,
        penalty_reference_rd_pra=0.0, bid_participation=participation, penalty_reference_ct_pra=100.0,
        penalty_reference_ct_cra=100.0,
    ), zone


@pytest.mark.parametrize("unit_count", [4, 120])
def test_a_flow_row_has_two_countertrade_variables_whatever_the_number_of_units(unit_count):
    rd_inputs, zone = _many_units_inputs(unit_count)
    nx_inputs = ct_builder_tests._rows_nx(zone)
    model = build_n0_milp_model(
        [ct_builder_tests._ae()], TS, lf_initial={"B1": {1: 1100.0}}, penalty_cost_overload_n0=1e6, rd_inputs=rd_inputs,
        nx_inputs=dataclasses.replace(nx_inputs, lf_nx={"CO1": {"B1": {1: 1100.0}}}),
    )
    for body in (model.xne_loading_n0["B1"].body, model.nx_patl_loading["B1", "CO1"].body):
        names = {v.name for v in identify_variables(body)}
        bids = {n.split("[")[1].rstrip("]") for n in names if n.startswith("rd_volume")}
        assert bids == {"BID_A_DOWN", "BID_B_UP"}                                      # one term (up - down) per RA and direction
    assert len(list(model.rd_net_injection_g)) == unit_count                          # the unit limits stay per unit


# ---------------------------------------------------------------------------
# the NaN warning
# ---------------------------------------------------------------------------

def test_the_nan_warning_gives_the_count_and_the_first_5_ids_and_the_full_list_at_debug(caplog):
    nan = float("nan")
    sensitivities = {("B1", f"U{i:02d}"): nan for i in range(12)}
    sensitivities[("B1", "OK")] = 1.0
    sensitivities.update({(f"B{i}", "U00"): nan for i in range(2, 9)})
    with caplog.at_level(logging.DEBUG):
        n0_sensitivity._warn_unreadable_entries("RD", sensitivities)
    warnings = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warnings) == 1 and "8 branch(es)" in warnings[0] and "B1: 12 variable(s)" in warnings[0]
    assert "B5" in warnings[0] and "B6" not in warnings[0] and "3 more" in warnings[0]
    debug = " ".join(r.getMessage() for r in caplog.records if r.levelno == logging.DEBUG)
    assert "B8" in debug and "U11" in debug


def test_the_nan_warning_with_few_ids_lists_them_all(caplog):
    with caplog.at_level(logging.DEBUG):
        n0_sensitivity._warn_unreadable_entries("RD", {("B1", "U1"): float("nan"), ("B1", "U2"): float("nan")})
    assert "B1: 2 variable(s)" in caplog.text and "U1, U2" in caplog.text
