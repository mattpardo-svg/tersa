"""
tests/test_rao_run_profile.py - duration and memory of each main step, and the summary table at the end of the run.
The clock and the memory reader are fakes, so the numbers are exact.
"""
import logging
import time

import pytest

import run_profile
from run_profile import RunProfile

MIB = 1024 * 1024


class _Clock:
    def __init__(self):
        self.now = 100.0

    def __call__(self):
        return self.now


class _Memory:
    def __init__(self, value_mib=100):
        self.value = value_mib * MIB

    def __call__(self):
        return self.value


def _profile(clock=None, memory=None):
    clock = clock or _Clock()
    memory = memory or _Memory()
    return RunProfile(clock=clock, rss_reader=memory, interval_seconds=None), clock, memory


def _table(profile, caplog):
    with caplog.at_level(logging.INFO):
        profile.finish()
    return [r.getMessage() for r in caplog.records]


def test_each_step_logs_its_duration_and_memory_when_it_ends(caplog):
    profile, clock, memory = _profile()
    with caplog.at_level(logging.INFO):
        profile.start("Setup")
        clock.now += 2.5
        memory.value = 150 * MIB
        profile.mark("Load")
    messages = [r.getMessage() for r in caplog.records]
    assert any("Step 'Setup' took 2.5 s" in m and "150 MiB" in m for m in messages)


def test_the_peak_is_the_largest_sample_during_the_step(caplog):
    profile, clock, memory = _profile()
    profile.start("Setup")
    memory.value = 400 * MIB
    profile.sample_now()
    memory.value = 120 * MIB
    clock.now += 1
    profile.mark("Load")
    row = profile.rows()[0]
    assert row["rss_end_mib"] == 120 and row["peak_mib"] == 400


def test_a_step_that_comes_back_is_added_up(caplog):
    profile, clock, _ = _profile()
    profile.start("Build")
    clock.now += 1
    profile.mark("Solve")
    clock.now += 4
    profile.mark("Build")
    clock.now += 2
    profile.finish()
    rows = {row["step"]: row for row in profile.rows()}
    assert rows["Build"]["seconds"] == pytest.approx(3.0) and rows["Solve"]["seconds"] == pytest.approx(4.0)
    assert [row["step"] for row in profile.rows()] == ["Build", "Solve"]


def test_the_table_gives_step_duration_share_end_and_peak_and_the_totals(caplog):
    profile, clock, memory = _profile()
    profile.start("Setup")
    clock.now += 1
    profile.mark("Solve")
    memory.value = 300 * MIB
    profile.sample_now()
    clock.now += 3
    text = "\n".join(_table(profile, caplog))
    messages = text.splitlines()
    assert "Run summary" in text
    setup_line = next(m for m in messages if m.strip().startswith("Setup"))
    solve_line = next(m for m in messages if m.strip().startswith("Solve"))
    assert "25.0 %" in setup_line and "75.0 %" in solve_line and "300" in solve_line
    assert "Total run time 4.0 s" in text and "overall peak 300 MiB" in text


def test_finish_without_a_start_logs_nothing(caplog):
    profile, _, _ = _profile()
    assert _table(profile, caplog) == []


def test_without_psutil_the_time_is_logged_with_one_warning(caplog, monkeypatch):
    monkeypatch.setattr(run_profile, "psutil", None)
    clock = _Clock()
    profile = RunProfile(clock=clock, interval_seconds=None)           # default reader: needs psutil
    with caplog.at_level(logging.INFO):
        profile.start("Setup")
        clock.now += 1
        profile.mark("Solve")
        clock.now += 1
        profile.finish()
    warnings = [r for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warnings) == 1 and "psutil" in warnings[0].getMessage()
    assert any("Total run time 2.0 s" in r.getMessage() for r in caplog.records)
    assert not any("MiB" in r.getMessage() for r in caplog.records)


def test_the_default_reader_uses_psutil_when_it_is_installed(monkeypatch):
    class _Process:
        def memory_info(self):
            return type("Info", (), {"rss": 64 * MIB})()

    monkeypatch.setattr(run_profile, "psutil", type("FakePsutil", (), {"Process": staticmethod(lambda: _Process())}))
    assert run_profile.default_rss_reader()() == 64 * MIB


def test_the_module_functions_do_nothing_before_a_start(caplog):
    run_profile.reset()
    with caplog.at_level(logging.INFO):
        run_profile.mark("Anything")
    assert not caplog.records


def test_the_background_thread_samples_and_stops_at_finish():
    memory = _Memory(100)
    profile = RunProfile(rss_reader=memory, interval_seconds=0.01)
    profile.start("Setup")
    memory.value = 500 * MIB
    time.sleep(0.15)
    memory.value = 100 * MIB
    profile.mark("Next")
    assert profile.rows()[0]["peak_mib"] == 500
    profile.finish()


def test_the_pipeline_logs_the_table_when_the_run_fails(monkeypatch, caplog, tmp_path):
    import run_pipeline

    (tmp_path / "input").mkdir()
    monkeypatch.setattr(run_pipeline, "INPUT_DIR", tmp_path / "input")        # no CGM zip: the run fails at the first step
    monkeypatch.setattr(run_pipeline, "OUTPUT_DIR", tmp_path / "output")
    with caplog.at_level(logging.INFO):
        with pytest.raises(Exception):
            run_pipeline.main()
    text = "\n".join(r.getMessage() for r in caplog.records)
    assert "Run summary" in text and "CGM load + base-case load flow" in text
    run_profile.reset()
