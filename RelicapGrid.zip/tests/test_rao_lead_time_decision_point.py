"""tests/test_rao_lead_time_decision_point.py - the lead-time decision point (lead_time.decision_point_hours_before_run):
the rule, the date, the builder (preventive and curative), the one summary line, the results file and the config key.
Synthetic ids and values only."""

import logging
from pathlib import Path

import pyomo.environ as pyo
import pytest
import yaml

import run_pipeline
from data_model import AEType, AssessedElement, BidDirection, PowerBid, RAKind, RDUnit
from milp.milp_builder import NxMilpInputs, RdMilpInputs, build_n0_milp_model, _lead_time_is_usable, describe_decision_point
CONFIG_DIR = Path(run_pipeline.__file__).parent / "config"
AVAILABLE_MW = 40.0


# ---- the rule and the date ----------------------------------------------------------------------------------------

@pytest.mark.parametrize("hours, lead, usable", [
    (1.0, 0.99, True), (1.0, 1.0, False), (1.0, 1.25, False), (6.0, 5.9, True), (6.0, 6.0, False), (6.0, 7.0, False),
    (0.0, 0.25, False), (2.5, 2.4, True), (2.5, 2.5, False),
])
def test_rao_a_bid_is_usable_when_its_lead_time_is_shorter_than_the_decision_point_distance(hours, lead, usable):
    assert _lead_time_is_usable(None, hours, lead, "0030Z") is usable


def test_rao_an_explicit_reference_time_still_overrides_the_decision_point_distance():
    assert _lead_time_is_usable("2330Z", 99.0, 3.0, "0230Z") is False     # cutoff 0230Z, strict
    assert _lead_time_is_usable("2330Z", 0.1, 3.0, "0330Z") is True


@pytest.mark.parametrize("timestamp, hours, text", [
    ("1030Z", 1.0, "0930Z"), ("0030Z", 1.0, "2330Z the day before"), ("0230Z", 6.0, "2030Z the day before"),
    ("1030Z", 30.0, "0430Z the day before"), ("1030Z", 54.0, "0430Z 2 days before"), ("1030Z", 1.25, "0915Z"),
])
def test_rao_the_decision_point_text_gives_the_clock_time_and_the_day(timestamp, hours, text):
    assert describe_decision_point(None, hours, timestamp) == text


# ---- the builder: preventive and curative -------------------------------------------------------------------------

def _unit(kind):
    return RDUnit(
        mrid="RD1", name="RD1", tso="TestTSO", gu_mrid="GU1", gu_name="GU1", available=True, kind=kind,
        initial_p=50.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None,
        linked_contingency_mrids=["CO1"] if kind == RAKind.CURATIVE else [], linked_xne_mrids=[],
    )


def _model(kind, lead_time_h, decision_point_hours_before_run=None, bid_count=1):
    units = [_unit(kind)]
    bids = [PowerBid(mrid="BID1", ra_mrid="RD1", direction=BidDirection.UP, available_mw={"1030Z": AVAILABLE_MW},
                     price_eur_mw=10.0, lead_time_h=lead_time_h, activation_cost_eur=None)]
    glsk, generator_data = {"RD1": {"GU1": 1.0}}, {"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}}
    for index in range(2, bid_count + 1):
        mrid = f"RD{index}"
        units.append(RDUnit(**{**_unit(kind).__dict__, "mrid": mrid, "name": mrid, "gu_mrid": f"GU{index}", "gu_name": f"GU{index}"}))
        bids.append(PowerBid(mrid=f"BID{index}", ra_mrid=mrid, direction=BidDirection.UP, available_mw={"1030Z": AVAILABLE_MW},
                             price_eur_mw=10.0, lead_time_h=lead_time_h, activation_cost_eur=None))
        glsk[mrid] = {f"GU{index}": 1.0}
        generator_data[f"GU{index}"] = {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}
    extra = {} if decision_point_hours_before_run is None else {"decision_point_hours_before_run": decision_point_hours_before_run}
    rd_inputs = RdMilpInputs(rd_list=units, bid_list=bids, glsk=glsk, sensitivity_rd_n0_pruned={}, generator_data=generator_data,
                             penalty_reference_rd_pra=10.0, **extra)
    ae = AssessedElement(mrid="AE_B1", name="AE B1", tso="TestTSO", ae_type=AEType.SECURED, branch_mrid="B1",
                         secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
                         patl_ka={"1030Z": 1.0}, branch_side=1)
    nx_inputs = None
    if kind == RAKind.CURATIVE:
        nx_inputs = NxMilpInputs(lf_nx={"CO1": {"B1": {1: 1050.0}}}, sensitivity_pst_nx={},
                                 sensitivity_rd_nx={"CO1": {("B1", "GU1"): -10.0}}, penalty_cost_overload_nx_patl=1e6)
    return build_n0_milp_model([ae], "1030Z", lf_initial={"B1": {1: 500.0}}, penalty_cost_overload_n0=1e6,
                               rd_inputs=rd_inputs, nx_inputs=nx_inputs)


def _upper_bound(model, kind):
    variable = model.rd_volume_upward["BID1"] if kind == RAKind.PREVENTIVE else model.curative_rd_volume_upward["BID1", "CO1"]
    return pyo.value(variable.ub)


@pytest.mark.parametrize("kind", [RAKind.PREVENTIVE, RAKind.CURATIVE])
@pytest.mark.parametrize("hours, lead, usable", [(None, 0.5, True), (None, 1.0, False), (3.0, 2.5, True), (3.0, 3.0, False),
                                                 (0.25, 0.5, False), (0.0, 0.5, False)])
def test_rao_the_builder_blocks_a_bid_whose_lead_time_is_not_shorter_than_the_decision_point_distance(kind, hours, lead, usable):
    assert _upper_bound(_model(kind, lead, hours), kind) == (AVAILABLE_MW if usable else 0.0)


# ---- the summary line -----------------------------------------------------------------------------------------------

@pytest.mark.parametrize("kind", [RAKind.PREVENTIVE, RAKind.CURATIVE])
def test_rao_blocked_bids_give_one_summary_line_with_the_decision_point(kind, caplog):
    with caplog.at_level(logging.DEBUG):
        _model(kind, 2.0, 1.0, bid_count=7)
    lines = [r.getMessage() for r in caplog.records if r.levelno == logging.INFO and "lead time" in r.getMessage()]
    assert len(lines) == 1
    line = lines[0]
    assert f"7 {kind.value} bid(s)" in line and "0930Z" in line and "1 h before the run" in line
    assert "BID1, BID2, BID3, BID4, BID5 and 2 more" in line and "BID6" not in line
    assert any("BID6" in r.getMessage() and "BID7" in r.getMessage() for r in caplog.records if r.levelno == logging.DEBUG)
    assert not [r for r in caplog.records if "not satisfied" in r.getMessage()]


def test_rao_no_blocked_bid_gives_no_lead_time_line(caplog):
    with caplog.at_level(logging.DEBUG):
        _model(RAKind.PREVENTIVE, 0.5, 1.0, bid_count=2)
    assert not [r for r in caplog.records if "lead time" in r.getMessage() and r.levelno >= logging.INFO]


# ---- results file -------------------------------------------------------------------------------------------------

# ---- config key ----------------------------------------------------------------------------------------------------

def _config(name="rao_config.yaml"):
    return yaml.safe_load((CONFIG_DIR / name).read_text(encoding="utf-8"))


@pytest.mark.parametrize("name", ["rao_config.yaml", "rao_config.default.yaml"])
def test_rao_both_config_files_have_the_decision_point_at_one_hour(name):
    assert _config(name)["lead_time"]["decision_point_hours_before_run"] == 1.0


@pytest.mark.parametrize("value", [-0.5, "soon", True, None])
def test_rao_the_decision_point_is_validated(value):
    config = _config()
    config["lead_time"]["decision_point_hours_before_run"] = value
    with pytest.raises(ValueError, match="lead_time.decision_point_hours_before_run"):
        run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))


def test_rao_a_missing_decision_point_key_is_a_config_key_error():
    config = _config()
    del config["lead_time"]
    with pytest.raises(run_pipeline.ConfigKeyError, match="lead_time.decision_point_hours_before_run"):
        run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))


def test_rao_a_config_with_twelve_hours_gives_a_decision_point_twelve_hours_before_the_run(caplog):
    config = _config()
    config["lead_time"]["decision_point_hours_before_run"] = 12.0
    run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))
    hours = float(run_pipeline._config_value(config, ("lead_time", "decision_point_hours_before_run"), Path("rao_config.yaml")))
    assert describe_decision_point(None, hours, "0030Z") == "1230Z the day before"
    with caplog.at_level(logging.INFO):
        model = _model(RAKind.PREVENTIVE, 6.0, hours)          # a 6 h lead time is usable with 12 h, blocked with 1 h
        assert _upper_bound(model, RAKind.PREVENTIVE) == AVAILABLE_MW
        _model(RAKind.PREVENTIVE, 13.0, hours)
    line = [r.getMessage() for r in caplog.records if "blocked by their lead time" in r.getMessage()]
    assert len(line) == 1 and "12 h before the run" in line[0] and "0030Z" not in line[0].split("decision point")[1][:6]


def test_rao_zero_is_a_valid_decision_point():
    config = _config()
    config["lead_time"]["decision_point_hours_before_run"] = 0
    run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))

