"""
tests/test_rao_nan_branch_summary.py - the branches left out of the MILP for a NaN N-0 sensitivity are one summary warning
(count, first 5 ids), the full list at debug level.
"""
import logging

from data_model import AEType
from helpers import _make_ae_mb_scanned, _make_pst_mb_scanned
from milp.milp_builder import PstMilpInputs, build_n0_milp_model


def _model_with_nan_branches(count, caplog):
    names = [f"BR_{n:02d}" for n in range(count)]
    ae = [_make_ae_mb_scanned(name, AEType.SECURED, 1, 1.0) for name in ["OK_BRANCH", *names]]
    lf = {name: {1: 500.0} for name in ["OK_BRANCH", *names]}
    sensitivity = {("OK_BRANCH", "PST1"): 5.0, **{(name, "PST1"): float("nan") for name in names}}
    inputs = PstMilpInputs(
        pst_list=[_make_pst_mb_scanned("PST1")], pst_tap_bounds={"PST1": (-5, 5)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned=sensitivity, pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=10.0,
    )
    with caplog.at_level(logging.DEBUG):
        model = build_n0_milp_model(ae, "1030Z", lf, 1000.0, pst_inputs=inputs)
    return model


def test_many_nan_branches_are_one_warning_with_the_count_and_the_first_five(caplog):
    model = _model_with_nan_branches(8, caplog)
    assert set(model.branch_ids) == {"OK_BRANCH"}
    warnings = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING and "NaN N-0 sensitivity" in r.getMessage()]
    assert len(warnings) == 1
    assert "8 branch" in warnings[0] and "BR_04" in warnings[0] and "BR_05" not in warnings[0] and "and 3 more" in warnings[0]


def test_the_full_list_of_nan_branches_is_at_debug_level(caplog):
    _model_with_nan_branches(8, caplog)
    assert any(r.levelno == logging.DEBUG and "BR_07" in r.getMessage() and "NaN N-0" in r.getMessage() for r in caplog.records)


def test_no_nan_branch_means_no_warning(caplog):
    _model_with_nan_branches(0, caplog)
    assert not [r for r in caplog.records if "NaN N-0" in r.getMessage()]
