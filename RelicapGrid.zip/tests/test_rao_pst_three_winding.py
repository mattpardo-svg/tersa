"""
tests/test_rao_pst_three_winding.py - a PST whose tap changer sits on a 3-winding transformer is left out of the PST list once,
before every step (sensitivities, MILP, groups, apply, AC verification, outputs). Synthetic network tables only.
"""
import logging

import pandas as pd

from data_model import PST, RAKind
from pre_milp import pst_groups
from pre_milp.pst_support import exclude_three_winding_psts


class _Network:
    """Only the three tables the filter reads."""

    def __init__(self, two_winding=(), three_winding=(), phase_changers=()):
        self._two, self._three, self._ptc = list(two_winding), list(three_winding), list(phase_changers)

    def get_2_windings_transformers(self):
        return pd.DataFrame(index=pd.Index(self._two, name="id"))

    def get_3_windings_transformers(self):
        return pd.DataFrame(index=pd.Index(self._three, name="id"))

    def get_phase_tap_changers(self):
        return pd.DataFrame(index=pd.Index(self._ptc, name="id"))


def _pst(mrid, group_id=None, kind=RAKind.PREVENTIVE, r0=0):
    return PST(
        mrid=mrid, name=mrid, tso="TSO_A", available=True, kind=kind, penalty_factor=1.0, low_step=-10, high_step=10,
        r0=r0, operating_tap_min=-10, operating_tap_max=10, group_id=group_id,
    )


def _warnings(caplog):
    return [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]


def test_a_pst_on_a_three_winding_transformer_is_removed_with_one_summary_warning(caplog):
    network = _Network(two_winding=["P1"], three_winding=["T3"], phase_changers=["P1", "T3"])
    with caplog.at_level(logging.DEBUG):
        kept = exclude_three_winding_psts(network, [_pst("P1"), _pst("T3")])
    assert [p.mrid for p in kept] == ["P1"]
    summary = [m for m in _warnings(caplog) if "3-winding" in m]
    assert len(summary) == 1 and "1 PST" in summary[0] and "T3" in summary[0]


def test_the_summary_names_the_first_five_ids_and_the_full_list_is_debug(caplog):
    ids = [f"T3_{n}" for n in range(8)]
    network = _Network(three_winding=ids, phase_changers=ids)
    with caplog.at_level(logging.DEBUG):
        exclude_three_winding_psts(network, [_pst(i) for i in ids])
    summary = [r for r in caplog.records if r.levelno == logging.WARNING and "3-winding" in r.getMessage()]
    assert len(summary) == 1
    text = summary[0].getMessage()
    assert "8 PST" in text and "T3_4" in text and "T3_5" not in text and "and 3 more" in text
    assert any(r.levelno == logging.DEBUG and "T3_7" in r.getMessage() for r in caplog.records)


def test_both_rows_of_a_transformer_with_a_preventive_and_a_curative_remedial_action_go():
    network = _Network(three_winding=["T3"], phase_changers=["T3"])
    kept = exclude_three_winding_psts(network, [_pst("T3"), _pst("T3", kind=RAKind.CURATIVE), _pst("P1")])
    assert [p.mrid for p in kept] == ["P1"]


def test_a_pst_that_is_not_in_the_network_at_all_is_kept():
    network = _Network(two_winding=["P1"], phase_changers=["P1"])
    assert [p.mrid for p in exclude_three_winding_psts(network, [_pst("P1"), _pst("UNKNOWN")])] == ["P1", "UNKNOWN"]


def test_without_a_three_winding_pst_nothing_changes_and_nothing_is_logged(caplog):
    network = _Network(two_winding=["P1", "P2"], phase_changers=["P1", "P2"])
    psts = [_pst("P1", "G1"), _pst("P2", "G1")]
    with caplog.at_level(logging.WARNING):
        kept = exclude_three_winding_psts(network, psts)
    assert kept == psts and not _warnings(caplog)


def test_an_excluded_member_leaves_its_group_and_a_group_with_two_members_left_stays(caplog):
    network = _Network(two_winding=["P1", "P2"], three_winding=["T3"], phase_changers=["P1", "P2", "T3"])
    with caplog.at_level(logging.WARNING):
        kept = exclude_three_winding_psts(network, [_pst("P1", "G1"), _pst("P2", "G1"), _pst("T3", "G1")])
    assert [(p.mrid, p.group_id) for p in kept] == [("P1", "G1"), ("P2", "G1")]
    group_warnings = [m for m in _warnings(caplog) if "G1" in m]
    assert len(group_warnings) == 1 and "T3" in group_warnings[0] and "dissolved" not in group_warnings[0]


def test_a_group_left_with_fewer_than_two_psts_is_dissolved_with_one_warning(caplog):
    network = _Network(two_winding=["P1"], three_winding=["T3"], phase_changers=["P1", "T3"])
    with caplog.at_level(logging.WARNING):
        kept = exclude_three_winding_psts(network, [_pst("P1", "G1"), _pst("T3", "G1"), _pst("P9", "G9")])
    assert [(p.mrid, p.group_id) for p in kept] == [("P1", None), ("P9", "G9")]
    group_warnings = [m for m in _warnings(caplog) if "G1" in m]
    assert len(group_warnings) == 1 and "dissolved" in group_warnings[0]


def test_the_input_psts_are_not_changed():
    network = _Network(two_winding=["P1"], three_winding=["T3"], phase_changers=["P1", "T3"])
    original = _pst("P1", "G1")
    exclude_three_winding_psts(network, [original, _pst("T3", "G1")])
    assert original.group_id == "G1"


def test_the_filtered_list_has_no_group_pair_and_no_model_variable_for_the_excluded_pst():
    from helpers import _make_ae_mb_scanned
    from data_model import AEType
    from milp.milp_builder import PstMilpInputs, build_n0_milp_model
    network = _Network(two_winding=["P1", "P2"], three_winding=["T3"], phase_changers=["P1", "P2", "T3"])
    kept = exclude_three_winding_psts(network, [_pst("P1", "G1", r0=1), _pst("P2", "G1", r0=1), _pst("T3", "G1")])
    bounds = {"P1": (-5, 5), "P2": (-5, 5)}
    pairs = pst_groups.build_pst_group_equality_pairs(kept, bounds)
    assert pairs == [("P1", "P2")]
    inputs = PstMilpInputs(
        pst_list=kept, pst_tap_bounds=bounds, pst_group_equality_pairs=pairs,
        sensitivity_pst_n0_pruned={("B1", "P1"): 5.0}, pst_degrees_per_tap={"P1": 1.0, "P2": 1.0},
        penalty_reference_pst_pra=10.0,
    )
    model = build_n0_milp_model(
        [_make_ae_mb_scanned("B1", AEType.SECURED, 1, 1.0)], "1030Z", {"B1": {1: 500.0}}, 1000.0, pst_inputs=inputs,
    )
    assert set(model.pst_ids) == {"P1", "P2"}
