"""tests/test_rao_shift_key_machines.py - a shift key that names a SynchronousMachine (or another RotatingMachine) instead of its
GeneratingUnit is mapped through the CGM EQ (RotatingMachine.GeneratingUnit, CGMES 3.0 and 2.4.15). Synthetic ids."""

import logging

import pytest

from pre_milp import glsk_resolver, ncp_parser
from data_model import RAKind, RDUnit
from text_encoding import TEXT_ENCODING

HEADER = ('<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:nc="https://cim4.eu/ns/nc#">')
EQ_30 = ('<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:cim="http://iec.ch/TC57/CIM100#">'
         '<cim:SynchronousMachine rdf:ID="_MACH1"><cim:RotatingMachine.GeneratingUnit rdf:resource="#_UNIT1"/></cim:SynchronousMachine>'
         '<cim:AsynchronousMachine rdf:ID="_MACH2"><cim:RotatingMachine.GeneratingUnit rdf:resource="#_UNIT2"/></cim:AsynchronousMachine>'
         '<cim:SynchronousMachine rdf:ID="_MACH3"></cim:SynchronousMachine></rdf:RDF>')
EQ_2415 = ('<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:cim="http://iec.ch/TC57/2013/CIM-schema-cim16#">'
           '<cim:SynchronousMachine rdf:ID="_MACH1"><cim:RotatingMachine.GeneratingUnit rdf:resource="#_UNIT1"/></cim:SynchronousMachine>'
           '</rdf:RDF>')


def _sis(resource_predicates):
    keys = "".join(
        f'<nc:PowerShiftKeySchedule rdf:ID="_KEY{i}"><cim:IdentifiedObject.mRID>KEY{i}</cim:IdentifiedObject.mRID>'
        f'<nc:PowerShiftKeySchedule.{predicate} rdf:resource="#_{target}"/></nc:PowerShiftKeySchedule>'
        f'<nc:PowerShiftKeyDistribution rdf:ID="_D{i}"><nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_BID1"/>'
        f'<nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_KEY{i}"/></nc:PowerShiftKeyDistribution>'
        f'<nc:ParticipationFactorTimePoint rdf:ID="_F{i}"><nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_KEY{i}"/>'
        f'<nc:ParticipationFactorTimePoint.participationFactor>0.5</nc:ParticipationFactorTimePoint.participationFactor>'
        f'</nc:ParticipationFactorTimePoint>'
        for i, (predicate, target) in enumerate(resource_predicates))
    return (HEADER + '<nc:PowerBidSchedule rdf:ID="_BID1"><cim:IdentifiedObject.mRID>BID1</cim:IdentifiedObject.mRID>'
            '<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/></nc:PowerBidSchedule>' + keys + "</rdf:RDF>")


def _rd(mrid="RA1"):
    return RDUnit(mrid=mrid, name=mrid, tso="X", gu_mrid="G1", gu_name="G1", available=True, kind=RAKind.PREVENTIVE,
                  initial_p=0.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None)


@pytest.mark.parametrize("eq_text", [EQ_30, EQ_2415], ids=["cgmes 3.0", "cgmes 2.4.15"])
def test_rao_the_machine_to_unit_map_reads_both_cgmes_forms(tmp_path, eq_text):
    path = tmp_path / "X_EQ.xml"
    path.write_text(eq_text, encoding=TEXT_ENCODING)
    mapping = ncp_parser.read_machine_units([path])
    assert mapping[ncp_parser.id_key("MACH1")] == "UNIT1"
    assert ncp_parser.id_key("MACH3") not in mapping            # a machine without a unit is not in the map


def test_rao_a_machine_in_the_shift_key_resolves_to_its_generator(tmp_path, caplog):
    sis_path = tmp_path / "X_SIS.xml"
    sis_path.write_text(_sis([("GeneratingUnit", "MACH1"), ("SynchronousMachine", "MACH2")]), encoding=TEXT_ENCODING)
    machines = {ncp_parser.id_key("MACH1"): "UNIT1", ncp_parser.id_key("MACH2"): "UNIT2"}
    with caplog.at_level(logging.INFO):
        glsk = glsk_resolver.resolve_glsk(
            sis_path, [_rd()], "X", {"GEN1", "GEN2"}, "1030Z",
            generators_by_unit={"UNIT1": ["GEN1"], "UNIT2": ["GEN2"]}, unit_of_machine=machines)
    assert glsk == {"RA1": {"GEN1": 0.5, "GEN2": 0.5}}
    lines = [r.getMessage() for r in caplog.records if "RotatingMachine" in r.getMessage() and "GeneratingUnit" in r.getMessage()]
    assert len(lines) == 1 and "2 shift-key resource(s)" in lines[0]


def test_rao_without_the_map_a_machine_is_still_not_supported(tmp_path):
    sis_path = tmp_path / "X_SIS.xml"
    sis_path.write_text(_sis([("GeneratingUnit", "MACH1")]), encoding=TEXT_ENCODING)
    glsk = glsk_resolver.resolve_glsk(sis_path, [_rd()], "X", {"GEN1"}, "1030Z", generators_by_unit={"UNIT1": ["GEN1"]})
    assert glsk == {"RA1": {}}


def test_rao_other_resource_classes_are_counted_per_class(tmp_path, caplog):
    sis_path = tmp_path / "X_SIS.xml"
    sis_path.write_text(_sis([("HydroPump", "P1"), ("HydroPump", "P2"), ("EnergyConsumer", "C1")]), encoding=TEXT_ENCODING)
    with caplog.at_level(logging.INFO):
        glsk_resolver.resolve_glsk(sis_path, [_rd()], "X", {"GEN1"}, "1030Z", generators_by_unit={"UNIT1": ["GEN1"]})
    lines = [r.getMessage() for r in caplog.records if "not resolved" in r.getMessage() and "shift key" in r.getMessage()]
    assert len(lines) == 1 and "EnergyConsumer: 1" in lines[0] and "HydroPump: 2" in lines[0]
