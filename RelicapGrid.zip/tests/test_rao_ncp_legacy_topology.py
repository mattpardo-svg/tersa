"""
tests/test_rao_ncp_legacy_topology.py - the NCP 2.2 legacy form (docs/specs/ncp_data_requirements.md section 13, DECISIONS 168):
remedial actions with an nc:TopologyAction (switch actions with a StaticPropertyRange on Switch.open) are not modelled: one summary
info line per RA file with their count, no line per RA, and no other warning because of them.
"""
import logging
import xml.etree.ElementTree as ET

import pytest
from rdflib import RDF

from helpers import mock_generators_by_unit
from mock_builders import standard
from mock_builders import legacy_writer as legacy_form
from pre_milp import hvdc_units, ncp_parser

NC = ncp_parser.NC
RDF_NS = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
HEADER = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:nc="https://cim4.eu/ns/nc#" xmlns:cim="https://cim.ucaiug.io/ns#">
"""


def _topology_ra(ident):
    return f"""  <nc:GridStateAlterationRemedialAction rdf:ID="_RA_{ident}"><cim:IdentifiedObject.mRID>RA_{ident}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>MOCK_TOPOLOGY_{ident}</cim:IdentifiedObject.name><nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
  </nc:GridStateAlterationRemedialAction>
  <nc:TopologyAction rdf:ID="_TA_{ident}"><nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA_{ident}"/>
    <nc:GridStateAlteration.PropertyReference rdf:resource="http://example.invalid/PropertyReference/Switch.open"/></nc:TopologyAction>
  <nc:StaticPropertyRange rdf:ID="_SPR_{ident}"><nc:RangeConstraint.GridStateAlteration rdf:resource="#_TA_{ident}"/>
    <nc:StaticPropertyRange.PropertyReference rdf:resource="http://example.invalid/PropertyReference/Switch.open"/>
    <nc:RangeConstraint.normalValue>1</nc:RangeConstraint.normalValue></nc:StaticPropertyRange>
"""


def _ra_file(tmp_path, count):
    path = tmp_path / "X_RA.xml"
    path.write_text(HEADER + "".join(_topology_ra(i) for i in range(count)) + "</rdf:RDF>\n", encoding="utf-8")
    return path


def _topology_lines(caplog):
    return [r for r in caplog.records if "topology remedial action" in r.getMessage()]


def test_rao_the_topology_ras_of_an_ra_file_are_one_summary_info_line_with_their_count(tmp_path, caplog):
    with caplog.at_level(logging.DEBUG):
        ncp_parser.note_topology_remedial_actions(_ra_file(tmp_path, 3), "TSO-X")
    lines = _topology_lines(caplog)
    assert len(lines) == 1 and lines[0].levelno == logging.INFO
    text = lines[0].getMessage()
    assert "X_RA.xml" in text and "3 topology remedial action(s)" in text and "not modelled" in text
    assert "MOCK_TOPOLOGY" not in caplog.text and "RA_0" not in caplog.text                 # no per-RA line


def test_rao_a_file_without_a_topology_ra_gives_no_line(tmp_path, caplog):
    with caplog.at_level(logging.DEBUG):
        ncp_parser.note_topology_remedial_actions(_ra_file(tmp_path, 0), "TSO-X")
    assert not _topology_lines(caplog)


def test_rao_the_standard_mock_has_no_topology_ra_and_the_legacy_mock_has_one(tmp_path, caplog):
    for name, data in standard.shipped_files().items():
        if name.endswith("_RA.xml"):
            (tmp_path / name).write_bytes(data)
            with caplog.at_level(logging.INFO):
                ncp_parser.note_topology_remedial_actions(tmp_path / name, name)
    assert not _topology_lines(caplog)
    legacy = {n: d for n, d in legacy_form.legacy_files().items() if "_RA_" in n}
    counts = {}
    for name, data in legacy.items():
        (tmp_path / name).write_bytes(data)
        caplog.clear()
        with caplog.at_level(logging.INFO):
            ncp_parser.note_topology_remedial_actions(tmp_path / name, name)
        counts[name] = len(_topology_lines(caplog))
    assert sorted(counts.values()) == [0, 0, 0, 1]


def _without_topology(path, target):
    """The RA file without its topology RA, action and range."""
    graph = ncp_parser._load_graph(path)
    ids = set()
    for action in graph.subjects(RDF.type, NC.TopologyAction):
        ids.add(str(action).rsplit("#", 1)[-1])
        ids.add(str(graph.value(action, NC["GridStateAlteration.GridStateAlterationRemedialAction"])).rsplit("#", 1)[-1])
        ids.update(str(r).rsplit("#", 1)[-1] for r in graph.subjects(NC["RangeConstraint.GridStateAlteration"], action))
    tree = ET.parse(path)
    root = tree.getroot()
    for element in list(root):
        if element.get(f"{{{RDF_NS}}}ID") in ids:
            root.remove(element)
    tree.write(target, encoding="utf-8", xml_declaration=True)
    return len(ids)


def _warnings_of_the_readers(ra_path, sis_path, caplog):
    caplog.clear()
    ae_less = {"tap": {}, "gen": {}}
    with caplog.at_level(logging.WARNING):
        ncp_parser.parse_psts(ra_path, "TSO-X", ae_less["tap"], {})
        ncp_parser.parse_rd_units(ra_path, sis_path, "TSO-X", "1030Z", ae_less["gen"], generators_by_unit=mock_generators_by_unit())
        ncp_parser.parse_hvdc_units(ra_path, "TSO-X")
        ncp_parser.parse_balanced_ra_groups(ra_path, "TSO-X")
        ncp_parser.build_pst_tap_bounds_curative(ra_path, {})
        ncp_parser.warn_unmatched_ra_references(ra_path, sis_path, "TSO-X")
    return sorted(r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING)


def test_rao_a_topology_ra_triggers_no_other_warning_in_any_reader(tmp_path, caplog):
    for name, data in legacy_form.legacy_files().items():
        (tmp_path / name).write_bytes(data)
    ra = tmp_path / legacy_form.file_name(legacy_form.TOPOLOGY_TSO, "RA")
    sis = tmp_path / legacy_form.file_name(legacy_form.TOPOLOGY_TSO, "SIS")
    stripped = tmp_path / "stripped_RA.xml"
    assert _without_topology(ra, stripped) == 3
    with_topology = _warnings_of_the_readers(ra, sis, caplog)
    without_topology = _warnings_of_the_readers(stripped, sis, caplog)
    assert with_topology == without_topology
    assert not any("opolog" in m or "Switch" in m or "TOPO" in m for m in with_topology)
