"""
tests/test_rao_ncp_pools.py - the NCP files of a profile are read as one pool (whatever their header creator) and the TSO
of an assessed element or a remedial action is taken from its operator (DECISIONS 173): the operator as an EIC URI, as a
local id that the Organisation file resolves, missing (the file's own TSO, the header creator, as before) or a local id
without an Organisation file (the file's TSO, one summary warning per file). Small synthetic snippets.
"""
import logging
import re

import pytest

from mock_builders import legacy_writer
from pre_milp import ncp_loader, ncp_parser
from pre_milp.operators import OperatorDirectory
from text_encoding import TEXT_ENCODING

HEADER = ('<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:nc="https://cim4.eu/ns/nc#">')
TS = "1030Z"
EIC_A, EIC_B = "10X-MOCK-TSO---A", "10X-MOCK-TSO---B"
OPERATOR = "AssessedElement.AssessedSystemOperator"

RUN_TIME_FILES = {"results_iteration_history.csv", "iterations.csv", "summary.csv", "results_summary.csv"}


def _ae(name, operator=None):
    reference = f'<nc:{OPERATOR} rdf:resource="{operator}"/>' if operator else ""
    return (f'<nc:AssessedElement rdf:ID="_{name}"><cim:IdentifiedObject.mRID>{name}</cim:IdentifiedObject.mRID>'
            f'<nc:AssessedElement.ConductingEquipment rdf:resource="#_BR-{name}"/>'
            f'<nc:AssessedElement.SecuredForRegion rdf:resource="#_REGION"/>{reference}</nc:AssessedElement>')


def _parse_aes(tmp_path, body, operators, file_tso="FILE-TSO", name="X_AE.xml"):
    path = tmp_path / name
    path.write_text(HEADER + body + "</rdf:RDF>", encoding=TEXT_ENCODING)
    branches = {f"BR-{mrid}": {1: 1000.0} for mrid in re.findall(r'rdf:ID="_([^"]+)"', body)}
    return {a.mrid: a.tso for a in ncp_parser.parse_assessed_elements(path, None, file_tso, TS, branches, operators=operators)}


# ---------------------------------------------------------------------------
# the operator of an assessed element
# ---------------------------------------------------------------------------

def test_an_operator_given_as_an_eic_uri_is_its_last_path_segment_whatever_the_base(tmp_path):
    body = _ae("A", f"http://energy.referencedata.eu/EIC/{EIC_A}") + _ae("B", f"http://data.europa.eu/energy/EIC/{EIC_B}")
    assert _parse_aes(tmp_path, body, OperatorDirectory()) == {"A": EIC_A, "B": EIC_B}


def test_an_eic_that_is_the_creator_of_a_known_file_takes_the_name_of_that_file_s_tso(tmp_path):
    body = _ae("A", f"http://energy.referencedata.eu/EIC/{EIC_A}") + _ae("B", f"http://energy.referencedata.eu/EIC/{EIC_B}")
    operators = OperatorDirectory(label_by_eic={EIC_A: "TSO-One"})
    assert _parse_aes(tmp_path, body, operators) == {"A": "TSO-One", "B": EIC_B}


def test_a_local_id_resolves_through_the_organisation_file(tmp_path):
    body = _ae("A", "#_op-1") + _ae("B", "#_op-2")
    operators = OperatorDirectory(name_by_id={"op-1": "TSO-One", "op-2": "TSO-Two"}, has_organisation=True)
    assert _parse_aes(tmp_path, body, operators) == {"A": "TSO-One", "B": "TSO-Two"}


def test_a_local_id_without_an_organisation_file_takes_the_files_tso_with_one_summary_per_file(tmp_path, caplog):
    body = "".join(_ae(f"A{i}", f"#_op-{i}") for i in range(7))
    operators = OperatorDirectory()
    with caplog.at_level(logging.WARNING):
        assert set(_parse_aes(tmp_path, body, operators).values()) == {"FILE-TSO"}
        operators.log_unresolved()
    messages = [r.getMessage() for r in caplog.records if "operator" in r.getMessage()]
    assert len(messages) == 1 and "X_AE.xml" in messages[0] and "7" in messages[0]
    assert "A0" in messages[0] and "A4" in messages[0] and "A5" not in messages[0]          # count and the first 5 ids


def test_a_local_id_that_the_organisation_file_does_not_know_takes_the_files_tso(tmp_path):
    operators = OperatorDirectory(name_by_id={"op-1": "TSO-One"}, has_organisation=True)
    assert _parse_aes(tmp_path, _ae("A", "#_other"), operators) == {"A": "FILE-TSO"}


def test_a_missing_operator_takes_the_files_tso_without_a_warning(tmp_path, caplog):
    operators = OperatorDirectory()
    with caplog.at_level(logging.WARNING):
        assert _parse_aes(tmp_path, _ae("A"), operators) == {"A": "FILE-TSO"}
        operators.log_unresolved()
    assert [r for r in caplog.records if "operator" in r.getMessage()] == []


def test_without_a_directory_the_files_tso_is_used_as_before(tmp_path):
    assert _parse_aes(tmp_path, _ae("A", f"http://energy.referencedata.eu/EIC/{EIC_A}"), None) == {"A": "FILE-TSO"}


# ---------------------------------------------------------------------------
# the operator of a remedial action
# ---------------------------------------------------------------------------

def _redispatch_files(tmp_path, operators_by_ra):
    ras, bids, keys = "", "", ""
    for ra, operator in operators_by_ra.items():
        reference = f'<nc:RemedialAction.RemedialActionSystemOperator rdf:resource="{operator}"/>' if operator else ""
        ras += (f'<nc:RedispatchRemedialAction rdf:ID="_{ra}"><cim:IdentifiedObject.mRID>{ra}</cim:IdentifiedObject.mRID>'
                f'<nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>'
                f'<nc:RemedialAction.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionKind.preventive"/>'
                f'<nc:RemedialAction.penaltyFactor>1.0</nc:RemedialAction.penaltyFactor>{reference}</nc:RedispatchRemedialAction>')
        bids += (f'<nc:PowerBidSchedule rdf:ID="_B-{ra}"><nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{ra}"/>'
                 f'<nc:PowerBidSchedule.direction rdf:resource="https://cim4.eu/ns/nc#MarketRegulationDirectionKind.up"/></nc:PowerBidSchedule>'
                 f'<nc:PowerShiftKeyDistribution rdf:ID="_D-{ra}"><nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_B-{ra}"/>'
                 f'<nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_K-{ra}"/></nc:PowerShiftKeyDistribution>')
        keys += (f'<nc:PowerShiftKeySchedule rdf:ID="_K-{ra}"><cim:IdentifiedObject.mRID>K-{ra}</cim:IdentifiedObject.mRID>'
                 f'<nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_U-{ra}"/></nc:PowerShiftKeySchedule>')
    (tmp_path / "X_RA.xml").write_text(HEADER + ras + "</rdf:RDF>", encoding=TEXT_ENCODING)
    (tmp_path / "X_SIS.xml").write_text(HEADER + bids + keys + "</rdf:RDF>", encoding=TEXT_ENCODING)
    return tmp_path / "X_RA.xml", tmp_path / "X_SIS.xml"


def test_the_tso_of_each_remedial_action_is_its_operator_in_one_file(tmp_path):
    ra, sis = _redispatch_files(tmp_path, {
        "RA1": f"http://energy.referencedata.eu/EIC/{EIC_A}", "RA2": f"http://energy.referencedata.eu/EIC/{EIC_B}", "RA3": None})
    generators = {f"G-{n}": {"name": f"G-{n}", "target_p": 10.0, "max_p": 100.0, "min_p": 0.0} for n in (1, 2, 3)}
    by_unit = {f"U-RA{n}": [f"G-{n}"] for n in (1, 2, 3)}
    units, _bids = ncp_parser.parse_rd_units(ra, sis, "FILE-TSO", TS, generators, generators_by_unit=by_unit, operators=OperatorDirectory())
    assert {u.mrid: u.tso for u in units} == {"RA1": EIC_A, "RA2": EIC_B, "RA3": "FILE-TSO"}


# ---------------------------------------------------------------------------
# the files of a profile are one pool
# ---------------------------------------------------------------------------

def _legacy_folder(tmp_path, change=None):
    files = dict(legacy_writer.legacy_files())
    if change:
        files = change(files)
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    return tmp_path


def _under_creator(files, source_eic, target_eic, profile):
    """The `profile` file of source_eic's TSO as a second file of that profile under target_eic's creator."""
    source = next(n for n in files if f"_{source_eic}_{profile}_" in n)
    new_name = source.replace(f"_{source_eic}_", f"_{target_eic}_").replace("_001.xml", "_002.xml")
    files[new_name] = files.pop(source).replace(source_eic.encode(), target_eic.encode())
    return files


def test_two_files_of_one_profile_under_one_creator_are_both_in_the_pool(tmp_path):
    eics = sorted(legacy_writer.EIC_BY_TSO.values())
    folder = _legacy_folder(tmp_path, lambda files: _under_creator(files, eics[1], eics[0], "RA"))
    pools = ncp_loader.classify_extracted_ncp_files(folder, {})
    assert len(pools["RA"]) == len(eics)                                                  # every RA file is read
    assert sorted(pools.file_tso[p] for p in pools["RA"]).count(eics[0]) == 2             # two of them under one creator
    assert len(pools["AE"]) == len(eics) and len(pools["CO"]) == len(eics)


def test_the_same_object_id_in_two_files_of_a_profile_stops_with_both_file_names_and_the_id(tmp_path):
    eics = sorted(legacy_writer.EIC_BY_TSO.values())

    def add_copy(files):
        source = next(n for n in files if f"_{eics[0]}_RA_" in n)
        files[source.replace("_001.xml", "_002.xml")] = files[source]
        return files

    pools = ncp_loader.classify_extracted_ncp_files(_legacy_folder(tmp_path, add_copy), {})
    with pytest.raises(ValueError) as error:
        ncp_parser.check_unique_ids(pools)
    message = str(error.value)
    assert "_RA_001.xml" in message and "_RA_002.xml" in message and re.search(r"[0-9a-f]{8}-[0-9a-f]{4}", message)


def test_distinct_ids_in_the_files_of_a_profile_pass_the_check(tmp_path):
    pools = ncp_loader.classify_extracted_ncp_files(_legacy_folder(tmp_path), {})
    ncp_parser.check_unique_ids(pools)


def test_a_missing_required_profile_stops_the_run(tmp_path):
    def drop_co(files):
        return {n: d for n, d in files.items() if "_CO_" not in n}

    with pytest.raises(ValueError, match="CO"):
        ncp_loader.classify_extracted_ncp_files(_legacy_folder(tmp_path, drop_co), {})


def test_one_log_line_per_profile_names_the_files_and_the_objects_per_tso(caplog):
    from collections import Counter
    pools = ncp_loader.NcpPools({"AE": ["a.xml", "b.xml"], "SIS": ["s.xml"]})
    with caplog.at_level(logging.INFO):
        ncp_loader.log_pool_summary(pools, {"AE": Counter({"TSO-One": 3, "TSO-Two": 2})})
    lines = [r.getMessage() for r in caplog.records if "NCP profile" in r.getMessage()]
    assert len(lines) == 2
    assert "AE" in lines[0] and "2 file(s)" in lines[0] and "TSO-One: 3" in lines[0] and "TSO-Two: 2" in lines[0]
    assert "SIS" in lines[1] and "1 file(s)" in lines[1]

# ---------------------------------------------------------------------------
# the run: the AE files of all TSOs under one creator, the operator in the content, same result as the plain run
# ---------------------------------------------------------------------------

def _csv_rows(path):
    return [line.split(",") for line in path.read_text(encoding="utf-8").splitlines()]


def _same_cells(rows_a, rows_b, tolerance=1e-8):
    if len(rows_a) != len(rows_b):
        return False
    for row_a, row_b in zip(rows_a, rows_b):
        if len(row_a) != len(row_b):
            return False
        for a, b in zip(row_a, row_b):
            if a == b:
                continue
            try:
                x, y = float(a), float(b)
            except ValueError:
                return False
            if abs(x - y) > tolerance * max(abs(x), abs(y), 1e-9):
                return False
    return True


def _zip_of(files, path):
    import zipfile
    with zipfile.ZipFile(path, "w") as archive:
        for name, data in files.items():
            archive.writestr(name, data)
    return path


def _every_ae_file_under_one_creator(files):
    """The AE files of all TSOs carry the creator of the first TSO; each element names its TSO as an EIC URI."""
    eics = sorted(legacy_writer.EIC_BY_TSO.values())
    result = {}
    for name, data in files.items():
        eic = next((e for e in eics if f"_{e}_AE_" in name), None)
        if eic is None:
            result[name] = data
            continue
        data = re.sub(rb'(dcterms:creator rdf:resource="[^"]*/)' + eic.encode() + rb'"', rb'\g<1>' + eics[0].encode() + b'"', data)
        data = re.sub(rb'(AssessedElement\.AssessedSystemOperator rdf:resource=")[^"]*"',
                      rb'\g<1>http://energy.referencedata.eu/EIC/' + eic.encode() + b'"', data)
        number = eics.index(eic) + 1
        result[name.replace(f"_{eic}_", f"_{eics[0]}_").replace("_AE_001.xml", f"_AE_00{number}.xml")] = data
    return result


def test_ae_files_of_all_tsos_under_one_creator_give_the_same_run_as_the_plain_run(tmp_path, caplog):
    from helpers import run_pipeline_on_fixture_inputs
    plain_zip = _zip_of(legacy_writer.legacy_files(), tmp_path / "plain.zip")
    pooled_zip = _zip_of(_every_ae_file_under_one_creator(legacy_writer.legacy_files()), tmp_path / "pooled.zip")
    plain = run_pipeline_on_fixture_inputs(tmp_path / "plain", plain_zip, enable_nx_analysis=False, ra_types=("pst",))
    with caplog.at_level(logging.INFO):
        pooled = run_pipeline_on_fixture_inputs(tmp_path / "pooled", pooled_zip, enable_nx_analysis=False, ra_types=("pst",))
    names = sorted(p.name for p in plain.output_dir.glob("*.csv"))
    assert names == sorted(p.name for p in pooled.output_dir.glob("*.csv"))
    for name in [n for n in names if n not in RUN_TIME_FILES]:          # these hold run times
        assert _same_cells(_csv_rows(plain.output_dir / name), _csv_rows(pooled.output_dir / name)), name
    line = next(r.getMessage() for r in caplog.records if r.getMessage().startswith("NCP profile AE:"))
    assert "4 file(s)" in line and all(f"{eic}:" in line for eic in legacy_writer.EIC_BY_TSO.values())
