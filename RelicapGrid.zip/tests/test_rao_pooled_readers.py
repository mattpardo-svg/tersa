"""tests/test_rao_pooled_readers.py - the readers of an RA see the whole pool of their profile: a shift key chain, a shift key
strategy or a bid in another creator's file counts, and an RA is found under its rdf:ID and under its mRID literal.
Synthetic ids only (TSO-A, TSO-B, EIC-TSO-C, RA_C, BID_C, GU_1)."""

from pathlib import Path

import pytest

from pre_milp import ncp_parser
from pre_milp.operators import OperatorDirectory

HEADER = ('<?xml version="1.0" encoding="UTF-8"?>\n<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:nc="https://cim4.eu/ns/nc#" xmlns:cim="https://cim.ucaiug.io/ns#">\n')
UNITS = {"GEN_1": {"name": "u1", "target_p": 100.0, "max_p": 200.0, "min_p": 0.0, "connected": True}}
UNITS_OF_GENERATOR = {"GU_1": ["GEN_1"]}


def _ra(ident, mrid=None, operator="EIC-TSO-C"):
    return (f'<nc:RedispatchRemedialAction rdf:ID="_{ident}"><cim:IdentifiedObject.mRID>{mrid or ident}</cim:IdentifiedObject.mRID>'
            f'<nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>'
            f'<nc:RemedialAction.RemedialActionSystemOperator rdf:resource="http://example.test/eic/{operator}"/>'
            f'</nc:RedispatchRemedialAction>\n')


def _bid(ident, ra_reference):
    return (f'<nc:PowerBidSchedule rdf:ID="_{ident}"><cim:IdentifiedObject.mRID>{ident}</cim:IdentifiedObject.mRID>'
            f'<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{ra_reference}"/>'
            f'<nc:PowerBidSchedule.direction rdf:resource="https://cim4.eu/ns/nc#BidDirectionKind.up"/></nc:PowerBidSchedule>\n'
            f'<nc:PowerBidScheduleTimePoint rdf:ID="_TP_{ident}"><nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{ident}"/>'
            f'<nc:PowerBidScheduleTimePoint.atTime>2030-01-01T10:30:00Z</nc:PowerBidScheduleTimePoint.atTime>'
            f'<nc:PowerBidScheduleTimePoint.p>50</nc:PowerBidScheduleTimePoint.p>'
            f'<nc:PowerBidScheduleTimePoint.price>10</nc:PowerBidScheduleTimePoint.price></nc:PowerBidScheduleTimePoint>\n')


def _legacy_key(ident, unit):
    return (f'<nc:GLSKSchedule rdf:ID="_{ident}"><cim:IdentifiedObject.mRID>{ident}</cim:IdentifiedObject.mRID>'
            f'<nc:GLSKSchedule.GeneratingUnit rdf:resource="#_{unit}"/>'
            f'<nc:BaseTimeSeries.interpolationKind rdf:resource="https://cim4.eu/ns/nc#InterpolationKind.none"/></nc:GLSKSchedule>\n'
            f'<nc:ParticipationFactorTimePoint rdf:ID="_TP_{ident}"><nc:ParticipationFactorTimePoint.GLSKSchedule rdf:resource="#_{ident}"/>'
            f'<nc:ParticipationFactorTimePoint.participationFactor>1</nc:ParticipationFactorTimePoint.participationFactor>'
            f'</nc:ParticipationFactorTimePoint>\n')


def _legacy_link(ident, bid, key):
    return (f'<nc:GLSKBidActionDistribution rdf:ID="_{ident}"><nc:GLSKBidActionDistribution.PowerBidSchedule rdf:resource="#_{bid}"/>'
            f'<nc:GLSKBidActionDistribution.GLSKSchedule rdf:resource="#_{key}"/></nc:GLSKBidActionDistribution>\n')


def _write(folder, name, *parts):
    path = Path(folder) / name
    path.write_text(HEADER + "".join(parts) + "</rdf:RDF>\n", encoding="utf-8")
    return path


def _parse(ra_files, sis_files):
    pool_of_ra, pool_of_sis = ncp_parser.PooledFiles(ra_files), ncp_parser.PooledFiles(sis_files)
    operators = OperatorDirectory(label_by_eic={"EIC-TSO-B": "TSO-B"})
    units, bids = [], []
    for ra_file in ra_files:
        found_units, found_bids = ncp_parser.parse_rd_units(
            ra_file, pool_of_sis, "TSO-B", "1030Z", UNITS, generators_by_unit=UNITS_OF_GENERATOR, operators=operators,
            ra_pool=pool_of_ra)
        units += found_units
        bids += found_bids
    return [(unit.mrid, unit.tso) for unit in units], [bid.mrid for bid in bids]


def test_rao_the_legacy_chain_converts_when_the_link_and_the_schedule_are_in_different_files(tmp_path):
    key_file = _write(tmp_path, "A_SIS.xml", _legacy_key("KEY_C", "GU_1"))
    link_file = _write(tmp_path, "B_SIS.xml", _bid("BID_C", "RA_C"), _legacy_link("LINK_C", "BID_C", "KEY_C"))
    ra_file = _write(tmp_path, "B_RA.xml", _ra("RA_C"))
    assert _parse([ra_file], [key_file, link_file]) == ([("RA_C", "EIC-TSO-C")], ["BID_C"])


def test_rao_the_legacy_chain_converts_when_the_key_is_in_the_file_of_another_creator_and_the_link_in_none_with_a_key(tmp_path):
    link_file = _write(tmp_path, "B_SIS.xml", _bid("BID_C", "RA_C"), _legacy_link("LINK_C", "BID_C", "KEY_C"))
    key_file = _write(tmp_path, "A_SIS.xml", _legacy_key("KEY_C", "GU_1"))
    ra_file = _write(tmp_path, "B_RA.xml", _ra("RA_C"))
    assert _parse([ra_file], [link_file, key_file]) == ([("RA_C", "EIC-TSO-C")], ["BID_C"])


@pytest.mark.parametrize("bid_reference", ["RA_C_ID", "RA_C_MRID"])
def test_rao_an_ra_is_found_under_its_rdf_id_and_under_its_mrid(tmp_path, bid_reference):
    sis_file = _write(tmp_path, "B_SIS.xml", _bid("BID_C", bid_reference), _legacy_key("KEY_C", "GU_1"),
                      _legacy_link("LINK_C", "BID_C", "KEY_C"))
    ra_file = _write(tmp_path, "B_RA.xml", _ra("RA_C_ID", mrid="RA_C_MRID"))
    assert _parse([ra_file], [sis_file]) == ([("RA_C_MRID", "EIC-TSO-C")], ["BID_C"])


def test_rao_read_redispatch_units_accepts_the_rdf_id_and_the_mrid_of_an_ra(tmp_path):
    sis_file = _write(tmp_path, "B_SIS.xml", _bid("BID_C", "RA_C_MRID"), _legacy_key("KEY_C", "GU_1"),
                      _legacy_link("LINK_C", "BID_C", "KEY_C"))
    ra_file = _write(tmp_path, "B_RA.xml", _ra("RA_C_ID", mrid="RA_C_MRID"))
    sis_graph, ra_graph = ncp_parser._load_graph(sis_file), ncp_parser._load_graph(ra_file)
    for asked in ("RA_C_ID", "RA_C_MRID"):
        assert ncp_parser.read_redispatch_units(sis_graph, ra_graph, {asked}) == {asked: ["GU_1"]}


def test_rao_the_strategy_of_an_ra_in_another_ra_file_gives_its_units(tmp_path):
    strategy = ('<nc:PowerShiftKeyStrategy rdf:ID="_STRATEGY_C"><nc:PowerShiftKeyStrategy.PowerRemedialAction rdf:resource="#_RA_C"/>'
                '</nc:PowerShiftKeyStrategy>\n')
    key = ('<nc:PowerShiftKeySchedule rdf:ID="_KEY_C"><cim:IdentifiedObject.mRID>KEY_C</cim:IdentifiedObject.mRID>'
           '<nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_GU_1"/></nc:PowerShiftKeySchedule>\n'
           '<nc:PowerShiftKeyDistribution rdf:ID="_DISTRIBUTION_C"><nc:PowerShiftKeyDistribution.PowerShiftKeyStrategy rdf:resource="#_STRATEGY_C"/>'
           '<nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_KEY_C"/></nc:PowerShiftKeyDistribution>\n'
           '<nc:ParticipationFactorTimePoint rdf:ID="_TP_KEY_C"><nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_KEY_C"/>'
           '<nc:ParticipationFactorTimePoint.participationFactor>1</nc:ParticipationFactorTimePoint.participationFactor>'
           '</nc:ParticipationFactorTimePoint>\n')
    strategy_file = _write(tmp_path, "A_RA.xml", strategy)
    ra_file = _write(tmp_path, "B_RA.xml", _ra("RA_C"))
    sis_file = _write(tmp_path, "B_SIS.xml", key, _bid("BID_C", "RA_C"))
    assert _parse([strategy_file, ra_file], [sis_file]) == ([("RA_C", "EIC-TSO-C")], ["BID_C"])
