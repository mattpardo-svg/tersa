"""tests/test_rao_gui_config.py - the RAO Settings page and the config file src/rao/config/rao_config.yaml.

The page shows every key of the file, section by section, with the comment of the file as help; saving writes the file and
keeps its comments and every key the page does not change; the values are checked by the pipeline's own config check.
"""

import shutil
import sys

import pytest
import yaml

from helpers import REPO_ROOT
from text_encoding import TEXT_ENCODING

CONFIG_FILE = REPO_ROOT / "src" / "rao" / "config" / "rao_config.yaml"


def _gui():
    pytest.importorskip("streamlit")
    pages = str(REPO_ROOT / "src" / "rao_pages")
    if pages not in sys.path:
        sys.path.insert(0, pages)
    import _gui_common
    return _gui_common


def _page():
    pytest.importorskip("streamlit")
    from streamlit.testing.v1 import AppTest
    return AppTest.from_file(str(REPO_ROOT / "src" / "rao_pages" / "3_RAO_Settings.py"), default_timeout=60)


def _file_keys(path=CONFIG_FILE) -> set:
    config = yaml.safe_load(path.read_text(encoding=TEXT_ENCODING))
    return {f"{section}.{key}" for section, values in config.items() if isinstance(values, dict) for key in values}


@pytest.fixture
def config_copy(tmp_path, monkeypatch):
    """A copy of the config file that the page and the GUI functions read and write instead of the real one."""
    gui = _gui()
    copy = tmp_path / "rao_config.yaml"
    shutil.copyfile(CONFIG_FILE, copy)
    monkeypatch.setattr(gui, "RAO_CONFIG_PATH", copy)
    return copy


# ---------------------------------------------------------------------------
# the page shows exactly the keys of the file
# ---------------------------------------------------------------------------

def test_the_page_shows_every_key_of_the_config_file_and_nothing_else():
    page = _page()
    page.run()
    assert not page.exception
    assert set(page.session_state["config_keys_shown"]) == _file_keys()


def test_a_key_added_to_the_file_is_shown_and_a_key_removed_from_it_is_not(config_copy):
    text = config_copy.read_text(encoding=TEXT_ENCODING)
    text = text.replace("outputs:\n", "outputs:\n  a_new_key_for_the_test: 3\n", 1)
    text = "\n".join(line for line in text.split("\n") if not line.startswith("  write_loadings_nx:"))
    config_copy.write_text(text, encoding=TEXT_ENCODING)
    page = _page()
    page.run()
    assert not page.exception
    shown = set(page.session_state["config_keys_shown"])
    assert "outputs.a_new_key_for_the_test" in shown and "outputs.write_loadings_nx" not in shown
    assert shown == _file_keys(config_copy)


def test_the_keys_of_the_new_outputs_and_the_other_listed_keys_are_on_the_page():
    page = _page()
    page.run()
    shown = set(page.session_state["config_keys_shown"])
    for key in (
        "outputs.loadings_n0_min_loading_pct", "outputs.loadings_nx_min_loading_pct", "outputs.write_loadings_nx",
        "outputs.write_sensitivity_csvs", "lead_time.decision_point_hours_before_run", "bids.default_price_eur_per_mwh",
        "nx_sensitivity.contingency_batch_size", "sensitivity_guard.absolute_floor_ampere", "sensitivity_guard.max_dropped_share",
        "nx_constraint_filter.enabled", "nx_constraint_filter.margin_ampere", "performance.lf_thread_count",
        "performance.solver_time_limit_seconds", "performance.solver_mip_rel_gap",
    ):
        assert key in shown, key
    assert "outputs.write_nx_sensitivity_csvs" not in shown


def test_every_key_has_the_comment_of_the_file_as_its_help_text():
    gui = _gui()
    fields = gui.config_fields(CONFIG_FILE.read_text(encoding=TEXT_ENCODING))
    helped = {f"{f['section']}.{f['key']}" for f in fields if f["help"]}
    assert "outputs.write_loadings_nx" in helped and "outputs.loadings_n0_min_loading_pct" in helped
    assert len(helped) >= 0.9 * len(fields)
    page = _page()
    page.run()
    toggle = next(t for t in page.toggle if t.label == "write_loadings_nx")
    assert toggle.help and "loadings_nx.csv" in toggle.help


def test_the_page_has_a_widget_per_scalar_key_with_the_name_of_the_key_as_label():
    page = _page()
    page.run()
    labels = {w.label for w in [*page.number_input, *page.toggle, *page.text_input, *page.selectbox, *page.multiselect]}
    for name in ("loadings_n0_min_loading_pct", "write_sensitivity_csvs", "contingency_batch_size", "max_change_ra", "debug_log_mode"):
        assert name in labels, name


# ---------------------------------------------------------------------------
# saving
# ---------------------------------------------------------------------------

def test_saving_changes_only_the_value_and_keeps_every_comment_and_every_other_key(config_copy):
    before = config_copy.read_text(encoding=TEXT_ENCODING)
    page = _page()
    page.run()
    page.number_input(key="config.thresholds.max_change_ra").set_value(2.5)
    next(b for b in page.button if b.label == "Save settings").click().run()
    assert not page.exception and not page.error
    after = config_copy.read_text(encoding=TEXT_ENCODING)

    changed = [(a, b) for a, b in zip(before.split("\n"), after.split("\n")) if a != b]
    assert len(before.split("\n")) == len(after.split("\n")) and len(changed) == 1
    assert changed[0][0].strip().startswith("max_change_ra:") and changed[0][1].strip() == "max_change_ra: 2.5"
    assert [l for l in before.split("\n") if l.lstrip().startswith("#")] == [l for l in after.split("\n") if l.lstrip().startswith("#")]
    old, new = yaml.safe_load(before), yaml.safe_load(after)
    new["thresholds"]["max_change_ra"] = old["thresholds"]["max_change_ra"]
    assert new == old


def test_a_value_that_the_pipeline_check_rejects_is_not_saved_and_the_page_says_why(config_copy):
    before = config_copy.read_text(encoding=TEXT_ENCODING)
    page = _page()
    page.run()
    page.number_input(key="config.outputs.loadings_nx_min_loading_pct").set_value(-1)
    next(b for b in page.button if b.label == "Save settings").click().run()
    assert any("loadings_nx_min_loading_pct" in error.value for error in page.error)
    assert config_copy.read_text(encoding=TEXT_ENCODING) == before


def test_the_page_uses_the_check_of_the_pipeline_and_not_a_copy_of_it(monkeypatch):
    gui = _gui()
    sys.path.insert(0, str(REPO_ROOT / "src" / "rao")) if str(REPO_ROOT / "src" / "rao") not in sys.path else None
    import run_pipeline

    def check(config, path):
        raise ValueError("the check of the pipeline was called")

    monkeypatch.setattr(run_pipeline, "validate_config_ranges", check)
    assert gui.validate_rao_config(yaml.safe_load(CONFIG_FILE.read_text(encoding=TEXT_ENCODING))) == ["the check of the pipeline was called"]


def test_the_config_file_as_it_is_passes_the_check_the_page_uses():
    gui = _gui()
    assert gui.validate_rao_config(yaml.safe_load(CONFIG_FILE.read_text(encoding=TEXT_ENCODING))) == []


def test_a_new_value_is_written_as_the_file_writes_it(config_copy):
    gui = _gui()
    gui.save_rao_config({
        ("outputs", "write_loadings_nx"): False, ("workflow_toggles", "ra_types"): ["pst", "hvdc"],
        ("performance", "solver_time_limit_seconds"): 30.0, ("outputs", "loadings_n0_min_loading_pct"): 75,
    })
    saved = yaml.safe_load(config_copy.read_text(encoding=TEXT_ENCODING))
    assert saved["outputs"]["write_loadings_nx"] is False and saved["workflow_toggles"]["ra_types"] == ["pst", "hvdc"]
    assert saved["performance"]["solver_time_limit_seconds"] == 30.0 and saved["outputs"]["loadings_n0_min_loading_pct"] == 75
    assert "  ra_types: [pst, hvdc]" in config_copy.read_text(encoding=TEXT_ENCODING)


def test_a_key_that_is_not_in_the_file_cannot_be_saved(config_copy):
    gui = _gui()
    with pytest.raises(KeyError):
        gui.save_rao_config({("outputs", "write_nx_sensitivity_csvs"): True})


def test_the_comment_at_the_end_of_a_changed_line_stays():
    gui = _gui()
    text = "outputs:\n  write_loadings_nx: true  # kept\n  other: 1\n"
    assert gui.update_config_text(text, {("outputs", "write_loadings_nx"): False}) == "outputs:\n  write_loadings_nx: false  # kept\n  other: 1\n"


def test_the_gui_run_uses_the_values_of_the_config_file(config_copy):
    gui = _gui()
    gui.save_rao_config({("outputs", "loadings_n0_min_loading_pct"): 60})
    assert gui.load_settings()["rao_config"]["outputs"]["loadings_n0_min_loading_pct"] == 60
