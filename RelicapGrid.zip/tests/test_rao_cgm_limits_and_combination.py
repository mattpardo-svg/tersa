"""
tests/test_rao_cgm_limits_and_combination.py - the NCP 2.2 legacy form (docs/specs/ncp_data_requirements.md section 13
"Single-TSO CGM"):
A. a 2W transformer side with only APPARENT_POWER limits (MVA) gets its PATL and TATL in amperes, I = S / (sqrt(3) * U);
B. the dangling lines of a CGMES-imported network have N-0 and N-X results, currents and sensitivities (nothing to fix);
   a branch without an N-0 result is described in the warning;
C. workflow_toggles.ae_contingency_combination (standard | all_contingencies);
E. a contingency without equipment is not sent to the security analysis.
"""
import logging
import math
import re

import pytest

pytest.importorskip("pypowsybl")
import pandas as pd
import pypowsybl as pp

from data_model import AEType, AssessedElement, Contingency, ContingencyType, monitored_after_contingency
from mock_builders import standard
from pre_milp import cgmes_loader, log_summary, ncp_parser

SQRT3 = math.sqrt(3.0)
TRAFO_A, TRAFO_B = "NGEN_NHV1", "NHV2_NLOAD"      # 24 / 380 kV and 380 / 150 kV


def _limit(element, side, name, value, duration, kind="APPARENT_POWER"):
    return dict(element_id=element, side=side, name=name, type=kind, value=float(value), acceptable_duration=duration)


def _network():
    """The eurostag network; TRAFO_A has apparent power limits only (MVA, both sides, with a TATL), TRAFO_B has a current
    limit on side ONE next to an apparent power limit and apparent power limits only on side TWO."""
    network = pp.network.create_eurostag_tutorial_example1_network()
    limits = pd.DataFrame.from_records([
        _limit(TRAFO_A, "ONE", "patl", 600, -1), _limit(TRAFO_A, "TWO", "patl", 600, -1), _limit(TRAFO_A, "TWO", "tatl", 700, 900),
        _limit(TRAFO_B, "ONE", "patl", 900, -1), _limit(TRAFO_B, "ONE", "patl_a", 500, -1, "CURRENT"),
        _limit(TRAFO_B, "TWO", "patl", 300, -1),
    ]).set_index(["element_id", "side", "name"])
    network.create_operational_limits(limits)
    pp.loadflow.run_ac(network)
    return network


def _amperes(mva, kv):
    return mva * 1000.0 / (SQRT3 * kv)


@pytest.fixture(scope="module")
def network():
    return _network()


# ---------------------------------------------------------------------------
# A: apparent power limits of a transformer
# ---------------------------------------------------------------------------

def test_rao_the_apparent_power_limits_of_a_transformer_side_without_a_current_limit_become_amperes(network):
    static = cgmes_loader.build_cgm_static_patl(network)
    assert static[TRAFO_A][1] == pytest.approx(_amperes(600, 24.0))
    assert static[TRAFO_A][2] == pytest.approx(_amperes(600, 380.0))
    assert static[TRAFO_B][2] == pytest.approx(_amperes(300, 150.0))


def test_rao_a_current_limit_on_the_same_side_wins_over_the_apparent_power_limit(network):
    assert cgmes_loader.build_cgm_static_patl(network)[TRAFO_B][1] == 500.0


def test_rao_the_tatl_of_an_apparent_power_limit_has_the_same_duration_in_amperes(network):
    from pre_milp.nx_security_analysis import compute_tatl_data

    ae = AssessedElement(mrid="AE_T", name="AE_T", tso="TSO-X", ae_type=AEType.SECURED, branch_mrid=TRAFO_A, secured_for_region="R",
                         scanned_for_region=None, exclusion_reason=None, patl_ka={"1030Z": 0.1}, branch_side=2)
    tatl = compute_tatl_data(network, [ae], "1030Z")
    assert tatl[TRAFO_A]["tatl_limit_ampere"] == pytest.approx(_amperes(700, 380.0))
    assert tatl[TRAFO_A]["tatl_duration_seconds"] == 900


def test_rao_the_converted_limits_are_one_summary_line(network, caplog):
    with caplog.at_level(logging.INFO):
        cgmes_loader.build_cgm_static_patl(network)
    lines = [r.getMessage() for r in caplog.records if "apparent power" in r.getMessage()]
    assert len(lines) == 1 and "4 " in lines[0] and "MVA" in lines[0]          # TRAFO_A: 3 limits, TRAFO_B side TWO: 1


def test_rao_an_assessed_element_on_a_transformer_with_apparent_power_limits_is_not_excluded(network, tmp_path):
    text = standard.shipped_files()["Belgovia_AE.xml"].decode("utf-8")
    text = re.sub(r"\s*<nc:AssessedElement\.OperationalLimit [^>]*/>", "", text)
    first = re.search(r'(<nc:AssessedElement\.ConductingEquipment rdf:resource="#_)[^"]+', text)
    path = tmp_path / "Belgovia_AE.xml"
    path.write_text(text[:first.start()] + first.group(1) + TRAFO_A + text[first.end():], encoding="utf-8")
    aes = ncp_parser.parse_assessed_elements(path, None, "TSO-X", "1030Z", cgmes_loader.build_cgm_static_patl(network),
                                             cgm_branch_mrids=set(cgmes_loader.build_branch_mrid_to_name(network)))
    kept = ncp_parser.exclude_without_usable_patl(aes, "TSO-X", "1030Z")
    assert [a.ae_type for a in kept] == [AEType.SECURED]


def test_rao_the_side_of_an_apparent_power_limit_is_read_from_its_terminal(tmp_path):
    text = legacy_eq_with_apparent_power_limit()
    path = tmp_path / "x_EQ_1.xml"
    path.write_text(text, encoding="utf-8")
    for graph in (ncp_parser.load_eq_graph(path), ncp_parser._load_graph(path, cache=False)):
        assert ncp_parser.build_current_limit_side_map(path, graph) == {"APL_1": 2}


def legacy_eq_with_apparent_power_limit():
    return """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:cim="http://iec.ch/TC57/2013/CIM-schema-cim16#">
  <cim:Terminal rdf:ID="_T2"><cim:ACDCTerminal.sequenceNumber>2</cim:ACDCTerminal.sequenceNumber></cim:Terminal>
  <cim:OperationalLimitSet rdf:ID="_S2"><cim:OperationalLimitSet.Terminal rdf:resource="#_T2"/></cim:OperationalLimitSet>
  <cim:ApparentPowerLimit rdf:ID="_APL_1"><cim:OperationalLimit.OperationalLimitSet rdf:resource="#_S2"/></cim:ApparentPowerLimit>
</rdf:RDF>
"""


# ---------------------------------------------------------------------------
# B: dangling lines of a CGMES-imported network (pypowsybl's CGMES micro grid)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def micro_grid():
    network = pp.network.create_micro_grid_be_network()
    pp.loadflow.run_ac(network)
    return network


def _ae(branch, side=1):
    return AssessedElement(mrid=f"AE_{branch[:6]}", name="AE", tso="TSO-X", ae_type=AEType.SECURED, branch_mrid=branch, secured_for_region="R",
                           scanned_for_region=None, exclusion_reason=None, patl_ka={"1030Z": 1.0}, branch_side=side)


def test_rao_the_dangling_lines_of_a_cgmes_network_have_n_0_and_n_x_results(micro_grid, caplog):
    from pre_milp.nx_security_analysis import compute_lf_nx

    dangling = sorted(micro_grid.get_dangling_lines().index)
    assert len(dangling) == 5
    lf_initial = cgmes_loader.build_lf_initial(micro_grid)
    assert all(lf_initial[b][1] > 0 and math.isnan(lf_initial[b][2]) for b in dangling)
    lines = sorted(micro_grid.get_lines().index)
    contingency = Contingency(mrid="C1", name="C1", tso="TSO-X", contingency_type=ContingencyType.ORDINARY, must_study={"1030Z": True},
                              equipment_mrids=[lines[0]], equipment_types=["line"])
    with caplog.at_level(logging.WARNING):
        lf_nx, skipped = compute_lf_nx(micro_grid, [contingency], [_ae(b) for b in dangling], "1030Z")
    assert not skipped and set(dangling) <= set(lf_nx["C1"]) and all(lf_nx["C1"][b][1] > 0 for b in dangling)
    assert "no result in the N-0" not in caplog.text


def test_rao_the_n_0_sensitivities_of_the_dangling_lines_of_a_cgmes_network(micro_grid):
    from data_model import PST, RAKind
    from pre_milp.n0_sensitivity import compute_sensitivity_pst_n0

    dangling = sorted(micro_grid.get_dangling_lines().index)
    transformer = micro_grid.get_phase_tap_changers().index[0]
    pst = PST(mrid=transformer, name="PST", tso="TSO-X", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0, low_step=-10, high_step=10,
              r0=0, operating_tap_min=-10, operating_tap_max=10, group_id=None)
    sensitivity = compute_sensitivity_pst_n0(micro_grid, [pst], [_ae(b) for b in dangling], "1030Z",
                                             lf_initial=cgmes_loader.build_lf_initial(micro_grid))
    assert {b for b, _ in sensitivity} == set(dangling) and all(math.isfinite(v) for v in sensitivity.values())


def test_rao_the_warning_for_a_branch_without_an_n_0_result_says_what_the_branch_is(caplog):
    from pre_milp.nx_security_analysis import compute_lf_nx

    network = pp.network.create_eurostag_tutorial_example1_network()
    network.create_dangling_lines(id="MOCK_DL", voltage_level_id="VLHV1", bus_id="NHV1", p0=50, q0=10, r=1, x=10, g=0, b=0)
    network.update_lines(id="NHV1_NHV2_2", connected1=False, connected2=False)
    pp.loadflow.run_ac(network)
    network.update_dangling_lines(id="MOCK_DL", connected=False)
    log_summary.reset_once()
    contingency = Contingency(mrid="C1", name="C1", tso="TSO-X", contingency_type=ContingencyType.ORDINARY, must_study={"1030Z": True},
                              equipment_mrids=["NHV1_NHV2_1"], equipment_types=["line"])
    with caplog.at_level(logging.WARNING):
        compute_lf_nx(network, [contingency], [_ae("NGEN_NHV1"), _ae("MOCK_DL"), _ae("NHV1_NHV2_2")], "1030Z")
    messages = [r.getMessage() for r in caplog.records if "no result in the N-0" in r.getMessage()]
    assert any("MOCK_DL" in m and "dangling line" in m and "disconnected" in m for m in messages)
    assert any("NHV1_NHV2_2" in m and "line" in m and "disconnected" in m for m in messages)


# ---------------------------------------------------------------------------
# C: ae_contingency_combination
# ---------------------------------------------------------------------------

def _ae_file_with_links(tmp_path):
    """The mock AE file: the first element is not combinable, with an included link to CO_A and an excluded one to CO_B."""
    text = standard.shipped_files()["Belgovia_AE.xml"].decode("utf-8")
    ae_id = re.search(r'<nc:AssessedElement rdf:ID="_([^"]+)"', text).group(1)
    text = text.replace("<nc:AssessedElement.isCombinableWithContingency>true", "<nc:AssessedElement.isCombinableWithContingency>false", 1)
    kind = "https://cim4.eu/ns/nc#ElementCombinationConstraintKind."
    links = "".join(
        f'<nc:AssessedElementWithContingency rdf:ID="_{name}"><nc:AssessedElementWithContingency.AssessedElement rdf:resource="#_{ae_id}"/>'
        f'<nc:AssessedElementWithContingency.Contingency rdf:resource="#_{contingency}"/>'
        f'<nc:AssessedElementWithContingency.combinationConstraintKind rdf:resource="{kind}{what}"/></nc:AssessedElementWithContingency>\n'
        for name, contingency, what in (("L_A", "CO_A", "included"), ("L_B", "CO_B", "excluded")))
    path = tmp_path / "Belgovia_AE.xml"
    path.write_text(text.replace("</rdf:RDF>", links + "</rdf:RDF>"), encoding="utf-8")
    return path, ae_id


def test_rao_standard_keeps_the_combination_of_the_profile(tmp_path):
    path, ae_id = _ae_file_with_links(tmp_path)
    ae = next(a for a in ncp_parser.parse_assessed_elements(path, None, "TSO-X", "1030Z", {}) if a.mrid == ae_id)
    assert ae.included_contingencies == ("CO_A",) and ae.excluded_contingencies == ("CO_B",)
    assert monitored_after_contingency(ae, "CO_A") and not monitored_after_contingency(ae, "CO_C") and not monitored_after_contingency(ae, "CO_B")


def test_rao_all_contingencies_combines_every_element_with_every_contingency_except_the_excluded_links(tmp_path):
    path, ae_id = _ae_file_with_links(tmp_path)
    ae = next(a for a in ncp_parser.parse_assessed_elements(path, None, "TSO-X", "1030Z", {}, ae_contingency_combination="all_contingencies")
              if a.mrid == ae_id)
    assert ae.included_contingencies is None and ae.excluded_contingencies == ("CO_B",)
    assert monitored_after_contingency(ae, "CO_A") and monitored_after_contingency(ae, "CO_C") and not monitored_after_contingency(ae, "CO_B")


def test_rao_the_default_gives_the_same_elements_as_standard(tmp_path):
    path, _ = _ae_file_with_links(tmp_path)
    assert (ncp_parser.parse_assessed_elements(path, None, "TSO-X", "1030Z", {})
            == ncp_parser.parse_assessed_elements(path, None, "TSO-X", "1030Z", {}, ae_contingency_combination="standard"))


def test_rao_the_combination_value_is_validated():
    import run_pipeline

    assert run_pipeline.validate_ae_contingency_combination("standard", "x.yaml") == "standard"
    assert run_pipeline.validate_ae_contingency_combination("all_contingencies", "x.yaml") == "all_contingencies"
    for bad in ("All_Contingencies", "", None, True, ["standard"]):
        with pytest.raises(run_pipeline.ConfigKeyError) as error:
            run_pipeline.validate_ae_contingency_combination(bad, "x.yaml")
        assert "ae_contingency_combination" in str(error.value) and "all_contingencies" in str(error.value)


def test_rao_a_bad_value_in_the_config_is_a_config_key_error_and_a_missing_key_is_standard():
    import copy
    from pathlib import Path

    import run_pipeline

    config = copy.deepcopy(run_pipeline._rao_config)
    config["workflow_toggles"]["ae_contingency_combination"] = "everything"
    with pytest.raises(run_pipeline.ConfigKeyError):
        run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))
    del config["workflow_toggles"]["ae_contingency_combination"]
    run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))
    assert run_pipeline.ae_contingency_combination_of(config, Path("/x/rao_config.yaml")) == "standard"


def test_rao_both_config_files_carry_the_option_with_the_default_standard():
    from pathlib import Path

    import yaml

    folder = Path(__file__).resolve().parents[1] / "src" / "rao" / "config"
    for name in ("rao_config.yaml", "rao_config.default.yaml"):
        assert yaml.safe_load((folder / name).read_text(encoding="utf-8"))["workflow_toggles"]["ae_contingency_combination"] == "standard"


def test_rao_all_contingencies_is_one_warning_per_run(caplog):
    import run_pipeline

    log_summary.reset_once()
    with caplog.at_level(logging.WARNING):
        run_pipeline.warn_ae_contingency_combination("all_contingencies")
        run_pipeline.warn_ae_contingency_combination("all_contingencies")
        run_pipeline.warn_ae_contingency_combination("standard")
    assert len([r for r in caplog.records if "all_contingencies" in r.getMessage()]) == 1


# ---------------------------------------------------------------------------
# E: a contingency without equipment
# ---------------------------------------------------------------------------

def test_rao_the_parser_keeps_a_contingency_without_equipment_links_and_drops_one_without_valid_equipment(tmp_path, caplog):
    """The parser contract stays (kept with an empty list); one whose links are all outside the CGM is
    excluded, with one summary line."""
    text = standard.shipped_files()["Svedala_CO.xml"].decode("utf-8")
    ids = re.findall(r'ContingencyEquipment.Equipment rdf:resource="#_([^"]+)"', text)
    first = re.search(r"\s*<cim:ContingencyEquipment .*?</cim:ContingencyEquipment>", text, re.S)
    path = tmp_path / "Svedala_CO.xml"
    path.write_text(text[:first.start()] + text[first.end():], encoding="utf-8")
    with caplog.at_level(logging.WARNING):
        contingencies = ncp_parser.parse_contingencies(path, "TSO-X", "1030Z", {i: "line" for i in ids})
    assert any(not c.equipment_mrids for c in contingencies)
    assert not [r for r in caplog.records if "excluded" in r.getMessage()]


def test_rao_a_must_study_contingency_without_equipment_is_skipped_before_the_security_analysis_and_listed(caplog):
    from pre_milp.nx_security_analysis import compute_lf_nx

    network = pp.network.create_eurostag_tutorial_example1_network()
    pp.loadflow.run_ac(network)
    empty = Contingency(mrid="C_EMPTY", name="C_EMPTY", tso="TSO-X", contingency_type=ContingencyType.ORDINARY, must_study={"1030Z": True},
                        equipment_mrids=[], equipment_types=[])
    full = Contingency(mrid="C_FULL", name="C_FULL", tso="TSO-X", contingency_type=ContingencyType.ORDINARY, must_study={"1030Z": True},
                       equipment_mrids=["NHV1_NHV2_1"], equipment_types=["line"])
    ae = AssessedElement(mrid="AE", name="AE", tso="TSO-X", ae_type=AEType.SECURED, branch_mrid="NHV1_NHV2_2", secured_for_region="R",
                         scanned_for_region=None, exclusion_reason=None, patl_ka={"1030Z": 1.0}, branch_side=1)
    with caplog.at_level(logging.WARNING):
        lf_nx, skipped = compute_lf_nx(network, [empty, full], [ae], "1030Z")
    assert list(lf_nx) == ["C_FULL"] and skipped == {"C_EMPTY": "no equipment in the contingency"}
    assert "no post-contingency result returned" not in caplog.text
    assert len([r for r in caplog.records if "must-study contingency(ies) skipped" in r.getMessage()]) == 1


def test_rao_the_equipment_not_in_the_cgm_is_one_summary_line(tmp_path, caplog):
    text = standard.shipped_files()["Svedala_CO.xml"].decode("utf-8")
    with caplog.at_level(logging.WARNING):
        ncp_parser.parse_contingencies(_write(tmp_path, text), "TSO-X", "1030Z", {})
    not_found = [r.getMessage() for r in caplog.records if "not found in CGM" in r.getMessage()]
    excluded = [r.getMessage() for r in caplog.records if "no valid equipment" in r.getMessage()]
    assert len(not_found) == 1 and len(excluded) == 1 and "more" in not_found[0]


def _write(tmp_path, text):
    path = tmp_path / "Svedala_CO.xml"
    path.write_text(text, encoding="utf-8")
    return path


def test_rao_the_security_analysis_gets_no_contingency_without_equipment():
    from pre_milp.nx_security_analysis import _get_must_study_contingencies

    empty = Contingency(mrid="C_EMPTY", name="C_EMPTY", tso="TSO-X", contingency_type=ContingencyType.ORDINARY, must_study={"1030Z": True},
                        equipment_mrids=[], equipment_types=[])
    full = Contingency(mrid="C_FULL", name="C_FULL", tso="TSO-X", contingency_type=ContingencyType.ORDINARY, must_study={"1030Z": True},
                       equipment_mrids=["L1"], equipment_types=["line"])
    assert [c.mrid for c in _get_must_study_contingencies([empty, full], "1030Z")] == ["C_FULL"]

def test_rao_a_run_with_all_contingencies_logs_the_warning_once_and_gives_the_results_of_the_mock(tmp_path, caplog):
    """The mock has no element with a restriction, so both settings give the same results."""
    from helpers import _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs

    def all_contingencies(rp, monkeypatch):
        monkeypatch.setattr(rp, "AE_CONTINGENCY_COMBINATION", "all_contingencies")

    with caplog.at_level(logging.WARNING):
        run_pipeline_on_fixture_inputs(tmp_path / "run", _MOCK_NX_NCP_ZIP, enable_nx_analysis=True, ra_types=("pst",),
                                       customize_pipeline=all_contingencies)
    assert len([r for r in caplog.records if "ae_contingency_combination is all_contingencies" in r.getMessage()]) == 1