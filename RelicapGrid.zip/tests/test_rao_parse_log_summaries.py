"""tests/test_rao_parse_log_summaries.py - the parse-step log summaries: excluded assessed elements by reason, contingencies
dropped by reason, RAs without a usable bid, bids parsed per TSO, ignored RAs by cause, the wording of the NCP-switch lines,
the scanned-list line and the inventory table with countertrade and HVDC columns. Synthetic ids only."""

import logging

import pandas as pd
import pytest

from data_model import (
    AEType, AssessedElement, BidDirection, Contingency, CtRa, HvdcUnit, PowerBid, RAKind, RDUnit,
)
from pre_milp import cgmes_loader, inventory_summary, ncp_parser, parse_summaries, scanned_elements

NC_HEADER = ('<?xml version="1.0" encoding="UTF-8"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
             'xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:nc="https://cim4.eu/ns/nc#">')


def _messages(caplog, *words, level=None):
    return [r.getMessage() for r in caplog.records
            if all(word in r.getMessage() for word in words) and (level is None or r.levelno == level)]


def _ae(mrid, ae_type=AEType.EXCLUDED, reason=None, in_base_case=True, tso="TSO-A"):
    return AssessedElement(mrid=mrid, name=mrid, tso=tso, ae_type=ae_type, branch_mrid="BR-" + mrid, secured_for_region=None,
                           scanned_for_region=None, exclusion_reason=reason, patl_ka={"1030Z": 1.0}, in_base_case=in_base_case)


# ---- excluded assessed elements by reason ---------------------------------------------------------------------------

def test_rao_excluded_elements_are_one_line_per_tso_and_reason_with_the_inbasecase_count(caplog):
    elements = [_ae(f"S{i}", reason="SecuredExclusionReasonKind.systemOperator", in_base_case=i % 2 == 0) for i in range(7)]
    elements += [_ae("N1", reason="no secured or scanned region code", in_base_case=False), _ae("D1", reason="disabled by the NCP"),
                 _ae("P1", reason="no usable PATL (0 or none)"), _ae("OK", ae_type=AEType.SECURED),
                 _ae("S-B", reason="SecuredExclusionReasonKind.capacityCalculationRegion", tso="TSO-B")]
    with caplog.at_level(logging.DEBUG):
        parse_summaries.log_excluded_assessed_elements(elements)
    lines = _messages(caplog, "excluded", level=logging.INFO)
    assert len(lines) == 5
    first = [m for m in lines if "systemOperator" in m]
    assert len(first) == 1 and first[0].startswith("TSO-A: 7 assessed element(s) excluded - exclusionReason systemOperator without ScannedForRegion")
    assert "(3 with inBaseCase=false)" in first[0] and "S0, S1, S2, S3, S4 and 2 more" in first[0]
    assert any("no secured or scanned region code" in m and "(1 with inBaseCase=false)" in m for m in lines)
    assert any("disabled by normalEnabled or a time point" in m and "(0 with inBaseCase=false)" in m for m in lines)
    assert any("no usable PATL" in m for m in lines)
    assert any(m.startswith("TSO-B: 1 assessed element(s) excluded - exclusionReason capacityCalculationRegion") for m in lines)
    assert any("S5" in m and "S6" in m for m in _messages(caplog, "all ids", level=logging.DEBUG))


# ---- contingencies dropped by reason ---------------------------------------------------------------------------------

def _co_file(tmp_path, equipment):
    parts = ['<nc:OrdinaryContingency rdf:ID="_CO1"><cim:IdentifiedObject.mRID>CO1</cim:IdentifiedObject.mRID>'
             '<nc:Contingency.normalMustStudy>true</nc:Contingency.normalMustStudy></nc:OrdinaryContingency>']
    for index, mrid in enumerate(equipment):
        parts.append(f'<cim:ContingencyEquipment rdf:ID="_CE{index}"><cim:ContingencyElement.Contingency rdf:resource="#_CO1"/>'
                     f'<cim:ContingencyEquipment.Equipment rdf:resource="#_{mrid}"/></cim:ContingencyEquipment>')
    path = tmp_path / "X_CO.xml"
    path.write_text(NC_HEADER + "".join(parts) + "</rdf:RDF>", encoding="utf-8")
    return path


def test_rao_a_three_winding_transformer_contingency_has_its_own_reason(tmp_path, caplog):
    path = _co_file(tmp_path, ["MISSING-1", "T3-1", "HVDC-1", "T3-2"])
    with caplog.at_level(logging.INFO):
        result = ncp_parser.parse_contingencies(
            path, "X", "1030Z", {"LINE-1": "line"},
            unsupported_equipment={"T3-1": "3-winding transformer", "T3-2": "3-winding transformer", "HVDC-1": "HVDC line"})
    assert result == []
    warnings = _messages(caplog, level=logging.WARNING)
    assert any("1 contingency equipment mRID(s) not found in CGM" in m and "MISSING-1" in m for m in warnings)
    assert any("2 contingency equipment mRID(s) are 3-winding transformers (not supported)" in m and "T3-1" in m for m in warnings)
    assert any("1 contingency equipment mRID(s) are HVDC lines (not supported)" in m and "HVDC-1" in m for m in warnings)
    assert not any("T3-1" in m and "not found in CGM" in m for m in warnings)


def test_rao_the_unsupported_equipment_of_a_network_names_three_winding_transformers():
    class FakeNetwork:
        def get_3_windings_transformers(self):
            return pd.DataFrame(index=["T3-1", "T3-2"])

        def get_hvdc_lines(self):
            return pd.DataFrame(index=["HVDC-1"])

    assert cgmes_loader.build_unsupported_equipment(FakeNetwork()) == {
        "T3-1": "3-winding transformer", "T3-2": "3-winding transformer", "HVDC-1": "HVDC line"}


# ---- RAs without a usable bid, bids parsed per TSO -----------------------------------------------------------------

def _unit(ra, tso="TSO-C", unit="GEN-" ):
    return RDUnit(mrid=ra, name=ra, tso=tso, gu_mrid=unit + ra, gu_name=ra, available=True, kind=RAKind.PREVENTIVE, initial_p=10.0,
                  max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None)


def _bid(mrid, ra, volume):
    return PowerBid(mrid=mrid, ra_mrid=ra, direction=BidDirection.UP, available_mw={"1030Z": volume}, price_eur_mw=1.0,
                    lead_time_h=0.0, activation_cost_eur=None)


def _ct(ra, tso="TSO-C"):
    return CtRa(mrid=ra, name=ra, tso=tso, zone_mrid="Z", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0,
                strategy="proportionalForRemainingCapacity")


def test_rao_ras_with_units_but_no_usable_bid_are_one_line_per_tso(caplog):
    rd = [_unit("RD1"), _unit("RD2"), _unit("RD3"), _unit("RD4", tso="TSO-D")]
    bids = [_bid("B1", "RD1", 50.0), _bid("B2", "RD2", 0.0)]
    with caplog.at_level(logging.DEBUG):
        parse_summaries.log_ras_without_usable_bid(rd, bids, [_ct("CT1"), _ct("CT2")], [_bid("B3", "CT1", 5.0)], "1030Z")
    lines = _messages(caplog, "no usable bid", level=logging.WARNING)
    assert len(lines) == 3
    assert any(m.startswith("TSO-C: 2 RD RA(s) have units but no usable bid (no bid refers to them, or every bid has volume 0 at 1030Z): RD2, RD3") for m in lines)
    assert any(m.startswith("TSO-D: 1 RD RA(s)") and "RD4" in m for m in lines)
    assert any(m.startswith("TSO-C: 1 CT RA(s)") and "CT2" in m for m in lines)


def test_rao_the_bids_parsed_are_one_total_per_tso(caplog):
    rd = [_unit("RD1"), _unit("RD2", tso="TSO-D")]
    with caplog.at_level(logging.INFO):
        parse_summaries.log_bids_parsed(rd, [_bid("B1", "RD1", 5.0), _bid("B2", "RD1", 5.0), _bid("B3", "RD2", 5.0)],
                                        [_ct("CT1")], [_bid("B4", "CT1", 5.0)])
    lines = _messages(caplog, "power bids parsed", level=logging.INFO)
    assert sorted(lines) == ["TSO-C: 3 power bids parsed (2 redispatch, 1 countertrade)", "TSO-D: 1 power bids parsed (1 redispatch, 0 countertrade)"]


def _sis_and_ra(tmp_path, with_bid):
    ra = ('<nc:RedispatchRemedialAction rdf:ID="_RA1"><cim:IdentifiedObject.mRID>RA1</cim:IdentifiedObject.mRID></nc:RedispatchRemedialAction>'
          '<nc:RedispatchRemedialAction rdf:ID="_RA2"><cim:IdentifiedObject.mRID>RA2</cim:IdentifiedObject.mRID></nc:RedispatchRemedialAction>')
    bid = ('<nc:PowerBidSchedule rdf:ID="_B1"><cim:IdentifiedObject.mRID>B1</cim:IdentifiedObject.mRID>'
           '<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA2"/></nc:PowerBidSchedule>') if with_bid else ""
    ra_file, sis_file = tmp_path / "X_RA.xml", tmp_path / "X_SIS.xml"
    ra_file.write_text(NC_HEADER + ra + "</rdf:RDF>", encoding="utf-8")
    sis_file.write_text(NC_HEADER + bid + "</rdf:RDF>", encoding="utf-8")
    return ncp_parser._load_graph(ra_file), ncp_parser._load_graph(sis_file)


def test_rao_ignored_ras_are_split_into_no_bid_in_the_pool_and_a_bid_but_no_unit(tmp_path, caplog):
    ra_graph, sis_graph = _sis_and_ra(tmp_path, with_bid=True)
    with caplog.at_level(logging.INFO):
        ncp_parser.warn_unsupported_power_remedial_actions(ra_graph, sis_graph, "X")
    lines = _messages(caplog, "IGNORED", level=logging.WARNING)
    assert len(lines) == 2
    assert any("1 nc:RedispatchRemedialAction(s)" in m and "no bid in the pool refers to it" in m and "RA1" in m for m in lines)
    assert any("1 nc:RedispatchRemedialAction(s)" in m and "a bid refers to it" in m and "RA2" in m for m in lines)


# ---- wording of the NCP-switch lines -------------------------------------------------------------------------------------

def _ae_file(tmp_path, *elements):
    parts = []
    for name, properties in elements:
        body = "".join(f"<nc:AssessedElement.{key}>{value}</nc:AssessedElement.{key}>" for key, value in properties.items())
        parts.append(f'<nc:AssessedElement rdf:ID="_{name}"><cim:IdentifiedObject.mRID>{name}</cim:IdentifiedObject.mRID>'
                     f'<nc:AssessedElement.ConductingEquipment rdf:resource="#_BR-{name}"/>'
                     f'<nc:AssessedElement.SecuredForRegion rdf:resource="#_REGION"/>{body}</nc:AssessedElement>')
    path = tmp_path / "X_AE.xml"
    path.write_text(NC_HEADER + "".join(parts) + "</rdf:RDF>", encoding="utf-8")
    return path


def test_rao_the_switch_lines_state_only_what_they_count(tmp_path, caplog):
    path = _ae_file(tmp_path, ("A", {"inBaseCase": "false"}), ("B", {"normalEnabled": "false"}), ("C", {"isCombinableWithContingency": "false"}),
                    ("D", {}))
    static = {f"BR-{name}": {1: 1000.0} for name in "ABCD"}
    with caplog.at_level(logging.INFO):
        ncp_parser.parse_assessed_elements(path, None, "X", "1030Z", static)
    assert _messages(caplog, "switched off or restricted") == []
    assert _messages(caplog, "1 assessed element(s) with inBaseCase=false: monitored after contingencies only", level=logging.INFO)
    assert _messages(caplog, "1 assessed element(s) switched off by the NCP", "B", level=logging.WARNING)
    assert _messages(caplog, "1 assessed element(s) restricted to the contingencies with an included link", "C", level=logging.WARNING)


# ---- the scanned list, several days -------------------------------------------------------------------------------------

def test_rao_the_scanned_list_line_gives_only_the_count(caplog):
    scanned = AssessedElement(mrid="S1", name="S1", tso="T", ae_type=AEType.SCANNED, branch_mrid="B1", secured_for_region=None,
                              scanned_for_region="R", exclusion_reason="x", patl_ka={"1030Z": 1.0})
    with caplog.at_level(logging.INFO):
        scanned_elements.build_scanned_element_list([scanned], "1030Z")
    (line,) = _messages(caplog, "ScannedElementList built")
    assert line == "ScannedElementList built: 1 entries"


def test_rao_bids_with_time_points_on_several_days_are_a_count_and_the_first_five_ids(tmp_path, caplog):
    def bid(index):
        ident = f"BID{index}"
        points = "".join(
            f'<nc:PowerBidScheduleTimePoint rdf:ID="_TP{index}{day}"><nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{ident}"/>'
            f'<nc:PowerBidScheduleTimePoint.atTime>2030-01-0{day}T10:30:00Z</nc:PowerBidScheduleTimePoint.atTime>'
            f'<nc:PowerBidScheduleTimePoint.p>5</nc:PowerBidScheduleTimePoint.p><nc:PowerBidScheduleTimePoint.price>1</nc:PowerBidScheduleTimePoint.price>'
            f'</nc:PowerBidScheduleTimePoint>' for day in (1, 2))
        return (f'<nc:PowerBidSchedule rdf:ID="_{ident}"><cim:IdentifiedObject.mRID>{ident}</cim:IdentifiedObject.mRID>'
                f'<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/>'
                f'<nc:PowerBidSchedule.direction rdf:resource="https://cim4.eu/ns/nc#BidDirectionKind.up"/></nc:PowerBidSchedule>{points}')
    path = tmp_path / "X_SIS.xml"
    path.write_text(NC_HEADER + "".join(bid(i) for i in range(8)) + "</rdf:RDF>", encoding="utf-8")
    with caplog.at_level(logging.DEBUG):
        ncp_parser.parse_power_bids(ncp_parser._load_graph(path), {"RA1"}, "X", "1030Z", run_date="2030-01-01")
    (line,) = _messages(caplog, "time points on several days - read by date and time", level=logging.WARNING)
    assert "8 bid(s)" in line and "BID0, BID1, BID2, BID3, BID4 and 3 more" in line and "BID7" not in line
    assert any("BID7" in m for m in _messages(caplog, "all ids", level=logging.DEBUG))


# ---- the inventory table ---------------------------------------------------------------------------------------------

def test_rao_the_inventory_has_countertrade_and_hvdc_columns_per_tso_and_in_the_total(caplog):
    hvdc = [HvdcUnit(mrid="H1", name="H1", tso="TSO-C", ei_mrid="EI", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0)]
    with caplog.at_level(logging.INFO):
        inventory_summary.print_inventory_summary(
            tso_name_map={"c": "TSO-C"}, tsos_with_data=["TSO-C", "TSO-D"], ae_flat_list=[], co_flat_list=[], pst_list=[],
            rd_list=[_unit("RD1")], bid_list=[_bid("B1", "RD1", 5.0)], timestamp="1030Z", hvdc_list=hvdc,
            ct_list=[_ct("CT1"), _ct("CT2")], ct_bid_list=[_bid("B2", "CT1", 5.0), _bid("B3", "CT1", 5.0), _bid("B4", "CT2", 5.0)])
    (table,) = [r.getMessage() for r in caplog.records if "INVENTORY SUMMARY" in r.getMessage()]
    header = [line for line in table.splitlines() if "AE-sec" in line][0].split()
    assert header[-4:] == ["Bids", "CT", "CT-bids", "HVDC"]
    row_c = [line for line in table.splitlines() if line.strip().startswith("TSO-C")][0].split()
    assert row_c[-5:] == ["1", "1", "2", "3", "1"]          # RD, Bids, CT, CT-bids, HVDC
    row_d = [line for line in table.splitlines() if line.strip().startswith("TSO-D")][0].split()
    assert row_d[-5:] == ["0", "0", "0", "0", "0"]
    total = [line for line in table.splitlines() if line.strip().startswith("TOTAL")][0].split()
    assert total[-5:] == ["1", "1", "2", "3", "1"]
