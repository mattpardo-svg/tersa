"""
tests/test_rao_pst_duplicate_rows.py - two available PST rows of the same kind (preventive or curative) on one transformer
stop the run with a clear error naming the PST and both remedial actions; one preventive plus one curative row on the same
PST is allowed (as in the shipped mock).
"""
import copy
import xml.etree.ElementTree as ET

import pytest

from mock_builders import ncp_xml as conv
from mock_builders import standard
from mock_builders.zipio import write_zip
from helpers import run_pipeline_on_fixture_inputs

TSO = "Belgovia"
DUPLICATE_SUFFIX = "_DUP"


def _nc(local):
    return conv._nc(local)


def _files_with_a_second_row(kind_word):
    """The shipped mock with a copy of Belgovia's first <kind_word> PST RA (new ids, name + _DUP, same tap changer)."""
    files = standard.shipped_files()
    doc = conv.Doc(f"{TSO}_RA.xml", files[f"{TSO}_RA.xml"])
    wanted = f"{conv.NC}RemedialActionKind.{kind_word}"
    for ra in doc.elements("GridStateAlterationRemedialAction"):
        kind = conv._child(ra, _nc("RemedialAction.kind"))
        action = next((a for a in doc.elements("TapPositionAction")
                       if conv._ref(a, _nc("GridStateAlteration.GridStateAlterationRemedialAction")) == Doc_ident(ra)), None)
        if kind is not None and kind.get(conv._rdf("resource")) == wanted and action is not None:
            break
    else:
        raise AssertionError(f"no {kind_word} PST RA")
    ra_id = Doc_ident(ra)
    new_ra_id, new_action_id = conv.new_id("dup-ra", ra_id), conv.new_id("dup-action", ra_id)
    new_ra, new_action = copy.deepcopy(ra), copy.deepcopy(action)
    new_ra.set(conv._rdf("ID"), "_" + new_ra_id)
    new_action.set(conv._rdf("ID"), "_" + new_action_id)
    for element, ident in ((new_ra, new_ra_id), (new_action, new_action_id)):
        element.find(conv._cim("IdentifiedObject.mRID")).text = ident
        element.find(conv._cim("IdentifiedObject.name")).text += DUPLICATE_SUFFIX
    new_action.find(_nc("GridStateAlteration.GridStateAlterationRemedialAction")).set(conv._rdf("resource"), "#_" + new_ra_id)
    doc.root.append(new_ra)
    doc.root.append(new_action)
    doc.changed = True
    files[f"{TSO}_RA.xml"] = doc.dump()
    name = conv._text(ra, conv._cim("IdentifiedObject.name"))
    return files, ra_id, name, new_ra_id, name + DUPLICATE_SUFFIX


def Doc_ident(element):
    return conv.Doc.ident(element)


@pytest.fixture(scope="module")
def tap_changer_maps(tmp_path_factory):
    from helpers import _MOCK_NX_CGM_ZIP
    from pre_milp import cgmes_loader, ncp_parser

    folder = tmp_path_factory.mktemp("cgm")
    cgmes_loader.extract_cgm_zip(_MOCK_NX_CGM_ZIP, folder)
    mapping = {}
    for eq in cgmes_loader.find_eq_files(folder):
        mapping.update(ncp_parser.build_tap_changer_to_transformer_map(eq))
    return mapping


def _psts(directory, mapping):
    from pre_milp import ncp_parser

    cgm = {t: {"low_tap": -16, "high_tap": 16, "tap": 0} for t in set(mapping.values())}
    return ncp_parser.parse_psts(directory / f"{TSO}_RA.xml", f"TSO-{TSO}", cgm, mapping)


def _write(files, folder):
    folder.mkdir(parents=True, exist_ok=True)
    for name, data in files.items():
        (folder / name).write_bytes(data)
    return folder


@pytest.mark.parametrize("kind_word", ["preventive", "curative"])
def test_rao_two_available_rows_of_one_kind_on_one_transformer_are_an_error(tmp_path, tap_changer_maps, kind_word):
    from pre_milp import ncp_parser

    files, ra_id, ra_name, other_id, other_name = _files_with_a_second_row(kind_word)
    psts = _psts(_write(files, tmp_path / "ncp"), tap_changer_maps)
    with pytest.raises(ValueError) as error:
        ncp_parser.check_unique_pst_rows(psts)
    message = str(error.value)
    for text in (kind_word, ra_id, ra_name, other_id, other_name):
        assert text in message
    assert "transformer" in message


def test_rao_one_preventive_and_one_curative_row_on_one_transformer_stay_allowed(tmp_path, tap_changer_maps):
    from pre_milp import ncp_parser

    directory = _write(standard.shipped_files(), tmp_path / "ncp")
    psts = _psts(directory, tap_changer_maps)
    assert len({p.mrid for p in psts}) < len(psts)                # the mock has both kinds on each of its PSTs
    ncp_parser.check_unique_pst_rows(psts)


def test_rao_an_unavailable_duplicate_row_is_no_error(tmp_path, tap_changer_maps):
    import dataclasses

    from pre_milp import ncp_parser

    files, *_ = _files_with_a_second_row("preventive")
    psts = _psts(_write(files, tmp_path / "ncp"), tap_changer_maps)
    psts = [dataclasses.replace(p, available=False) if p.name.endswith(DUPLICATE_SUFFIX) else p for p in psts]
    ncp_parser.check_unique_pst_rows(psts)


@pytest.mark.parametrize("kind_word", ["preventive", "curative"])
def test_rao_a_run_with_two_rows_of_one_kind_on_one_transformer_stops_with_the_clear_error(tmp_path, kind_word):
    files, ra_id, ra_name, other_id, other_name = _files_with_a_second_row(kind_word)
    zip_path = tmp_path / "ncp_duplicate.zip"
    write_zip(files, zip_path)
    with pytest.raises(ValueError, match="PST") as error:
        run_pipeline_on_fixture_inputs(tmp_path / "run", zip_path, enable_nx_analysis=False, ra_types=("pst",))
    assert ra_id in str(error.value) and other_id in str(error.value) and other_name in str(error.value)
