"""
tests/test_rao_objective_breakdown.py - after every solve one INFO block: the value of each objective term, the PST moves
(count, tap steps, the 5 largest) and a line per PST group whose members had different taps before. Log only.
Synthetic model: a PST group whose members start on different taps, no branch near its limit.
"""
import logging

import pytest

from data_model import PST, AEType, RAKind
from helpers import _make_ae_mb_scanned
from milp.milp_builder import PstMilpInputs, build_n0_milp_model
from milp.milp_solver import solve_n0_milp_model


def _pst(mrid, r0, group_id):
    return PST(
        mrid=mrid, name=mrid, tso="TSO_A", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0, low_step=-10,
        high_step=10, r0=r0, operating_tap_min=-10, operating_tap_max=10, group_id=group_id,
    )


def _solve(starting_taps, group_id="G1", grouped=True, max_taps=100):
    names = [f"P{n}" for n in range(len(starting_taps))]
    psts = [_pst(name, tap, group_id if grouped else None) for name, tap in zip(names, starting_taps)]
    pairs = [(names[0], other) for other in names[1:]] if grouped else []
    inputs = PstMilpInputs(
        pst_list=psts, pst_tap_bounds={name: (-10, 10) for name in names}, pst_group_equality_pairs=pairs,
        sensitivity_pst_n0_pruned={("B1", names[0]): 5.0}, pst_degrees_per_tap={name: 1.0 for name in names},
        penalty_reference_pst_pra=10.0, max_taps_per_tso=max_taps,
    )
    model = build_n0_milp_model(
        [_make_ae_mb_scanned("B1", AEType.SECURED, 1, 1.0)], "1030Z", {"B1": {1: 500.0}}, 1000.0, pst_inputs=inputs,
    )
    results, _ = solve_n0_milp_model(model, psts, 10.0)
    return model, results


def _info(caplog):
    return [r.getMessage() for r in caplog.records if r.levelno == logging.INFO]


def test_the_block_gives_each_objective_term_and_the_total(caplog):
    with caplog.at_level(logging.INFO):
        _solve([3, 7])
    text = "\n".join(_info(caplog))
    assert "Objective breakdown" in text
    assert "pst_tap_change_penalty" in text and "40" in text          # 4 tap steps x 10
    assert "overload_n0" in text


def test_the_terms_add_up_to_the_objective():
    import pyomo.environ as pyo
    model, _ = _solve([3, 7])
    total = sum(float(pyo.value(expression)) for expression in model.objective_term_expressions.values())
    assert total == pytest.approx(float(pyo.value(model.objective)))


def test_the_summary_term_dictionary_is_unchanged():
    model, _ = _solve([3, 7])
    assert set(model.objective_penalty_term_expressions) == {"overload_n0"}


def test_the_block_counts_moved_psts_and_tap_steps_and_names_the_largest_moves(caplog):
    with caplog.at_level(logging.INFO):
        _solve([3, 7])
    text = "\n".join(_info(caplog))
    assert " of 2 PST(s) moved, 4 tap step(s) in total; largest: " in text    # any tap between 3 and 7 costs 4 steps
    assert "P0 3 -> " in text or "P1 7 -> " in text


def test_a_group_with_different_taps_before_gets_one_line_with_taps_before_and_after(caplog):
    with caplog.at_level(logging.INFO):
        _solve([3, 7])
    lines = [m for m in _info(caplog) if "PST group G1" in m]
    assert len(lines) == 1
    assert "before [3, 7]" in lines[0]
    after = lines[0].split("after")[1]
    assert after.count(",") == 1 and len({value.strip(" []") for value in after.split(",")}) == 1   # equal after


def test_a_group_with_equal_taps_before_gets_no_line(caplog):
    with caplog.at_level(logging.INFO):
        _solve([5, 5])
    text = "\n".join(_info(caplog))
    assert "PST group" not in text and "0 of 2 PST(s) moved" in text


def test_only_the_five_largest_moves_are_listed(caplog):
    with caplog.at_level(logging.INFO):
        _solve([-6, -4, -2, 0, 2, 4, 6], max_taps=100)
    line = next(m for m in _info(caplog) if "largest" in m)
    assert line.count(" -> ") == 5


def test_without_psts_the_block_has_the_terms_and_no_pst_lines(caplog):
    from milp.objective_report import log_objective_report
    import pyomo.environ as pyo
    model = pyo.ConcreteModel()
    model.objective_term_expressions = {"overload_n0": 0.0}
    model.objective = pyo.Objective(expr=0.0)
    with caplog.at_level(logging.INFO):
        log_objective_report(model, {}, [])
    text = "\n".join(_info(caplog))
    assert "overload_n0" in text and "PST(s) moved" not in text
