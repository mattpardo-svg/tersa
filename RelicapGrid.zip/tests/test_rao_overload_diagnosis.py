"""tests/test_rao_overload_diagnosis.py - the INFO block per overloaded N-X pair after the final check (log only),
and the separate overload counts of the solver line."""

import logging

import pyomo.environ as pyo
import pytest

from helpers import _make_ae_nx_filters as _ae, _make_pst_nx_filters as _pst
from milp.milp_builder import NxMilpInputs, PstMilpInputs, RdMilpInputs, build_n0_milp_model
from milp.milp_solver import solve_n0_milp_model
from milp.overload_diagnosis import log_overload_diagnosis

TS = "1030Z"


def _model(pst_sensitivity=-5.0, threshold_active=False, r0=0, bounds=(-10, 10)):
    pst = _pst("PST1", r0=r0)
    pst_inputs = PstMilpInputs(
        pst_list=[pst], pst_tap_bounds={"PST1": bounds}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={}, pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: 1100.0}}}, sensitivity_pst_nx={"CO1": {("B1", "PST1"): pst_sensitivity}},
        sensitivity_rd_nx={}, penalty_cost_overload_nx_patl=10_000.0, drop_zero_pst_terms=threshold_active,
    )
    model = build_n0_milp_model(
        [_ae("a1", "B1")], TS, {"B1": {1: 500.0}}, 1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    model.nx_build_baseline = {"lf_nx": nx_inputs.lf_nx, "sensitivity_pst_nx": nx_inputs.sensitivity_pst_nx}
    return model


def _detail(overload=180.0, limit=1000.0):
    return {"limit": limit, "current": limit + overload, "overload": overload}


def _messages(caplog, level):
    return [r.getMessage() for r in caplog.records if r.levelno == level and "overload diagnosis" in r.getMessage()]


def test_one_info_block_per_pair_with_the_pst_effect_and_the_best_relief(caplog):
    model = _model()
    with caplog.at_level(logging.DEBUG, logger="milp.overload_diagnosis"):
        log_overload_diagnosis(model, {("nx_patl", "B1", "CO1"): _detail()})
    (block,) = _messages(caplog, logging.INFO)
    for text in ("N-X PATL", "B1", "CO1", "limit 1000.0 A", "AC current 1180.0 A", "overload 180.0 A",
                 "largest effect per tap 5.0 A", "best possible relief 50.0 A",
                 "no PST can relieve this overload by more than 50.0 A"):
        assert text in block, text
    assert "before the threshold 5.0 A" in block         # no threshold applied: the raw value is the table value


def test_before_the_threshold_says_pruned_when_the_raw_value_is_not_kept(caplog):
    model = _model(threshold_active=True)
    with caplog.at_level(logging.INFO, logger="milp.overload_diagnosis"):
        log_overload_diagnosis(model, {("nx_patl", "B1", "CO1"): _detail()})
    (block,) = _messages(caplog, logging.INFO)
    assert "before the threshold pruned" in block


def test_the_relief_follows_the_tap_range_from_the_current_tap(caplog):
    model = _model(r0=7, bounds=(-10, 10))               # helpful direction is up (-5 A per tap): 3 taps left
    with caplog.at_level(logging.INFO, logger="milp.overload_diagnosis"):
        log_overload_diagnosis(model, {("nx_patl", "B1", "CO1"): _detail()})
    (block,) = _messages(caplog, logging.INFO)
    assert "best possible relief 15.0 A" in block


def test_no_closing_line_when_a_pst_could_relieve_the_overload(caplog):
    model = _model()
    with caplog.at_level(logging.INFO, logger="milp.overload_diagnosis"):
        log_overload_diagnosis(model, {("nx_patl", "B1", "CO1"): _detail(overload=20.0)})
    (block,) = _messages(caplog, logging.INFO)
    assert "no PST can relieve" not in block


def test_at_most_twenty_pairs_at_info_and_the_rest_at_debug(caplog):
    model = _model()
    details = {("nx_patl", "B1", f"CO{i:02d}"): _detail(overload=100.0 + i) for i in range(25)}
    with caplog.at_level(logging.DEBUG, logger="milp.overload_diagnosis"):
        log_overload_diagnosis(model, details)
    assert len(_messages(caplog, logging.INFO)) == 20
    assert len(_messages(caplog, logging.DEBUG)) == 5
    assert "overload 124.0 A" in _messages(caplog, logging.INFO)[0]      # the largest overload first


def test_a_model_without_psts_still_gives_the_block(caplog):
    nx_inputs = NxMilpInputs(lf_nx={"CO1": {"B1": {1: 1100.0}}}, sensitivity_pst_nx={}, sensitivity_rd_nx={})
    model = build_n0_milp_model([_ae("a1", "B1")], TS, {"B1": {1: 500.0}}, 1000.0, nx_inputs=nx_inputs)
    with caplog.at_level(logging.INFO, logger="milp.overload_diagnosis"):
        log_overload_diagnosis(model, {("nx_patl", "B1", "CO1"): _detail()})
    (block,) = _messages(caplog, logging.INFO)
    assert "no PST can relieve this overload by more than 0.0 A" in block


def test_the_solver_line_counts_n0_and_the_three_n_x_kinds_separately(caplog):
    model = _model(pst_sensitivity=0.0)                   # nothing can relieve B1 after CO1: PATL slack 100 A
    with caplog.at_level(logging.INFO, logger="milp.milp_solver"):
        solve_n0_milp_model(model, [_pst("PST1")], 10.0)
    (line,) = [r.getMessage() for r in caplog.records if "MILP solved optimally" in r.getMessage()]
    assert "N-0 overloaded branches=0" in line and "N-X PATL pairs=1" in line
    assert "N-X TATL pairs=0" in line and "N-X scanned pairs=0" in line
    assert pyo.value(model.nx_patl_overload_slack["B1", "CO1"]) > 0


# ---------------------------------------------------------------------------
# redispatch and countertrade in the block, and the closing line per pair
# ---------------------------------------------------------------------------

def _rd_model(sensitivity=-0.5, volume=20.0, max_p=100.0, pruned=False, with_pst=False):
    """One RD RA on GU1 with an up bid; A per MW on (B1, CO1) = sensitivity; unit at 50 MW, limit max_p."""
    from data_model import BidDirection, PowerBid, RAKind, RDUnit
    rd = RDUnit(mrid="RA1", name="RA1", tso="T", gu_mrid="GU1", gu_name="GU1", available=True, kind=RAKind.PREVENTIVE,
                initial_p=50.0, max_p=max_p, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None)
    bid = PowerBid(mrid="BID1", ra_mrid="RA1", direction=BidDirection.UP, available_mw={TS: volume}, price_eur_mw=1.0,
                   lead_time_h=0.0, activation_cost_eur=None)
    rd_inputs = RdMilpInputs(
        rd_list=[rd], bid_list=[bid], glsk={"RA1": {"GU1": 1.0}}, sensitivity_rd_n0_pruned={("B1", "GU1"): sensitivity},
        generator_data={"GU1": {"target_p": 50.0, "max_p": max_p, "min_p": 0.0, "name": "GU1"}}, penalty_reference_rd_pra=1.0)
    pst_inputs = PstMilpInputs(
        pst_list=[_pst("PST1")], pst_tap_bounds={"PST1": (-10, 10)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={}, pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=10.0) if with_pst else None
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: 1100.0}}}, sensitivity_pst_nx={"CO1": {("B1", "PST1"): -5.0}} if with_pst else {},
        sensitivity_rd_nx={"CO1": {("B1", "GU1"): sensitivity}}, penalty_cost_overload_nx_patl=10_000.0,
        drop_zero_rd_terms=pruned)
    model = build_n0_milp_model(
        [_ae("a1", "B1")], TS, {"B1": {1: 500.0}}, 1000.0, pst_inputs=pst_inputs, rd_inputs=rd_inputs, nx_inputs=nx_inputs)
    model.nx_build_baseline = {"lf_nx": nx_inputs.lf_nx, "sensitivity_pst_nx": nx_inputs.sensitivity_pst_nx,
                               "sensitivity_rd_nx": nx_inputs.sensitivity_rd_nx}
    return model


def test_the_block_has_the_redispatch_effect_per_100_mw_and_the_best_relief_within_the_bid_volume(caplog):
    with caplog.at_level(logging.INFO, logger="milp.overload_diagnosis"):
        log_overload_diagnosis(_rd_model(), {("nx_patl", "B1", "CO1"): _detail()})
    (block,) = _messages(caplog, logging.INFO)
    assert ("preventive redispatch: largest effect per 100 MW 50.0 A (before the threshold 50.0 A), "
            "best possible relief 10.0 A (before the threshold 10.0 A)") in block


def test_the_relief_of_a_redispatch_bid_stops_at_the_unit_limit(caplog):
    with caplog.at_level(logging.INFO, logger="milp.overload_diagnosis"):
        log_overload_diagnosis(_rd_model(max_p=55.0), {("nx_patl", "B1", "CO1"): _detail()})
    (block,) = _messages(caplog, logging.INFO)
    assert "best possible relief 2.5 A" in block                     # 5 MW of room x 0.5 A per MW


def test_before_the_threshold_says_pruned_for_redispatch_too(caplog):
    with caplog.at_level(logging.INFO, logger="milp.overload_diagnosis"):
        log_overload_diagnosis(_rd_model(pruned=True), {("nx_patl", "B1", "CO1"): _detail()})
    (block,) = _messages(caplog, logging.INFO)
    assert "preventive redispatch: largest effect per 100 MW 50.0 A (before the threshold pruned)" in block


def test_one_closing_line_names_the_best_ra_type_and_its_relief(caplog):
    with caplog.at_level(logging.INFO, logger="milp.overload_diagnosis"):
        log_overload_diagnosis(_rd_model(with_pst=True), {("nx_patl", "B1", "CO1"): _detail()})
        log_overload_diagnosis(_rd_model(), {("nx_patl", "B1", "CO1"): _detail()})
    first, second = _messages(caplog, logging.INFO)
    assert first.count("best RA type") == 1 and first.endswith("best RA type: PST, relief 50.0 A")       # 50 A beats 10 A
    assert second.endswith("best RA type: redispatch, relief 10.0 A")


# ---------------------------------------------------------------------------
# the shared RD + countertrade balance and the binding limit
# ---------------------------------------------------------------------------

def _balance_model(up_volume=500.0, down_volume=300.0, down_lead_time=5.0, ct_volume=204.0, up_max_p=1000.0, current_a=1100.0):
    """B1 after CO1 carries 1100 A (limit 1000 A). RD up bid on GU_UP (-5 A per MW), RD down bid on GU_DN (+3 A per MW, lead
    time down_lead_time h), countertrade down bid on GU_CT (+4 A per MW, volume ct_volume). The decision point is 1 h before
    the run, so a 5 h lead time blocks the RD down bid."""
    from data_model import BidDirection, PowerBid, RAKind, RDUnit
    def unit(ra, gu, ct):
        return RDUnit(mrid=ra, name=ra, tso="T", gu_mrid=gu, gu_name=gu, available=True, kind=RAKind.PREVENTIVE,
                      initial_p=300.0, max_p=up_max_p if gu == "GU_UP" else 1000.0, min_p=0.0, raise_ramp_rate=None,
                      lower_ramp_rate=None, countertrade=ct)
    bid = lambda mrid, ra, direction, volume, lead: PowerBid(                      # noqa: E731
        mrid=mrid, ra_mrid=ra, direction=direction, available_mw={TS: volume}, price_eur_mw=1.0, lead_time_h=lead,
        activation_cost_eur=None)
    sensitivity = {("B1", "GU_UP"): -5.0, ("B1", "GU_DN"): 3.0, ("B1", "GU_CT"): 4.0}
    rd_inputs = RdMilpInputs(
        rd_list=[unit("RA_UP", "GU_UP", False), unit("RA_DN", "GU_DN", False), unit("RA_CT", "GU_CT", True)],
        bid_list=[bid("BID_UP", "RA_UP", BidDirection.UP, up_volume, 0.0), bid("BID_DN", "RA_DN", BidDirection.DOWN, down_volume, down_lead_time),
                  bid("BID_CT", "RA_CT", BidDirection.DOWN, ct_volume, 0.0)],
        glsk={"RA_UP": {"GU_UP": 1.0}, "RA_DN": {"GU_DN": 1.0}},
        sensitivity_rd_n0_pruned=dict(sensitivity),
        generator_data={gu: {"target_p": 300.0, "max_p": up_max_p if gu == "GU_UP" else 1000.0, "min_p": 0.0, "name": gu}
                        for gu in ("GU_UP", "GU_DN", "GU_CT")},
        penalty_reference_rd_pra=1.0, bid_participation={"BID_CT": {"GU_CT": 1.0}},
        penalty_reference_ct_pra=1.0, penalty_reference_ct_cra=1.0)
    nx_inputs = NxMilpInputs(lf_nx={"CO1": {"B1": {1: current_a}}}, sensitivity_pst_nx={}, sensitivity_rd_nx={"CO1": dict(sensitivity)},
                             penalty_cost_overload_nx_patl=10_000.0)
    model = build_n0_milp_model([_ae("a1", "B1")], TS, {"B1": {1: 500.0}}, 1000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs)
    model.nx_build_baseline = {"lf_nx": nx_inputs.lf_nx, "sensitivity_pst_nx": {}, "sensitivity_rd_nx": nx_inputs.sensitivity_rd_nx}
    return model


def test_the_solved_slack_is_the_overload_minus_the_relief_within_the_balance():
    """Overload 2000 A: the free relief (3316 A) would clear it, the relief within the balance (1836 A) leaves 164 A."""
    model = _balance_model(current_a=3000.0)
    solve_n0_milp_model(model, [], 10.0)
    assert pyo.value(model.nx_patl_overload_slack["B1", "CO1"]) == pytest.approx(164.0, abs=1e-3)
    assert pyo.value(model.rd_volume_upward["BID_UP"]) == pytest.approx(204.0, abs=1e-3)
    assert pyo.value(model.rd_volume_downward["BID_CT"]) == pytest.approx(204.0, abs=1e-3)
    assert pyo.value(model.rd_volume_downward["BID_DN"]) == pytest.approx(0.0, abs=1e-6)


def _balance_block(caplog, model, overload=100.0):
    with caplog.at_level(logging.INFO, logger="milp.overload_diagnosis"):
        log_overload_diagnosis(model, {("nx_patl", "B1", "CO1"): _detail(overload=overload)})
    (block,) = _messages(caplog, logging.INFO)
    return block


def test_the_relief_within_the_balance_is_below_the_free_relief_when_one_side_is_short(caplog):
    block = _balance_block(caplog, _balance_model())
    # free: up 500 MW x 5 A + countertrade down 204 MW x 4 A (the RD down bid is blocked); balanced: 204 MW each side
    assert "within the shared balance" in block
    assert "best possible relief 1836.0 A (without the balance 3316.0 A)" in block
    assert "binding limit: balance" in block


def test_the_block_names_why_the_short_side_is_short(caplog):
    block = _balance_block(caplog, _balance_model())
    assert "up 500.0 MW" in block and "down 204.0 MW" in block
    assert "1 countertrade bid(s) at their volume limit" in block
    assert "1 redispatch bid(s) blocked by the lead time" in block


def test_a_unit_limit_is_named_when_it_stops_the_up_side(caplog):
    block = _balance_block(caplog, _balance_model(up_max_p=350.0, ct_volume=500.0, down_lead_time=0.0))
    assert "1 redispatch bid(s) at a unit limit" in block          # GU_UP can only rise 50 MW


def test_no_balance_limit_when_both_sides_have_room(caplog):
    block = _balance_block(caplog, _balance_model(up_volume=100.0, ct_volume=100.0))      # the RD down bid stays blocked
    assert "best possible relief 900.0 A (without the balance 900.0 A)" in block      # 100 MW up (500 A) + 100 MW down (400 A)
    assert "binding limit: bid volume" in block


def test_the_existing_lines_and_the_closing_line_are_unchanged(caplog):
    block = _balance_block(caplog, _balance_model())
    assert "preventive redispatch: largest effect per 100 MW" in block and "preventive countertrade: largest effect per 100 MW" in block
    assert block.endswith("best RA type: redispatch, relief 2500.0 A")


def test_countertrade_bids_are_their_own_line(caplog):
    from test_rao_milp_builder_ct import _ae as ct_ae, _inputs, TS as CT_TS
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: 1100.0}}}, sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("B1", "A1"): 0.4, ("B1", "A2"): 0.2, ("B1", "B1"): -0.1, ("B1", "B2"): -0.1}},
        penalty_cost_overload_nx_patl=1e6)
    model = build_n0_milp_model([ct_ae()], CT_TS, {"B1": {1: 1100.0}}, 1e6, rd_inputs=_inputs(), nx_inputs=nx_inputs)
    model.nx_build_baseline = {"lf_nx": nx_inputs.lf_nx, "sensitivity_pst_nx": {}, "sensitivity_rd_nx": nx_inputs.sensitivity_rd_nx}
    with caplog.at_level(logging.INFO, logger="milp.overload_diagnosis"):
        log_overload_diagnosis(model, {("nx_patl", "B1", "CO1"): _detail(overload=500.0)})
    (block,) = _messages(caplog, logging.INFO)
    assert "preventive redispatch: largest effect per 100 MW 0.0 A" in block
    assert ("preventive countertrade: largest effect per 100 MW 36.0 A (before the threshold 36.0 A), "
            "best possible relief 138.0 A") in block                  # 0.36 A/MW x 300 MW + 0.1 A/MW x 300 MW
    assert block.endswith("best RA type: countertrade, relief 138.0 A")
