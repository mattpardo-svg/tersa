"""fp_check.py - fingerprints of the models built from the shipped standard mock against
tests/fixtures/milp_model_fingerprints.json (fixture_run part). The argument (kept for the gate) must be 'none'."""
import sys, json, pathlib, tempfile
repo = pathlib.Path(__file__).resolve().parents[3]
sys.path[:0] = [str(repo / "tests"), str(repo / "src" / "rao"), str(repo)]
import helpers
assert sys.argv[1] == "none", "the only form of the mock is the shipped standard one"
work = pathlib.Path(tempfile.mkdtemp(prefix="fp_"))
z = helpers._MOCK_NX_NCP_ZIP
models = []
def keep(rp, mp):
    b = rp.ac_convergence_loop.build_n0_milp_model
    def kb(*a, **k):
        m = b(*a, **k); models.append(m); return m
    mp.setattr(rp.ac_convergence_loop, "build_n0_milp_model", kb)
helpers.run_pipeline_on_fixture_inputs(work / "run", z, enable_nx_analysis=True, customize_pipeline=keep)
got = [helpers.milp_model_fingerprint_by_family(m, coefficients=False) for m in models]
want = json.loads((repo / "tests" / "fixtures" / "milp_model_fingerprints.json").read_text(encoding="utf-8"))["fixture_run"]
print("models", len(got), "expected", len(want))
print("FINGERPRINTS", "IDENTICAL" if got == want else "DIFFERENT")
if got != want:
    for i, (g, w) in enumerate(zip(got, want)):
        for k in sorted(set(g) | set(w)):
            if g.get(k) != w.get(k): print("  model", i, "family", k)
