# tests/tools

The development tool of the RAO prototype: it regenerates the frozen fixtures of `tests/fixtures/`, and runs the golden matrix and the gate against the golden runs. Nothing in `src/` imports this folder (the GUI never does), and no non-public data is ever put here.

The test suite does not need this folder. It needs only `src/`, `tests/` and `tests/fixtures/` (`tests/test_rao_suite_independence.py` fails when a test, a helper or a builder reaches outside them; the whole suite passes with `input/` and `docs/` renamed). The builders of the mock NCP packages that the tests use live in `tests/mock_builders/`; this folder imports them.

## Content

| Path | What |
|---|---|
| `fixture_cli.py` | The command line, `python tests/tools/fixture_cli.py`. |
| `golden/` | Golden matrix (52 runs of `run_pipeline.main()`, among them the mock with its countertrade RAs on, `pst+rd+countertrade`, and 4 runs of the mock with the N-X pruning thresholds at 0.02 %, `mockpruned`), the comparison rule, the suite in parallel by file (`tests/`), the fingerprint check and the gate; see `golden/README.md`. |
| `check_doc_links.py` | The link check of the documentation (the last step of the gate). |
| `../test_rao_doc_links.py`, `../test_rao_golden_compare.py`, `../test_rao_mock_data_cli.py` | Tests of these tools; they are part of the suite. |

The builders are in `tests/mock_builders/`:

| Module | What |
|---|---|
| `paths.py` | Where the data files are and what they are called (the one place to rename a zip); everything is under `tests/fixtures/`. |
| `standard.py` | The standard-form mock. `base_zip()` / `build_base()`: the frozen base without countertrade; the builders below start from it. `build_standard()`: the shipped mock = base plus the 8 countertrade RAs. |
| `countertrade_p.py` | The countertrade RAs and bids of the shipped mock (a preventive and a curative RA per region; Espheim with three bids per direction). |
| `ct_mock.py`, `hvdc_mock.py` | Mock NCPs of the countertrade and HVDC tests, built on top of the base. |
| `ncp_dataset.py` | The NCP test dataset (valid package, invalid and warning variants, data rules) and the shared-bid redispatch cases. |
| `ae_switch_variants.py`, `multiday.py` | Variants with switches on assessed elements, and values that depend on the day. |
| `legacy_writer.py` | Writes the shipped mock in the NCP 2.2 legacy form (flat, no organisation file, creator EIC per TSO, shift keys in the `GLSKSchedule` chain, bids without direction for one TSO) and a small CGMES 2.4.15 EQ snippet; see `docs/specs/ncp_data_requirements.md` section 13. |
| `ncp_xml.py` | Helpers: namespaces, deterministic ids, `Doc` (one parsed file), element writers, the zip reader, the map of CGM machines to generating units. |
| `zipio.py` | Zip helper: entries with fixed time stamps, so equal input gives equal bytes. |

## Commands (from the repo root)

```
python tests/tools/fixture_cli.py standard [--out PATH]       write the standard-form mock (default: the fixture path)
python tests/tools/fixture_cli.py base [--out PATH]           write the frozen base of the builders (same bytes as the fixture)
python tests/tools/fixture_cli.py ncp22-legacy OUT.zip         write the mock in the NCP 2.2 legacy form
python tests/tools/fixture_cli.py check                        SHA-256 of the fixture zips; standard = base + countertrade; copies in input/
python tests/tools/fixture_cli.py variant ct|hvdc|cthvdc|dataset OUT.zip
python tests/tools/fixture_cli.py dataset-variant --list       names of the invalid / warning variants
python tests/tools/fixture_cli.py dataset-variant NAME OUT.zip
python tests/tools/fixture_cli.py shared-bid CASE OUT.zip      A, A_strategy, B_preventive, C_preventive, D_espheim
```

The golden matrix, the baseline, the comparison rule, the gate (`python tests/tools/golden/run_gate.py OUTDIR TAG none`, about 25 minutes, with the link check of the docs as its last step) and the timing script are described in `golden/README.md`.

## The frozen fixtures of `tests/fixtures/` and how to regenerate each

| Fixture | What | Regenerate |
|---|---|---|
| `CGM_package.zip` | Official CGM sample. | Never: it is an official sample and is not changed. |
| `NCP_sample_generic_2_4.zip` | Official NCP sample (profile 2.4); the `RotatingMachineAction` redispatch form is its form. | Never: not changed. |
| `NCP_mock_standard_base.zip` | The standard-form mock without countertrade, the start of every builder. Frozen: the converter that once made it from an old-form zip is removed. | Edit the files by hand (or with `ncp_xml.Doc`) and write the zip with `python tests/tools/fixture_cli.py base --out tests/fixtures/NCP_mock_standard_base.zip`; then regenerate the shipped mock and update the SHA-256 in `tests/test_rao_standard_mock.py`. |
| `NCP_mock_standard.zip` | The shipped standard mock: the base plus the countertrade RAs and bids of `countertrade_p.py`. | `python tests/tools/fixture_cli.py standard` (the test `test_rao_the_shipped_mock_is_the_base_plus_the_countertrade_ras` compares the bytes). |
| `milp_model_fingerprints.json` | Structure of the MILP models of the mock run. | Only on purpose (a DECISIONS entry): `helpers.write_milp_model_fingerprints(path)` run with `PYTHONHASHSEED=0`, as `tests/test_rao_milp_builder_nx.py` does in a subprocess; `golden/fp_check.py none` shows the difference. |
| `ra_shared_tapchanger_preventive_and_curative.xml` | One small RA file for the shared tap changer test. | By hand. |

`input/` holds user data; no test reads it.

## Rules

- The zips written here are byte-stable (fixed zip time stamps, deterministic mRIDs). The byte-equality test `test_rao_the_shipped_mock_is_the_base_plus_the_countertrade_ras` guards the standard mock.
- The sample zips (the CGM and the generic NCP sample) are official and never changed.
- A builder never imports a test file; tests import builders with `from mock_builders import ...`. No test and no builder reads `input/` or `docs/`.

## Adding a variant

Write the builder next to the others in `tests/mock_builders/` (copy the standard mock, change what the variant is about, write with `zipio.fixed_entry`), add a command or a case name to `cli.py`, add a test.
