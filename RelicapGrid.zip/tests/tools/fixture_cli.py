"""cli.py - python tests/tools/fixture_cli.py COMMAND ...

  standard [--out PATH]           the shipped standard-form mock NCP (the frozen base plus the countertrade RAs)
  base [--out PATH]               the frozen base of the builders, the standard mock without countertrade
  check                           SHA-256 of the fixture zips, the standard mock and its base regenerated, copies in input/
  ncp22-legacy OUT.zip            the mock NCP in the NCP 2.2 legacy form (flat, no organisation file)
  variant ct|hvdc|cthvdc|dataset OUT.zip
  dataset-variant NAME OUT.zip    one invalid / warning variant of the NCP test dataset (--list shows the names)
  shared-bid CASE OUT.zip         a shared-bid redispatch case on the standard-form mock
All outputs are deterministic (fixed zip time stamps, deterministic mRIDs)."""
from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))        # tests/ for `mock_builders`
from mock_builders import paths

HERE = Path(__file__).resolve().parent
INPUT_DIR = paths.REPO_ROOT / "input"


def sha256(path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check() -> int:
    """Print the fixture zips with their SHA-256 and compare the standard mock with the converter output."""
    from mock_builders import standard

    problems = 0
    for label, path in (("CGM", paths.CGM_ZIP), ("standard", paths.STANDARD_ZIP), ("standard base", paths.STANDARD_BASE_ZIP),
                        ("generic sample", paths.SAMPLE_GENERIC_ZIP)):
        print(f"{label:15} {sha256(path)[:16]}  {path.stat().st_size:>9} bytes  {path.name}")
    import tempfile
    with tempfile.TemporaryDirectory() as folder:
        regenerated = standard.build_standard(Path(folder) / "standard.zip")
        same = regenerated.read_bytes() == paths.STANDARD_ZIP.read_bytes()
    print("standard = base + countertrade:", "yes" if same else "NO")
    problems += 0 if same else 1
    for name in sorted(p.name for p in INPUT_DIR.glob("*.zip")) if INPUT_DIR.is_dir() else []:
        target = INPUT_DIR / name
        known = [label for label, path in (("CGM", paths.CGM_ZIP), ("standard", paths.STANDARD_ZIP), ("standard base", paths.STANDARD_BASE_ZIP),
                                           ("generic sample", paths.SAMPLE_GENERIC_ZIP)) if sha256(path) == sha256(target)]
        print(f"input/{name}: " + (f"identical to the {known[0]} fixture" if known else "not a fixture copy"))
    return problems


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="python tests/tools/fixture_cli.py", description=__doc__.split("\n\n")[0])
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("standard", help="write the standard-form mock NCP")
    p.add_argument("--out", type=Path, default=paths.STANDARD_ZIP)
    p = sub.add_parser("base", help="write the frozen base of the builders")
    p.add_argument("--out", type=Path, default=paths.STANDARD_BASE_ZIP)
    sub.add_parser("check", help="hashes of the fixture zips, standard = base + countertrade")
    p = sub.add_parser("variant", help="a mock NCP of the countertrade / HVDC / dataset builders")
    p.add_argument("name", choices=("ct", "hvdc", "cthvdc", "dataset"))
    p.add_argument("out", type=Path)
    p = sub.add_parser("dataset-variant", help="one variant of the NCP test dataset")
    p.add_argument("name", nargs="?")
    p.add_argument("out", type=Path, nargs="?")
    p.add_argument("--list", action="store_true")
    p = sub.add_parser("shared-bid", help="a shared-bid redispatch case")
    p.add_argument("case")
    p.add_argument("out", type=Path)
    p = sub.add_parser("ncp22-legacy", help="the mock NCP in the NCP 2.2 legacy form")
    p.add_argument("out", type=Path)
    args = parser.parse_args(argv)

    if args.command == "standard":
        from mock_builders import standard
        out = standard.build_standard(args.out)
        print(f"{out}  {sha256(out)[:16]}")
        return 0
    if args.command == "base":
        from mock_builders import standard
        out = standard.build_base(args.out)
        print(f"{out}  {sha256(out)[:16]}")
        return 0
    if args.command == "check":
        return check()
    if args.command == "ncp22-legacy":
        from mock_builders import legacy_writer as writer
        out = writer.build_legacy(args.out)
        print(f"{out}  {sha256(out)[:16]}")
        return 0
    if args.command == "variant":
        from mock_builders import ct_mock, hvdc_mock, ncp_dataset
        builders = {"ct": ct_mock.build_ct_mock_ncp, "hvdc": hvdc_mock.build_hvdc_mock_ncp,
                    "cthvdc": ct_mock.build_ct_and_hvdc_mock_ncp, "dataset": ncp_dataset.build_valid_ncp}
        print(builders[args.name](args.out))
        return 0
    if args.command == "dataset-variant":
        from mock_builders import ncp_dataset
        names = sorted(set(ncp_dataset.VARIANTS) | set(ncp_dataset.FILE_VARIANTS))
        if args.list or args.name is None:
            print("\n".join(names))
            return 0
        if args.name not in names or args.out is None:
            parser.error("dataset-variant NAME OUT.zip (NAME from --list)")
        print(ncp_dataset.build_variant_ncp(args.out, args.name))
        return 0
    if args.command == "shared-bid":
        from mock_builders import ncp_dataset
        if args.case not in ncp_dataset.SHARED_BID_CASES:
            parser.error(f"case must be one of {sorted(ncp_dataset.SHARED_BID_CASES)}")
        print(ncp_dataset.build_shared_bid_ncp(args.out, args.case))
        return 0
    return 2


if __name__ == "__main__":
    sys.exit(main())
