"""tests/test_rao_nx_sensitivity_batches.py - the N-X sensitivity analyses of PSTs, RD units, HVDC units and countertrade
units run in batches of contingencies (nx_sensitivity.contingency_batch_size): one pypowsybl analysis per batch, read and
filtered, then released. The result must be the one of a single analysis: the tables, the guard, the dropped pairs
(coverage line), the threshold lines, the CSV files and the NaN entries. A fake analysis (synthetic matrices) checks all of
that; the mock network checks a real analysis. Synthetic ids and values only."""

import copy
import logging
import math
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest
import yaml

import run_pipeline
from data_model import AEType, AssessedElement, BidDirection, Contingency, ContingencyType, LfNx, PST, RAKind, RDUnit
from pre_milp import cgmes_loader, nx_sensitivity, sensitivity_checks

TS = "1030Z"
BRANCHES = ["b1", "b2", "b3"]
CONTINGENCIES = [f"co-{n}" for n in (3, 1, 5, 2, 4)]            # not sorted: the must-study order is kept in the result
PSTS, UNITS, EIS = ["p1", "p2"], ["g1", "g2", "g3"], ["e1", "e2"]
CONFIG_DIR = Path(run_pipeline.__file__).parent / "config"


# ---- a fake pypowsybl: the analysis records the contingencies of every run -----------------------------------------

class _Enum:
    NONE, SPECIFIC, ALL = "NONE", "SPECIFIC", "ALL"
    BRANCH_CURRENT_1, BRANCH_CURRENT_2 = "BRANCH_CURRENT_1", "BRANCH_CURRENT_2"
    TRANSFORMER_PHASE, INJECTION_ACTIVE_POWER = "TRANSFORMER_PHASE", "INJECTION_ACTIVE_POWER"


class _Result:
    def __init__(self, matrices, references):
        self._matrices, self._references = matrices, references

    def get_sensitivity_matrix(self, matrix_id, contingency_id=None):
        return self._matrices.get((matrix_id, contingency_id))

    def get_reference_matrix(self, matrix_id, contingency_id=None):
        reference = self._references.get(contingency_id)
        return None if reference is None else pd.DataFrame([reference], index=["ref"])


class _Analysis:
    def __init__(self, fake):
        self._fake, self._contingencies = fake, []

    def add_single_element_contingency(self, element_id, contingency_id):
        self._contingencies.append(contingency_id)

    def add_multiple_elements_contingency(self, element_ids, contingency_id):
        self._contingencies.append(contingency_id)

    def add_factor_matrix(self, **kwargs):
        pass

    def run(self, network, parameters=None):
        self._fake.runs.append(list(self._contingencies))
        return _Result(self._fake.matrices, self._fake.references)


class _FakePypowsybl:
    def __init__(self, matrices, references):
        self.runs, self.matrices, self.references = [], matrices, references
        self.sensitivity = SimpleNamespace(
            ContingencyContextType=_Enum, SensitivityFunctionType=_Enum, SensitivityVariableType=_Enum,
            create_ac_analysis=lambda: _Analysis(self), Parameters=lambda **kw: SimpleNamespace(**kw))
        self.loadflow = SimpleNamespace(Parameters=lambda **kw: SimpleNamespace(**kw))


def _matrix(variables, seed, nan_at=None, zero=False):
    values = np.array([[(-1) ** (row + column + seed) * (1.0 + 0.37 * seed + row + 2.5 * column) for column in range(3)]
                       for row in range(len(variables))])
    if zero:
        values[:] = 0.0
    if nan_at is not None:
        values[nan_at] = float("nan")
    return pd.DataFrame(values, index=variables, columns=BRANCHES)


def _case(monkeypatch, references_override=None, all_zero_pst_contingency="co-4"):
    """5 contingencies, 3 branches (100 A after every contingency, limit 1000 A), 2 PSTs, 3 RD units (two of them carry a
    countertrade RA), 2 HVDC injections. co-2: no reference on b2; co-3: reference 200 A on b3 (deviates); co-4: all-zero PST
    matrix; co-1: a NaN entry in every kind."""
    matrices, references = {}, {}
    for number, contingency in enumerate(sorted(CONTINGENCIES), start=1):
        for prefix, variables in (("nx_pst", PSTS), ("nx_rd", UNITS[:2]), ("nx_hvdc", EIS), ("nx_ct", UNITS), ("nx", PSTS)):
            matrices[(f"{prefix}_side1", contingency)] = _matrix(
                variables, number, nan_at=(0, 0) if contingency == "co-1" else None, zero=(prefix == "nx_pst" and contingency == all_zero_pst_contingency))
        references[contingency] = {"b1": 100.0, "b2": 100.0, "b3": 100.0}
    references["co-2"]["b2"] = float("nan")
    references["co-3"]["b3"] = 200.0
    if references_override:
        references_override(references)
    fake = _FakePypowsybl(matrices, references)
    monkeypatch.setitem(sys.modules, "pypowsybl", fake)
    monkeypatch.setattr(cgmes_loader, "build_branch_mrid_to_name", lambda network: {})
    network = SimpleNamespace(get_2_windings_transformers=lambda: pd.DataFrame(index=PSTS))
    contingencies = [Contingency(mrid=c, name=c, tso="T", contingency_type=ContingencyType.ORDINARY, must_study={TS: True},
                                 equipment_mrids=[f"eq-{c}"]) for c in CONTINGENCIES]
    ae_flat_list = [AssessedElement(mrid=f"ae-{b}", name=b, tso="T", ae_type=AEType.SECURED, branch_mrid=b, secured_for_region=None,
                                    scanned_for_region=None, exclusion_reason=None, patl_ka={TS: 1.0}, branch_side=1) for b in BRANCHES]
    pst_list = [PST(mrid=p, name=p, tso="T", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0, low_step=-10, high_step=10,
                    r0=0, operating_tap_min=-10, operating_tap_max=10, group_id=None) for p in PSTS]
    rd_list = [RDUnit(mrid=f"RD_{g}", name=g, tso="T", gu_mrid=g, gu_name=g, available=True, kind=RAKind.PREVENTIVE, initial_p=50.0,
                      max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None) for g in UNITS[:2]]
    rd_list += [RDUnit(mrid=f"CT_{g}", name=g, tso="T", gu_mrid=g, gu_name=g, available=True, kind=RAKind.PREVENTIVE, initial_p=50.0,
                       max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None, countertrade=True,
                       ct_weight_up=0.5, ct_weight_down=0.5) for g in UNITS[1:]]
    return SimpleNamespace(fake=fake, network=network, contingencies=contingencies, ae_flat_list=ae_flat_list, pst_list=pst_list,
                           rd_list=rd_list)


def _lf_nx():
    lf_nx = LfNx({c: {b: {1: 100.0} for b in BRANCHES} for c in CONTINGENCIES})
    for contingency, per_branch in lf_nx.items():
        per_branch["b1"] = {1: 100.0 + (contingency == "co-5")}
    return lf_nx


def _run(case, batch_size, tmp_path=None, pruned=False, **extra):
    case.fake.runs.clear()
    lf_nx = _lf_nx()
    guards = {"pst": {}, "rd": {}}
    references = {"pst": {}, "rd": {}}
    hvdc_out = {}
    paths = {} if tmp_path is None else {"pst_output_path": tmp_path / "pst.csv", "rd_output_path": tmp_path / "rd.csv"}
    pst, rd = nx_sensitivity.compute_sensitivities_nx(
        case.network, case.contingencies, case.pst_list, case.rd_list, case.ae_flat_list, TS, lf_nx, {b: {1: 50.0} for b in BRANCHES},
        pst_guard_out=guards["pst"], rd_guard_out=guards["rd"], pst_reference_out=references["pst"],
        rd_reference_out=references["rd"], hvdc_ei_mrids=EIS, hvdc_out=hvdc_out,
        sensitivity_threshold_pct_pst_nx=0.5 if pruned else 0.0, sensitivity_threshold_pct_rd_nx=50.0 if pruned else 0.0,
        contingency_batch_size=batch_size, **paths, **extra)
    return SimpleNamespace(pst=pst, rd=rd, hvdc=hvdc_out, guards=guards, references=references, lf_nx=lf_nx,
                           runs=[list(r) for r in case.fake.runs])


def _plain(tables):
    """{contingency: sorted [(key, value or 'nan')]} in the order of the tables."""
    return [(c, sorted((k, "nan" if isinstance(v, float) and math.isnan(v) else v) for k, v in dict(t).items()))
            for c, t in tables.items()]


def _clean(value):
    """The value with every NaN replaced by the text "nan" (NaN is not equal to itself)."""
    if isinstance(value, dict):
        return {k: _clean(v) for k, v in value.items()}
    return "nan" if isinstance(value, float) and math.isnan(value) else value


def _lines(caplog):
    return sorted(r.getMessage() for r in caplog.records if r.name.startswith(("pre_milp.nx_sensitivity", "pre_milp.sensitivity_checks")))


def _same(one, other):
    assert _plain(one.pst) == _plain(other.pst)
    assert _plain(one.rd) == _plain(other.rd)
    assert _plain(other.hvdc["sensitivity"]) == _plain(one.hvdc["sensitivity"])
    assert other.hvdc["zero_units"] == one.hvdc["zero_units"] and other.hvdc["guard"] == one.hvdc["guard"]
    assert other.guards == one.guards and list(other.guards["pst"]) == list(one.guards["pst"])
    assert _clean(other.references) == _clean(one.references)
    assert {c: dict(v) for c, v in other.lf_nx.items()} == {c: dict(v) for c, v in one.lf_nx.items()}
    assert (other.lf_nx.dropped, other.lf_nx.guard_dropped) == (one.lf_nx.dropped, one.lf_nx.guard_dropped)


# ---- the equality with one analysis ---------------------------------------------------------------------------------

@pytest.mark.parametrize("batch_size", [1, 2, 3, 5, 99])
def test_rao_batches_give_the_result_of_one_analysis(monkeypatch, batch_size):
    case = _case(monkeypatch)
    whole = _run(case, None)
    batched = _run(case, batch_size)
    _same(whole, batched)
    assert list(batched.pst) == list(whole.pst) and list(batched.rd) == list(whole.rd) and len(whole.pst) == len(CONTINGENCIES)
    main_runs = batched.runs[0::2]                                       # per batch: the analysis of the units, then the countertrade one
    assert batched.runs[1::2] == main_runs
    assert sum(len(run) for run in main_runs) == len(CONTINGENCIES)                         # every contingency once
    assert len(main_runs) == math.ceil(len(CONTINGENCIES) / batch_size) and max(len(r) for r in main_runs) <= batch_size
    assert len(whole.runs) == 2 and sorted(whole.runs[0]) == sorted(CONTINGENCIES)


def test_rao_the_test_case_has_guard_drops_invalid_contingencies_nan_and_pruned_entries(monkeypatch):
    case = _case(monkeypatch)
    whole = _run(case, None, pruned=True)
    assert whole.lf_nx.guard_dropped, "no pair dropped by the guard"
    assert set(whole.guards["pst"]) == {"co-4"} and not whole.guards["rd"]
    assert any(v == "nan" for _c, items in _plain(whole.rd) for _k, v in items)
    unpruned = _run(case, None)
    for kept, all_entries in ((whole.pst, unpruned.pst), (whole.rd, unpruned.rd)):
        assert 0 < sum(len(dict(t)) for t in kept.values()) < sum(len(dict(t)) for t in all_entries.values())


def test_rao_the_pairs_dropped_by_the_guard_are_left_out_of_the_rd_and_hvdc_tables_as_in_one_analysis(monkeypatch):
    # the PST guard runs before the RD and HVDC tables are read: a dropped pair has no entry there
    for batch_size in (None, 1, 2):
        run = _run(_case(monkeypatch), batch_size)
        assert ("b2", "g1") not in dict(run.rd["co-2"]) and ("b3", "g1") not in dict(run.rd["co-3"])
        assert ("b2", "e1") not in dict(run.hvdc["sensitivity"]["co-2"])
        assert ("b1", "g1") in dict(run.rd["co-2"])


def test_rao_the_threshold_lines_the_guard_summary_and_the_coverage_line_are_the_same(monkeypatch, caplog):
    case = _case(monkeypatch)
    with caplog.at_level(logging.INFO):
        whole = _run(case, None, pruned=True)
    whole_lines = _lines(caplog)
    caplog.clear()
    with caplog.at_level(logging.INFO):
        batched = _run(case, 2, pruned=True)
    assert _lines(caplog) == whole_lines
    assert any("kept" in line and "dropped" in line for line in whole_lines)
    guard_lines = [line for line in whole_lines if "SENSITIVITY GUARD (N-X" in line]
    assert len(guard_lines) == 2                                      # one summary per cause, not one per batch
    assert any("co-2/b2" in line for line in guard_lines) and any("co-3/b3" in line for line in guard_lines)
    assert sensitivity_checks.guard_share_error(whole.lf_nx, 1.0) == sensitivity_checks.guard_share_error(batched.lf_nx, 1.0)


def test_rao_when_every_contingency_has_no_valid_branch_all_are_invalid_and_no_pair_is_dropped(monkeypatch):
    def no_reference(references):
        for per_branch in references.values():
            per_branch.update({b: float("nan") for b in BRANCHES})

    case = _case(monkeypatch, no_reference, all_zero_pst_contingency=None)
    whole = _run(case, None)
    batched = _run(case, 2)
    assert set(whole.guards["pst"]) == set(CONTINGENCIES) == set(batched.guards["pst"])
    assert set(whole.guards["pst"].values()) == {sensitivity_checks.NO_VALID_BRANCH}
    assert whole.guards == batched.guards
    assert {c: dict(v) for c, v in batched.lf_nx.items()} == {c: dict(v) for c, v in _lf_nx().items()} and not batched.lf_nx.guard_dropped


def test_rao_the_standalone_functions_take_the_batch_size_too(monkeypatch):
    case = _case(monkeypatch)
    lf_initial = {b: {1: 50.0} for b in BRANCHES}
    results = {}
    for size in (None, 2):
        case.fake.runs.clear()
        pst = nx_sensitivity.compute_sensitivity_pst_nx(
            case.network, case.contingencies, case.pst_list, case.ae_flat_list, TS, _lf_nx(), lf_initial, contingency_batch_size=size)
        results[size] = (_plain(pst), len(case.fake.runs))
    assert results[None][0] == results[2][0] and (results[None][1], results[2][1]) == (1, 3)      # one analysis; three batches
    assert len(results[None][0]) == 5 and all(items for _c, items in results[None][0])


def test_rao_a_batch_size_below_one_is_rejected(monkeypatch):
    case = _case(monkeypatch)
    with pytest.raises(ValueError, match="contingency_batch_size"):
        _run(case, 0)


# ---- the mock network: a real analysis ------------------------------------------------------------------------------

def test_rao_a_real_analysis_in_batches_gives_the_values_of_one_analysis():
    from helpers import _MOCK_NX_CGM_ZIP
    from mock_builders.hvdc_mock import EI_SD_BO3, EI_SD_EH1
    network = cgmes_loader.load_cgm(_MOCK_NX_CGM_ZIP)
    cgmes_loader.run_initial_loadflow(network, run_pipeline.USE_REACTIVE_LIMITS, run_pipeline.EXTRA_LF_PARAMS)
    lf_initial = cgmes_loader.build_lf_initial(network)
    branches = sorted(b for b, sides in lf_initial.items() if all(v == v for v in sides.values()))
    ae_flat_list = [AssessedElement(mrid=f"AE-{b}", name=b, tso="T", ae_type=AEType.SECURED, branch_mrid=b, secured_for_region=None,
                                    scanned_for_region=None, exclusion_reason=None, patl_ka={TS: 100.0}, branch_side=1) for b in branches]
    contingencies = [Contingency(mrid=co, name=co, tso="T", contingency_type=ContingencyType.ORDINARY, must_study={TS: True},
                                 equipment_mrids=[co], equipment_types=["line"])
                     for co in ("7e253493-0bb4-4306-95b3-374075834b98", "b85e5fb8-7e2b-4264-a059-edab9a838116",
                                "d9622e7f-5bf0-4e7e-b766-b8596c6fe4ae")]
    units = [str(g) for g in network.get_generators().index[:3]] + [EI_SD_EH1]
    rd_list = [RDUnit(mrid=f"RD_{i}", name=g, tso="T", gu_mrid=g, gu_name=g, available=True, kind=RAKind.CURATIVE, initial_p=100.0,
                      max_p=400.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None) for i, g in enumerate(units)]
    from pre_milp.nx_security_analysis import compute_lf_nx
    lf_nx, _ = compute_lf_nx(network, contingencies, ae_flat_list, TS, lf_initial=lf_initial,
                             use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS)

    def run(size):
        hvdc_out = {}
        _pst, rd = nx_sensitivity.compute_sensitivities_nx(
            network, contingencies, [], rd_list, ae_flat_list, TS, copy.deepcopy(lf_nx), lf_initial, with_pst=False,
            use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
            hvdc_ei_mrids=[EI_SD_EH1, EI_SD_BO3], hvdc_out=hvdc_out, contingency_batch_size=size)
        return rd, hvdc_out

    whole, whole_hvdc = run(None)
    batched, batched_hvdc = run(1)
    assert list(whole) == list(batched)
    for tables, other in ((whole, batched), (whole_hvdc["sensitivity"], batched_hvdc["sensitivity"])):
        checked = 0
        for contingency in tables:
            assert set(dict(tables[contingency])) == set(dict(other[contingency]))
            for key, value in dict(tables[contingency]).items():
                got = dict(other[contingency])[key]
                assert (value != value and got != got) or got == pytest.approx(value, rel=1e-8, abs=1e-9)
                checked += 1
        assert checked > 30


# ---- the config key ---------------------------------------------------------------------------------------------------

def _config(name="rao_config.yaml"):
    return yaml.safe_load((CONFIG_DIR / name).read_text(encoding="utf-8"))


@pytest.mark.parametrize("name", ["rao_config.yaml", "rao_config.default.yaml"])
def test_rao_both_config_files_have_the_batch_size(name):
    value = _config(name)["nx_sensitivity"]["contingency_batch_size"]
    assert isinstance(value, int) and value >= 1
    assert _config("rao_config.yaml")["nx_sensitivity"] == _config("rao_config.default.yaml")["nx_sensitivity"]


@pytest.mark.parametrize("value", [0, -3, 1.5, "all", True, None])
def test_rao_the_batch_size_is_validated(value):
    config = _config()
    config["nx_sensitivity"]["contingency_batch_size"] = value
    with pytest.raises(ValueError, match="nx_sensitivity.contingency_batch_size"):
        run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))


def test_rao_a_missing_batch_size_key_is_a_config_key_error():
    config = _config()
    del config["nx_sensitivity"]
    with pytest.raises(run_pipeline.ConfigKeyError, match="nx_sensitivity.contingency_batch_size"):
        run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))


def test_rao_the_pipeline_passes_the_configured_batch_size_to_both_analyses(monkeypatch):
    assert run_pipeline.NX_SENSITIVITY_CONTINGENCY_BATCH_SIZE == _config()["nx_sensitivity"]["contingency_batch_size"]
    source = (Path(run_pipeline.__file__)).read_text(encoding="utf-8")
    assert source.count("contingency_batch_size=NX_SENSITIVITY_CONTINGENCY_BATCH_SIZE") == 2      # the first and the refreshed analysis

