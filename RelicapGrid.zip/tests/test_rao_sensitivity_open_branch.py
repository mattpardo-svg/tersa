"""tests/test_rao_sensitivity_open_branch.py - a monitored branch that is open at one end has a load-flow current but no
reference current in the sensitivity analysis, in every state. It is dropped for its pairs; it must not stop the run.
Real pypowsybl, a small synthetic network (a tie line is opened at one end)."""

import math

import pytest

pp = pytest.importorskip("pypowsybl")
import pandas as pd  # noqa: E402

from data_model import AEType, AssessedElement, Contingency, ContingencyType, PST, RAKind  # noqa: E402
from pre_milp import n0_sensitivity, nx_security_analysis, nx_sensitivity  # noqa: E402

TIME = "1030Z"
OPEN_BRANCH = "NHV1_NHV2_1"
OTHER_BRANCH = "NGEN_NHV1"


def _network_with_an_open_tie_line():
    network = pp.network.create_eurostag_tutorial_example1_with_tie_lines_and_areas()
    transformers = list(network.get_2_windings_transformers().index)
    phase_changers = pd.DataFrame(
        index=pd.Series(name="id", data=transformers),
        columns=["target_deadband", "regulation_mode", "low_tap", "tap"], data=[[0, "CURRENT_LIMITER", 0, 1]] * len(transformers))
    steps = pd.DataFrame(
        index=pd.Series(name="id", data=[t for t in transformers for _ in range(3)]),
        columns=["b", "g", "r", "x", "rho", "alpha"], data=[[0, 0, 0, 0, 1, a] for _ in transformers for a in (-5, 0, 5)])
    network.create_phase_tap_changers(phase_changers, steps)
    network.update_dangling_lines(id="XNODE1_NHV2", connected=False)         # the tie line is open at its second end
    return network


def _elements():
    return [
        AssessedElement(mrid=f"ae-{branch}", name=branch, tso="T", ae_type=AEType.SECURED, branch_mrid=branch,
                        secured_for_region=None, scanned_for_region=None, exclusion_reason=None, patl_ka={TIME: 50.0}, branch_side=1)
        for branch in (OPEN_BRANCH, OTHER_BRANCH)
    ]


def _psts():
    return [PST(mrid=OTHER_BRANCH, name=OTHER_BRANCH, tso="T", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0,
                low_step=-1, high_step=1, r0=0, operating_tap_min=-1, operating_tap_max=1, group_id=None)]


def _contingencies():
    return [Contingency(mrid="co-load-transformer", name="co", tso="T", contingency_type=ContingencyType.ORDINARY,
                        must_study={TIME: True}, equipment_mrids=["NHV2_NLOAD"])]


LF_INITIAL = {OPEN_BRANCH: {1: 100.0, 2: 100.0}, OTHER_BRANCH: {1: 15000.0, 2: 15000.0}}


def test_n_x_the_open_branch_is_dropped_for_its_pair_and_the_contingency_stays_valid():
    network, elements = _network_with_an_open_tie_line(), _elements()
    lf_nx, _skipped = nx_security_analysis.compute_lf_nx(network, _contingencies(), elements, TIME, lf_initial=LF_INITIAL)
    current = lf_nx["co-load-transformer"][OPEN_BRANCH][1]
    assert not math.isnan(current) and current > 1.0           # the security analysis does give a current
    guard = {}
    sensitivities = nx_sensitivity.compute_sensitivity_pst_nx(
        network, _contingencies(), _psts(), elements, TIME, lf_nx, LF_INITIAL, guard_out=guard)
    assert guard == {}
    assert OPEN_BRANCH not in lf_nx["co-load-transformer"] and OTHER_BRANCH in lf_nx["co-load-transformer"]
    assert lf_nx.dropped["co-load-transformer"] == [OPEN_BRANCH]
    assert sensitivities["co-load-transformer"]


def test_n_0_the_open_branch_is_dropped_and_the_guard_is_clear():
    network, elements = _network_with_an_open_tie_line(), _elements()
    guard = {}
    pp.loadflow.run_ac(network)
    current = float(network.get_2_windings_transformers().loc[OTHER_BRANCH, "i1"])
    lf_initial = {OPEN_BRANCH: {1: 89.0, 2: 0.0}, OTHER_BRANCH: {1: current, 2: current}}      # the open end still has a current
    sensitivity = n0_sensitivity.compute_sensitivity_pst_n0(
        network, _psts(), elements, TIME, lf_initial=lf_initial, guard_out=guard)
    assert guard == {}
    assert all(math.isnan(value) for (branch, _pst), value in sensitivity.items() if branch == OPEN_BRANCH)
    assert not any(math.isnan(value) for (branch, _pst), value in sensitivity.items() if branch == OTHER_BRANCH)
