"""
tests/test_rao_ncp_legacy_namespaces.py - the NCP 2.2 legacy form (docs/specs/ncp_data_requirements.md section 13):
the header fields are read by local name whatever their namespace URI, and every place that reads CGM XML directly accepts
the CGMES 3.0 and the CGMES 2.4.15 (cim16) namespaces and both forms of the entsoe extension namespace.
"""
import logging

import pytest

from mock_builders import legacy_writer as legacy_form
from pre_milp import cgmes_loader, ct_units, eq_stream, ncp_header, ncp_loader, ncp_parser, tso_name_resolver

EIC = "10X-MOCK-TSO---A"
CIM16 = "http://iec.ch/TC57/2013/CIM-schema-cim16#"
HEADER = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <md:FullModel xmlns:md="http://iec.ch/TC57/61970-552/ModelDescription/1#" xmlns:dcat="{dcat}" xmlns:dcterms="{dcterms}" xmlns:dc="{dc}" rdf:about="urn:uuid:00000000-0000-4000-8000-000000000001">
    <{prefix}:creator>http://energy.referencedata.eu/EIC/{eic}</{prefix}:creator>
    <dcterms:conformsTo rdf:resource="http://entsoe.eu/ns/CIM/RemedialAction-EU/2.2"/>
    {keyword}
  </md:FullModel>
</rdf:RDF>
"""


def _header_file(path, dcterms, dc="http://purl.org/dc/elements/1.1/#", prefix="dcterms", dcat="http://www.w3.org/ns/dcat#", keyword="<dcat:keyword>RA</dcat:keyword>"):
    path.write_text(HEADER.format(dcterms=dcterms, dc=dc, dcat=dcat, prefix=prefix, eic=EIC, keyword=keyword), encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# cause 1: header namespaces with a trailing "#"
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("dcterms", ["http://purl.org/dc/terms/#", "http://purl.org/dc/terms/", "http://example.invalid/own/"])
@pytest.mark.parametrize("prefix", ["dcterms", "dc"])
def test_rao_header_fields_are_read_by_local_name_whatever_the_namespace(tmp_path, dcterms, prefix):
    path = _header_file(tmp_path / "a.xml", dcterms, prefix=prefix)
    assert ncp_header.read_header(path) == ncp_header.NcpHeader(profile="RA", creator=EIC)


def test_rao_header_keyword_in_a_namespace_with_a_trailing_hash_is_read(tmp_path):
    path = _header_file(tmp_path / "a.xml", "http://purl.org/dc/terms/#", dcat="http://www.w3.org/ns/dcat/#")
    assert ncp_header.read_header(path).profile == "RA"


def test_rao_header_conforms_to_as_text_names_the_profile_when_there_is_no_keyword(tmp_path):
    path = tmp_path / "a.xml"
    _header_file(path, "http://purl.org/dc/terms/#", keyword="")
    assert ncp_header.read_header(path).profile == "RA"


def test_rao_legacy_mock_headers_declare_their_namespaces_with_a_trailing_hash(tmp_path):
    files = legacy_form.legacy_files()
    assert files
    for name, data in files.items():
        text = data.decode("utf-8")
        assert 'xmlns:dcterms="http://purl.org/dc/terms/#"' in text and 'xmlns:dc="http://purl.org/dc/elements/1.1/#"' in text, name


def test_rao_legacy_mock_files_are_classified_by_creator_and_profile(tmp_path, caplog):
    for name, data in legacy_form.legacy_files().items():
        (tmp_path / name).write_bytes(data)
    with caplog.at_level(logging.WARNING):
        files = ncp_loader.classify_extracted_ncp_files(tmp_path, {}).by_label()
    assert sorted(files) == sorted(legacy_form.EIC_BY_TSO.values())
    assert "no TSO read" not in caplog.text
    for profiles in files.values():
        assert sorted(profiles) == ["AE", "CO", "ER", "RA", "SIS"]


# ---------------------------------------------------------------------------
# cause 2: CGMES 2.4.15 (cim16) in the readers of CGM XML
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def eq_2_4_15(tmp_path_factory):
    path = tmp_path_factory.mktemp("eq_2_4_15") / "20220615T1030Z_1D_10X-MOCK-TSO---A_EQ_001.xml"
    path.write_bytes(legacy_form.eq_snippet_2_4_15())
    return path


def test_rao_the_namespace_list_has_cgmes_3_and_2_4_15_and_both_entsoe_extensions():
    from pre_milp import cgm_namespaces

    assert set(cgm_namespaces.CIM_NAMESPACES) == {"https://cim.ucaiug.io/ns#", "http://iec.ch/TC57/CIM100#", CIM16}
    assert set(cgm_namespaces.ENTSOE_NAMESPACES) == {"http://iec.ch/TC57/CIM100-European#", "http://entsoe.eu/CIM/SchemaExtension/3/1#"}


@pytest.mark.parametrize("streamed", [True, False])
def test_rao_tap_changer_and_current_limit_maps_of_a_2_4_15_eq_file(eq_2_4_15, streamed):
    ids = legacy_form.eq_snippet_pst_ids()
    graph = eq_stream.stream_eq(eq_2_4_15) if streamed else ncp_parser._load_graph(eq_2_4_15, cache=False)
    assert graph is not None
    assert ncp_parser.build_tap_changer_to_transformer_map(eq_2_4_15, graph) == {ids["tap_changer"]: ids["transformer"]}
    assert ncp_parser.build_current_limit_side_map(eq_2_4_15, graph) == {ids["limit"]: ids["side"]}


def test_rao_a_2_4_15_eq_file_is_found_and_its_maps_resolve_through_load_eq_graph(eq_2_4_15):
    ids = legacy_form.eq_snippet_pst_ids()
    assert cgmes_loader.find_eq_files(eq_2_4_15.parent) == [eq_2_4_15]
    graph = ncp_parser.load_eq_graph(eq_2_4_15)
    assert ncp_parser.build_tap_changer_to_transformer_map(eq_2_4_15, graph) == {ids["tap_changer"]: ids["transformer"]}


def test_rao_control_area_units_of_a_2_4_15_eq_file(tmp_path, eq_2_4_15):
    text = eq_2_4_15.read_text(encoding="utf-8")
    unit_id = legacy_form.eq_snippet_unit_ids()[0]
    link = (f'  <cim:ControlAreaGeneratingUnit rdf:ID="_link">\n    <cim:ControlAreaGeneratingUnit.ControlArea rdf:resource="#_area"/>\n'
            f'    <cim:ControlAreaGeneratingUnit.GeneratingUnit rdf:resource="#_{unit_id}"/>\n  </cim:ControlAreaGeneratingUnit>\n</rdf:RDF>')
    (tmp_path / "x_EQ_1.xml").write_text(text.replace("</rdf:RDF>", link), encoding="utf-8")
    assert ct_units.read_control_area_units(tmp_path) == {"area": {unit_id}}


def test_rao_substation_regions_of_a_2_4_15_eq_file(tmp_path):
    (tmp_path / "x_EQ_1.xml").write_text(f"""<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:cim="{CIM16}">
  <cim:SubGeographicalRegion rdf:ID="_region"><cim:IdentifiedObject.name>MOCK_REGION</cim:IdentifiedObject.name></cim:SubGeographicalRegion>
  <cim:Substation rdf:ID="_station"><cim:Substation.Region rdf:resource="#_region"/></cim:Substation>
</rdf:RDF>
""", encoding="utf-8")
    substation_to_tso, _ = tso_name_resolver.build_substation_mrid_to_tso(tmp_path)
    assert substation_to_tso == {"station": "MOCK_REGION"}
