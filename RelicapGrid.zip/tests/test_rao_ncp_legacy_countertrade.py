"""
tests/test_rao_ncp_legacy_countertrade.py - the NCP 2.2 legacy form (docs/specs/ncp_data_requirements.md section 13, DECISIONS 167):
L5 any strategy value of a countertrade RA (gLSKStrategy, shiftMethod) is ignored with one warning per RA, the remaining capacity is
always used; L6 without an Organisation file the zone EIC (last segment of PowerRemedialAction.BiddingZone) is matched to the CGM
ControlArea with that entsoe energyIdentCodeEic (CGMES 3.0 and 2.4.15), its units via ControlAreaGeneratingUnit, else all generating
units of the same EQ file.
"""
import logging
import re
import zipfile

import pytest

from mock_builders import standard
from mock_builders import legacy_writer as legacy_form
from data_model import RAKind, CtRa
from helpers import _MOCK_NX_CGM_ZIP, _RA_FOOTER, _RA_HEADER
from pre_milp import cgmes_loader, ct_units
from pre_milp.ct_units import CtGenerator
from test_rao_ct_parser import LOG, STRATEGY, _bid, _ct_ra, _messages, _parse

EQ_HEADER = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:cim="{cim}" xmlns:eu="{eu}">
"""
CIM16, ENTSOE_2_4_15 = "http://iec.ch/TC57/2013/CIM-schema-cim16#", "http://entsoe.eu/CIM/SchemaExtension/3/1#"
CIM100, EU_3_0 = "http://iec.ch/TC57/CIM100#", "http://iec.ch/TC57/CIM100-European#"


# ---------------------------------------------------------------------------
# L5: any strategy value is ignored with one warning per RA
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("strategy", ["explicitInstruction", "proportionalForGenerator", "explicitSchedule", "somethingElse"])
def test_rao_another_strategy_is_ignored_with_one_warning_and_the_ra_is_kept(tmp_path, caplog, strategy):
    ras, bids = _parse(tmp_path, _ct_ra(strategy=strategy), _bid("B", "CT-1", "up"), caplog)
    assert len(ras) == 1 and ras[0].strategy == STRATEGY and len(bids) == 1
    messages = [m for m in _messages(caplog) if "ignored" in m]
    assert len(messages) == 1 and "CT-1" in messages[0] and strategy in messages[0] and "remaining capacity" in messages[0]
    assert not any("IGNORED" in m for m in _messages(caplog))


def test_rao_a_shift_method_is_ignored_in_the_same_warning(tmp_path, caplog):
    extra = '<nc:CountertradeRemedialAction.shiftMethod>MOCK_SHIFT_METHOD</nc:CountertradeRemedialAction.shiftMethod>'
    ras, _ = _parse(tmp_path, _ct_ra(strategy="proportionalForGenerator", extra=extra), _bid("B", "CT-1", "up"), caplog)
    messages = [m for m in _messages(caplog) if "ignored" in m]
    assert len(ras) == 1 and len(messages) == 1 and "proportionalForGenerator" in messages[0] and "MOCK_SHIFT_METHOD" in messages[0]


def test_rao_different_strategies_on_the_ra_and_its_bids_are_ignored_together_not_a_reason_to_drop_the_ra(tmp_path, caplog):
    ras, bids = _parse(tmp_path, _ct_ra(strategy=None),
                       _bid("B1", "CT-1", "up", strategy=STRATEGY) + _bid("B2", "CT-1", "down", strategy="explicitInstruction"), caplog)
    assert len(ras) == 1 and len(bids) == 2
    messages = [m for m in _messages(caplog) if "ignored" in m]
    assert len(messages) == 1 and "explicitInstruction" in messages[0]


def test_rao_a_declared_strategy_and_no_strategy_keep_their_messages(tmp_path, caplog):
    _parse(tmp_path, _ct_ra(), _bid("B", "CT-1", "up"), caplog)
    declared = [m for m in _messages(caplog) if "ignored" in m]
    assert len(declared) == 1 and "gLSKStrategy proportionalForRemainingCapacity" in declared[0]
    caplog.clear()
    _parse(tmp_path, _ct_ra(strategy=None), _bid("B", "CT-1", "up"), caplog)
    assert len([m for m in _messages(caplog) if "assumed" in m]) == 1 and not [m for m in _messages(caplog) if "ignored" in m]


def test_rao_every_countertrade_ra_of_the_legacy_mock_is_kept_with_one_warning_each(tmp_path, caplog):
    for name, data in legacy_form.legacy_files().items():
        (tmp_path / name).write_bytes(data)
    total = 0
    for country in legacy_form.EIC_BY_TSO:
        caplog.clear()
        with caplog.at_level(logging.INFO, logger=LOG):
            ras, _ = ct_units.parse_ct_remedial_actions(tmp_path / legacy_form.file_name(country, "RA"),
                                                        tmp_path / legacy_form.file_name(country, "SIS"), country, "1030Z")
        total += len(ras)
        warnings = [m for m in _messages(caplog) if "ignored" in m]
        assert len(warnings) == len(ras) == 2 and all("shiftMethod" in m for m in warnings)
    assert total == 8


# ---------------------------------------------------------------------------
# L6: the zone EIC to a CGM ControlArea
# ---------------------------------------------------------------------------

def _area(ident, name, eic, cim, eu_namespace=True):
    return (f'  <cim:ControlArea rdf:ID="_{ident}"><cim:IdentifiedObject.name>{name}</cim:IdentifiedObject.name>'
            f'<eu:IdentifiedObject.energyIdentCodeEic>{eic}</eu:IdentifiedObject.energyIdentCodeEic></cim:ControlArea>\n')


def _unit(ident, cls="ThermalGeneratingUnit"):
    return f'  <cim:{cls} rdf:ID="_{ident}"><cim:IdentifiedObject.name>{ident}</cim:IdentifiedObject.name></cim:{cls}>\n'


def _row(ident, area, unit):
    return (f'  <cim:ControlAreaGeneratingUnit rdf:ID="_{ident}"><cim:ControlAreaGeneratingUnit.ControlArea rdf:resource="#_{area}"/>'
            f'<cim:ControlAreaGeneratingUnit.GeneratingUnit rdf:resource="#_{unit}"/></cim:ControlAreaGeneratingUnit>\n')


def _eq(folder, name, body, cim=CIM16, eu=ENTSOE_2_4_15):
    (folder / name).write_text(EQ_HEADER.format(cim=cim, eu=eu) + body + "</rdf:RDF>\n", encoding="utf-8")


def _ra_in(zone_eic, mrid="CT-1"):
    return CtRa(mrid=mrid, name="CT", tso="T", zone_mrid=zone_eic, available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0, strategy=STRATEGY)


def _gen(gu, unit, cls="SynchronousMachine"):
    return CtGenerator(gu_mrid=gu, unit_mrid=unit, name=gu, original_class=cls, prod=50.0, pmin=0.0, pmax=100.0, connected=True, in_main_component=True)


@pytest.mark.parametrize("cim, eu", [(CIM16, ENTSOE_2_4_15), (CIM100, EU_3_0)])
def test_rao_a_zone_eic_is_matched_to_a_control_area_without_control_area_generating_units(tmp_path, cim, eu):
    _eq(tmp_path, "20220615T1030Z_1D_X_EQ_001.xml", _area("CA_A", "AREA_A", "10Y-MOCK-ZONE--A", cim) + _area("CA_B", "AREA_B", "10Y-MOCK-ZONE--B", cim)
        + _unit("U1") + _unit("U2", "HydroGeneratingUnit") + _unit("U3", "WindGeneratingUnit"), cim, eu)
    areas = ct_units.read_control_areas(tmp_path)
    assert set(areas) == {"10Y-MOCK-ZONE--A", "10Y-MOCK-ZONE--B"} and areas["10Y-MOCK-ZONE--A"].name == "AREA_A"
    zones, area_units = ct_units.zones_from_control_areas([_ra_in("10Y-MOCK-ZONE--A")], tmp_path, {})
    assert list(zones) == ["10Y-MOCK-ZONE--A"] and zones["10Y-MOCK-ZONE--A"].control_area_mrids == ["CA_A"]
    assert area_units["CA_A"] == {"U1", "U2", "U3"}                        # all generating units of the same EQ file


def test_rao_control_area_generating_units_win_over_the_whole_file(tmp_path):
    _eq(tmp_path, "x_EQ_1.xml", _area("CA_A", "AREA_A", "10Y-MOCK-ZONE--A", CIM16) + _area("CA_B", "AREA_B", "10Y-MOCK-ZONE--B", CIM16)
        + _unit("U1") + _unit("U2") + _unit("U3") + _row("R1", "CA_A", "U1"))
    area_units = ct_units.read_control_area_units(tmp_path)
    zones, units = ct_units.zones_from_control_areas([_ra_in("10Y-MOCK-ZONE--A"), _ra_in("10Y-MOCK-ZONE--B", "CT-2")], tmp_path, area_units)
    assert units["CA_A"] == {"U1"} and units["CA_B"] == {"U1", "U2", "U3"}        # B has no row: the file


def test_rao_the_resolved_units_leave_out_equivalent_injections_and_external_grids(tmp_path):
    _eq(tmp_path, "x_EQ_1.xml", _area("CA_A", "AREA_A", "10Y-MOCK-ZONE--A", CIM16) + _unit("U1") + _unit("U2") + _unit("U3"))
    zones, area_units = ct_units.zones_from_control_areas([_ra_in("10Y-MOCK-ZONE--A")], tmp_path, {})
    generators = {"G1": _gen("G1", "U1"), "G2": _gen("G2", "U2", "EquivalentInjection"), "G3": _gen("G3", "U3", "ExternalNetworkInjection")}
    kept, units_by_zone = ct_units.resolve_zone_units([_ra_in("10Y-MOCK-ZONE--A")], zones, area_units, generators,
                                                      zone_source="the CGM ControlAreas")
    assert [ra.mrid for ra in kept] == ["CT-1"] and [u.gu_mrid for u in units_by_zone["10Y-MOCK-ZONE--A"]] == ["G1"]


def test_rao_a_zone_eic_without_a_control_area_drops_the_ra_with_the_reason(tmp_path, caplog):
    _eq(tmp_path, "x_EQ_1.xml", _area("CA_A", "AREA_A", "10Y-MOCK-ZONE--A", CIM16) + _unit("U1"))
    zones, area_units = ct_units.zones_from_control_areas([_ra_in("10Y-MOCK-ZONE--Z")], tmp_path, {})
    assert zones == {}
    with caplog.at_level(logging.WARNING, logger=LOG):
        kept, _ = ct_units.resolve_zone_units([_ra_in("10Y-MOCK-ZONE--Z")], zones, area_units, {"G1": _gen("G1", "U1")},
                                              zone_source="the CGM ControlAreas")
    assert kept == []
    messages = _messages(caplog)
    assert len(messages) == 1 and "DROPPED" in messages[0] and "10Y-MOCK-ZONE--Z" in messages[0] and "not in the CGM ControlAreas" in messages[0]


def test_rao_the_chain_with_an_organisation_file_is_unchanged(caplog):
    zones = {"ZONE-1": ct_units.CtZone("ZONE-1", "BZ-One", ["CA-1"])}
    with caplog.at_level(logging.WARNING, logger=LOG):
        kept, _ = ct_units.resolve_zone_units([_ra_in("ZONE-9")], zones, {"CA-1": {"U1"}}, {"G1": _gen("G1", "U1")})
    assert kept == [] and "not in the Organisation profile" in _messages(caplog)[0]


# ---------------------------------------------------------------------------
# the legacy mock against the Organisation-file chain of the current mock
# ---------------------------------------------------------------------------

def _cgm_with_zone_eics(path):
    """The mock CGM with the legacy zone EIC on the ControlArea of each TSO (the mock areas have none)."""
    eic_of_area = {c: legacy_form.ZONE_EIC_BY_TSO[c] for c in legacy_form.EIC_BY_TSO}
    with zipfile.ZipFile(_MOCK_NX_CGM_ZIP) as source, zipfile.ZipFile(path, "w") as target:
        for name in source.namelist():
            data = source.read(name)
            if "_EQ_" in name:
                text = data.decode("utf-8")
                for country, eic in eic_of_area.items():
                    text = re.sub(rf'(<cim:ControlArea rdf:ID="[^"]+">(?:(?!</cim:ControlArea>).)*?<cim:IdentifiedObject.name>{country}</cim:IdentifiedObject.name>)',
                                  rf"\1<eu:IdentifiedObject.energyIdentCodeEic>{eic}</eu:IdentifiedObject.energyIdentCodeEic>", text, flags=re.S)
                data = text.encode("utf-8")
            target.writestr(name, data)
    return path


def test_rao_the_legacy_mock_gets_the_same_units_per_ra_as_the_organisation_file_chain(tmp_path):
    from pre_milp import ncp_parser

    cgm = _cgm_with_zone_eics(tmp_path / "cgm_eic.zip")
    extract = tmp_path / "cgm"
    cgmes_loader.extract_cgm_zip(cgm, extract)
    network = cgmes_loader.load_cgm(cgm)
    generators = ct_units.read_generator_table(network)
    area_units = ct_units.read_control_area_units(extract)
    current, legacy = tmp_path / "current", tmp_path / "legacy"
    for folder, files in ((current, standard.shipped_files()), (legacy, legacy_form.legacy_files())):
        folder.mkdir()
        for name, data in files.items():
            (folder / name).write_bytes(data)
    ras_current, ras_legacy = [], []
    for country in legacy_form.EIC_BY_TSO:
        ras_current += ct_units.parse_ct_remedial_actions(current / f"{country}_RA.xml", current / f"{country}_SIS.xml", country, "1030Z")[0]
        ras_legacy += ct_units.parse_ct_remedial_actions(legacy / legacy_form.file_name(country, "RA"), legacy / legacy_form.file_name(country, "SIS"),
                                                         country, "1030Z")[0]
    zones_current = ct_units.parse_bidding_zones(current / "Org-NineRealms_CD.xml")
    kept_current, by_zone_current = ct_units.resolve_zone_units(ras_current, zones_current, area_units, generators)
    zones_legacy, units_legacy = ct_units.zones_from_control_areas(ras_legacy, extract, area_units)
    kept_legacy, by_zone_legacy = ct_units.resolve_zone_units(ras_legacy, zones_legacy, units_legacy, generators, zone_source="the CGM ControlAreas")
    assert len(kept_current) == len(kept_legacy) == 8
    units_of = lambda kept, by_zone: {ra.mrid: [u.gu_mrid for u in by_zone[ra.zone_mrid]] for ra in kept}      # noqa: E731
    assert units_of(kept_legacy, by_zone_legacy) == units_of(kept_current, by_zone_current)
