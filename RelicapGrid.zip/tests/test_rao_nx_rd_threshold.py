"""tests/test_rao_nx_rd_threshold.py - the N-X redispatch and countertrade sensitivity threshold (sensitivity_threshold_pct_rd_nx,
percent of the branch limit per 100 MW), applied while the sensitivities are read, one contingency at a time."""

import logging
import re
import sys

import pandas as pd
import pytest

from data_model import AEType, AssessedElement, Contingency, ContingencyType, RAKind, RDUnit
from pre_milp import nx_sensitivity
from pre_milp.nx_sensitivity import compute_ct_nx, compute_sensitivity_rd_nx
from helpers import run_pipeline_on_fixture_inputs, _MOCK_NX_NCP_ZIP
from test_rao_nx_pst_threshold import (
    _FakePypowsybl, _assessed_element, _contingency, _no_guard_drops,  # noqa: F401 (the fixture applies to this module)
)


def _rd_unit(unit):
    return RDUnit(mrid=f"ra-{unit}", name=unit, tso="TSO", gu_mrid=unit, gu_name=unit, available=True, kind=RAKind.PREVENTIVE,
                  initial_p=0.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None)


def _case(monkeypatch):
    """Two branches (limit 1000 A), two units, two contingencies; values in A per MW."""
    matrices = {
        ("nx_side1", "co-1"): pd.DataFrame([[0.05, 0.2], [-0.5, 0.01]], index=["gu-1", "gu-2"], columns=["b1", "b2"]),
        ("nx_side1", "co-2"): pd.DataFrame([[0.5, 0.11], [0.09, 0.4]], index=["gu-1", "gu-2"], columns=["b1", "b2"]),
    }
    monkeypatch.setitem(sys.modules, "pypowsybl", _FakePypowsybl(matrices))
    return dict(
        co_flat_list=[_contingency("co-1"), _contingency("co-2")], rd_list=[_rd_unit("gu-1"), _rd_unit("gu-2")],
        ae_flat_list=[_assessed_element("b1", 1.0), _assessed_element("b2", 1.0)], timestamp="1030Z",
        lf_nx={c: {"b1": {1: 100.0}, "b2": {1: 100.0}} for c in ("co-1", "co-2")},
        lf_initial={"b1": {1: 50.0}, "b2": {1: 50.0}},
    )


def _compute(case, **extra):
    return compute_sensitivity_rd_nx(
        object(), case["co_flat_list"], case["rd_list"], case["ae_flat_list"], case["timestamp"],
        lf_nx=case["lf_nx"], lf_initial=case["lf_initial"], **extra)


def test_rao_a_threshold_drops_the_entries_below_the_percent_of_the_limit_per_100_mw(monkeypatch):
    """1 % of 1000 A = 10 A per 100 MW = 0.1 A per MW: 0.05, 0.01, 0.09 go; 0.2, -0.5, 0.5, 0.11, 0.4 stay."""
    result = _compute(_case(monkeypatch), sensitivity_threshold_pct_rd_nx=1.0)
    assert dict(result["co-1"]) == {("b2", "gu-1"): 0.2, ("b1", "gu-2"): -0.5}
    assert dict(result["co-2"]) == {("b1", "gu-1"): 0.5, ("b2", "gu-1"): 0.11, ("b2", "gu-2"): 0.4}


def test_rao_the_default_threshold_drops_nothing(monkeypatch):
    result = _compute(_case(monkeypatch))
    assert len(result["co-1"]) == 4 and len(result["co-2"]) == 4


def test_rao_the_threshold_is_applied_one_contingency_at_a_time(monkeypatch):
    calls = []
    original = nx_sensitivity._prune_by_magnitude

    def recording(sensitivity, *args, **kwargs):
        calls.append(sorted(sensitivity))
        return original(sensitivity, *args, **kwargs)
    monkeypatch.setattr(nx_sensitivity, "_prune_by_magnitude", recording)
    _compute(_case(monkeypatch), sensitivity_threshold_pct_rd_nx=1.0)
    assert calls == [["co-1"], ["co-2"]]


def test_rao_the_log_gives_the_entries_kept_dropped_and_the_threshold(monkeypatch, caplog):
    with caplog.at_level(logging.INFO):
        _compute(_case(monkeypatch), sensitivity_threshold_pct_rd_nx=1.0)
    lines = [r.getMessage() for r in caplog.records if "N-X RD sensitivity threshold" in r.getMessage()]
    assert len(lines) == 1 and "kept 5, dropped 3" in lines[0] and "1 %" in lines[0] and "per 100 MW" in lines[0]


def test_rao_the_countertrade_units_are_pruned_per_unit_before_the_sum(monkeypatch):
    """Variable ct-v = 0.5 x u1 + 0.5 x u2; u1 has 0.05 A per MW on b1 (below 0.1), u2 has 0.5: the sum is 0.25, not 0.275."""
    matrices = {("nx_ct_side1", "co-1"): pd.DataFrame([[0.05], [0.5]], index=["u1", "u2"], columns=["b1"])}
    monkeypatch.setitem(sys.modules, "pypowsybl", _FakePypowsybl(matrices))
    weights = {"ct-v": {"u1": 0.5, "u2": 0.5}}
    contingencies, sides = [_contingency("co-1")], {"b1": 1}
    plain, _ = compute_ct_nx(object(), contingencies, sides, weights)
    pruned, _ = compute_ct_nx(object(), contingencies, sides, weights, prune_limits={"b1": 1000.0}, prune_threshold_pct=1.0)
    assert plain["co-1"][1][2][0][0] == pytest.approx(0.275)
    assert pruned["co-1"][1][2][0][0] == pytest.approx(0.25)


@pytest.mark.parametrize("mode", ["ac_single_pass", "ac_iterative"])
def test_rao_the_threshold_applies_in_every_calculation_mode(mode, tmp_path, caplog):
    """On the shipped mock a threshold of 0.01 % of the limit per 100 MW drops some entries and keeps others, in both modes."""
    def customize(rp, patcher):
        patcher.setattr(rp, "SENSITIVITY_THRESHOLD_PCT_RD_NX", 0.5)
    with caplog.at_level(logging.INFO):
        run_pipeline_on_fixture_inputs(tmp_path, _MOCK_NX_NCP_ZIP, True, customize_pipeline=customize,
                                       ra_types=("pst", "rd"), calculation_mode=mode)
    lines = [r.getMessage() for r in caplog.records if "N-X RD sensitivity threshold" in r.getMessage()]
    assert lines, "no summary line"
    kept, dropped = map(int, re.search(r"kept (\d+), dropped (\d+)", lines[0]).groups())
    assert kept > 0 and dropped > 0, lines[0]
