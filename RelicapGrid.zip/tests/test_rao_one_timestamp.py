"""
tests/test_rao_one_timestamp.py - the run optimises one timestamp, the CGM scenario time (DECISIONS 172): no timestamp
list, no per-timeframe RA-count limit, one row per element in the outputs, and the lead-time column of
results_lead_times.csv reports the run timestamp when the bid is usable at run time, blank otherwise.
"""
import csv
import inspect
import logging
import zipfile

import pytest

from data_model import AcVerificationStatus, AEType, AssessedElement, BidDirection, PowerBid
from helpers import _MOCK_NX_NCP_ZIP
from milp import milp_builder
from milp.milp_builder import RdMilpInputs, _timestamp_is_usable
from pre_milp import ncp_loader, ncp_parser, scanned_elements
from post_milp import n0_results_export

TS = "1030Z"


# ---------------------------------------------------------------------------
# no timestamp list, no per-timeframe limit
# ---------------------------------------------------------------------------

def test_the_per_timeframe_ra_count_limit_is_gone():
    import run_pipeline
    assert not hasattr(run_pipeline, "MAX_RA_COUNT_PER_TIMEFRAME_TSO")
    assert "max_ra_count_per_timeframe_tso" not in {f for f in RdMilpInputs.__dataclass_fields__}
    for name in ("rao_config.yaml", "rao_config.default.yaml"):
        text = (run_pipeline.RAO_CONFIG_PATH.parent / name).read_text(encoding="utf-8")
        assert "timeframe" not in text, name


def test_a_removed_config_key_with_a_value_gives_one_warning_and_a_null_or_absent_one_none(caplog):
    import run_pipeline
    with caplog.at_level(logging.WARNING):
        run_pipeline.warn_removed_config_keys({"ra_limits": {"max_ra_count_per_timeframe_tso": None}})
        run_pipeline.warn_removed_config_keys({"ra_limits": {}})
        run_pipeline.warn_removed_config_keys({})
        assert [r for r in caplog.records if "no longer used" in r.getMessage()] == []
        run_pipeline.warn_removed_config_keys({"ra_limits": {"max_ra_count_per_timeframe_tso": {"TSO-A": 3}}})
    messages = [r.getMessage() for r in caplog.records if "no longer used, ignored" in r.getMessage()]
    assert len(messages) == 1 and "ra_limits.max_ra_count_per_timeframe_tso" in messages[0]


# ---------------------------------------------------------------------------
# one timestamp in the readers and the outputs
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def mock_files(tmp_path_factory):
    folder = tmp_path_factory.mktemp("one_timestamp")
    with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as archive:
        archive.extractall(folder)
    return folder


def test_a_contingency_has_one_must_study_flag_at_the_run_timestamp(mock_files):
    import re
    text = (mock_files / "Belgovia_CO.xml").read_text(encoding="utf-8")
    equipment = {mrid: "line" for mrid in re.findall(r'ContingencyEquipment\.Equipment rdf:resource="#_?([^"]+)"', text)}
    contingencies = ncp_parser.parse_contingencies(mock_files / "Belgovia_CO.xml", "TSO-Belgovia", TS, equipment)
    assert contingencies and all(list(c.must_study) == [TS] for c in contingencies)


def test_a_bid_has_its_volume_at_the_run_timestamp_only(mock_files):
    graph = ncp_parser._load_graph(mock_files / "Belgovia_SIS.xml")
    ras = {ncp_parser._frag(str(s)) for s in graph.objects(None, ncp_parser.NC["PowerBidSchedule.PowerRemedialAction"])}
    bids = ncp_parser.parse_power_bids(graph, ras, "TSO-Belgovia", TS)
    assert bids and all(list(b.available_mw) == [TS] for b in bids)


def _scanned_element():
    return AssessedElement(mrid="AE1", name="AE1", tso="T", ae_type=AEType.SCANNED, branch_mrid="B1", secured_for_region=None,
                           scanned_for_region=None, exclusion_reason=None, patl_ka={TS: 1.0}, branch_side=1)


# ---------------------------------------------------------------------------
# lead time: the run timestamp when usable, blank otherwise
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("lead_hours, expected", [(0.0, "1030Z"), (0.5, "1030Z"), (0.99, "1030Z"), (1.0, None), (3.0, None)])
def test_a_bid_is_usable_at_the_run_timestamp_when_its_lead_time_is_shorter_than_the_distance(lead_hours, expected):
    assert _timestamp_is_usable("0930Z", lead_hours, TS) is (expected is not None)             # decision point one hour before

