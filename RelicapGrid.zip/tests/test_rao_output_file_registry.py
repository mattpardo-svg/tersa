"""tests/test_rao_output_file_registry.py - the registry of output file names.

A writer that produces a file that is not registered fails a test (here and in test_rao_output_files.py).
"""

import ast
import re
from pathlib import Path

from output_file_registry import OUTPUT_FILE_REGISTRY
from text_encoding import TEXT_ENCODING

REPO_ROOT = Path(__file__).resolve().parents[1]


def test_registry_has_no_duplicates_and_only_lower_case_names():
    assert len(OUTPUT_FILE_REGISTRY) == len(set(OUTPUT_FILE_REGISTRY))
    for name in OUTPUT_FILE_REGISTRY:
        assert re.fullmatch(r"[a-z0-9]+(_[a-z0-9]+)*\.(csv|txt)", name), name
        assert not name.startswith("results_"), name


def test_registry_lists_the_17_files_the_six_sensitivity_files_and_the_log():
    sensitivity = [n for n in OUTPUT_FILE_REGISTRY if n.startswith("sensitivity_")]
    assert len(sensitivity) == 6
    assert len([n for n in OUTPUT_FILE_REGISTRY if n.endswith(".csv")]) - len(sensitivity) == 17
    assert "run_log.txt" in OUTPUT_FILE_REGISTRY


def test_every_output_file_name_literal_in_the_source_is_registered():
    """Static guard for writers a pipeline run does not reach: every string literal in src that looks like a csv/txt
    file name is a registered name."""
    allowed = set(OUTPUT_FILE_REGISTRY) | {"run_log_failed.txt"}
    file_name_pattern = re.compile(r"^[A-Za-z0-9_]+\.(csv|txt)$")
    unregistered = []
    for path in sorted((REPO_ROOT / "src" / "rao").rglob("*.py")):
        if path.name == "output_file_registry.py":
            continue
        for node in ast.walk(ast.parse(path.read_text(encoding=TEXT_ENCODING))):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                if file_name_pattern.match(node.value) and node.value not in allowed:
                    unregistered.append(f"{path.relative_to(REPO_ROOT)}:{node.lineno}: {node.value}")
    assert unregistered == []

