"""
tests/test_rao_ncp_legacy_blockers.py - the NCP 2.2 legacy form (docs/specs/ncp_data_requirements.md section 13):
the creator of a header (text or rdf:resource, any EIC base, hyphen padding kept) names the TSO, an unreadable creator is
logged with the file name and the reason, the CGM EQ files are found in sub-folders and nested zips by their header
profile, and the countertrade unit log line stays short.
"""
import logging
import re
import xml.etree.ElementTree as ET
import zipfile

import pytest

from mock_builders import legacy_writer as legacy_form
from helpers import _MOCK_NX_CGM_ZIP
from pre_milp import ct_units, cgmes_loader, ncp_header, ncp_loader

EIC = "10X-MOCK-TSO---A"
BASES = ("http://energy.referencedata.eu/EIC/", "https://energy.referencedata.eu/EIC/", "http://data.europa.eu/energy/EIC/")
# files of the mock CGM that declare the CoreEquipment profile without "_EQ_" in the name
EQ_PROFILE_FILES = ("Boundary_", "Grid_CommonData")
HEADER_CHILDREN = ["accessRights", "creator", "conformsTo", "identifier", "generatedAtTime", "startDate", "endDate", "keyword", "version"]
NAMESPACES = ('xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:md="http://iec.ch/TC57/61970-552/ModelDescription/1#" '
              'xmlns:dcat="http://www.w3.org/ns/dcat#" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:prov="http://www.w3.org/ns/prov#"')


def _legacy_header_file(path, creator_line, profile="RA"):
    path.write_text(f"""<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF {NAMESPACES}>
  <md:FullModel rdf:about="urn:uuid:00000000-0000-4000-8000-000000000001">
    <dcterms:accessRights>http://example.invalid/access</dcterms:accessRights>
    {creator_line}
    <dcterms:conformsTo rdf:resource="http://entsoe.eu/ns/CIM/RemedialAction-EU/2.2"/>
    <dcterms:identifier>urn:uuid:00000000-0000-4000-8000-000000000001</dcterms:identifier>
    <prov:generatedAtTime>2022-06-15T10:00:00Z</prov:generatedAtTime>
    <dcat:startDate>2022-06-15T10:30:00Z</dcat:startDate>
    <dcat:endDate>2022-06-15T11:30:00Z</dcat:endDate>
    <dcat:keyword>{profile}</dcat:keyword>
    <dcat:version>001</dcat:version>
  </md:FullModel>
</rdf:RDF>
""", encoding="utf-8")
    return path


@pytest.fixture(scope="module")
def legacy_dir(tmp_path_factory):
    folder = tmp_path_factory.mktemp("legacy_blockers")
    for name, data in legacy_form.legacy_files().items():
        (folder / name).write_bytes(data)
    return folder


# ---------------------------------------------------------------------------
# blocker 1: the creator of the header
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("base", BASES)
def test_rao_creator_as_text_content_keeps_the_hyphens_of_the_eic(tmp_path, base):
    path = _legacy_header_file(tmp_path / "a.xml", f"<dcterms:creator>{base}{EIC}</dcterms:creator>")
    assert ncp_header.read_header(path) == ncp_header.NcpHeader(profile="RA", creator=EIC)


@pytest.mark.parametrize("base", BASES)
def test_rao_creator_as_rdf_resource_keeps_the_hyphens_of_the_eic(tmp_path, base):
    path = _legacy_header_file(tmp_path / "a.xml", f'<dcterms:creator rdf:resource="{base}{EIC}"/>')
    assert ncp_header.read_header(path).creator == EIC


def test_rao_legacy_mock_files_have_the_header_of_the_real_form(legacy_dir):
    for country, eic in legacy_form.EIC_BY_TSO.items():
        assert len(eic) == 16
        for profile in legacy_form.PROFILES:
            root = ET.parse(legacy_dir / legacy_form.file_name(country, profile)).getroot()
            header = root[0]
            assert header.tag == "{http://iec.ch/TC57/61970-552/ModelDescription/1#}FullModel"
            assert header.get("{http://www.w3.org/1999/02/22-rdf-syntax-ns#}about").startswith("urn:uuid:")
            assert [child.tag.rsplit("}", 1)[-1] for child in header] == HEADER_CHILDREN
            creator = next(child for child in header if child.tag.rsplit("}", 1)[-1] == "creator")
            assert creator.attrib == {} and creator.text == "http://energy.referencedata.eu/EIC/" + eic


def test_rao_legacy_mock_zone_uris_are_eic_uris_of_the_two_known_bases(legacy_dir):
    nc_zone = "{http://entsoe.eu/ns/nc#}PowerRemedialAction.BiddingZone"
    resource = "{http://www.w3.org/1999/02/22-rdf-syntax-ns#}resource"
    bases = set()
    for country in legacy_form.EIC_BY_TSO:
        root = ET.parse(legacy_dir / legacy_form.file_name(country, "RA")).getroot()
        for zone in root.iter(nc_zone):
            base, _, eic = zone.get(resource).rpartition("/")
            bases.add(base + "/")
            assert len(eic) == 16 and eic == legacy_form.ZONE_EIC_BY_TSO[country]
    assert bases == {"http://energy.referencedata.eu/EIC/", "http://data.europa.eu/energy/EIC/"}


@pytest.mark.parametrize("creator_line, reason", [
    ("", "missing"),
    ("<dcterms:creator>SYNTHETIC-VALUE</dcterms:creator>", "not a URI"),
    ("<dcterms:creator></dcterms:creator>", "empty"),
    ("<dcterms:creator>http://energy.referencedata.eu/EIC/</dcterms:creator>", "empty segment"),
])
def test_rao_a_creator_that_cannot_be_read_is_logged_with_the_file_name_and_the_reason(tmp_path, caplog, creator_line, reason):
    folder = tmp_path / "ncp"
    folder.mkdir()
    for profile in ("AE", "CO", "RA"):
        _legacy_header_file(folder / f"file_{profile}.xml", creator_line, profile)
    with caplog.at_level(logging.WARNING), pytest.raises(ValueError, match="missing required"):          # no file is usable
        ncp_loader.classify_extracted_ncp_files(folder, {})
    text = "\n".join(record.getMessage() for record in caplog.records)
    assert "file_RA.xml" in text and reason in text
    assert "SYNTHETIC-VALUE" not in text


# ---------------------------------------------------------------------------
# blocker 2: the EQ files of a nested CGM
# ---------------------------------------------------------------------------

def _model_file(profile_url, name_part):
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:md="http://iec.ch/TC57/61970-552/ModelDescription/1#"
    xmlns:cim="http://iec.ch/TC57/2013/CIM-schema-cim16#">
  <md:FullModel rdf:about="urn:uuid:00000000-0000-4000-8000-000000000002">
    <md:Model.profile>{profile_url}</md:Model.profile>
    <md:Model.scenarioTime>2022-06-15T10:30:00Z</md:Model.scenarioTime>
    <md:Model.modelingAuthoritySet>http://example.invalid/{name_part}</md:Model.modelingAuthoritySet>
  </md:FullModel>
</rdf:RDF>
""".encode("utf-8")


def _nested_cgm(tmp_path):
    """The mock CGM as a zip holding one sub-folder with one zip per file, plus a 2.4.15 EQ, a boundary EQ and TP."""
    inner = tmp_path / "inner"
    inner.mkdir()
    with zipfile.ZipFile(_MOCK_NX_CGM_ZIP) as source:
        contents = {name: source.read(name) for name in source.namelist()}
    contents["20220615T1030Z_1D_10X-MOCK-TSO---A_EQ_001.xml"] = _model_file("http://entsoe.eu/CIM/EquipmentCore/3/1", "a")
    contents["20220615T1030Z__10X-MOCK-TSO---A_EQBD_001.xml"] = _model_file("http://entsoe.eu/CIM/EquipmentBoundary/3/1", "b")
    contents["20220615T1030Z_1D_10X-MOCK-TSO---A_TP_001.xml"] = _model_file("http://entsoe.eu/CIM/Topology/4/1", "c")
    path = tmp_path / "cgm_nested.zip"
    with zipfile.ZipFile(path, "w") as outer:
        for name, data in contents.items():
            member = inner / (name.removesuffix(".xml") + ".zip")
            with zipfile.ZipFile(member, "w") as part:
                part.writestr(name, data)
            outer.write(member, "package/" + member.name)
    return path, sorted(name for name in contents if "_EQ_" in name or name.startswith(EQ_PROFILE_FILES))


def test_rao_eq_files_are_found_in_nested_zips_by_the_header_profile(tmp_path):
    path, eq_names = _nested_cgm(tmp_path)
    cgmes_loader.extract_cgm_zip(path, tmp_path / "extracted")
    found = cgmes_loader.find_eq_files(tmp_path / "extracted")
    assert sorted(f.name for f in found) == eq_names                 # the EquipmentBoundary file and the TP are not in it


def test_rao_eq_files_of_the_flat_mock_cgm_are_the_ones_by_name_and_its_boundary_and_common_data_files(tmp_path):
    cgmes_loader.extract_cgm_zip(_MOCK_NX_CGM_ZIP, tmp_path)
    expected = sorted(f for f in tmp_path.iterdir() if "_EQ_" in f.name or f.name.startswith(EQ_PROFILE_FILES))
    assert cgmes_loader.find_eq_files(tmp_path) == expected and len(expected) > 9


def test_rao_the_header_profile_decides_over_the_file_name(tmp_path):
    (tmp_path / "x_SSH_1.xml").write_bytes(_model_file("http://entsoe.eu/CIM/EquipmentCore/3/1", "d"))
    (tmp_path / "y_EQ_1.xml").write_bytes(_model_file("http://entsoe.eu/CIM/SteadyStateHypothesis/1/1", "e"))
    (tmp_path / "z_EQ_1.xml").write_bytes(b"<rdf:RDF xmlns:rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns#'/>")
    assert [f.name for f in cgmes_loader.find_eq_files(tmp_path)] == ["x_SSH_1.xml", "z_EQ_1.xml"]     # no header profile: the name


def test_rao_control_area_units_are_read_from_nested_zips(tmp_path):
    path, _ = _nested_cgm(tmp_path)
    cgmes_loader.extract_cgm_zip(path, tmp_path / "nested")
    cgmes_loader.extract_cgm_zip(_MOCK_NX_CGM_ZIP, tmp_path / "flat")
    flat = ct_units.read_control_area_units(tmp_path / "flat")
    assert flat and ct_units.read_control_area_units(tmp_path / "nested") == flat


# ---------------------------------------------------------------------------
# log noise: the countertrade unit line
# ---------------------------------------------------------------------------

def _generator(index, unit):
    return ct_units.CtGenerator(gu_mrid=f"MOCK_GEN_{index:02d}", unit_mrid=unit, name="g", original_class="ThermalGeneratingUnit",
                                prod=1.0, pmin=0.0, pmax=10.0, connected=True, in_main_component=True)


def test_rao_countertrade_unit_line_has_the_counts_and_the_first_five_ids(caplog):
    generators = {f"MOCK_GEN_{i:02d}": _generator(i, "") for i in range(12)}
    with caplog.at_level(logging.DEBUG):
        ct_units._log_unassigned_generators(generators, {})
    info = [r for r in caplog.records if r.levelno == logging.INFO and "countertrade units" in r.getMessage()]
    debug = [r for r in caplog.records if r.levelno == logging.DEBUG and "countertrade units" in r.getMessage()]
    assert len(info) == 1 and "12 without a GeneratingUnit id" in info[0].getMessage()
    for index in range(5):
        assert f"MOCK_GEN_{index:02d}" in info[0].getMessage()
    assert "MOCK_GEN_05" not in info[0].getMessage() and "7 more" in info[0].getMessage()
    assert len(debug) == 1 and "MOCK_GEN_11" in debug[0].getMessage()
