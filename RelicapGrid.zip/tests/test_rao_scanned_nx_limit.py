"""tests/test_rao_scanned_nx_limit.py - the N-X limit of a scanned element is max(PATL, its initial post-contingency
loading of the same pair, same side and source as the model flow), not the N-0 loading."""

import pyomo.environ as pyo
import pytest

from data_model import AEType
from helpers import _make_ae_nx_filters as _ae, _make_pst_nx_filters as _pst
from milp.milp_builder import NxMilpInputs, PstMilpInputs, build_n0_milp_model
from milp.single_pass import nx_element_limits, nx_overloads_ampere

TS = "1030Z"


def _build(lf_nx, lf_nx_original=None, side=1, sensitivity=0.0, n0_current=500.0, patl_ka=1.0):
    pst_inputs = PstMilpInputs(
        pst_list=[_pst("PST1")], pst_tap_bounds={"PST1": (-10, 10)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={}, pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx=lf_nx, lf_nx_original=lf_nx_original,
        sensitivity_pst_nx={"CO1": {("B1", "PST1"): sensitivity}}, sensitivity_rd_nx={},
        penalty_cost_overload_nx_scanned=10_000.0, constraint_filter_enabled=False,
    )
    ae = [_ae("a1", "B1", branch_side=side, patl_ka=patl_ka, ae_type=AEType.SCANNED)]
    return build_n0_milp_model(
        ae, TS, {"B1": {1: n0_current, 2: n0_current}}, 1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )


def _solve(model):
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model


def test_without_any_move_the_scanned_nx_slack_is_zero():
    # N-0 loading 500 A, PATL 1000 A, post-contingency 1500 A and no PST effect: the limit is the 1500 A of the pair
    model = _solve(_build({"CO1": {"B1": {1: 1500.0}}}))
    assert model.nx_scanned_pair_limit_ampere[("B1", "CO1")] == pytest.approx(1500.0)
    assert pyo.value(model.nx_scanned_overload_slack["B1", "CO1"]) == pytest.approx(0.0, abs=1e-9)
    assert pyo.value(model.objective) == pytest.approx(0.0, abs=1e-9)


def test_the_limit_is_the_patl_when_the_post_contingency_loading_is_below_it():
    model = _build({"CO1": {"B1": {1: 800.0}}})
    assert model.nx_scanned_pair_limit_ampere[("B1", "CO1")] == pytest.approx(1000.0)


def test_the_limit_stays_anchored_to_the_original_post_contingency_loading():
    # the model flow is the current state (1400 A), the limit the original one (1500 A)
    model = _build({"CO1": {"B1": {1: 1400.0}}}, lf_nx_original={"CO1": {"B1": {1: 1500.0}}})
    assert model.nx_scanned_pair_limit_ampere[("B1", "CO1")] == pytest.approx(1500.0)


def test_the_limit_uses_the_side_of_the_element():
    model = _build({"CO1": {"B1": {1: 2000.0, 2: 1200.0}}}, side=2)
    assert model.nx_scanned_pair_limit_ampere[("B1", "CO1")] == pytest.approx(1200.0)


def test_a_pst_can_still_reduce_the_flow_below_the_limit_of_the_pair():
    model = _solve(_build({"CO1": {"B1": {1: 1500.0}}}, sensitivity=-10.0))
    assert pyo.value(model.nx_scanned_overload_slack["B1", "CO1"]) == pytest.approx(0.0, abs=1e-9)
    assert pyo.value(model.tap_change_upward["PST1"]) == pytest.approx(0.0, abs=1e-9)


def test_the_final_check_uses_the_same_pair_limit():
    ae = [_ae("a1", "B1", patl_ka=1.0, ae_type=AEType.SCANNED)]
    original = {"CO1": {"B1": {1: 1500.0}}}
    limits = nx_element_limits(ae, TS, {"B1": {1: 500.0}}, None, lf_nx_original=original)
    overloads = nx_overloads_ampere(limits, {"CO1": {"B1": {1: 1500.0}}}, {}, set(), {})
    assert overloads[("nx_scanned", "B1", "CO1")] == pytest.approx(0.0)
    overloads = nx_overloads_ampere(limits, {"CO1": {"B1": {1: 1530.0}}}, {}, set(), {})
    assert overloads[("nx_scanned", "B1", "CO1")] == pytest.approx(30.0)
