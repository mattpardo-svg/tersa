"""tests/test_rao_output_files.py - the output files of a run (docs/specs/output_files_specs.md).

Sections: which file is written when, the loading thresholds and switches, column rules, removed files, config keys.
"""

import csv
import re

import pytest

from helpers import _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs
from output_file_registry import OUTPUT_FILE_REGISTRY
from post_milp import run_outputs
from text_encoding import TEXT_ENCODING

OLD_FILE_NAMES = [
    "co_flat_list.csv", "countertrade_glsk_resolved.csv", "ct_cra_availability.csv", "glsk_resolved.csv",
    "hvdc_cra_availability.csv", "lf_basecase.csv", "lf_nx_initial.csv", "lf_post_n0.csv", "pst_cra_availability.csv",
    "rd_cra_availability.csv", "results_completeness_iterations.csv", "results_contingency_status.csv",
    "results_curative_countertrade.csv", "results_curative_hvdc.csv", "results_curative_pst.csv",
    "results_curative_pst_groups.csv", "results_curative_rd.csv", "results_countertrade.csv",
    "results_generating_units.csv", "results_hvdc.csv", "results_iteration_history.csv", "results_lead_times.csv",
    "results_net_positions.csv", "results_nx_loadings.csv", "results_nx_scanned_elements.csv",
    "results_preventive_rd.csv", "results_preventive_rd_ra_count.csv", "results_preventive_rd_ra_groups.csv",
    "results_pst.csv", "results_summary.csv", "results_tso_tap_limits.csv", "results_zone_exchange.csv",
    "scanned_element_list.csv", "tatl_data.csv",
]
FORBIDDEN_NAME_PARTS = ("mrid", "_ka", "timestamp", "ac_verification", "seconds", "minutes", "hours", "ampere")


def _run(tmp_path, nx=True, ra_types=("pst", "rd"), mode="ac_iterative", settings=None):
    def customize(rp, monkeypatch):
        for name, value in (settings or {}).items():
            monkeypatch.setattr(rp, name, value)
    return run_pipeline_on_fixture_inputs(
        tmp_path, _MOCK_NX_NCP_ZIP, enable_nx_analysis=nx, ra_types=ra_types, calculation_mode=mode, customize_pipeline=customize,
    )


def _names(run) -> set:
    return {p.name for p in run.output_dir.iterdir() if p.is_file()}


def _rows(path):
    with open(path, newline="", encoding=TEXT_ENCODING) as handle:
        return list(csv.DictReader(handle))


@pytest.fixture(scope="module")
def nx_run(tmp_path_factory):
    return _run(tmp_path_factory.mktemp("files_nx"), settings={"WRITE_SENSITIVITY_CSVS": False})


@pytest.fixture(scope="module")
def pst_only_run(tmp_path_factory):
    return _run(tmp_path_factory.mktemp("files_pst"), nx=False, ra_types=("pst",), settings={"WRITE_SENSITIVITY_CSVS": False})


@pytest.fixture(scope="module")
def single_pass_run(tmp_path_factory):
    return _run(tmp_path_factory.mktemp("files_single"), mode="ac_single_pass", settings={"WRITE_SENSITIVITY_CSVS": False})


# ---------------------------------------------------------------------------
# a file is written only when its feature is on
# ---------------------------------------------------------------------------

def test_a_pst_and_rd_run_with_nx_writes_exactly_its_files(nx_run):
    assert _names(nx_run) == {
        "assessed_elements.csv", "contingencies.csv", "generating_units.csv", "pst_ra.csv", "rd_bids.csv", "pst_results.csv",
        "rd_results.csv", "tso_limits.csv", "summary.csv", "loadings_n0.csv", "loadings_nx.csv", "iterations.csv", "run_log.txt",
    }


def test_a_pst_only_run_writes_no_rd_hvdc_or_countertrade_file_and_no_nx_loadings(pst_only_run):
    names = _names(pst_only_run)
    assert {"pst_ra.csv", "pst_results.csv", "tso_limits.csv", "assessed_elements.csv", "summary.csv"} <= names
    assert not names & {
        "rd_bids.csv", "rd_results.csv", "ct_bids.csv", "ct_results.csv", "hvdc_ra.csv", "hvdc_results.csv",
        "zone_net_positions.csv", "generating_units.csv", "loadings_nx.csv",
    }


def test_contingencies_is_not_written_without_nx(pst_only_run):
    assert "contingencies.csv" not in _names(pst_only_run)


def test_iterations_exists_only_in_ac_iterative(nx_run, single_pass_run):
    assert "iterations.csv" in _names(nx_run)
    assert "iterations.csv" not in _names(single_pass_run)
    metrics = {row["metric"] for row in _rows(single_pass_run.output_dir / "summary.csv")}
    assert {"iterations", "solve_s"} <= metrics


def test_the_removed_files_are_no_longer_written(nx_run, pst_only_run, single_pass_run):
    for run in (nx_run, pst_only_run, single_pass_run):
        assert not _names(run) & set(OLD_FILE_NAMES)


def test_every_file_written_is_registered(nx_run, pst_only_run, single_pass_run):
    for run in (nx_run, pst_only_run, single_pass_run):
        assert _names(run) <= set(OUTPUT_FILE_REGISTRY)


# ---------------------------------------------------------------------------
# thresholds and switches
# ---------------------------------------------------------------------------

def test_the_loading_thresholds_filter_the_rows(nx_run, tmp_path_factory):
    high = _run(tmp_path_factory.mktemp("files_high"), settings={
        "WRITE_SENSITIVITY_CSVS": False, "LOADINGS_N0_MIN_LOADING_PCT": 1e9, "LOADINGS_NX_MIN_LOADING_PCT": 1e9,
    })
    zero = _run(tmp_path_factory.mktemp("files_zero"), settings={
        "WRITE_SENSITIVITY_CSVS": False, "LOADINGS_N0_MIN_LOADING_PCT": 0, "LOADINGS_NX_MIN_LOADING_PCT": 0,
    })
    for name in ("loadings_n0.csv", "loadings_nx.csv"):
        assert _rows(high.output_dir / name) == []
        default_rows = _rows(nx_run.output_dir / name)
        assert len(_rows(zero.output_dir / name)) >= len(default_rows)
        assert len(_rows(zero.output_dir / name)) > 0
        assert all(max(float(r["loading_initial_pct"]), float(r[next(c for c in r if c.startswith("loading_after"))])) >= 80.0 for r in default_rows)


def test_write_loadings_nx_false_skips_the_file(tmp_path):
    run = _run(tmp_path, settings={"WRITE_SENSITIVITY_CSVS": False, "WRITE_LOADINGS_NX": False})
    assert "loadings_nx.csv" not in _names(run)
    assert "loadings_n0.csv" in _names(run)


def test_write_sensitivity_csvs_controls_the_sensitivity_files(nx_run, tmp_path):
    assert not [n for n in _names(nx_run) if n.startswith("sensitivity_")]
    on = _run(tmp_path, settings={"WRITE_SENSITIVITY_CSVS": True})
    assert {n for n in _names(on) if n.startswith("sensitivity_")} == {
        "sensitivity_pst_n0.csv", "sensitivity_rd_n0.csv", "sensitivity_pst_nx.csv", "sensitivity_rd_nx.csv",
    }
    # the N-X PST file is per tap: its columns have no degree
    header = next(csv.reader(open(on.output_dir / "sensitivity_pst_nx.csv", encoding=TEXT_ENCODING)))
    assert header[-1] == "sensitivity_a_per_tap"


# ---------------------------------------------------------------------------
# column rules
# ---------------------------------------------------------------------------

def test_tso_is_the_first_column_wherever_it_is_a_column_and_names_follow_the_unit_rule(nx_run):
    checked = 0
    for path in sorted(nx_run.output_dir.glob("*.csv")):
        with open(path, newline="", encoding=TEXT_ENCODING) as handle:
            header = next(csv.reader(handle))
        if "tso" in header:
            assert header[0] == "tso", path.name
        for column in header:
            assert re.fullmatch(r"[a-z0-9]+(_[a-z0-9]+)*", column), (path.name, column)
            assert not any(part in column for part in FORBIDDEN_NAME_PARTS), (path.name, column)
        checked += 1
    assert checked >= 10


def test_every_registered_header_follows_the_rules():
    for name, header in run_outputs.HEADERS.items():
        if "tso" in header:
            assert header[0] == "tso", name
        for column in header:
            assert not any(part in column for part in FORBIDDEN_NAME_PARTS), (name, column)
    # limits before the value
    for name in ("pst_ra.csv", "hvdc_ra.csv"):
        header = run_outputs.HEADERS[name]
        assert header.index("tap_min" if name == "pst_ra.csv" else "p_min_mw") < header.index("tap" if name == "pst_ra.csv" else "p_mw")


def test_units_are_amperes_not_kiloamperes(nx_run):
    rows = _rows(nx_run.output_dir / "assessed_elements.csv")
    assert rows and all(float(r["patl_a"]) > 50.0 for r in rows)     # a PATL in kA would be a small number
    assert {r["patl_source"] for r in rows} <= {"ncp", "cgm"}
    assert {r["ae_type"] for r in rows} <= {"secured", "scanned"}


# ---------------------------------------------------------------------------
# config keys
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("key, bad", [
    ("loadings_n0_min_loading_pct", -1), ("loadings_n0_min_loading_pct", "x"), ("loadings_n0_min_loading_pct", True),
    ("loadings_nx_min_loading_pct", -0.5), ("loadings_nx_min_loading_pct", None),
    ("write_loadings_nx", "yes"), ("write_loadings_nx", 1), ("write_sensitivity_csvs", "no"), ("write_sensitivity_csvs", None),
])
def test_the_new_output_config_keys_are_validated(key, bad, tmp_path):
    import importlib
    import yaml
    from pathlib import Path
    rp = importlib.import_module("run_pipeline")
    config = yaml.safe_load(Path(rp.RAO_CONFIG_PATH).read_text(encoding=TEXT_ENCODING))
    config["outputs"][key] = bad
    with pytest.raises(ValueError):
        rp.validate_config_ranges(config, Path(rp.RAO_CONFIG_PATH))


def test_the_default_config_has_the_new_keys_and_not_the_removed_one():
    import importlib
    import yaml
    from pathlib import Path
    rp = importlib.import_module("run_pipeline")
    outputs = yaml.safe_load(Path(rp.RAO_CONFIG_PATH).read_text(encoding=TEXT_ENCODING))["outputs"]
    assert outputs == {
        "loadings_n0_min_loading_pct": 80, "loadings_nx_min_loading_pct": 80, "write_loadings_nx": True,
        "write_sensitivity_csvs": False,
    }

# ---------------------------------------------------------------------------
# monitored branch sides
# ---------------------------------------------------------------------------

def _element(mrid, branch, side, tso="TSO-X"):
    from data_model import AEType, AssessedElement
    return AssessedElement(
        mrid=mrid, name=mrid, tso=tso, ae_type=AEType.SECURED, branch_mrid=branch, secured_for_region="R", scanned_for_region=None,
        exclusion_reason=None, patl_ka={"1030Z": 1.0 + side}, branch_side=side,
    )


def test_two_elements_on_the_two_sides_of_one_branch_give_one_row_of_the_side_the_pipeline_monitors():
    """The pipeline keeps one limit per branch (the last element decides), so one row per branch is written, not one per side."""
    records = run_outputs.monitored_branches([_element("a", "BR", 1), _element("b", "BR", 2)], "1030Z", {})
    assert list(records) == ["BR"] and records["BR"]["side"] == 2 and records["BR"]["elements"] == 2
    lf = {"BR": {1: 900.0, 2: 800.0}}
    rows = run_outputs.loadings_n0_rows(records, set(), lf, None, 0.0)
    assert [(r["branch_id"], r["side"]) for r in rows] == [("BR", 2)]


def test_a_pst_ra_without_a_name_in_the_ra_profile_takes_the_name_of_its_pst():
    from data_model import PST, RAKind

    def pst(name):
        return PST(mrid="PST1", name=name, tso="T", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0, low_step=-5, high_step=5,
                   r0=0, operating_tap_min=-5, operating_tap_max=5, group_id=None, ra_mrid="RA1")
    assert run_outputs.pst_ra_rows([pst("RA name")], [], None, {"PST1": "Transformer name"})[0]["ra_name"] == "RA name"
    assert run_outputs.pst_ra_rows([pst("RA1")], [], None, {"PST1": "Transformer name"})[0]["ra_name"] == "Transformer name"


def test_a_static_mva_limit_converted_to_amperes_is_marked_converted_mva():
    from pre_milp.cgmes_loader import StaticPatl
    limits = StaticPatl({"BR": {1: 1000.0}})
    limits.converted.add(("BR", 1))
    assert ("BR", 1) in limits.converted and ("BR", 2) not in limits.converted
