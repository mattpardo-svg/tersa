"""tests/test_rao_output_folder.py - one output folder per run: output/<CGM time>/.

Sections: folder name and emptying (unit), the pipeline run (folder, rerun, other folders), a run that stops early.
"""

import datetime
import re

import pytest

from helpers import _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs
from output_file_registry import FAILED_LOG_FILE_NAME, empty_run_folder, run_folder_name
from text_encoding import TEXT_ENCODING

FOLDER_PATTERN = re.compile(r"^\d{8}T\d{4}Z$")


def test_run_folder_name_is_the_utc_cgm_time():
    utc = datetime.timezone.utc
    assert run_folder_name(datetime.datetime(2025, 5, 6, 0, 30, tzinfo=utc)) == "20250506T0030Z"
    plus_two = datetime.timezone(datetime.timedelta(hours=2))
    assert run_folder_name(datetime.datetime(2025, 5, 6, 2, 30, tzinfo=plus_two)) == "20250506T0030Z"


def test_run_folder_name_needs_a_time_zone():
    with pytest.raises(ValueError):
        run_folder_name(datetime.datetime(2025, 5, 6, 0, 30))


def test_empty_run_folder_empties_only_that_folder(tmp_path):
    run_dir, other_dir = tmp_path / "20250506T0030Z", tmp_path / "20250506T0130Z"
    (run_dir / "sub").mkdir(parents=True)
    (run_dir / "a.csv").write_text("x", encoding=TEXT_ENCODING)
    (run_dir / "sub" / "b.csv").write_text("x", encoding=TEXT_ENCODING)
    other_dir.mkdir()
    (other_dir / "keep.csv").write_text("keep", encoding=TEXT_ENCODING)

    assert empty_run_folder(run_dir) == 2

    assert list(run_dir.iterdir()) == []
    assert (other_dir / "keep.csv").read_text(encoding=TEXT_ENCODING) == "keep"


def test_empty_run_folder_creates_a_missing_folder(tmp_path):
    assert empty_run_folder(tmp_path / "new" / "20250506T0030Z") == 0
    assert (tmp_path / "new" / "20250506T0030Z").is_dir()


@pytest.fixture(scope="module")
def two_runs(tmp_path_factory):
    work_dir = tmp_path_factory.mktemp("folder_runs")
    first = run_pipeline_on_fixture_inputs(work_dir, _MOCK_NX_NCP_ZIP, enable_nx_analysis=False)
    base = first.output_base
    other_folder = base / "20000101T0000Z"
    other_folder.mkdir()
    (other_folder / "keep.csv").write_text("keep", encoding=TEXT_ENCODING)
    (first.output_dir / "left_over.csv").write_text("old", encoding=TEXT_ENCODING)
    (first.output_dir / "left_over_dir").mkdir()
    second = run_pipeline_on_fixture_inputs(work_dir, _MOCK_NX_NCP_ZIP, enable_nx_analysis=False)
    return first, second, other_folder


def test_every_file_and_the_log_are_in_the_folder_named_by_the_cgm_time(two_runs):
    first, _second, _other = two_runs
    assert FOLDER_PATTERN.match(first.output_dir.name)
    assert first.output_dir.parent == first.output_base
    assert (first.output_dir / "run_log.txt").is_file()
    assert list(first.output_base.glob("*.csv")) == []
    assert not (first.output_base / "run_log.txt").exists()


def test_a_rerun_empties_its_folder_first(two_runs):
    first, second, _other = two_runs
    assert second.output_dir == first.output_dir
    assert not (second.output_dir / "left_over.csv").exists()
    assert not (second.output_dir / "left_over_dir").exists()
    assert (second.output_dir / "run_log.txt").is_file()


def test_a_run_never_touches_another_folder(two_runs):
    _first, _second, other_folder = two_runs
    assert (other_folder / "keep.csv").read_text(encoding=TEXT_ENCODING) == "keep"


def test_the_log_holds_the_lines_written_before_the_cgm_time_was_known(two_runs):
    first, _second, _other = two_runs
    log_text = (first.output_dir / "run_log.txt").read_text(encoding=TEXT_ENCODING)
    first_line = log_text.splitlines()[0]
    assert "calculation_mode=" in first_line


def test_a_run_that_stops_before_the_cgm_time_writes_the_buffered_log_next_to_the_folders(tmp_path):
    import helpers

    def invalid_ra_types(rp, monkeypatch):
        monkeypatch.setattr(rp, "RA_TYPES", ["not_an_ra_type"])

    with pytest.raises(Exception):
        run_pipeline_on_fixture_inputs(tmp_path, _MOCK_NX_NCP_ZIP, enable_nx_analysis=False, customize_pipeline=invalid_ra_types)

    base = tmp_path / "output"
    failed_log = base / FAILED_LOG_FILE_NAME
    assert failed_log.is_file()
    assert "not_an_ra_type" in failed_log.read_text(encoding=TEXT_ENCODING)
    assert [p for p in base.iterdir() if p.is_dir()] == []
    assert helpers is not None


def test_a_cgm_without_a_scenario_time_stops_the_run_before_any_folder_is_made(tmp_path):
    def no_case_date(rp, monkeypatch):
        original_load = rp.cgmes_loader.load_cgm

        def load_without_time(*args, **kwargs):
            network = original_load(*args, **kwargs)
            return _NetworkWithoutTime(network)

        monkeypatch.setattr(rp.cgmes_loader, "load_cgm", load_without_time)

    with pytest.raises(RuntimeError, match="scenario time"):
        run_pipeline_on_fixture_inputs(tmp_path, _MOCK_NX_NCP_ZIP, enable_nx_analysis=False, customize_pipeline=no_case_date)

    base = tmp_path / "output"
    assert [p for p in base.iterdir() if p.is_dir()] == []
    assert "scenario time" in (base / FAILED_LOG_FILE_NAME).read_text(encoding=TEXT_ENCODING)


class _NetworkWithoutTime:
    """The network, with no case date."""

    def __init__(self, network):
        self._network = network
        self.case_date = None

    def __getattr__(self, name):
        return getattr(self._network, name)
