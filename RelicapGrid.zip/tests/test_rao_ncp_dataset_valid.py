"""
test_rao_ncp_dataset_valid.py — the valid NCP test dataset (tests/mock_builders/ncp_dataset.py;
parts A and B): run_pipeline.main() on it with ra_types pst+rd+hvdc+countertrade and N-X analysis on, in
ac_iterative, ac_single_pass and dc. One test per coverage row: the dataset holds the element and the run reacts as
docs/specs/ncp_data_requirements.md says (a log line of run_log.txt or a value of a result file). Every run has a per-TSO
RA-count limit of 1 for TSO-Galia (config, not NCP data), so that row is exercised too.
"""
import csv
from helpers import read_summary
import math
import zipfile

import pytest
from rdflib import Namespace, RDF

from mock_builders import ct_mock
from mock_builders import hvdc_mock
from mock_builders import ncp_dataset as ds
from helpers import run_pipeline_on_fixture_inputs
from milp import milp_builder
from pre_milp import ncp_parser

NC = Namespace(ds.ENUM)
RA_TYPES = ("pst", "rd", "hvdc", "countertrade")
MODES = ("ac_iterative", "ac_single_pass", "dc")
GALIA_RA_LIMIT = 1
BO_LINE_2 = "b58bf21a-096a-4dae-9a01-3f03b60c24c7"
BO_LINE_2_SHS_PATL_A = 1850.0          # Belgovia_SHS.xml of the base package: 2023-07-22T10:30:00Z (another date)
AAC, AAA1 = "2c9a0753-421a-489b-9761-9452f60b3157", "703f5b86-b6c6-4c47-8f6b-55d7d93838c9"
GA_TR2_1, GA_TR2_2 = "e8a7eaec-51d6-4571-b3d9-c36d52073c33", "2184f365-8cd5-4b5d-8a28-9d68603bb6a4"
BO_TR2_2 = "b94318f6-6d24-4f56-96b9-df2531ad6543"


@pytest.fixture(scope="module")
def dataset(tmp_path_factory):
    return ds.build_valid_ncp(tmp_path_factory.mktemp("ncp_dataset") / "valid.zip")


@pytest.fixture(scope="module")
def package(dataset):
    return ds.read_package(dataset)


@pytest.fixture(scope="module")
def files(dataset, tmp_path_factory):
    folder = tmp_path_factory.mktemp("ncp_dataset_files")
    with zipfile.ZipFile(dataset) as zf:
        zf.extractall(folder)
    return {path.name: path for path in folder.iterdir()}


_RUNS = {}


def _run(mode, dataset, tmp_path_factory):
    if mode not in _RUNS:
        def limit(rp, monkeypatch):
            monkeypatch.setattr(rp, "MAX_RA_COUNT_PER_TIMESTAMP_TSO", {"TSO-Galia": GALIA_RA_LIMIT})
        run = run_pipeline_on_fixture_inputs(
            tmp_path_factory.mktemp(f"ncp_dataset_{mode}"), dataset, enable_nx_analysis=True, ra_types=RA_TYPES,
            calculation_mode=mode, customize_pipeline=limit,
        )
        _RUNS[mode] = run.output_dir
    return _RUNS[mode]


@pytest.fixture(scope="module")
def ac(dataset, tmp_path_factory):
    return _run("ac_iterative", dataset, tmp_path_factory)


@pytest.fixture(scope="module", params=MODES)
def mode_run(request, dataset, tmp_path_factory):
    return request.param, _run(request.param, dataset, tmp_path_factory)


def _rows(output_dir, name):
    with open(output_dir / name, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _log(output_dir):
    return (output_dir / "run_log.txt").read_text(encoding="utf-8")


def _log_lines(output_dir, *parts):
    return [line for line in _log(output_dir).splitlines() if all(p in line for p in parts)]


def _patl_ka(output_dir, branch):
    return float(next(r for r in _rows(output_dir, "assessed_elements.csv") if r["branch_id"] == branch)["patl_a"]) / 1000.0


def _subject(package, file_name, mrid):
    graph = package[file_name]
    return next(s for s in graph.subjects() if str(s).endswith(f"#_{mrid}"))


def _ae_of_branch(package, file_name, branch):
    graph = package[file_name]
    return next(str(ae).rsplit("#_", 1)[-1] for ae in graph.subjects(RDF.type, NC.AssessedElement)
                if str(graph.value(ae, NC["AssessedElement.ConductingEquipment"]) or graph.value(ae, NC["AssessedElement.Line"])).endswith(branch))


def _tatl_branches(output_dir):
    return {r["branch_id"] for r in _rows(output_dir, "assessed_elements.csv") if r["tatl_a"] != ""}


def _scanned_branches(output_dir):
    return {r["branch_id"] for r in _rows(output_dir, "assessed_elements.csv") if r["ae_type"] == "scanned"}


# ---------------------------------------------------------------------------
# data rules
# ---------------------------------------------------------------------------

def test_the_generator_checks_the_data_rules(dataset, tmp_path):
    assert ds.check_data_rules(dataset) == []
    broken = {
        "bid_price_missing": f"{ds.VARIANT_BID} without direction, volume or price",
        "hvdc_group_of_three": "with 3 members",
        "patl_zero": "has PATL 0.0 <= 0",
        "reaction_time_unreadable_pst": f"curative RA {ds.CRA_PST_AAC} without a readable timeToImplement",
        "ct_zone_without_units": "fewer than two usable generators",
    }
    for case, text in broken.items():
        violations = ds.check_data_rules(ds.build_variant_ncp(tmp_path / f"{case}.zip", case))
        assert any(text in v for v in violations), (case, violations)


# ---------------------------------------------------------------------------
# assessed elements and PATL
# ---------------------------------------------------------------------------

def test_secured_and_scanned_without_a_reason_is_secured(package, ac):
    ae = _subject(package, "Espheim_AE.xml", ds.ae_mrid("secured+scanned"))
    graph = package["Espheim_AE.xml"]
    assert graph.value(ae, NC["AssessedElement.SecuredForRegion"]) and graph.value(ae, NC["AssessedElement.ScannedForRegion"])
    assert ds.EH_LINE1 in _tatl_branches(ac) and ds.EH_LINE1 not in _scanned_branches(ac)


@pytest.mark.parametrize("key, branch", [
    ("scanned+systemOperator", ds.LINE_EH_SD4), ("all three, capacityCalculationRegion", ds.TIE_EH_SD2),
])
def test_a_reason_with_a_scanned_region_is_scanned(package, ac, key, branch):
    graph = package["Espheim_AE.xml"]
    ae = _subject(package, "Espheim_AE.xml", ds.ae_mrid(key))
    assert graph.value(ae, NC["AssessedElement.exclusionReason"]) is not None
    assert branch in _scanned_branches(ac) and branch not in _tatl_branches(ac)


def test_a_reason_without_a_scanned_region_is_excluded(package, ac):
    graph = package["Espheim_AE.xml"]
    ae = _subject(package, "Espheim_AE.xml", ds.ae_mrid("secured+nonNative"))
    assert str(graph.value(ae, NC["AssessedElement.exclusionReason"])).endswith("nonNativeCapacityCalculationRegion")
    assert ds.TIE_EH_HVDC not in _tatl_branches(ac) | _scanned_branches(ac)
    assert _log_lines(ac, "TSO-Espheim: 10 AEs parsed (secured=7, scanned=2, excluded=1)")


def test_no_region_code_is_excluded_with_an_info_line(ac):
    assert _log_lines(ac, "TSO-Galia:", "assessed element(s) excluded - no secured or scanned region code", ds.ae_mrid("no region code"))
    assert ds.TIE_GA_HVDC_BH not in _tatl_branches(ac) | _scanned_branches(ac)


def test_scanned_only_is_secured(ac):
    assert ds.TIE_GA_HVDC_NH in _tatl_branches(ac) and ds.TIE_GA_HVDC_NH not in _scanned_branches(ac)


def test_the_line_predicate_gives_the_branch(package, ac):
    graph = package["Svedala_AE.xml"]
    ae = _subject(package, "Svedala_AE.xml", ds.ae_mrid("Line predicate"))
    assert graph.value(ae, NC["AssessedElement.ConductingEquipment"]) is None and graph.value(ae, NC["AssessedElement.Line"])
    assert ds.TIE_SD_HVDC in _tatl_branches(ac)
    assert _patl_ka(ac, ds.TIE_SD_HVDC) == pytest.approx(ds.AE_PATL_A[ds.TIE_SD_HVDC] / 1000.0)


def test_the_patl_from_the_shs_file_wins(package, ac):
    ae = _ae_of_branch(package, "Belgovia_AE.xml", ct_mock.BRANCH_GA_BO4_BELGOVIA)
    assert _patl_ka(ac, ct_mock.BRANCH_GA_BO4_BELGOVIA) == pytest.approx(ct_mock.CT_HVDC_PATL_A / 1000.0)
    assert _log_lines(ac, ae, "SHS PATL that differs by more than 10% from the CGM static PATL")


def test_the_patl_from_a_base_case_current_limit(ac):
    assert _patl_ka(ac, ds.EH_LINE1) == pytest.approx(ds.AE_PATL_A[ds.EH_LINE1] / 1000.0)


def test_the_cgm_patl_is_the_fallback_with_a_warning(ac):
    assert _patl_ka(ac, ds.SER_RLC) == pytest.approx(ds.SER_RLC_CGM_PATL_A / 1000.0)
    assert _log_lines(ac, ds.ae_mrid("CGM PATL fallback"), "no PATL in NCP", "using CGM static PATL")


def test_an_shs_time_point_of_another_date_matches_by_clock_time(package, ac):
    graph = package["Belgovia_SHS.xml"]
    dates = {str(graph.value(p, NC["CurrentLimitTimePoint.atTime"]))[:10] for p in graph.subjects(RDF.type, NC.CurrentLimitTimePoint)}
    assert "2023-07-22" in dates
    assert _patl_ka(ac, BO_LINE_2) == pytest.approx(BO_LINE_2_SHS_PATL_A / 1000.0)


# ---------------------------------------------------------------------------
# contingencies
# ---------------------------------------------------------------------------

EQUIPMENT_TYPE_CONTINGENCY = {
    "line": "b6b780cb-9fe5-4c45-989d-447a927c3874", "transformer": ds.CO_BO_TR2_1_OUT,
    "gen": ct_mock.CONTINGENCY_BELGOVIA_CO3, "load": "65582e87-5035-4465-8dd9-cb655224b29f",
    "switch": ds.CO_SWITCH, "shuntCompensator": "62eac668-82a1-4739-8cfc-de929b78ef7e",
    "staticVarCompensator": ds.CO_SVC, "busbar": ds.CO_BUSBAR,
}


# ---------------------------------------------------------------------------
# PST
# ---------------------------------------------------------------------------

def _tatl_seconds(output_dir):
    return {r["branch_id"]: int(r["tatl_duration_s"]) for r in _rows(output_dir, "assessed_elements.csv") if r["tatl_a"] != ""}


# ---------------------------------------------------------------------------
# RD
# ---------------------------------------------------------------------------

def test_the_activation_cost_of_the_time_point_wins(files):
    bids = ncp_parser.parse_power_bids(ncp_parser._load_graph(files["Galia_SIS.xml"]), {ds.PRA_RD_GA_G1_UP}, "TSO-Galia", "1030Z")
    assert next(b for b in bids if b.mrid == ds.GA_G1_SECOND_BID).activation_cost_eur == 150.0


def test_unit_costs_from_sis_and_er(files):
    to_generator = {ds.STORFORS_G1_UNIT: ds.STORFORS_G1, ds.STENFORSEN_G1_UNIT: ds.STENFORSEN_G1}
    costs = ncp_parser.parse_unit_costs(files["Svedala_SIS.xml"], files["Svedala_ER.xml"], "TSO-Svedala", "1030Z", to_generator)
    sis = dict(ds.SIS_UNIT_COSTS)[ds.STORFORS_G1_UNIT]
    assert (costs[ds.STORFORS_G1].startup_cost_eur, costs[ds.STORFORS_G1].shutdown_cost_eur) == (sis["warm_startup"], sis["shutdown"])
    _unit, startup, shutdown = ds.ER_UNITS[0]
    assert (costs[ds.STENFORSEN_G1].startup_cost_eur, costs[ds.STENFORSEN_G1].shutdown_cost_eur) == (startup, shutdown)


def test_the_er_file_is_read(ac):
    assert not _log_lines(ac, "optional profile ER not found")          # one ER file in the pool (TSO-Svedala)
    assert _log_lines(ac, "NCP profile ER: 1 file(s)")


# ---------------------------------------------------------------------------
# HVDC
# ---------------------------------------------------------------------------

def _hvdc(output_dir):
    return {r["ra_id"]: {**r, "unit_mrid": r["ra_id"], "change_mw": r["p_change_mw"], "result_p_mw": r["p_after_mw"], "original_p_mw": r["p_before_mw"]} for r in _rows(output_dir, "hvdc_results.csv")}


def test_hvdc_units_without_technical_limits_and_description(ac):
    for unit in ds.HVDC_PREVENTIVE:
        assert _log_lines(ac, f"HVDC unit {unit} (EquivalentInjection", "has no technical limits (minP/maxP)")
    assert _log_lines(ac, f"the description of EquivalentInjection {hvdc_mock.EI_SD_EH1}", 'does not start with "HVDC"')


# ---------------------------------------------------------------------------
# countertrade
# ---------------------------------------------------------------------------

def test_every_countertrade_zone_has_at_least_two_units(ac):
    assert _log_lines(ac, "(BZ-Belgovia): 2 candidate unit(s)") and _log_lines(ac, "(BZ-Galia): 3 candidate unit(s)")


# ---------------------------------------------------------------------------
# the three modes: every RA type acts, preventive (all modes) and curative (ac_iterative)
# ---------------------------------------------------------------------------


def test_the_tatl_is_at_least_the_patl_and_lasts(ac):
    rows = [r for r in _rows(ac, "assessed_elements.csv") if r["tatl_a"] != ""]
    assert rows
    for row in rows:
        assert float(row["tatl_a"]) >= float(row["patl_a"]) - 1e-9
        assert int(row["tatl_duration_s"]) > 0
    # the CGM TATL below the PATL is the CGM's own data: raised to the PATL and marked
    assert any(row["tatl_source"] == "raised_to_patl" for row in rows)


def test_a_glsk_over_several_units_drops_an_unconnected_one(ac):
    bid = next(r for r in _rows(ac, "rd_bids.csv") if r["ra_id"] == ds.RD_MULTI_GLSK)
    factors = dict(zip(bid["unit_ids"].split(";"), (float(f) for f in bid["participation_factors"].split(";"))))
    connected = {unit: factor for unit, factor in ds.RD_MULTI_GLSK_FACTORS if unit != ds.KARNAN_G3}
    assert factors == pytest.approx({unit: factor / sum(connected.values()) for unit, factor in connected.items()})
    assert _log_lines(ac, "not connected, excluded from the redispatch and redistributed", ds.KARNAN_G3)


def test_the_per_tso_ra_count_limit(ac):
    row = next(r for r in _rows(ac, "tso_limits.csv") if r["tso"] == "TSO-Galia")
    assert float(row["ra_count_max"]) == GALIA_RA_LIMIT and float(row["ra_count"]) <= GALIA_RA_LIMIT

