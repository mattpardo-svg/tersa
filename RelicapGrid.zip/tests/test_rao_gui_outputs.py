"""tests/test_rao_gui_outputs.py - what the GUI shows of a run: the run folder of the CGM time and the output files in it.

Sections: the CGM time and the run folder, reading one file (a missing file is not an error), the Main page shows each
file with its columns, nothing of the old file names is left in the GUI code.
"""

import datetime
import io
import re
import sys
import zipfile
from pathlib import Path

import pytest

from helpers import REPO_ROOT, _MOCK_NX_CGM_ZIP, _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs
from post_milp import run_outputs
from text_encoding import TEXT_ENCODING

UTC = datetime.timezone.utc
HEADER = '<?xml version="1.0"?><rdf:RDF><md:FullModel rdf:about="urn:uuid:x"><md:Model.scenarioTime>{time}</md:Model.scenarioTime></md:FullModel></rdf:RDF>'


def _modules():
    pytest.importorskip("streamlit")
    pages = str(REPO_ROOT / "src" / "rao_pages")
    if pages not in sys.path:
        sys.path.insert(0, pages)
    import _gui_common
    import _output_view
    return _gui_common, _output_view


def _page(name="1_Main.py"):
    pytest.importorskip("streamlit")
    from streamlit.testing.v1 import AppTest
    return AppTest.from_file(str(REPO_ROOT / "src" / "rao_pages" / name), default_timeout=60)


def _zip(files: dict) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        for name, text in files.items():
            archive.writestr(name, text)
    return buffer.getvalue()


# ---------------------------------------------------------------------------
# the CGM time and the run folder
# ---------------------------------------------------------------------------

def test_the_scenario_time_is_read_from_the_cgm_header_without_loading_the_network():
    _, view = _modules()
    moment = view.scenario_time_from_cgm(_MOCK_NX_CGM_ZIP.read_bytes())
    assert moment == datetime.datetime(2022, 6, 16, 23, 30, tzinfo=UTC)
    assert view.run_folder_name(moment) == "20220616T2330Z"


def test_the_folder_name_of_the_gui_is_the_folder_the_pipeline_writes(tmp_path):
    """The mock run writes output/<CGM time>/: the GUI finds the same name from the CGM package alone."""
    _, view = _modules()
    run = run_pipeline_on_fixture_inputs(tmp_path, _MOCK_NX_NCP_ZIP, enable_nx_analysis=False)
    assert run.output_dir.name == view.run_folder_name(view.scenario_time_from_cgm(_MOCK_NX_CGM_ZIP.read_bytes()))


def test_a_time_with_an_offset_is_converted_to_utc_in_the_folder_name():
    _, view = _modules()
    moment = view.scenario_time_from_cgm(_zip({"a_EQ_1.xml": HEADER.format(time="2025-05-06T02:30:00+02:00")}))
    assert view.run_folder_name(moment) == "20250506T0030Z"


def test_the_state_variable_file_gives_the_time_when_the_files_differ():
    _, view = _modules()
    files = {
        "a_EQ_1.xml": HEADER.format(time="2025-05-06T00:30:00Z"), "b_EQ_1.xml": HEADER.format(time="2025-05-06T00:30:00Z"),
        "c_SV_1.xml": HEADER.format(time="2025-05-06T01:30:00Z"),
    }
    assert view.run_folder_name(view.scenario_time_from_cgm(_zip(files))) == "20250506T0130Z"
    del files["c_SV_1.xml"]
    assert view.run_folder_name(view.scenario_time_from_cgm(_zip(files))) == "20250506T0030Z"       # the most common time


@pytest.mark.parametrize("content", [b"not a zip", _zip({"a_EQ_1.xml": "<x/>"}), _zip({})])
def test_a_cgm_without_a_scenario_time_gives_none(content):
    _, view = _modules()
    assert view.scenario_time_from_cgm(content) is None


def test_a_missing_run_folder_says_there_is_no_run_for_this_cgm_time_yet(tmp_path):
    _, view = _modules()
    folder, message = view.find_run_folder(tmp_path, datetime.datetime(2025, 5, 6, 0, 30, tzinfo=UTC))
    assert folder is None and "no run for this CGM time yet" in message and "20250506T0030Z" in message


def test_the_run_folder_of_the_cgm_time_is_found_and_no_other_folder_is_taken(tmp_path):
    _, view = _modules()
    (tmp_path / "20250506T0030Z").mkdir()
    (tmp_path / "20250506T0130Z").mkdir()
    folder, message = view.find_run_folder(tmp_path, datetime.datetime(2025, 5, 6, 0, 30, tzinfo=UTC))
    assert folder == tmp_path / "20250506T0030Z" and message == ""
    assert view.find_run_folder(tmp_path, None)[0] is None


def test_the_temporary_folder_of_a_gui_run_holds_only_the_inputs_and_the_run_config_and_is_removed_whole(tmp_path):
    gui, _ = _modules()
    tmpdir = gui.build_temp_run_dir(b"cgm", b"ncp", gui.DEFAULT_RAO_CONFIG, gui.DEFAULT_LOAD_FLOW_CONFIG)
    try:
        assert sorted(p.name for p in tmpdir.iterdir()) == ["config", "input"]
        assert sorted(p.name for p in (tmpdir / "config").iterdir()) == ["load_flow_config.yaml", "rao_config.yaml"]
        assert (tmpdir / "input" / "cgm_package.zip").read_bytes() == b"cgm"
    finally:
        gui.cleanup_temp_run_dir(tmpdir)
    assert not tmpdir.exists()


def test_a_gui_run_of_the_pipeline_leaves_its_run_folder_in_the_output_base(tmp_path):
    """The pipeline runs as the GUI starts it (src/rao/run_pipeline.py as a subprocess, its locations given by the environment) and writes output/<CGM time>/ into the
    output base; the folder is there after the temporary folder is removed."""
    gui, view = _modules()
    base = tmp_path / "base"
    tmpdir = gui.build_temp_run_dir(
        _MOCK_NX_CGM_ZIP.read_bytes(), _MOCK_NX_NCP_ZIP.read_bytes(), gui.DEFAULT_RAO_CONFIG, gui.DEFAULT_LOAD_FLOW_CONFIG,
    )
    try:
        lines = list(gui.run_pipeline_subprocess(tmpdir, output_base=base))
    finally:
        gui.cleanup_temp_run_dir(tmpdir)
    assert lines[-1] == "__RAO_GUI_PROCESS_EXIT_CODE__:0"
    moment = view.scenario_time_from_cgm(_MOCK_NX_CGM_ZIP.read_bytes())
    folder, message = view.find_run_folder(base, moment)
    assert folder is not None and message == ""
    assert (folder / "summary.csv").is_file() and (folder / "run_log.txt").is_file()


def test_the_gui_has_no_copy_of_a_run_folder():
    gui, _ = _modules()
    assert not hasattr(gui, "publish_run_output") and not hasattr(gui, "output_roots")


# ---------------------------------------------------------------------------
# reading one file
# ---------------------------------------------------------------------------

def test_a_missing_file_is_not_written_in_this_run_and_raises_nothing(tmp_path):
    _, view = _modules()
    assert view.read_output_file(tmp_path, "ct_results.csv") == (None, "not written in this run")
    assert view.read_output_file(None, "ct_results.csv") == (None, "not written in this run")
    assert view.read_header(tmp_path, "ct_results.csv") == []


def test_a_file_is_read_with_its_columns_in_the_order_and_names_of_the_file(tmp_path):
    _, view = _modules()
    header = run_outputs.HEADERS["loadings_n0.csv"]
    (tmp_path / "loadings_n0.csv").write_text(",".join(header) + "\n" + ",".join("1" for _ in header) + "\n", encoding=TEXT_ENCODING)
    rows, message = view.read_output_file(tmp_path, "loadings_n0.csv")
    assert message == "" and len(rows) == 1 and list(rows[0]) == header
    assert view.read_header(tmp_path, "loadings_n0.csv") == header


def test_every_output_file_of_the_spec_is_in_a_group_of_the_view():
    _, view = _modules()
    shown = {name for files in view.FILE_GROUPS.values() for name, _ in files}
    assert shown == set(run_outputs.HEADERS)


# ---------------------------------------------------------------------------
# the Main page
# ---------------------------------------------------------------------------

def _main_page_with_run(tmp_path, monkeypatch, files: dict):
    """The Main page with the mock CGM loaded and a run folder in output/ that holds only `files` {name: row count}."""
    gui, view = _modules()
    moment = view.scenario_time_from_cgm(_MOCK_NX_CGM_ZIP.read_bytes())
    if files is not None:
        folder = tmp_path / view.run_folder_name(moment)
        folder.mkdir(parents=True)
        for name, count in files.items():
            header = run_outputs.HEADERS[name]
            body = "".join(",".join(["1.5"] * len(header)) + "\n" for _ in range(count))
            (folder / name).write_text(",".join(header) + "\n" + body, encoding=TEXT_ENCODING)
    monkeypatch.setattr(gui, "OUTPUT_ROOT", tmp_path)
    page = _page()
    page.session_state["cgm_bytes"] = _MOCK_NX_CGM_ZIP.read_bytes()
    page.session_state["cgm_time"] = moment
    return page


def test_the_main_page_shows_no_run_for_this_cgm_time_yet_when_the_folder_is_missing(tmp_path, monkeypatch):
    page = _main_page_with_run(tmp_path, monkeypatch, None)
    page.run()
    assert not page.exception
    assert any("no run for this CGM time yet" in info.value for info in page.info)


def test_the_main_page_shows_the_cgm_time_and_its_folder_without_a_folder_picker(tmp_path, monkeypatch):
    page = _main_page_with_run(tmp_path, monkeypatch, None)
    page.run()
    assert any("output/20220616T2330Z/" in caption.value for caption in page.caption)
    assert not any("folder" in (widget.label or "").lower() for widget in page.text_input)


@pytest.mark.parametrize("name", sorted(run_outputs.HEADERS))
def test_each_file_is_shown_with_its_own_columns_and_the_others_say_not_written(tmp_path, monkeypatch, name):
    page = _main_page_with_run(tmp_path, monkeypatch, {name: 2})
    page.run()
    assert not page.exception
    frames = [frame.value for frame in page.dataframe]
    assert [list(frame.columns) for frame in frames] == [run_outputs.HEADERS[name]]          # names and units as in the file
    assert len(frames[0]) == 2
    not_written = [info for info in page.info if info.value == "not written in this run"]
    assert len(not_written) == len(run_outputs.HEADERS) - 1


def test_a_run_folder_without_files_shows_not_written_for_every_file(tmp_path, monkeypatch):
    page = _main_page_with_run(tmp_path, monkeypatch, {})
    page.run()
    assert not page.exception
    assert len([info for info in page.info if info.value == "not written in this run"]) == len(run_outputs.HEADERS)


def test_the_inventory_after_a_run_counts_the_rows_of_the_input_files(tmp_path):
    gui, _ = _modules()
    (tmp_path / "pst_ra.csv").write_text("a\n1\n2\n", encoding=TEXT_ENCODING)
    inventory = gui.read_tier2_inventory(tmp_path)
    assert inventory == {
        "monitored_branches": 0, "contingencies": 0, "pst_ras": 2, "rd_bids": 0, "ct_bids": 0, "hvdc_ras": 0,
    }


def test_the_gui_code_uses_none_of_the_removed_file_names():
    removed = [
        "lf_basecase", "lf_post_n0", "lf_nx_initial", "results_pst", "results_preventive_rd", "results_summary", "results_hvdc",
        "results_countertrade", "results_curative", "results_net_positions", "results_zone_exchange", "results_tso_tap_limits",
        "results_nx_loadings", "results_iteration_history", "co_flat_list", "scanned_element_list", "tatl_data",
        "glsk_resolved", "write_nx_sensitivity_csvs",
    ]
    found = []
    for path in sorted((REPO_ROOT / "src" / "rao_pages").glob("*.py")):
        text = path.read_text(encoding=TEXT_ENCODING)
        found += [f"{path.name}: {name}" for name in removed if re.search(rf"\b{name}", text)]
    assert found == []
