"""tests/test_rao_empty_glsk_causes.py - a bid whose GLSK has no unit in the model: the cause is named, one summary per cause
(bids, RAs, first 5 ids; all at DEBUG), and an RA id that differs only in form or case from the GLSK key still finds its GLSK."""

import logging

import pyomo.environ as pyo

from data_model import AEType, AssessedElement, BidDirection, PowerBid, RAKind, RDUnit
from milp.milp_builder import RdMilpInputs, build_n0_milp_model

TS = "1030Z"
UNIT = {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "u"}


def _ae():
    return AssessedElement(mrid="ae", name="ae", tso="T", ae_type=AEType.SECURED, branch_mrid="BR", secured_for_region=None,
                           scanned_for_region=None, exclusion_reason=None, patl_ka={TS: 1.0}, branch_side=1)


def _rd(mrid, unit="GU1"):
    return RDUnit(mrid=mrid, name=mrid, tso="T", gu_mrid=unit, gu_name=unit, available=True, kind=RAKind.PREVENTIVE,
                  initial_p=50.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None)


def _bid(mrid, ra):
    return PowerBid(mrid=mrid, ra_mrid=ra, direction=BidDirection.UP, available_mw={TS: 20.0}, price_eur_mw=10.0,
                    lead_time_h=0.0, activation_cost_eur=None)


def _build(glsk, bids, rds, generator_data=None):
    inputs = RdMilpInputs(
        rd_list=rds, bid_list=bids, glsk=glsk, sensitivity_rd_n0_pruned={("BR", "GU1"): -10.0},
        generator_data=generator_data if generator_data is not None else {"GU1": dict(UNIT)}, penalty_reference_rd_pra=5.0)
    return build_n0_milp_model([_ae()], TS, {"BR": {1: 500.0}}, 1000.0, rd_inputs=inputs)


def _lines(caplog):
    return [r.getMessage() for r in caplog.records if "GLSK" in r.getMessage() and "no generating unit" in r.getMessage()]


def test_rao_each_cause_has_one_summary_with_its_bids_and_ras(caplog):
    rds = [_rd("RA_OK")] + [_rd(f"RA_NOKEY{i}") for i in range(7)] + [_rd("RA_EMPTY"), _rd("RA_NODATA", "GU9")]
    bids = [_bid("B_OK", "RA_OK")] + [_bid(f"B_NOKEY{i}", f"RA_NOKEY{i}") for i in range(7)] + [
        _bid("B_EMPTY", "RA_EMPTY"), _bid("B_NODATA", "RA_NODATA")]
    glsk = {"RA_OK": {"GU1": 1.0}, "RA_EMPTY": {}, "RA_NODATA": {"GU9": 1.0}}
    with caplog.at_level(logging.DEBUG):
        model = _build(glsk, bids, rds)
    lines = _lines(caplog)
    assert len(lines) == 3, lines
    no_key = next(m for m in lines if "no GLSK entry" in m)
    assert "7 bid(s)" in no_key and "7 RA(s)" in no_key and "B_NOKEY0" in no_key and "B_NOKEY5" not in no_key and "2 more" in no_key
    assert any("empty after resolution" in m and "1 bid(s)" in m and "B_EMPTY" in m for m in lines)
    assert any("not in the generator data" in m and "B_NODATA" in m for m in lines)
    assert pyo.value(model.rd_volume_upward["B_OK"].ub) == 20.0
    assert all(pyo.value(model.rd_volume_upward[b].ub) == 0.0 for b in ("B_EMPTY", "B_NODATA", "B_NOKEY0"))
    assert "B_NOKEY5" in " ".join(r.getMessage() for r in caplog.records if r.levelno == logging.DEBUG)

