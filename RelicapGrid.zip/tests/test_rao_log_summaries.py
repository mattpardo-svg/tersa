"""tests/test_rao_log_summaries.py - one summary line (count and first 5 ids, all ids at DEBUG) for the per-item warnings."""

import logging

import pandas as pd

from pre_milp import cgmes_loader


class _Network:
    def __init__(self, steps):
        self._steps = steps

    def get_phase_tap_changer_steps(self):
        return self._steps


def test_non_uniform_tap_steps_give_one_summary_with_the_first_5_ids(caplog):
    ids = [f"PST-{i}" for i in range(8)]
    steps = pd.DataFrame(
        {"alpha": [0.0, 1.0, 3.0] * len(ids)},                     # steps 1 and 2 degrees apart: not uniform
        index=pd.Index([pst for pst in ids for _ in range(3)], name="id"),
    )
    with caplog.at_level(logging.DEBUG):
        result = cgmes_loader.build_pst_degrees_per_tap(_Network(steps), ids)
    assert len(result) == 8
    warnings = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warnings) == 1 and "8 PST(s)" in warnings[0] and "not uniformly spaced" in warnings[0]
    assert "PST-4" in warnings[0] and "PST-5" not in warnings[0] and "3 more" in warnings[0]
    assert "PST-7" in " ".join(r.getMessage() for r in caplog.records if r.levelno == logging.DEBUG)
