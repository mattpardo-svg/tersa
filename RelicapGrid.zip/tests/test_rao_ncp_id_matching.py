"""tests/test_rao_ncp_id_matching.py - a bid and a shift key find their remedial action whatever the form of the id
(rdf:ID, rdf:about, IdentifiedObject.mRID; "#", "#__", "urn:uuid:", any case). Small hand-written files, synthetic ids."""

import itertools
import logging

import pytest

from pre_milp import ncp_parser
from text_encoding import TEXT_ENCODING

HEADER = ('<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:nc="https://cim4.eu/ns/nc#">')
NC_NS = "https://cim4.eu/ns/nc#"
UUID = "0a1b2c3d-0000-4000-8000-00000000abcd"

REFERENCES = {
    "hash-underscore": f"#_{UUID}", "hash-two-underscores": f"#__{UUID}", "urn": f"urn:uuid:{UUID}",
    "hash-plain": f"#{UUID}", "hash-upper": f"#_{UUID.upper()}", "urn-upper": f"urn:uuid:{UUID.upper()}",
}
REMEDIAL_ACTIONS = {
    "rdf-id": (f'rdf:ID="_{UUID}"', ""),
    "rdf-about": (f'rdf:about="#_{UUID}"', ""),
    "mrid-only": ('rdf:ID="_other-id"', f"<cim:IdentifiedObject.mRID>{UUID}</cim:IdentifiedObject.mRID>"),
    "mrid-upper": (f'rdf:ID="_{UUID.upper()}"', f"<cim:IdentifiedObject.mRID>{UUID.upper()}</cim:IdentifiedObject.mRID>"),
}


def _ra_xml(attribute, mrid_xml):
    return (f'<nc:RedispatchRemedialAction {attribute}>{mrid_xml}'
            '<nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>'
            '</nc:RedispatchRemedialAction>')


def _sis_xml(reference):
    return (
        '<nc:PowerBidSchedule rdf:ID="_BID1"><cim:IdentifiedObject.mRID>BID1</cim:IdentifiedObject.mRID>'
        f'<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="{reference}"/>'
        f'<nc:PowerBidSchedule.direction rdf:resource="{NC_NS}BidDirectionKind.up"/>'
        f'<nc:BaseTimeSeries.interpolationKind rdf:resource="{NC_NS}InterpolationKind.none"/></nc:PowerBidSchedule>'
        '<nc:PowerBidScheduleTimePoint rdf:ID="_P1"><nc:PowerBidScheduleTimePoint.atTime>2024-02-22T10:30:00Z</nc:PowerBidScheduleTimePoint.atTime>'
        '<nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_BID1"/>'
        '<nc:PowerBidScheduleTimePoint.p>50</nc:PowerBidScheduleTimePoint.p>'
        '<nc:PowerBidScheduleTimePoint.price>9</nc:PowerBidScheduleTimePoint.price></nc:PowerBidScheduleTimePoint>'
        '<nc:PowerShiftKeySchedule rdf:ID="_KEY1"><cim:IdentifiedObject.mRID>KEY1</cim:IdentifiedObject.mRID>'
        '<nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_UNIT1"/></nc:PowerShiftKeySchedule>'
        '<nc:PowerShiftKeyDistribution rdf:ID="_D1"><nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_BID1"/>'
        '<nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_KEY1"/></nc:PowerShiftKeyDistribution>'
    )


def _files(tmp_path, reference, ra_form):
    attribute, mrid_xml = REMEDIAL_ACTIONS[ra_form]
    ra_path, sis_path = tmp_path / "X_RA.xml", tmp_path / "X_SIS.xml"
    ra_path.write_text(HEADER + _ra_xml(attribute, mrid_xml) + "</rdf:RDF>", encoding=TEXT_ENCODING)
    sis_path.write_text(HEADER + _sis_xml(reference) + "</rdf:RDF>", encoding=TEXT_ENCODING)
    return ra_path, sis_path


def _ra_mrid(ra_path):
    graph = ncp_parser._load_graph(ra_path)
    (subject,) = graph.subjects(ncp_parser.RDF.type, ncp_parser.NC.RedispatchRemedialAction)
    literal = graph.value(subject, ncp_parser.CIM["IdentifiedObject.mRID"])
    return ncp_parser.ncp_id(literal) if literal is not None else ncp_parser._frag(str(subject))


@pytest.mark.parametrize("reference_form,ra_form", list(itertools.product(REFERENCES, REMEDIAL_ACTIONS)))
def test_rao_a_bid_finds_its_remedial_action_in_every_id_form(tmp_path, reference_form, ra_form):
    ra_path, sis_path = _files(tmp_path, REFERENCES[reference_form], ra_form)
    mrid = _ra_mrid(ra_path)
    bids = ncp_parser.parse_power_bids(
        ncp_parser._load_graph(sis_path), {mrid}, "X", "1030Z", ra_graph=ncp_parser._load_graph(ra_path))
    assert [(b.mrid, b.ra_mrid) for b in bids] == [("BID1", mrid)]


@pytest.mark.parametrize("reference_form,ra_form", list(itertools.product(REFERENCES, REMEDIAL_ACTIONS)))
def test_rao_a_shift_key_route_finds_its_remedial_action_in_every_id_form(tmp_path, reference_form, ra_form):
    ra_path, sis_path = _files(tmp_path, REFERENCES[reference_form], ra_form)
    mrid = _ra_mrid(ra_path)
    by_bid, _ = ncp_parser.read_key_routes(
        ncp_parser._load_graph(sis_path), ncp_parser._load_graph(ra_path), {mrid})
    assert by_bid[mrid] == {"KEY1"}


@pytest.mark.parametrize("reference_form,ra_form", list(itertools.product(REFERENCES, REMEDIAL_ACTIONS)))
def test_rao_no_false_unmatched_warning_in_any_id_form(tmp_path, caplog, reference_form, ra_form):
    ra_path, sis_path = _files(tmp_path, REFERENCES[reference_form], ra_form)
    with caplog.at_level(logging.WARNING):
        unmatched = ncp_parser.warn_unmatched_ra_references(ra_path, sis_path, "X")
    assert unmatched == []


def test_rao_a_reference_to_another_id_is_still_unmatched(tmp_path):
    ra_path, sis_path = _files(tmp_path, "#_something-else", "rdf-id")
    assert len(ncp_parser.warn_unmatched_ra_references(ra_path, sis_path, "X")) == 1


def test_rao_id_key_removes_uri_hash_urn_underscores_and_case():
    key = ncp_parser.id_key
    assert key("http://example.test/base#__AbC") == key("urn:uuid:abc") == key("#_abc") == key("ABC") == "abc"
    assert key("RA_1") == "ra_1"                              # an underscore inside the id stays
