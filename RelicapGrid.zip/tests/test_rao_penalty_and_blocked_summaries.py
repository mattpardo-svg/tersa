"""tests/test_rao_penalty_and_blocked_summaries.py - one summary line (count and first 5 ids) for the countertrade and HVDC RAs
without a penaltyFactor and for the preventive bids blocked by a unit that is off. Small synthetic files."""

import logging

from data_model import AEType, AssessedElement, BidDirection, PowerBid, RAKind, RDUnit
from milp.milp_builder import RdMilpInputs, build_n0_milp_model
from pre_milp import ct_units, ncp_parser
from text_encoding import TEXT_ENCODING

HEADER = ('<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:nc="https://cim4.eu/ns/nc#">')


def _ct_ra(index):
    return (f'<nc:CountertradeRemedialAction rdf:ID="_C{index}"><cim:IdentifiedObject.mRID>C{index}</cim:IdentifiedObject.mRID>'
            '<nc:PowerRemedialAction.BiddingZone rdf:resource="#_ZONE"/></nc:CountertradeRemedialAction>')


def _hvdc_ra(index):
    return (f'<nc:GridStateAlterationRemedialAction rdf:ID="_H{index}"><cim:IdentifiedObject.mRID>H{index}</cim:IdentifiedObject.mRID>'
            '</nc:GridStateAlterationRemedialAction>'
            f'<nc:EquivalentInjectionAction rdf:ID="_A{index}">'
            f'<nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_H{index}"/>'
            f'<nc:EquivalentInjectionAction.EquivalentInjection rdf:resource="#_EI{index}"/></nc:EquivalentInjectionAction>')


def _write(tmp_path, body):
    path = tmp_path / "X_RA.xml"
    path.write_text(HEADER + body + "</rdf:RDF>", encoding=TEXT_ENCODING)
    return path


def _warnings(caplog, text):
    return [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING and text in r.getMessage()]


def test_rao_countertrade_ras_without_a_penalty_factor_give_one_summary(tmp_path, caplog):
    path = _write(tmp_path, "".join(_ct_ra(i) for i in range(1, 8)))
    with caplog.at_level(logging.DEBUG):
        ras, _ = ct_units.parse_ct_remedial_actions(path, None, "X", "1030Z")
    assert len(ras) == 7
    (line,) = _warnings(caplog, "no RemedialAction.penaltyFactor")
    assert "7 countertrade RA(s)" in line and "C1, C2, C3, C4, C5 and 2 more" in line


def test_rao_hvdc_ras_without_a_penalty_factor_give_one_summary(tmp_path, caplog):
    path = _write(tmp_path, "".join(_hvdc_ra(i) for i in range(1, 8)))
    with caplog.at_level(logging.DEBUG):
        units = ncp_parser.parse_hvdc_units(path, "X")
    assert len(units) == 7
    (line,) = _warnings(caplog, "no RemedialAction.penaltyFactor")
    assert "7 HVDC remedial action(s)" in line and "H1, H2, H3, H4, H5 and 2 more" in line


def test_rao_blocked_preventive_bids_give_one_summary(caplog):
    ts = "1030Z"
    ae = AssessedElement(mrid="ae", name="ae", tso="T", ae_type=AEType.SECURED, branch_mrid="BR", secured_for_region=None,
                         scanned_for_region=None, exclusion_reason=None, patl_ka={ts: 1.0}, branch_side=1)
    rds = [RDUnit(mrid=f"RA{i}", name=f"RA{i}", tso="T", gu_mrid=f"GU{i}", gu_name=f"GU{i}", available=True, kind=RAKind.PREVENTIVE,
                  initial_p=0.0, max_p=100.0, min_p=10.0, raise_ramp_rate=None, lower_ramp_rate=None) for i in range(1, 8)]
    bids = [PowerBid(mrid=f"B{i}", ra_mrid=f"RA{i}", direction=BidDirection.UP, available_mw={ts: 5.0}, price_eur_mw=1.0,
                     lead_time_h=0.0, activation_cost_eur=None) for i in range(1, 8)]
    inputs = RdMilpInputs(
        rd_list=rds, bid_list=bids, glsk={f"RA{i}": {f"GU{i}": 1.0} for i in range(1, 8)},
        sensitivity_rd_n0_pruned={("BR", f"GU{i}"): -1.0 for i in range(1, 8)},
        generator_data={f"GU{i}": {"target_p": 0.0, "max_p": 100.0, "min_p": 10.0, "name": f"GU{i}"} for i in range(1, 8)})
    with caplog.at_level(logging.INFO):
        build_n0_milp_model([ae], ts, {"BR": {1: 500.0}}, 1000.0, rd_inputs=inputs)
    lines = [r.getMessage() for r in caplog.records if "blocked (volume 0)" in r.getMessage()]
    assert len(lines) == 1, lines                       # all seven have the same reason
    assert lines[0].startswith("7 Preventive bid(s)") and "B1, B2, B3, B4, B5 and 2 more" in lines[0]
    assert "no start-up cost" in lines[0]
