"""
Equivalence harness for the NCP 2.2 legacy form (docs/specs/ncp_data_requirements.md section 13): the mock written by
tests/mock_builders/legacy_writer.py is parsed with the current readers and compared, section by section, with the
parsed shipped mock (same data, current form).

Intended differences, compared explicitly:
  files          SHS only in the current mock (the legacy form has none); ER only in the legacy mock (header only);
                 the TSO name is the creator EIC (no organisation file)
  pst            the first Belgovia PST RA of the legacy mock has a second TapPositionAction (one group of two)
  countertrade   strategy values of the legacy RAs are ignored (L5)
  bids           the legacy bids of the first TSO have no direction: it comes from the name suffix (L3)
  unused         SSI, IAM, PS and topology RAs are not read (L8): one info line per profile / RA file
Every section passes.
"""
import dataclasses
import io
import zipfile

import pytest
from rdflib import Graph, RDF, Namespace

from mock_builders import legacy_writer as legacy_form
from mock_builders import standard
from helpers import _MOCK_NX_CGM_ZIP

NC = Namespace("https://cim4.eu/ns/nc#")
TS = "1030Z"
COUNTRY_OF_EIC = {eic: country for country, eic in legacy_form.EIC_BY_TSO.items()}
COUNTRIES = list(legacy_form.EIC_BY_TSO)


def _extract(files, folder):
    folder.mkdir(parents=True, exist_ok=True)
    for name, data in files.items():
        (folder / name).write_bytes(data)
    return folder


@pytest.fixture(scope="module")
def current(tmp_path_factory):
    return _extract(standard.shipped_files(), tmp_path_factory.mktemp("current_form"))


@pytest.fixture(scope="module")
def legacy(tmp_path_factory):
    return _extract(legacy_form.legacy_files(), tmp_path_factory.mktemp("legacy_form"))


def _cur(current, country, profile):
    return current / f"{country}_{profile}.xml"


def _graph(path):
    """The graph of an NCP file as the parser reads it (the legacy namespaces rewritten to the current ones)."""
    from pre_milp import ncp_parser

    return ncp_parser._load_graph(path)


def _ordered(items):
    """The parsed objects in a fixed order, their lists of ids too: rdflib lists the subjects of a type in hash order, which
    depends on their URIs."""
    def fixed(item):
        lists = {f.name: sorted(getattr(item, f.name)) for f in dataclasses.fields(item) if isinstance(getattr(item, f.name), list)}
        return dataclasses.replace(item, **lists)

    return sorted((fixed(item) for item in items), key=lambda item: (item.mrid, item.name, str(getattr(item, "kind", ""))))


def _raw_graph(path):
    """The graph of an NCP file with the namespaces of the current form but the legacy shift key chain as written."""
    from pre_milp import ncp_parser

    return ncp_parser._use_current_namespaces(Graph().parse(str(path), format="xml"))


def _leg(legacy, country, profile):
    return legacy / legacy_form.file_name(country, profile)


def _label(country):
    return f"TSO-{country}"


# ---------------------------------------------------------------------------
# files: profile from the header, TSO from the creator EIC
# ---------------------------------------------------------------------------

def _classified_legacy(legacy):
    from pre_milp import ncp_loader

    return ncp_loader.classify_extracted_ncp_files(legacy, {})


def _classified_current(current):
    from pre_milp import ncp_loader, tso_name_resolver

    return ncp_loader.classify_extracted_ncp_files(current, tso_name_resolver.build_tso_name_map(current / "Org-NineRealms_CD.xml"))


def test_rao_legacy_files_are_classified_like_the_current_files(legacy, current):
    old, new = _classified_current(current).by_label(), _classified_legacy(legacy).by_label()
    assert sorted(new) == sorted(legacy_form.EIC_BY_TSO.values())
    for country, eic in legacy_form.EIC_BY_TSO.items():
        current_profiles = set(old[_label(country)]) - {"SHS"}
        legacy_profiles = set(new[eic]) - {"ER"}
        assert legacy_profiles == current_profiles
        assert [p.name for p in new[eic]["ER"]] == [legacy_form.file_name(country, "ER")]
        assert {profile: [p.name for p in paths] for profile, paths in new[eic].items()} == \
            {profile: [legacy_form.file_name(country, profile)] for profile in new[eic]}


# ---------------------------------------------------------------------------
# AE and CO: unchanged content, must pass today
# ---------------------------------------------------------------------------

def test_rao_legacy_assessed_elements_are_equal(legacy, current):
    from pre_milp import ncp_parser

    for country in COUNTRIES:
        old = ncp_parser.parse_assessed_elements(_cur(current, country, "AE"), None, _label(country), TS, {})
        new = ncp_parser.parse_assessed_elements(_leg(legacy, country, "AE"), None, _label(country), TS, {})
        assert old and _ordered(new) == _ordered(old)


def test_rao_legacy_contingencies_are_equal(legacy, current):
    from pre_milp import ncp_parser

    for country in COUNTRIES:
        g = Graph().parse(str(_cur(current, country, "CO")), format="xml", publicID="urn:ncp")
        equipment = {str(o).rsplit("#", 1)[-1].lstrip("_"): "line" for o in g.objects(None, Namespace("https://cim.ucaiug.io/ns#")["ContingencyEquipment.Equipment"])}
        old = ncp_parser.parse_contingencies(_cur(current, country, "CO"), _label(country), TS, equipment)
        new = ncp_parser.parse_contingencies(_leg(legacy, country, "CO"), _label(country), TS, equipment)
        assert old and _ordered(new) == _ordered(old)


# ---------------------------------------------------------------------------
# PST (L9): no change in the reader; several actions of one RA are a group
# ---------------------------------------------------------------------------

def _tap_changers(path):
    g = _graph(path)
    return {str(o).rsplit("#", 1)[-1].lstrip("_") for o in g.objects(None, NC["TapPositionAction.TapChanger"])}


def _psts(path, label):
    from pre_milp import ncp_parser

    changers = _tap_changers(path)
    return ncp_parser.parse_psts(path, label, {f"T_{c}": {"low_tap": -16, "high_tap": 16, "tap": 0} for c in changers},
                                 {c: f"T_{c}" for c in changers})


def test_rao_legacy_psts_are_equal_except_the_two_action_ra(legacy, current):
    for country in COUNTRIES:
        old = _ordered(_psts(_cur(current, country, "RA"), _label(country)))
        new = _ordered(_psts(_leg(legacy, country, "RA"), _label(country)))
        grouped = [p for p in new if p.group_id is not None]
        if country != legacy_form.PST_TWO_ACTIONS_TSO:
            assert new == old and not grouped
            continue
        assert len(grouped) == 2 and len({p.group_id for p in grouped}) == 1
        assert len(new) == len(old)                                  # the second PST RA is merged into the first
        assert {p.mrid for p in new} == {p.mrid for p in old}
        grouped_mrids = {p.mrid for p in grouped}
        assert [p for p in new if p.mrid not in grouped_mrids] == [p for p in old if p.mrid not in grouped_mrids]
        by_mrid = {p.mrid: p for p in old}
        for p in grouped:                                            # the group takes kind and timing of the first RA
            assert (p.low_step, p.high_step, p.r0) == (by_mrid[p.mrid].low_step, by_mrid[p.mrid].high_step, by_mrid[p.mrid].r0)

def test_rao_legacy_topology_ra_is_no_pst(legacy):
    new = _psts(_leg(legacy, legacy_form.TOPOLOGY_TSO, "RA"), _label(legacy_form.TOPOLOGY_TSO))
    assert "PRA_TOPO_MOCK_SWITCH" not in {p.name for p in new}


# ---------------------------------------------------------------------------
# bids, shift keys, redispatch units, countertrade: the readers come later
# ---------------------------------------------------------------------------

def _generators_by_unit():
    from mock_builders import ncp_xml as conv

    result = {}
    for machine, unit in conv.generating_unit_by_machine(conv._read_zip(_MOCK_NX_CGM_ZIP))[0].items():
        result.setdefault(unit, []).append(machine)
    return result


def _sorted_lists(item):
    """The item with its list fields sorted (rdflib lists subjects in hash order)."""
    return dataclasses.replace(item, **{f.name: sorted(getattr(item, f.name)) for f in dataclasses.fields(item) if isinstance(getattr(item, f.name), list)})


def _rd(directory, path_of):
    from pre_milp import ncp_parser

    machines = {m for ms in _generators_by_unit().values() for m in ms}
    gens = {m: {"name": m, "target_p": 10.0, "max_p": 100.0, "min_p": 0.0} for m in machines}
    units, bids = [], []
    for country in COUNTRIES:
        u, b = ncp_parser.parse_rd_units(path_of(directory, country, "RA"), path_of(directory, country, "SIS"), _label(country), TS,
                                         gens, generators_by_unit=_generators_by_unit())
        units += [_sorted_lists(dataclasses.replace(x, raise_ramp_rate=None, lower_ramp_rate=None)) for x in u]
        bids += b
    return sorted(units, key=lambda x: (x.mrid, x.gu_mrid)), sorted(bids, key=lambda x: x.mrid)


def test_rao_legacy_redispatch_units_are_equal(legacy, current):
    old_units, _ = _rd(current, _cur)
    new_units, _ = _rd(legacy, _leg)
    assert len(old_units) == 32 and new_units == old_units


def _power_bids(directory, path_of):
    """The bids of every redispatch and countertrade RA of the RA file (whatever the units are)."""
    from pre_milp import ncp_parser

    bids = []
    for country in COUNTRIES:
        ras = {ncp_parser._frag(str(r)) for cls in (NC.RedispatchRemedialAction, NC.CountertradeRemedialAction)
               for r in _graph(path_of(directory, country, "RA")).subjects(RDF.type, cls)}
        bids += ncp_parser.parse_power_bids(_graph(path_of(directory, country, "SIS")), ras, _label(country), TS)
    return sorted(bids, key=lambda b: b.mrid)


def test_rao_legacy_bids_are_equal(legacy, current):
    old_bids, new_bids = _power_bids(current, _cur), _power_bids(legacy, _leg)
    assert len(old_bids) == 56 and new_bids == old_bids


def test_rao_legacy_glsk_is_equal(legacy, current):
    from pre_milp import glsk_resolver

    units_old, _ = _rd(current, _cur)
    units_new, _ = _rd(legacy, _leg)
    machines = {m for ms in _generators_by_unit().values() for m in ms}
    for country in COUNTRIES:
        resolve = lambda path_of, directory, units: glsk_resolver.resolve_glsk(      # noqa: E731
            path_of(directory, country, "SIS"), [u for u in units if u.tso == _label(country)], _label(country), machines, "1030Z",
            generators_by_unit=_generators_by_unit(), ra_path=path_of(directory, country, "RA"))
        old = resolve(_cur, current, units_old)
        assert old and resolve(_leg, legacy, units_new) == old


def _ct(directory, path_of):
    from pre_milp import ct_units

    ras, bids = [], []
    for country in COUNTRIES:
        r, b = ct_units.parse_ct_remedial_actions(path_of(directory, country, "RA"), path_of(directory, country, "SIS"), _label(country), TS)
        ras += r
        bids += [dataclasses.replace(x, name="") if hasattr(x, "name") else x for x in b]
    ras = [_sorted_lists(dataclasses.replace(r, zone_mrid='')) for r in ras]          # the zone is an EIC in the legacy form (L6), an id of the Organisation file in the current one
    return sorted(ras, key=lambda r: r.mrid), sorted(bids, key=lambda b: b.mrid)


def test_rao_legacy_countertrade_is_equal(legacy, current):
    old_ras, old_bids = _ct(current, _cur)
    new_ras, new_bids = _ct(legacy, _leg)
    assert len(old_ras) == 8 and (new_ras, new_bids) == (old_ras, old_bids)


def test_rao_legacy_countertrade_ras_carry_both_strategy_values_and_a_shift_method(legacy):
    g = _graph(_leg(legacy, "Belgovia", "RA"))
    ras = list(g.subjects(RDF.type, NC.CountertradeRemedialAction))
    strategies = sorted(str(g.value(r, NC["CountertradeRemedialAction.gLSKStrategy"])).rsplit(".", 1)[-1] for r in ras)
    assert strategies == ["explicitSchedule", "proportionalForGenerator"]
    assert all(g.value(r, NC["CountertradeRemedialAction.shiftMethod"]) is not None for r in ras)


# ---------------------------------------------------------------------------
# the form of the mock itself
# ---------------------------------------------------------------------------

def test_rao_legacy_mock_has_the_agreed_form(legacy):
    names = sorted(p.name for p in legacy.iterdir())
    assert names == sorted(legacy_form.file_name(c, p) for c in COUNTRIES for p in legacy_form.PROFILES)
    assert not any("CD" in n or "SHS" in n for n in names)
    sis = {c: _raw_graph(_leg(legacy, c, "SIS")) for c in COUNTRIES}
    for country, g in sis.items():
        assert not list(g.subjects(RDF.type, NC.PowerShiftKeySchedule)) and list(g.subjects(RDF.type, NC.GLSKSchedule))
        points = list(g.subjects(RDF.type, NC.ParticipationFactorTimePoint))
        assert points and all(g.value(p, NC["ParticipationFactorTimePoint.atTime"]) is None for p in points)
        for point in g.subjects(RDF.type, NC.PowerBidScheduleTimePoint):
            assert float(g.value(point, NC["PowerBidScheduleTimePoint.p"])) > 0
        directions = {str(g.value(b, NC["PowerBidSchedule.direction"])).rsplit("#", 1)[-1].split(".")[0]
                      if g.value(b, NC["PowerBidSchedule.direction"]) is not None else None
                      for b in g.subjects(RDF.type, NC.PowerBidSchedule)}
        expected = {legacy_form.NO_DIRECTION_TSO: {None}, legacy_form.BID_DIRECTION_KIND_TSO: {"BidDirectionKind"}}
        assert directions == expected.get(country, {"MarketRegulationDirectionKind"})
        names = [str(g.value(b, Namespace("https://cim.ucaiug.io/ns#")["IdentifiedObject.name"])) for b in g.subjects(RDF.type, NC.PowerBidSchedule)]
        if country == legacy_form.NO_DIRECTION_TSO:
            assert all(n.upper().endswith(("_UP", "_DOWN")) for n in names)


def test_rao_legacy_topology_ra_has_a_static_property_range_on_switch_open(legacy):
    g = _graph(_leg(legacy, legacy_form.TOPOLOGY_TSO, "RA"))
    ranges = list(g.subjects(RDF.type, NC.StaticPropertyRange))
    assert len(ranges) == 1 and str(g.value(ranges[0], NC["StaticPropertyRange.PropertyReference"])).endswith("Switch.open")
    assert len(list(g.subjects(RDF.type, NC.TopologyAction))) == 1


def test_rao_legacy_ssi_has_available_entries_and_iam_one_qualitative_impact(legacy):
    for country in COUNTRIES:
        ssi = _graph(_leg(legacy, country, "SSI"))
        assert list(ssi.subject_objects(NC["RemedialAction.available"]))
        iam = _graph(_leg(legacy, country, "IAM"))
        assert len(list(iam.subjects(RDF.type, NC.QualitativeRemedialActionImpact))) == 1
        for profile in ("PS", "ER"):
            assert not [s for s in _graph(_leg(legacy, country, profile)).subjects(RDF.type, None)
                        if "nc#" in str(s)]


def test_rao_legacy_headers_name_the_profile_and_the_creator(legacy):
    from rdflib import Namespace as N

    dcterms, dcat = N("http://purl.org/dc/terms/#"), N("http://www.w3.org/ns/dcat#")
    for country, eic in legacy_form.EIC_BY_TSO.items():
        for profile in legacy_form.PROFILES:
            g = _graph(_leg(legacy, country, profile))
            assert str(next(g.objects(None, dcat.keyword))) == profile
            assert str(next(g.objects(None, dcterms.creator))).rsplit("/", 1)[-1] == eic
            assert str(next(g.objects(None, dcterms.conformsTo))).startswith("http://entsoe.eu/ns/CIM/") \
                and str(next(g.objects(None, dcterms.conformsTo))).endswith("-EU/2.2")


# ---------------------------------------------------------------------------
# generator and CGM snippet
# ---------------------------------------------------------------------------

def test_rao_legacy_converter_section_is_deterministic(tmp_path):
    first, second = legacy_form.build_legacy(tmp_path / "one.zip"), legacy_form.build_legacy(tmp_path / "two.zip")
    assert first.read_bytes() == second.read_bytes()
    assert legacy_form.eq_snippet_2_4_15() == legacy_form.eq_snippet_2_4_15()


def test_rao_legacy_mock_uses_only_synthetic_tso_codes():
    assert all(eic.startswith("10X-MOCK-TSO-") for eic in legacy_form.EIC_BY_TSO.values())
    assert all(eic.startswith("10Y-MOCK-ZONE-") for eic in legacy_form.EQ_SNIPPET_ZONE_EICS.values())


def test_rao_eq_snippet_is_cgmes_2_4_15_with_two_control_areas_and_no_area_unit_link():
    g = Graph().parse(io.BytesIO(legacy_form.eq_snippet_2_4_15()), format="xml", publicID="urn:eq")
    cim16, entsoe = Namespace(legacy_form.CGMES_2_4_15), Namespace(legacy_form.ENTSOE_EXTENSION)
    areas = list(g.subjects(RDF.type, cim16.ControlArea))
    assert sorted(str(g.value(a, entsoe["IdentifiedObject.energyIdentCodeEic"])) for a in areas) == sorted(legacy_form.EQ_SNIPPET_ZONE_EICS.values())
    assert len(list(g.subjects(RDF.type, cim16.ThermalGeneratingUnit))) == 3
    assert not list(g.subjects(RDF.type, cim16.ControlAreaGeneratingUnit))


def test_rao_legacy_power_remedial_actions_name_their_bidding_zone_by_a_synthetic_eic_uri(legacy):
    for country in COUNTRIES:
        g = _graph(_leg(legacy, country, "RA"))
        zones = {str(z) for z in g.objects(None, NC["PowerRemedialAction.BiddingZone"])}
        assert zones == {legacy_form.zone_uri(country)}
        assert all(z.rsplit("/", 1)[-1].startswith("10Y-MOCK-ZONE-") for z in zones)
