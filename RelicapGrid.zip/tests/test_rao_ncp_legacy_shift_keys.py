"""
tests/test_rao_ncp_legacy_shift_keys.py - the NCP 2.2 legacy form (docs/specs/ncp_data_requirements.md section 13, DECISIONS 166):
the shift keys of a bid or RA come from the PowerShiftKey chain; only when it gives none for a bid, the legacy chain is read:
GLSKSchedule (GeneratingUnit, interpolationKind) <- ParticipationFactorTimePoint (GLSKSchedule, participationFactor, no atTime
needed) and GLSKBidActionDistribution (PowerBidSchedule, GLSKSchedule). One summary line per file; weights are normalised as always.
"""
import logging

import pytest
from rdflib import Graph, RDF

from data_model import RAKind, RDUnit
from pre_milp import glsk_resolver, ncp_parser

NC = ncp_parser.NC
HEADER = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:nc="https://cim4.eu/ns/nc#" xmlns:cim="https://cim.ucaiug.io/ns#">
"""


def _bid(ident, ra):
    return (f'  <nc:PowerBidSchedule rdf:ID="_{ident}"><cim:IdentifiedObject.mRID>{ident}</cim:IdentifiedObject.mRID>'
            f'<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{ra}"/></nc:PowerBidSchedule>\n')


def _glsk(ident, unit, factor, at_time=None):
    when = f"<nc:ParticipationFactorTimePoint.atTime>{at_time}</nc:ParticipationFactorTimePoint.atTime>" if at_time else ""
    return (f'  <nc:GLSKSchedule rdf:ID="_{ident}"><cim:IdentifiedObject.mRID>{ident}</cim:IdentifiedObject.mRID>'
            f'<nc:GLSKSchedule.GeneratingUnit rdf:resource="#_{unit}"/>'
            f'<nc:BaseTimeSeries.interpolationKind rdf:resource="https://cim4.eu/ns/nc#InterpolationKind.none"/></nc:GLSKSchedule>\n'
            f'  <nc:ParticipationFactorTimePoint rdf:ID="_TP_{ident}"><nc:ParticipationFactorTimePoint.GLSKSchedule rdf:resource="#_{ident}"/>'
            f'<nc:ParticipationFactorTimePoint.participationFactor>{factor}</nc:ParticipationFactorTimePoint.participationFactor>{when}'
            f'</nc:ParticipationFactorTimePoint>\n')


def _legacy_link(ident, bid, glsk):
    return (f'  <nc:GLSKBidActionDistribution rdf:ID="_{ident}"><nc:GLSKBidActionDistribution.PowerBidSchedule rdf:resource="#_{bid}"/>'
            f'<nc:GLSKBidActionDistribution.GLSKSchedule rdf:resource="#_{glsk}"/></nc:GLSKBidActionDistribution>\n')


def _standard(ident, unit, factor, bid):
    return (f'  <nc:PowerShiftKeySchedule rdf:ID="_{ident}"><cim:IdentifiedObject.mRID>{ident}</cim:IdentifiedObject.mRID>'
            f'<nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_{unit}"/></nc:PowerShiftKeySchedule>\n'
            f'  <nc:ParticipationFactorTimePoint rdf:ID="_TP_{ident}"><nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_{ident}"/>'
            f'<nc:ParticipationFactorTimePoint.participationFactor>{factor}</nc:ParticipationFactorTimePoint.participationFactor></nc:ParticipationFactorTimePoint>\n'
            f'  <nc:PowerShiftKeyDistribution rdf:ID="_D_{ident}"><nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_{bid}"/>'
            f'<nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_{ident}"/></nc:PowerShiftKeyDistribution>\n')


def _sis(tmp_path, *parts):
    path = tmp_path / "X_SIS.xml"
    path.write_text(HEADER + "".join(parts) + "</rdf:RDF>\n", encoding="utf-8")
    return path


def _legacy_only(tmp_path, first=3.0, second=1.0, at_time=None):
    return _sis(tmp_path, _bid("B1", "RA_1"), _glsk("GL1", "GU_1", first, at_time), _glsk("GL2", "GU_2", second, at_time),
                _legacy_link("L1", "B1", "GL1"), _legacy_link("L2", "B1", "GL2"))


def test_rao_the_legacy_chain_gives_the_units_of_a_redispatch_ra(tmp_path):
    graph = ncp_parser._load_graph(_legacy_only(tmp_path))
    assert ncp_parser.read_redispatch_units(graph, None, {"RA_1"}) == {"RA_1": ["GU_1", "GU_2"]}


def test_rao_the_legacy_weights_are_normalised_as_always_and_need_no_time(tmp_path):
    rd = [RDUnit(mrid="RA_1", name="RA_1", tso="TSO-X", gu_mrid=g, gu_name=g, available=True, kind=RAKind.PREVENTIVE, initial_p=10.0,
                 max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None, penalty_factor=1.0) for g in ("G1", "G2")]
    for at_time in (None, "2022-06-15T10:30:00Z"):
        path = _legacy_only(tmp_path, at_time=at_time)
        glsk = glsk_resolver.resolve_glsk(path, rd, "TSO-X", {"G1", "G2"}, "1030Z", generators_by_unit={"GU_1": ["G1"], "GU_2": ["G2"]})
        assert glsk == {"RA_1": {"G1": pytest.approx(0.75), "G2": pytest.approx(0.25)}}


def test_rao_the_current_chain_stays_first_for_a_bid_that_has_it(tmp_path):
    path = _sis(tmp_path, _bid("B1", "RA_1"), _bid("B2", "RA_2"), _glsk("GL1", "GU_1", 1.0), _legacy_link("L1", "B1", "GL1"),
                _standard("PS2", "GU_3", 1.0, "B2"), _glsk("GL3", "GU_4", 1.0), _legacy_link("L3", "B2", "GL3"))
    graph = ncp_parser._load_graph(path)
    assert ncp_parser.read_redispatch_units(graph, None, {"RA_1", "RA_2"}) == {"RA_1": ["GU_1"], "RA_2": ["GU_3"]}


def test_rao_the_bids_resolved_through_the_legacy_chain_are_one_summary_line_per_file(tmp_path, caplog):
    path = _sis(tmp_path, _bid("B1", "RA_1"), _bid("B2", "RA_2"), _glsk("GL1", "GU_1", 1.0), _legacy_link("L1", "B1", "GL1"),
                _standard("PS2", "GU_3", 1.0, "B2"), _glsk("GL3", "GU_4", 1.0), _legacy_link("L3", "B2", "GL3"))
    with caplog.at_level(logging.INFO):
        ncp_parser._load_graph(path)
    lines = [r for r in caplog.records if "legacy shift key chain" in r.getMessage()]
    assert len(lines) == 1 and lines[0].levelno == logging.INFO
    assert "X_SIS.xml" in lines[0].getMessage() and "1 bid(s)" in lines[0].getMessage() and "B1" in lines[0].getMessage()


def test_rao_a_file_without_the_legacy_chain_is_read_as_before(tmp_path, caplog):
    path = _sis(tmp_path, _bid("B2", "RA_2"), _standard("PS2", "GU_3", 1.0, "B2"))
    with caplog.at_level(logging.INFO):
        graph = ncp_parser._load_graph(path)
    assert not [r for r in caplog.records if "legacy shift key chain" in r.getMessage()]
    assert len(graph) == len(Graph().parse(str(path), format="xml"))


def test_rao_every_redispatch_ra_of_the_legacy_mock_gets_units():
    from mock_builders import legacy_writer as writer

    import tempfile
    from pathlib import Path

    folder = Path(tempfile.mkdtemp())
    for name, data in writer.legacy_files().items():
        (folder / name).write_bytes(data)
    for country in writer.EIC_BY_TSO:
        ra_graph = ncp_parser._load_graph(folder / writer.file_name(country, "RA"))
        sis_graph = ncp_parser._load_graph(folder / writer.file_name(country, "SIS"))
        ras = {ncp_parser._frag(str(r)) for r in ra_graph.subjects(RDF.type, NC.RedispatchRemedialAction)}
        units = ncp_parser.read_redispatch_units(sis_graph, ra_graph, ras)
        assert ras and all(units[ra] for ra in ras), country
