"""tests/test_rao_run_pipeline_end_to_end.py - tests that run run_pipeline.main() on the
fixtures (the ReliCapGrid case and the mock cases): real-dataset runs, the operating point of the loop, the
sensitivity guard in a full run, curative RD without preventive RD, the lf_nx baseline of
the export, the results summary identity, unknown TSO in the overrides.
"""

import csv
import importlib
import sys
import pytest
import pandas as pd
import shutil
import pyomo.environ as pyo

from pathlib import Path
from types import SimpleNamespace
from helpers import (
    _MOCK_NX_NCP_ZIP,
    run_pipeline_on_fixture_inputs,
    _bid_rd_cost as _bid,
    _unit,
    _make_ae,
    _make_pst,
    REFERENCE_PST,
    REFERENCE_RD,
    _all_terms_scenario,
    FIXTURE_CGM_ZIP,
    fixture_instance_root,
)
from pre_milp import sensitivity_checks as sv
from data_model import BidDirection, PowerBid, RAKind, RDUnit, AcVerificationStatus
from milp import ac_convergence_loop as acl
from milp.milp_builder import NxMilpInputs, PstMilpInputs, RdMilpInputs, build_n0_milp_model
from post_milp.n0_results_export import (
    extract_curative_rd_results,
    extract_rd_results,
    extract_results_summary,
    )
from text_encoding import TEXT_ENCODING  # noqa: E402

from helpers import read_summary  # noqa: E402


def _find_repo_root(start: Path) -> Path:
    """Walk upward from `start` to the first directory containing src/rao/data_model.py (a
    fixed-location marker, as in run_pipeline._find_repo_root)."""
    candidate = start.resolve()
    for _ in range(8):
        if (candidate / "src" / "rao" / "data_model.py").is_file():
            return candidate
        if candidate.parent == candidate:
            break
        candidate = candidate.parent
    raise RuntimeError(
        f"Could not locate the repo root (a directory containing "
        f"src/rao/data_model.py) by walking up from {start} â€” "
        f"checked up to 8 parent directories. If the repo layout has "
        f"changed, this search depth may need increasing."
    )


REPO_ROOT = _find_repo_root(Path(__file__).parent)


SRC_ROOT = REPO_ROOT / "src" / "rao"


DATA_ROOT = fixture_instance_root()


@pytest.fixture
def run_pipeline_module(tmp_path, monkeypatch, real_input_folder):
    """Fresh import of run_pipeline with OUTPUT_DIR redirected to a tmp
    directory, so tests never write into (or depend on) the repo's real
    output/ directory."""
    # SRC_ROOT and REPO_ROOT on sys.path again, in case test ordering changed it
    if str(SRC_ROOT) not in sys.path:
        sys.path.insert(0, str(SRC_ROOT))
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))

    import run_pipeline as rp
    importlib.reload(rp)
    monkeypatch.setattr(rp, "OUTPUT_DIR", tmp_path)
    # main() reads only input/: real_input_folder (conftest.py) builds it from tests/fixtures
    monkeypatch.setattr(rp, "INPUT_DIR", real_input_folder)
    return rp


# ---------------------------------------------------------------------------
# Regression: ENABLE_NX_ANALYSIS=False (the default) is unaffected
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# ENABLE_NX_ANALYSIS=True produces real, non-trivial N-X artifacts
# ---------------------------------------------------------------------------

class TestNxAnalysisEnabled:
    def test_an_empty_ra_type_list_stops_the_run_before_anything_is_parsed(self, run_pipeline_module, tmp_path):
        """No RA type left (an empty ra_types list) is an error at the start of main(), before any
        file is read or written."""
        run_pipeline_module.RA_TYPES = []
        run_pipeline_module.ENABLE_NX_ANALYSIS = False

        with pytest.raises(ValueError, match="non-empty list"):
            run_pipeline_module.main()
        assert [p.name for p in tmp_path.iterdir() if p.name not in ("input", "run_log_failed.txt")] == []  # nothing written to the output dir

class TestWorkflowOptionsFailFast:
    @pytest.mark.parametrize("ra_types, message", [
        (["pst", "pst"], "duplicate"), (["pst", "countertrades"], "not yet supported"), ([], "non-empty list"),
    ])
    def test_an_invalid_ra_type_list_stops_before_anything_is_parsed(
        self, run_pipeline_module, tmp_path, ra_types, message,
    ):
        run_pipeline_module.RA_TYPES = ra_types

        with pytest.raises(ValueError, match=message):
            run_pipeline_module.main()
        assert [p.name for p in tmp_path.iterdir() if p.name not in ("input", "run_log_failed.txt")] == []  # nothing written to the output dir

    @pytest.mark.parametrize("mode, message", [("fast", "allowed values"), ("DC", "allowed values")])
    def test_an_unknown_mode_stops_at_startup(self, run_pipeline_module, tmp_path, mode, message):
        run_pipeline_module.CALCULATION_MODE = mode

        with pytest.raises(ValueError, match=message):
            run_pipeline_module.main()
        assert [p.name for p in tmp_path.iterdir() if p.name not in ("input", "run_log_failed.txt")] == []  # nothing written to the output dir

    @pytest.mark.parametrize("name, value, message", [
        ("DC_POWER_FACTOR", 0.0, "dc_power_factor"),
        ("DC_POWER_FACTOR", None, "dc_power_factor"),
        ("DC_CURRENT_FACTOR_TABLE", {"default": -1.0}, r"current_factor_by_nominal_voltage_kv\.default"),
        ("DC_CURRENT_FACTOR_TABLE", None, "must be a table"),
    ])
    def test_an_invalid_dc_setting_stops_a_dc_run_at_startup(self, run_pipeline_module, tmp_path, name, value, message):
        run_pipeline_module.CALCULATION_MODE = "dc"
        setattr(run_pipeline_module, name, value)

        with pytest.raises(ValueError, match=message):
            run_pipeline_module.main()
        assert [p.name for p in tmp_path.iterdir() if p.name not in ("input", "run_log_failed.txt")] == []  # nothing written to the output dir


# ---------------------------------------------------------------------------
# CRA correctly computes empty on this dataset â€” not skipped, not erroring
# ---------------------------------------------------------------------------

class TestCraCorrectlyComputesEmptyOnRealData:
    def test_pst_cra_availability_confirmed_empty_and_curative_rd_confirmed_absent(self):
        """The two dataset facts the previous test depends on, derived from the data here."""
        from pathlib import Path as P
        from pre_milp import cgmes_loader, tso_name_resolver, ncp_loader, ncp_parser
        from pre_milp.nx_security_analysis import compute_tatl_data
        from pre_milp.cra_preprocessing import compute_pst_cra_availability
        from data_model import RAKind

        org_cd_path = DATA_ROOT / "commonData" / "NetworkCode" / "cimxml" / "Org-NineRealms_CD.xml"
        network = cgmes_loader.load_cgm(cgm_zip_override=FIXTURE_CGM_ZIP)
        _, tap_changer_dict, generating_unit_dict = cgmes_loader.extract_equipment_dicts(network)
        tso_name_map = tso_name_resolver.build_tso_name_map(org_cd_path)
        ncp_files = ncp_loader.build_ncp_files(DATA_ROOT, tso_name_map)
        timestamp = "1030Z"

        ae_flat_list, pst_list, rd_list = [], [], []
        cgm_static_patl = cgmes_loader.build_cgm_static_patl(network)
        branch_mrid_to_name = cgmes_loader.build_branch_mrid_to_name(network)
        for tso, profiles in sorted(ncp_files.items()):
            country = tso.removeprefix("TSO-")
            eq_candidates = list((DATA_ROOT / country / "Grid" / "cimxml").glob("*_EQ_*.xml"))
            tap_changer_to_transformer = (
                ncp_parser.build_tap_changer_to_transformer_map(eq_candidates[0]) if eq_candidates else {}
            )
            current_limit_side = (
                ncp_parser.build_current_limit_side_map(eq_candidates[0]) if eq_candidates else {}
            )
            ae_flat_list.extend(ncp_parser.parse_assessed_elements(
                profiles["AE"], profiles.get("SHS"), tso, timestamp, cgm_static_patl,
                cgm_branch_mrids=set(branch_mrid_to_name.keys()), current_limit_side=current_limit_side,
            ))
            if "RA" in profiles:
                pst_list.extend(ncp_parser.parse_psts(
                    profiles["RA"], tso, tap_changer_dict, tap_changer_to_transformer,
                ))
                rds, _bids = ncp_parser.parse_rd_units(
                    profiles["RA"], profiles.get("SIS"), tso, timestamp, generating_unit_dict,
                )
                rd_list.extend(rds)

        tatl_data = compute_tatl_data(network, ae_flat_list, "1030Z")
        pst_cra_availability = compute_pst_cra_availability(pst_list, tatl_data)

        assert pst_cra_availability == {}
        assert all(rd.kind == RAKind.PREVENTIVE for rd in rd_list)

# ---------------------------------------------------------------------------
# Completeness loop on non-public data: it ends by convergence (no new congestion at the last
# check), not by running out of max_completeness_iterations. No exact iteration count is
# asserted (it depends on the dataset).
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# End to end on a generator-produced NCP zip, the CGM zip of non-public data and an input/ folder
# ---------------------------------------------------------------------------

# _REAL_CGM_ZIP / _NCP_GENERIC_ZIP for TestRealEndToEndInputFolder. NCP_sample_generic_2_4.zip is an
# unmodified generic submission (unlike the purpose-built NCP_mock_standard.zip).
_REAL_CGM_ZIP = REPO_ROOT / "tests" / "fixtures" / "CGM_package.zip"


_NCP_GENERIC_ZIP = REPO_ROOT / "tests" / "fixtures" / "NCP_sample_generic_2_4.zip"


# ===========================================================================
# Operating point of the loop
# ===========================================================================

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _rows(path: Path) -> list[dict]:
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.DictReader(f))


def _close(left: dict, right: dict, tolerance: float = 1e-6) -> bool:
    """Nested {key: {key: {side: amps}}} / {key: {side: amps}} comparison."""
    if isinstance(left, dict):
        return left.keys() <= right.keys() and all(_close(left[k], right[k], tolerance) for k in left)
    if float(left) != float(left) and float(right) != float(right):
        return True  # both NaN (out-of-service side)
    return abs(float(left) - float(right)) <= tolerance * max(1.0, abs(float(right)))


@pytest.fixture(scope="module")
def instrumented_run(tmp_path_factory):
    captured = SimpleNamespace(builds=[], models=[], network=None, state=None, nx_hooks=None, mismatches=[])

    def customize(rp, monkeypatch):
        acl = rp.ac_convergence_loop
        real_nested = acl.run_nested_rao_loop
        real_build = acl.build_n0_milp_model

        def spy_nested(**kwargs):
            captured.network = kwargs["network"]
            captured.state = kwargs["state"]
            captured.nx_hooks = kwargs["nx_hooks"]
            return real_nested(**kwargs)

        def spy_build(*args, **kwargs):
            network = captured.network
            record = {
                "r0": {p.mrid: p.r0 for p in kwargs["pst_inputs"].pst_list} if kwargs.get("pst_inputs") else {},
                "target_p": (
                    {gu: d["target_p"] for gu, d in kwargs["rd_inputs"].generator_data.items()}
                    if kwargs.get("rd_inputs") else {}
                ),
                "network_taps": acl._extract_phase_tap_positions(network),
                "network_target_p": acl._extract_generator_target_p(network),
                "lf_n0_matches": _close(kwargs["lf_initial"], acl.cgmes_loader.build_lf_initial(network)),
                "lf_initial": kwargs["lf_initial"],
                "lf_nx": kwargs["nx_inputs"].lf_nx if kwargs.get("nx_inputs") is not None else None,
            }
            if kwargs.get("nx_inputs") is not None and captured.nx_hooks is not None:
                fresh_lf_nx = captured.nx_hooks.compute_lf_nx(network)
                record["lf_nx_matches"] = _close(kwargs["nx_inputs"].lf_nx, fresh_lf_nx, 1e-5)
            captured.builds.append(record)
            model = real_build(*args, **kwargs)
            captured.models.append(model)
            return model

        monkeypatch.setattr(acl, "run_nested_rao_loop", spy_nested)
        monkeypatch.setattr(acl, "build_n0_milp_model", spy_build)

    run = run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp("instrumented_mock_run"), _MOCK_NX_NCP_ZIP, enable_nx_analysis=True,
        customize_pipeline=customize,
    )
    captured.output_dir = run.output_dir
    return captured


def test_every_build_on_the_real_network_starts_from_the_applied_state(instrumented_run):
    builds = instrumented_run.builds
    assert len(builds) >= 2, "the mock case needs a second build for this to mean anything"
    for index, build in enumerate(builds, start=1):
        for mrid, r0 in build["r0"].items():
            assert float(build["network_taps"][mrid]) == r0, f"build {index}: PST {mrid} r0 != network tap"
        for gu, target_p in build["target_p"].items():
            assert build["network_target_p"][gu] == pytest.approx(target_p, abs=1e-9), (
                f"build {index}: GU {gu} target_p != network"
            )
        assert build["lf_n0_matches"], f"build {index}: N-0 load flow is not the one of the network"
        assert build["lf_nx_matches"], f"build {index}: N-X load flow is not a fresh one of the network"
    assert builds[-1]["network_taps"] != builds[0]["network_taps"], "nothing moved between the builds"


def _summary_values(out: Path) -> dict[str, float]:
    rows = _rows(out / "results_summary.csv")
    key_column, value_column = list(rows[0].keys())[:2]
    values = {}
    for row in rows:
        try:
            values[row[key_column]] = float(row[value_column])
        except ValueError:
            pass
    return values


def _criterion_4_lines(output_dir) -> list:
    """(overload change in A, threshold in A, met) of every [CONVERGENCE] line of the run log, in iteration order."""
    import re
    pattern = re.compile(r"criterion 4: overload change=([\d.]+) A \(< ([\d.]+) A\) (MET|no)")
    log = (output_dir / "run_log.txt").read_text(encoding=TEXT_ENCODING)
    return [(float(a), float(b), c == "MET") for a, b, c in pattern.findall(log)]


def test_criterion_4_is_taken_from_the_ac_state_and_is_met_exactly_below_its_threshold(instrumented_run):
    """Seen through the log (iterations.csv has no criterion columns): iteration 1 is evaluable against the initial AC
    state and does not fire on the mock case; every line is MET exactly when the change is below the threshold."""
    lines = _criterion_4_lines(instrumented_run.output_dir)
    assert lines
    first_change, threshold, first_met = lines[0]
    assert first_change > 1.0 and not first_met
    for change, threshold, met in lines:
        assert met == (change < threshold)


def test_criterion_4_equals_an_independent_recomputation_from_the_ac_states(instrumented_run):
    """Per solve s: sum over the model's monitored elements of |overload(state s) - overload(state s-1)|
    with overload = max(0, I_AC (+ curative effect of the solve, PATL rows only: the TATL rows
    bound the state before the curative actions) - limit); state s-1 is the input of solve s,
    state s the input of build s+1. The value is read from the log (printed with three decimals)."""
    from data_model import select_by_side
    logged = _criterion_4_lines(instrumented_run.output_dir)
    builds, models = instrumented_run.builds, instrumented_run.models
    assert len(builds) == len(models) >= 2

    def overload_sum(model, build, curative_model):
        total = {}
        for branch, (side, limit) in model.overload_monitoring["n0"].items():
            total[("n0", branch)] = max(0.0, select_by_side(build["lf_initial"][branch], side, branch) - limit)
        for kind in ("nx_patl", "nx_tatl"):
            for (branch, contingency), (side, limit) in model.overload_monitoring[kind].items():
                current = select_by_side(build["lf_nx"][contingency][branch], side, branch)
                if curative_model is not None and kind == "nx_patl":
                    current += curative_model.nx_curative_effect_ampere(branch, contingency)
                total[(kind, branch, contingency)] = max(0.0, current - limit)
        return total

    for solve in range(1, len(builds)):          # solves with a following build = a known state s
        model = models[solve - 1]
        now = overload_sum(model, builds[solve], model)
        before = overload_sum(model, builds[solve - 1], models[solve - 2] if solve >= 2 else None)
        expected = sum(abs(now[k] - before[k]) for k in now)
        assert logged[solve - 1][0] == pytest.approx(expected, rel=1e-6, abs=1e-3), f"solve {solve}"


def test_the_state_keeps_the_curative_effect_of_the_last_applied_solve(instrumented_run):
    state, model = instrumented_run.state, instrumented_run.models[-1]
    assert state.last_curative_effect_ampere
    for (branch, contingency), effect in state.last_curative_effect_ampere.items():
        assert effect == pytest.approx(model.nx_curative_effect_ampere(branch, contingency), abs=1e-9)
    assert any(abs(v) > 1e-6 for v in state.last_curative_effect_ampere.values())


# ===========================================================================
# Sensitivity guard in a full run
# ===========================================================================

SIDES = {"L1": 1, "L2": 2}


# ---------------------------------------------------------------------------
# the four compute functions fill guard_out (fake pypowsybl)
# ---------------------------------------------------------------------------

def _install_with_references(monkeypatch, reference_value, sensitivity_value=1.0):
    from helpers import _Result, _install
    fake = _install(monkeypatch)
    reference = lambda: pd.DataFrame([[reference_value]], index=["reference_values"], columns=["b1"])
    fake.matrices["psdf_n0_side1"] = pd.DataFrame([[sensitivity_value]], index=["p1"], columns=["b1"])
    fake.matrices["ptdf_rd_n0_side1"] = pd.DataFrame([[sensitivity_value]], index=["g1"], columns=["b1"])
    fake.matrices[("nx_side1", "c1")] = pd.DataFrame([[sensitivity_value]], index=["p1"], columns=["b1"])
    monkeypatch.setattr(
        _Result, "get_reference_matrix",
        lambda self, matrix_id, contingency_id=None: reference(), raising=True,
    )
    return fake


# ---------------------------------------------------------------------------
# end to end on the mock case: a failing analysis for one contingency
# ---------------------------------------------------------------------------
# Every mode fails only AFTER the first MILP was built (the initial computation is healthy, so there is
# a valid set to reuse; a failure at the initial computation stops the run, see the last test):
# mode "refresh_only":      reference current and sensitivities of one contingency are zero
# mode "refresh_sens_only": only the sensitivities are zero (the reference still matches the load flow)
# mode "refresh_pst_only" / "refresh_rd_only": only the sensitivities of that analysis are zero

@pytest.fixture(scope="module", params=["refresh_only", "refresh_sens_only", "refresh_pst_only", "refresh_rd_only"])
def failing_run(request, tmp_path_factory):
    mode = request.param
    seen = {"target": None, "events": [], "active": False, "built": []}
    sens_only_modes = ("refresh_sens_only", "refresh_pst_only", "refresh_rd_only")

    def customize(rp, monkeypatch):
        import logging
        from pypowsybl.sensitivity.impl.ac_sensitivity_analysis import AcSensitivityAnalysis
        real_run = AcSensitivityAnalysis.run

        class Failed:
            analysis = "n0"

            def __init__(self, real):
                self.real = real

            def get_reference_matrix(self, matrix_id, contingency_id=None):
                matrix = self.real.get_reference_matrix(matrix_id, contingency_id)
                if contingency_id is None or matrix is None:
                    return matrix
                if seen["target"] is None and float(matrix.abs().max().max()) > 50.0:
                    seen["target"] = contingency_id
                zero = seen["active"] and mode not in sens_only_modes and contingency_id == seen["target"]
                return matrix * 0.0 if zero else matrix

            def get_sensitivity_matrix(self, matrix_id, contingency_id=None):
                matrix = self.real.get_sensitivity_matrix(matrix_id, contingency_id)
                restricted = {"refresh_pst_only": "pst", "refresh_rd_only": "rd"}.get(mode)
                # one N-X analysis holds both kinds: its matrix ids say which (nx_pst_*, nx_rd_*)
                kind = ("pst" if str(matrix_id).startswith("nx_pst") else
                        "rd" if str(matrix_id).startswith("nx_rd") else self.analysis)
                if seen["active"] and contingency_id is not None and matrix is not None \
                        and contingency_id == seen["target"] and restricted in (None, kind):
                    return matrix * 0.0
                return matrix

            def __getattr__(self, name):
                return getattr(self.real, name)

        def run(self, network, parameters=None, *args, **kwargs):
            import inspect
            names = [frame.function for frame in inspect.stack()[1:6]]
            analysis = "pst" if "compute_sensitivity_pst_nx" in names else "rd" if "compute_sensitivity_rd_nx" in names else "n0"
            failed = Failed(real_run(self, network, parameters, *args, **kwargs))
            failed.analysis = analysis
            return failed

        monkeypatch.setattr(AcSensitivityAnalysis, "run", run)

        warnings_seen = []

        class Collect(logging.Handler):
            def emit(self, record):
                if record.levelno == logging.WARNING and "SENSITIVITY GUARD" in record.getMessage():
                    warnings_seen.append(record.getMessage())

        seen["collector"] = Collect()
        logging.getLogger().addHandler(seen["collector"])
        acl = rp.ac_convergence_loop
        real_build = acl.build_n0_milp_model

        def spy_build(*args, **kwargs):
            seen["events"].append(("build", len(warnings_seen)))
            seen["active"] = True      # from the first build on, every analysis of the target fails
            nx = kwargs.get("nx_inputs")
            seen["built"].append((
                dict(nx.sensitivity_pst_nx.get(seen["target"], {})), dict(nx.sensitivity_rd_nx.get(seen["target"], {})),
            ))
            return real_build(*args, **kwargs)

        monkeypatch.setattr(acl, "build_n0_milp_model", spy_build)
        # the target contingency must be known before the first build in every mode
    run = run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp(f"guard_{mode}"), _MOCK_NX_NCP_ZIP, enable_nx_analysis=True,
        customize_pipeline=customize,
    )
    import logging
    logging.getLogger().removeHandler(seen["collector"])
    return SimpleNamespace(run=run, mode=mode, target=seen["target"], out=run.output_dir, events=seen["events"], built=seen["built"])


def _rows_sensitivity_guard(path):
    with open(path, newline="", encoding=TEXT_ENCODING) as handle:
        return list(csv.DictReader(handle))


def test_the_failing_contingency_is_logged_as_a_warning_in_run_log(failing_run):
    lines = (failing_run.out / "run_log.txt").read_text(encoding=TEXT_ENCODING).splitlines()
    guard = [line for line in lines if "SENSITIVITY GUARD" in line]
    assert guard and all("WARNING" in line for line in guard)
    assert any(failing_run.target in line for line in guard)
    assert any("refresh" in line for line in guard)
    assert not any("initial state" in line for line in guard)


def test_the_builder_receives_the_valid_initial_set_of_the_failing_contingency_in_every_later_solve(failing_run):
    """e2e spy on the builder inputs: never the zero (invalid) set, always the last valid one"""
    built = failing_run.built
    assert len(built) >= 2
    initial_pst, initial_rd = built[0]
    assert any(v != 0.0 for v in initial_pst.values()) or any(v != 0.0 for v in initial_rd.values())
    for pst, rd in built[1:]:
        assert pst == initial_pst and rd == initial_rd


def test_the_warning_precedes_every_build_that_used_the_invalid_sensitivities(failing_run):
    """never silent: by the time a MILP is built from reused sensitivities the WARNING is out"""
    builds = [count for kind, count in failing_run.events if kind == "build"]
    assert len(builds) >= 2
    assert builds[0] == 0 and builds[1] >= 1 and all(b > a for a, b in zip(builds[1:], builds[2:]))


# ---------------------------------------------------------------------------
# loop level (FakeGrid harness): the N-0 refresh at the applied state
# ---------------------------------------------------------------------------


# ===========================================================================
# Curative RD without preventive RD
# ===========================================================================

REPO_ROOT_curative_rd_without_preventive_rd = Path(__file__).resolve().parent.parent


# ---- 3. pipeline level -------------------------------------------------------

FIXTURES = REPO_ROOT_curative_rd_without_preventive_rd / "tests" / "fixtures"


requires_fixtures = pytest.mark.skipif(
    not ((FIXTURES / "CGM_package.zip").is_file() and (FIXTURES / "NCP_mock_standard.zip").is_file()),
    reason="CGM_package.zip / NCP_mock_standard.zip not in tests/fixtures",
)


# ===========================================================================
# lf_nx baseline handed to the export
# ===========================================================================

REPO_ROOT_completeness_loop = Path(__file__).resolve().parents[1]


@pytest.fixture
def run_pipeline_module_completeness_loop(tmp_path, monkeypatch, real_input_folder):
    if str(SRC_ROOT) not in sys.path:
        sys.path.insert(0, str(SRC_ROOT))
    if str(REPO_ROOT_completeness_loop) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT_completeness_loop))
    import run_pipeline as rp
    importlib.reload(rp)
    monkeypatch.setattr(rp, "OUTPUT_DIR", tmp_path)
    # main() reads only input/: real_input_folder (conftest.py) builds it from tests/fixtures
    monkeypatch.setattr(rp, "INPUT_DIR", real_input_folder)
    return rp


# ===========================================================================
# Results summary identity
# ===========================================================================

REPO_ROOT_results_summary = Path(__file__).resolve().parents[1]


# ===========================================================================
# Unknown TSO in the tap limit overrides
# ===========================================================================

# ===========================================================================
# Solver time limit and the N-X sensitivity CSV switch
# ===========================================================================

@pytest.fixture(scope="module")
def time_limited_run_without_nx_csvs(tmp_path_factory):
    """The mock N-X run with a 1 Âµs HiGHS time limit and write_nx_sensitivity_csvs false."""
    from milp import milp_solver

    def customize(rp, monkeypatch):
        monkeypatch.setattr(rp, "SOLVER_TIME_LIMIT_SECONDS", 1e-6)
        monkeypatch.setattr(rp, "WRITE_SENSITIVITY_CSVS", False)
        monkeypatch.setattr(milp_solver, "SOLVER_TIME_LIMIT_SECONDS", milp_solver.SOLVER_TIME_LIMIT_SECONDS)

    return run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp("time_limited"), _MOCK_NX_NCP_ZIP, enable_nx_analysis=True,
        customize_pipeline=customize,
    )


def _summary_metrics(output_dir):
    from helpers import read_summary
    return read_summary(output_dir)


def test_a_solve_stopped_at_the_time_limit_ends_the_run_as_solver_non_optimal(time_limited_run_without_nx_csvs):
    metrics = _summary_metrics(time_limited_run_without_nx_csvs.output_dir)
    assert metrics["status"] == AcVerificationStatus.SOLVER_NON_OPTIMAL.value


def test_without_a_time_limit_the_run_is_not_stopped_by_the_solver(mock_nx_pipeline_run):
    metrics = _summary_metrics(mock_nx_pipeline_run.output_dir)
    assert metrics["status"] == AcVerificationStatus.CONVERGED.value


def test_the_nx_sensitivity_csvs_are_written_by_default(mock_nx_pipeline_run):
    assert (mock_nx_pipeline_run.output_dir / "sensitivity_pst_nx.csv").exists()
    assert (mock_nx_pipeline_run.output_dir / "sensitivity_rd_nx.csv").exists()


@pytest.fixture(scope="module")
def second_mock_nx_run(mock_nx_pipeline_run, tmp_path_factory):
    """A second mock N-X run in this process (mock_nx_pipeline_run is the first), with the
    arguments of every compute_rd_cra_availability call of the pipeline recorded."""
    calls = []

    def record_rd_cra_availability(rp, monkeypatch):
        original = rp.compute_rd_cra_availability

        def recording(*args, **kwargs):
            calls.append((args, kwargs))
            return original(*args, **kwargs)

        monkeypatch.setattr(rp, "compute_rd_cra_availability", recording)

    run = run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp("second_mock_nx_run"), _MOCK_NX_NCP_ZIP, enable_nx_analysis=True,
        customize_pipeline=record_rd_cra_availability,
    )
    return SimpleNamespace(output_dir=run.output_dir, rd_cra_availability_calls=calls)


def test_a_second_run_in_the_same_process_writes_the_once_per_run_log_lines_again(mock_nx_pipeline_run, second_mock_nx_run):
    """F2 rule 15 [review]: the reservePrice fallback line (once per bid and run) is in the
    run_log.txt of a second run in this process (mock_nx_pipeline_run was the first), as often
    as in the first run."""
    marker = "no reservePrice"
    first = (mock_nx_pipeline_run.output_dir / "run_log.txt").read_text(encoding=TEXT_ENCODING).count(marker)
    second = (second_mock_nx_run.output_dir / "run_log.txt").read_text(encoding=TEXT_ENCODING).count(marker)
    assert first > 0
    assert second == first


def test_cumulative_tap_change_per_tso_stays_within_the_limit(instrumented_run):
    out = instrumented_run.output_dir
    limits = {r["tso"]: float(r["tap_change_max"]) for r in _rows(out / "tso_limits.csv") if r["tap_change_max"] != ""}
    used: dict[str, float] = {}
    for row in _rows(out / "pst_results.csv"):
        if row["tso"] in limits and row["contingency_id"] == "":
            used[row["tso"]] = used.get(row["tso"], 0.0) + abs(float(row["tap_change"]))
    assert limits and used
    for tso, total in used.items():
        assert total <= limits[tso] + 1e-6, f"{tso}: |final - original| summed over its PSTs = {total} > limit {limits[tso]}"
    for row in _rows(out / "tso_limits.csv"):
        if row["tap_changes"] != "":
            assert float(row["tap_changes"]) == pytest.approx(used.get(row["tso"], 0.0), abs=1e-6)


def test_the_nx_sensitivity_csvs_are_not_written_when_switched_off(time_limited_run_without_nx_csvs):
    output_dir = time_limited_run_without_nx_csvs.output_dir
    assert not (output_dir / "sensitivity_pst_nx.csv").exists()
    assert not (output_dir / "sensitivity_rd_nx.csv").exists()
    assert (output_dir / "loadings_nx.csv").exists()


def test_the_pipeline_passes_every_monitored_branch_to_the_rd_availability_helper(second_mock_nx_run):
    """R9 rule 10 [review]: run_pipeline calls compute_rd_cra_availability with
    branch_mrids = the monitored branches (limit_by_branch_nx: secured and scanned) and the config
    fallback duration. On the mock input every secured branch is also in tatl_data, so the CSV
    alone cannot tell this call from one without branch_mrids; the recorded argument can."""
    import run_pipeline as rp
    calls = second_mock_nx_run.rd_cra_availability_calls
    assert len(calls) == 1
    args, kwargs = calls[0]
    assert kwargs.get("branch_mrids") is not None
    assert kwargs["fallback_duration_seconds"] == rp.TATL_FALLBACK_DURATION_S
    with open(second_mock_nx_run.output_dir / "loadings_nx.csv", newline="", encoding=TEXT_ENCODING) as f:
        monitored_in_nx = {row["branch_id"] for row in csv.DictReader(f)}
    assert monitored_in_nx <= set(kwargs["branch_mrids"])
    tatl_data = args[1]
    assert set(tatl_data) <= set(kwargs["branch_mrids"])


# ===========================================================================
# Sensitivity guard and convergence, seen through the log, the summary and the files
# ===========================================================================

def _guard_lines(run_dir, context):
    text = (run_dir / "run_log.txt").read_text(encoding=TEXT_ENCODING)
    return [line for line in text.splitlines() if f"SENSITIVITY GUARD (N-X, {context})" in line]


def test_only_the_failing_contingency_is_reported_invalid_at_every_refresh(failing_run):
    lines = _guard_lines(failing_run.out, "refresh at the applied state")
    assert lines and all(failing_run.target in line and "1 invalid" in line for line in lines)


def test_every_solve_after_the_first_reports_its_invalid_contingency(failing_run):
    """Solve 1 was built from the healthy initial sensitivities; the refresh before each later solve reports the target."""
    solves = int(read_summary(failing_run.out)["iterations"])
    assert len(_guard_lines(failing_run.out, "refresh at the applied state")) == solves - 1
    assert not _guard_lines(failing_run.out, "initial state")


def test_the_sensitivity_guard_flags_nothing_on_a_healthy_run(instrumented_run):
    out = instrumented_run.output_dir
    assert "SENSITIVITY GUARD" not in (out / "run_log.txt").read_text(encoding=TEXT_ENCODING)
    assert _rows(out / "contingencies.csv")                     # every contingency of the run is valid and listed


def test_invalid_sensitivities_at_the_initial_computation_stop_the_run_with_a_clear_error(tmp_path):
    """no earlier valid set exists: SensitivityGuardError, the outputs say why, the rule and the contingency are named"""
    from pre_milp.sensitivity_checks import SensitivityGuardError
    seen = {"target": None}

    def customize(rp, monkeypatch):
        from pypowsybl.sensitivity.impl.ac_sensitivity_analysis import AcSensitivityAnalysis
        real_run = AcSensitivityAnalysis.run

        class Failed:
            def __init__(self, real):
                self.real = real

            def get_reference_matrix(self, matrix_id, contingency_id=None):
                matrix = self.real.get_reference_matrix(matrix_id, contingency_id)
                if contingency_id is None or matrix is None:
                    return matrix
                if seen["target"] is None and float(matrix.abs().max().max()) > 50.0:
                    seen["target"] = contingency_id
                return matrix * 0.0 if contingency_id == seen["target"] else matrix

            def __getattr__(self, name):
                return getattr(self.real, name)

        monkeypatch.setattr(
            AcSensitivityAnalysis, "run", lambda self, *a, **k: Failed(real_run(self, *a, **k)),
        )

    with pytest.raises(SensitivityGuardError) as error:
        run_pipeline_on_fixture_inputs(tmp_path, _MOCK_NX_NCP_ZIP, enable_nx_analysis=True, customize_pipeline=customize)
    out = next(p for p in (tmp_path / "output").iterdir() if (p / "summary.csv").is_file())
    assert seen["target"] in str(error.value) and "zero reference current" in str(error.value)
    assert read_summary(out)["status"] == "SENSITIVITY_INVALID"
    log_lines = (out / "run_log.txt").read_text(encoding=TEXT_ENCODING)
    assert any("ERROR" in line and seen["target"] in line for line in log_lines.splitlines() if "SENSITIVITY GUARD" in line)
    assert seen["target"] not in {row["contingency_id"] for row in _rows(out / "contingencies.csv")}     # an invalid one is not used


def test_completeness_loop_converges_on_real_data_not_just_exhausts_iterations(run_pipeline_module_completeness_loop, tmp_path):
    """With N-X on the non-public data, iterations.csv has at least one row and its last row adds no new constraint
    (converged, not exhausted)."""
    run_pipeline_module_completeness_loop.ENABLE_NX_ANALYSIS = True
    run_pipeline_module_completeness_loop.main()
    run_dir = next(p for p in tmp_path.iterdir() if (p / "iterations.csv").is_file())
    rows = list(csv.DictReader((run_dir / "iterations.csv").open(encoding=TEXT_ENCODING)))
    assert len(rows) >= 1
    assert int(rows[-1]["new_nx_constraints"]) == 0, (
        f"the last solve added {rows[-1]['new_nx_constraints']!r} new constraints: the completeness loop was exhausted "
        "or the dataset changed its convergence behaviour; check which before changing this test"
    )
