"""tests/test_rao_bid_default_price.py - the default bid price (bids.default_price_eur_per_mwh) and the one-line summaries of the
bid parse (count and first 5 ids, all ids at DEBUG). Small hand-written files, synthetic ids."""

import logging
from pathlib import Path

import pytest
import yaml

import run_pipeline
from pre_milp import ncp_parser
from text_encoding import TEXT_ENCODING

HEADER = ('<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:nc="https://cim4.eu/ns/nc#">')
NC_NS = "https://cim4.eu/ns/nc#"


def _bid(index, price="9", direction=True, at_time="2024-02-22T10:30:00Z", extra_point="", name_suffix=""):
    direction_xml = f'<nc:PowerBidSchedule.direction rdf:resource="{NC_NS}BidDirectionKind.up"/>' if direction else ""
    price_xml = f'<nc:PowerBidScheduleTimePoint.price>{price}</nc:PowerBidScheduleTimePoint.price>' if price is not None else ""
    return (
        f'<nc:PowerBidSchedule rdf:ID="_B{index}"><cim:IdentifiedObject.mRID>B{index}</cim:IdentifiedObject.mRID>'
        f'<cim:IdentifiedObject.name>bid {index}{name_suffix}</cim:IdentifiedObject.name>'
        f'<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/>{direction_xml}'
        f'<nc:BaseTimeSeries.interpolationKind rdf:resource="{NC_NS}InterpolationKind.none"/></nc:PowerBidSchedule>'
        f'<nc:PowerBidScheduleTimePoint rdf:ID="_P{index}"><nc:PowerBidScheduleTimePoint.atTime>{at_time}</nc:PowerBidScheduleTimePoint.atTime>'
        f'<nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_B{index}"/>'
        f'<nc:PowerBidScheduleTimePoint.p>50</nc:PowerBidScheduleTimePoint.p>{price_xml}{extra_point}'
        '</nc:PowerBidScheduleTimePoint>'
    )


def _parse(tmp_path, bids_xml, tso="X", **kwargs):
    path = tmp_path / "X_SIS.xml"
    path.write_text(HEADER + bids_xml + "</rdf:RDF>", encoding=TEXT_ENCODING)
    graph = ncp_parser._load_graph(path)
    return ncp_parser.parse_power_bids(graph, {"RA1"}, tso, "1030Z", **kwargs), graph


def _messages(caplog, level=logging.WARNING):
    return [r.getMessage() for r in caplog.records if r.levelno == level]


def test_rao_a_bid_without_a_price_gets_the_default_price_with_one_summary(tmp_path, caplog):
    xml = "".join(_bid(i, price=None) for i in range(1, 8)) + _bid(9, price="4")
    with caplog.at_level(logging.DEBUG):
        bids, _ = _parse(tmp_path, xml, default_price_eur_mw=37.5)
    assert {b.mrid: b.price_eur_mw for b in bids} == {**{f"B{i}": 37.5 for i in range(1, 8)}, "B9": 4.0}
    (line,) = [m for m in _messages(caplog) if "no price" in m]
    assert "7 bid(s)" in line and "37.5" in line and "B1, B2, B3, B4, B5 and 2 more" in line and "B6" not in line
    assert any("B6" in m and "B7" in m for m in _messages(caplog, logging.DEBUG))


def test_rao_negative_prices_are_zero_with_one_summary_per_file(tmp_path, caplog):
    """Up and down bids alike: 7 negative prices, 1 positive -> 0, one warning (count, first 5 ids), all ids at DEBUG."""
    xml = "".join(_bid(i, price="-3.5", direction=i % 2 == 1, name_suffix="" if i % 2 == 1 else "_DOWN")
                  for i in range(1, 8)) + _bid(9, price="4")
    with caplog.at_level(logging.DEBUG):
        bids, _ = _parse(tmp_path, xml)
    assert {b.mrid: b.price_eur_mw for b in bids} == {**{f"B{i}": 0.0 for i in range(1, 8)}, "B9": 4.0}
    assert {b.direction.name for b in bids} == {"UP", "DOWN"}
    (line,) = [m for m in _messages(caplog) if "negative price" in m]
    assert "7 bid(s)" in line and "B1, B2, B3, B4, B5 and 2 more" in line and "B6" not in line and "B9" not in line
    assert any("B6" in m and "B7" in m and "all ids" in m for m in _messages(caplog, logging.DEBUG))


def test_rao_negative_reserve_prices_are_zero_with_one_summary_per_file(tmp_path, caplog):
    reserve = '<nc:PowerBidScheduleTimePoint.reservePrice>{}</nc:PowerBidScheduleTimePoint.reservePrice>'
    xml = "".join(_bid(i, price="5", extra_point=reserve.format(-2)) for i in range(1, 8)) + _bid(9, price="5", extra_point=reserve.format(2))
    with caplog.at_level(logging.DEBUG):
        bids, _ = _parse(tmp_path, xml)
    assert {b.mrid: b.reserve_price_eur_mw for b in bids} == {**{f"B{i}": 0.0 for i in range(1, 8)}, "B9": 2.0}
    assert all(b.price_eur_mw == 5.0 for b in bids)
    (line,) = [m for m in _messages(caplog) if "negative reservePrice" in m]
    assert "7 bid(s)" in line and "B1, B2, B3, B4, B5 and 2 more" in line and "B6" not in line
    assert any("B6" in m and "B7" in m and "all ids" in m for m in _messages(caplog, logging.DEBUG))


def test_rao_no_negative_price_gives_no_negative_price_warning(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        _parse(tmp_path, _bid(1, price="4"))
    assert not [m for m in _messages(caplog) if "negative" in m]


def test_rao_the_default_default_price_is_zero_as_before(tmp_path):
    bids, _ = _parse(tmp_path, _bid(1, price=None))
    assert bids[0].price_eur_mw == 0.0


def test_rao_a_bid_with_a_time_point_other_than_the_run_time_is_counted_apart(tmp_path, caplog):
    xml = _bid(1, price=None, at_time="2024-02-22T09:00:00Z") + _bid(2, price=None)
    with caplog.at_level(logging.WARNING):
        bids, _ = _parse(tmp_path, xml, default_price_eur_mw=5.0)
    assert {b.mrid: b.available_mw for b in bids} == {"B1": {"1030Z": 0.0}, "B2": {"1030Z": 50.0}}
    lines = _messages(caplog)
    assert any("1 bid(s) have no price" in m and "B2" in m and "B1" not in m for m in lines)
    assert any("1 bid(s) have no time point" in m and "B1" in m for m in lines)


def test_rao_unread_time_point_attributes_give_one_summary(tmp_path, caplog):
    extra = ('<nc:PowerBidScheduleTimePoint.minimumActivationP>5</nc:PowerBidScheduleTimePoint.minimumActivationP>'
             '<nc:PowerBidScheduleTimePoint.stepIncrementP>1</nc:PowerBidScheduleTimePoint.stepIncrementP>')
    xml = "".join(_bid(i, extra_point=extra) for i in range(1, 8))
    with caplog.at_level(logging.WARNING):
        _parse(tmp_path, xml)
    lines = [m for m in _messages(caplog) if "not read" in m]
    assert len(lines) == 1 and "7 bid(s)" in lines[0] and "B1, B2, B3, B4, B5 and 2 more" in lines[0]
    assert "minimumActivationP: 7" in lines[0] and "stepIncrementP: 7" in lines[0]


def test_rao_the_bid_direction_summary_is_given_once_for_the_pooled_file_not_once_per_tso(tmp_path, caplog):
    xml = "".join(_bid(i, direction=False, name_suffix="_nodirection") for i in range(1, 4))
    path = tmp_path / "X_SIS.xml"
    path.write_text(HEADER + xml + "</rdf:RDF>", encoding=TEXT_ENCODING)
    graph = ncp_parser._load_graph(path)
    with caplog.at_level(logging.WARNING):
        for tso in ("X", "Y", "Z"):
            ncp_parser.parse_power_bids(graph, {"RA1"}, tso, "1030Z")
    assert len([m for m in _messages(caplog) if "bid direction" in m]) == 1


def test_rao_ras_without_a_unit_are_ignored_with_one_summary(tmp_path, caplog):
    ras = "".join(
        f'<nc:RedispatchRemedialAction rdf:ID="_R{i}"><cim:IdentifiedObject.mRID>R{i}</cim:IdentifiedObject.mRID>'
        '</nc:RedispatchRemedialAction>' for i in range(1, 9))
    path = tmp_path / "X_RA.xml"
    path.write_text(HEADER + ras + "</rdf:RDF>", encoding=TEXT_ENCODING)
    with caplog.at_level(logging.DEBUG):
        ncp_parser.warn_unsupported_power_remedial_actions(ncp_parser._load_graph(path), None, "X")
    lines = [m for m in _messages(caplog) if "IGNORED" in m]
    assert len(lines) == 1 and "8 nc:RedispatchRemedialAction" in lines[0] and "R5 and 3 more" in lines[0]
    assert "R8" in " ".join(_messages(caplog, logging.DEBUG))


@pytest.mark.parametrize("name", ["rao_config.yaml", "rao_config.default.yaml"])
def test_rao_both_config_files_have_the_default_price_at_zero(name):
    config = yaml.safe_load((Path(run_pipeline.__file__).parent / "config" / name).read_text(encoding="utf-8"))
    assert config["bids"]["default_price_eur_per_mwh"] == 0.0


@pytest.mark.parametrize("value", [-1.0, "free", True, None])
def test_rao_the_default_price_is_validated(value):
    config = yaml.safe_load((Path(run_pipeline.__file__).parent / "config" / "rao_config.yaml").read_text(encoding="utf-8"))
    config["bids"]["default_price_eur_per_mwh"] = value
    with pytest.raises(ValueError, match="bids.default_price_eur_per_mwh"):
        run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))
