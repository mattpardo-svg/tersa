"""standard.py - the standard-form mock NCP.

base: tests/fixtures/NCP_mock_standard_base.zip, the standard-form mock without countertrade RA. The builders of the
countertrade, HVDC and dataset mocks and the shared-bid cases start from it.
shipped: the base plus one preventive and one curative countertrade RA per region with their bids (countertrade_p).
`python tests/tools/fixture_cli.py standard` writes the shipped one; a test asserts that the file in tests/fixtures equals this output
byte for byte."""
import functools
import io
import zipfile
from pathlib import Path

from .countertrade_p import add_countertrade
from .paths import STANDARD_BASE_ZIP
from .zipio import write_zip


@functools.lru_cache(maxsize=None)
def _base_files(base=str(STANDARD_BASE_ZIP)):
    with zipfile.ZipFile(base) as archive:
        return {item.filename: archive.read(item.filename) for item in archive.infolist() if not item.is_dir()}


def base_files() -> dict:
    """{name: bytes} of the standard-form mock without countertrade (a copy)."""
    return dict(_base_files())


def build_base(dest) -> Path:
    """Write the standard-form mock without countertrade to dest and return it."""
    write_zip(_base_files(), dest)
    return Path(dest)


def base_zip() -> io.BytesIO:
    """The standard-form mock without countertrade as a readable zip (a new buffer each call)."""
    buffer = io.BytesIO()
    write_zip(_base_files(), buffer)
    buffer.seek(0)
    return buffer


def shipped_files() -> dict:
    return add_countertrade(_base_files())


def build_standard(dest) -> Path:
    """Write the shipped standard-form mock (base plus the countertrade RAs) to dest and return it."""
    write_zip(shipped_files(), dest)
    return Path(dest)
