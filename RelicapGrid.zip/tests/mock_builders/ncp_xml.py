"""ncp_xml.py - helpers to read and write NCP RDF/XML files in the mock builders: namespaces, deterministic ids, the
Doc class (one parsed file), small element writers, the zip reader, and the map of CGM machines to generating units."""
from __future__ import annotations

import re
import uuid
import xml.etree.ElementTree as ET
import zipfile
from typing import Optional

NC = "https://cim4.eu/ns/nc#"
CIM = "https://cim.ucaiug.io/ns#"
RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
_UUID_NAMESPACE = uuid.UUID("5c1f3b1e-9d2a-4e47-9a53-0b6f6a6c1d10")


def _nc(local: str) -> str:
    return f"{{{NC}}}{local}"


def _cim(local: str) -> str:
    return f"{{{CIM}}}{local}"


def _rdf(local: str) -> str:
    return f"{{{RDF}}}{local}"


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _fragment(uri: Optional[str]) -> str:
    return (uri or "").rsplit("#", 1)[-1].lstrip("_")


def new_id(*parts: str) -> str:
    """A deterministic UUID from the given key parts."""
    return str(uuid.uuid5(_UUID_NAMESPACE, "|".join(parts)))


class Doc:
    """One parsed RDF/XML file; `changed` is set by every edit."""

    def __init__(self, name: str, data: bytes):
        self.name = name
        self.original = data
        text = data.decode("utf-8")
        for prefix, uri in re.findall(r'xmlns:([A-Za-z0-9_.-]+)="([^"]+)"', text):
            try:
                ET.register_namespace(prefix, uri)
            except ValueError:      # a prefix of the form ns<digits> is reserved by ElementTree; it gets a generated one
                pass
        builder = ET.TreeBuilder(insert_comments=True)
        self.root = ET.XMLParser(target=builder)
        self.root.feed(data)
        self.root = self.root.close()
        self.changed = False

    def elements(self, local: str):
        return [e for e in self.root if _local(e.tag) == local and e.tag.startswith("{" + NC)]

    @staticmethod
    def ident(element) -> str:
        return _fragment(element.get(_rdf("ID")) or element.get(_rdf("about")))

    def by_id(self, local: str) -> dict:
        return {self.ident(e): e for e in self.elements(local)}

    def dump(self) -> bytes:
        if not self.changed:
            return self.original
        ET.indent(self.root, space="  ")
        return ET.tostring(self.root, encoding="utf-8", xml_declaration=True) + b"\n"


def _child(element, tag: str):
    for c in element:
        if c.tag == tag:
            return c
    return None


def _children(element, tag: str):
    return [c for c in element if c.tag == tag]


def _text(element, tag: str) -> str:
    c = _child(element, tag)
    return (c.text or "").strip() if c is not None else ""


def _ref(element, tag: str) -> str:
    c = _child(element, tag)
    return _fragment(c.get(_rdf("resource"))) if c is not None else ""


def _new_element(tag: str, ident: str, about: bool = False):
    e = ET.Element(tag)
    e.set(_rdf("about") if about else _rdf("ID"), ("#_" if about else "_") + ident)
    return e


def _add_literal(element, tag: str, value: str):
    c = ET.SubElement(element, tag)
    c.text = value
    return c


def _add_ref(element, tag: str, ident: str):
    c = ET.SubElement(element, tag)
    c.set(_rdf("resource"), "#_" + ident)
    return c


def _add_enum(element, tag: str, uri: str):
    c = ET.SubElement(element, tag)
    c.set(_rdf("resource"), uri)
    return c


def _identified(element, ident: str, name: str = "", description: str = ""):
    if description:
        _add_literal(element, _cim("IdentifiedObject.description"), description)
    _add_literal(element, _cim("IdentifiedObject.mRID"), ident)
    if name:
        _add_literal(element, _cim("IdentifiedObject.name"), name)


def _last_word(value: str) -> str:
    return re.split(r"[#.]", value)[-1]


def _insert_after(root, new, anchor) -> None:
    root.insert(list(root).index(anchor) + 1, new)


def _insert_before(root, new, anchor) -> None:
    root.insert(list(root).index(anchor), new)


def generating_unit_by_machine(cgm_files: dict) -> dict:
    """{RotatingMachine mRID: GeneratingUnit mRID} and the set of GeneratingUnit mRIDs of the CGM EQ files."""
    pattern = re.compile(
        r'<cim:(?:SynchronousMachine|AsynchronousMachine) rdf:ID="_([^"]+)">(.*?)</cim:(?:SynchronousMachine|AsynchronousMachine)>', re.S)
    unit_pattern = re.compile(r'<cim:RotatingMachine\.GeneratingUnit rdf:resource="#_([^"]+)"')
    machines, units = {}, set()
    for name, data in cgm_files.items():
        if "_EQ_" not in name:
            continue
        text = data.decode("utf-8")
        units.update(re.findall(r'<cim:[A-Za-z]*GeneratingUnit rdf:ID="_([^"]+)"', text))
        for machine, body in pattern.findall(text):
            unit = unit_pattern.search(body)
            if unit:
                machines[machine] = unit.group(1)
    return machines, units


def _read_zip(path) -> dict:
    with zipfile.ZipFile(path) as z:
        return {item.filename: z.read(item.filename) for item in z.infolist() if not item.is_dir()}
