"""Builders of the mock NCP packages that the tests use (the shipped standard mock, countertrade, HVDC, dataset and
legacy-form variants). They read only tests/fixtures. tests/tools/ (the fixture tool) imports them to regenerate fixtures."""
