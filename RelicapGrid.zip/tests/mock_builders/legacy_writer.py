"""ncp_legacy_form/writer.py - the ReliCapGrid mock NCP written in the "NCP 2.2 legacy form".

Section of the converter tools (next to convert_ncp_to_standard.py, same helpers): where that converter rewrites the
old mock into the standard form, this one rewrites the shipped standard-form mock into the legacy form. Values and ids
of AE and CO stay as they are; RA and SIS keep their ids, only the shape changes. No non-public data is used: TSO ids are
synthetic EIC codes, profile names of IAM and PS are placeholders (the header keyword is what a reader uses).

Form (docs/specs/ncp_data_requirements.md section 13):
  - one flat folder, no organisation (CD) file, no SHS, one file per TSO and profile, named
    <effectiveDateTime>_<timeframe>_<sendingParty>_<profileKeyword>_<fileVersion>.xml
  - header: md:FullModel with accessRights, creator (the TSO's EIC URI, as text), conformsTo, identifier,
    generatedAtTime, startDate, endDate, keyword, version; the EIC has 16 characters with hyphens as padding
  - RA: redispatch with BiddingZone (an EIC URI, no organisation file) / penaltyFactor / kind, contingency links with normalEnabled, countertrade with
    gLSKStrategy (proportionalForGenerator, explicitSchedule) and shiftMethod, one PST RA with two TapPositionActions
    and no range (it takes over the tap changer of the second PST RA), one topology RA with a StaticPropertyRange
  - SIS: bids of the first TSO without a direction (name suffix _UP / _DOWN), bids of the second TSO with
    BidDirectionKind.up / down, p > 0 for every bid, shift keys in the GLSKSchedule chain only
  - SSI, IAM, PS, ER files.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path

from . import ncp_xml as conv
from .ncp_xml import Doc, _add_enum, _add_literal, _add_ref, _child, _nc, _rdf, _ref
from .zipio import write_zip

EIC_BY_TSO = {"Belgovia": "10X-MOCK-TSO---A", "Espheim": "10X-MOCK-TSO---B", "Galia": "10X-MOCK-TSO---C", "Svedala": "10X-MOCK-TSO---D"}
PROFILES = ("AE", "CO", "RA", "SIS", "SSI", "IAM", "PS", "ER")
PROFILE_NAME = {"AE": "AssessedElement", "CO": "Contingency", "RA": "RemedialAction", "SIS": "StateInstructionSchedule",
                "SSI": "SteadyStateInstruction", "IAM": "ImpactAssessmentMatrix", "PS": "PlannedSchedule",
                "ER": "EquipmentReliability"}
NO_DIRECTION_TSO = "Belgovia"
BID_DIRECTION_KIND_TSO = "Espheim"
PST_TWO_ACTIONS_TSO = "Belgovia"
TOPOLOGY_TSO = "Belgovia"
SENDING_PARTY_PREFIX = "20220615T1030Z_1D"
FILE_VERSION = "001"
PARTY = "http://energy.referencedata.eu/EIC/"
PROPERTY_REFERENCE = "https://energy.referencedata.eu/PropertyReference/"
ZONE_BASES = ("http://energy.referencedata.eu/EIC/", "http://data.europa.eu/energy/EIC/")      # both appear in a zone reference
ZONE_EIC_BY_TSO = {tso: "10Y-MOCK-ZONE--" + eic[-1] for tso, eic in EIC_BY_TSO.items()}
NC_URI = conv.NC
LEGACY_NC = "http://entsoe.eu/ns/nc#"
LEGACY_CIM = "http://iec.ch/TC57/CIM100#"
LEGACY_EU = "http://iec.ch/TC57/CIM100-European#"
LEGACY_XML_BASE = "http://entsoe.eu/ns/nc"
NAMESPACES = (f'xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:nc="{LEGACY_NC}" xmlns:cim="{LEGACY_CIM}" '
              f'xmlns:eu="{LEGACY_EU}" xml:base="{LEGACY_XML_BASE}"')
_ROOT = re.compile(r"<rdf:RDF(?=[\s>])")
_HEADER = re.compile(r"<(md:FullModel|dcat:Dataset)\b.*?</\1>", re.S)      # the header of the standard-form source
MD = "http://iec.ch/TC57/61970-552/ModelDescription/1#"
DCTERMS = "http://purl.org/dc/terms/#"           # the header namespaces end with "#"
DC = "http://purl.org/dc/elements/1.1/#"

CT_STRATEGIES = ("proportionalForGenerator", "explicitSchedule")
CT_SHIFT_METHOD = "MOCK_SHIFT_METHOD"

CGMES_2_4_15 = "http://iec.ch/TC57/2013/CIM-schema-cim16#"
ENTSOE_EXTENSION = "http://entsoe.eu/CIM/SchemaExtension/3/1#"
EQ_SNIPPET_ZONE_EICS = {"MOCK_CA_A": "10Y-MOCK-ZONE--A", "MOCK_CA_B": "10Y-MOCK-ZONE--B"}
EQ_SNIPPET_UNITS = ("MOCK_GU_1", "MOCK_GU_2", "MOCK_GU_3")


def file_name(tso: str, profile: str) -> str:
    return f"{SENDING_PARTY_PREFIX}_{EIC_BY_TSO[tso]}_{profile}_{FILE_VERSION}.xml"


def zone_uri(tso: str) -> str:
    """The BiddingZone reference of a TSO: an EIC URI, alternating between the two known bases."""
    base = ZONE_BASES[list(EIC_BY_TSO).index(tso) % len(ZONE_BASES)]
    return base + ZONE_EIC_BY_TSO[tso]


def _header(tso: str, profile: str) -> str:
    name = file_name(tso, profile)
    identifier = conv.new_id("ncp22-header", name)
    return f"""<md:FullModel xmlns:md="{MD}" xmlns:dcat="http://www.w3.org/ns/dcat#" xmlns:dcterms="{DCTERMS}" xmlns:dc="{DC}" xmlns:prov="http://www.w3.org/ns/prov#" rdf:about="urn:uuid:{identifier}">
    <dcterms:accessRights>http://example.invalid/access-right/MOCK</dcterms:accessRights>
    <dcterms:creator>{PARTY}{EIC_BY_TSO[tso]}</dcterms:creator>
    <dcterms:conformsTo rdf:resource="http://entsoe.eu/ns/CIM/{PROFILE_NAME[profile]}-EU/2.2"/>
    <dcterms:identifier>urn:uuid:{identifier}</dcterms:identifier>
    <prov:generatedAtTime>2022-06-15T10:00:00Z</prov:generatedAtTime>
    <dcat:startDate>2022-06-15T10:30:00Z</dcat:startDate>
    <dcat:endDate>2022-06-15T11:30:00Z</dcat:endDate>
    <dcat:keyword>{profile}</dcat:keyword>
    <dcat:version>{FILE_VERSION}</dcat:version>
  </md:FullModel>"""


def _with_header(tso: str, profile: str, data: bytes) -> bytes:
    """The content of `data` with its dataset header replaced by the legacy-form header."""
    text = data.decode("utf-8")
    replaced, count = _HEADER.subn(lambda _: _header(tso, profile), text, count=1)
    assert count == 1, f"{tso} {profile}: no dataset header"
    return replaced.encode("utf-8")


def _document(tso: str, profile: str, body: str = "") -> bytes:
    return (f'<?xml version="1.0" encoding="UTF-8"?>\n<rdf:RDF {NAMESPACES}>\n  {_header(tso, profile)}\n{body}</rdf:RDF>\n'
            ).encode("utf-8")


# ---------------------------------------------------------------------------
# RA
# ---------------------------------------------------------------------------

def _convert_ra(tso: str, data: bytes) -> bytes:
    doc = Doc(f"{tso}_RA.xml", data)
    root = doc.root
    for strategy in doc.elements("PowerShiftKeyStrategy"):
        root.remove(strategy)
    for zone in root.iter(_nc("PowerRemedialAction.BiddingZone")):
        zone.set(_rdf("resource"), zone_uri(tso))
    for link in doc.elements("ContingencyWithRemedialAction"):
        if _child(link, _nc("ContingencyWithRemedialAction.normalEnabled")) is None:
            _add_literal(link, _nc("ContingencyWithRemedialAction.normalEnabled"), "true")
    for index, ra in enumerate(doc.elements("CountertradeRemedialAction")):
        _add_enum(ra, _nc("CountertradeRemedialAction.gLSKStrategy"), f"{NC_URI}GLSKStrategyKind.{CT_STRATEGIES[index % 2]}")
        _add_literal(ra, _nc("CountertradeRemedialAction.shiftMethod"), CT_SHIFT_METHOD)
    if tso == PST_TWO_ACTIONS_TSO:
        _add_second_tap_action(doc)
    if tso == TOPOLOGY_TSO:
        _add_topology_action(doc)
    doc.changed = True
    return doc.dump()


def _add_second_tap_action(doc: Doc) -> None:
    """The first PST RA takes over the tap changer of the second PST RA as a second TapPositionAction (the second RA, its
    action and its contingency links are dropped, so the number of PSTs stays the same)."""
    actions = doc.elements("TapPositionAction")
    first, second = actions[0], actions[1]
    first_ra = _ref(first, _nc("GridStateAlteration.GridStateAlterationRemedialAction"))
    second_ra = _ref(second, _nc("GridStateAlteration.GridStateAlterationRemedialAction"))
    second_changer = _ref(second, _nc("TapPositionAction.TapChanger"))
    for ra in doc.elements("GridStateAlterationRemedialAction"):
        if Doc.ident(ra) == second_ra:
            doc.root.remove(ra)
    for link in doc.elements("ContingencyWithRemedialAction"):
        if _ref(link, _nc("ContingencyWithRemedialAction.RemedialAction")) == second_ra:
            doc.root.remove(link)
    action_id = Doc.ident(second)
    second.find(_nc("GridStateAlteration.GridStateAlterationRemedialAction")).set(_rdf("resource"), "#_" + first_ra)

def _add_topology_action(doc: Doc) -> None:
    """One preventive topology RA: a TopologyAction on Switch.open with a StaticPropertyRange."""
    key = Doc.ident(doc.elements("GridStateAlterationRemedialAction")[0])
    ra_id, action_id, range_id, switch_id = (conv.new_id("ncp22-topology", key, part) for part in ("ra", "action", "range", "switch"))
    doc.root.append(ET.fromstring(f"""<nc:GridStateAlterationRemedialAction xmlns:nc="{NC_URI}" xmlns:cim="{conv.CIM}" xmlns:rdf="{conv.RDF}" rdf:ID="_{ra_id}">
    <cim:IdentifiedObject.mRID>{ra_id}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>PRA_TOPO_MOCK_SWITCH</cim:IdentifiedObject.name>
    <nc:RemedialAction.kind rdf:resource="{NC_URI}RemedialActionKind.preventive"/>
    <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
    <nc:RemedialAction.penaltyFactor>1.0</nc:RemedialAction.penaltyFactor>
  </nc:GridStateAlterationRemedialAction>"""))
    doc.root.append(ET.fromstring(f"""<nc:TopologyAction xmlns:nc="{NC_URI}" xmlns:cim="{conv.CIM}" xmlns:rdf="{conv.RDF}" rdf:ID="_{action_id}">
    <cim:IdentifiedObject.mRID>{action_id}</cim:IdentifiedObject.mRID>
    <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_{ra_id}"/>
    <nc:GridStateAlteration.PropertyReference rdf:resource="{PROPERTY_REFERENCE}Switch.open"/>
    <nc:TopologyAction.Switch rdf:resource="#_{switch_id}"/>
  </nc:TopologyAction>"""))
    doc.root.append(ET.fromstring(f"""<nc:StaticPropertyRange xmlns:nc="{NC_URI}" xmlns:rdf="{conv.RDF}" rdf:ID="_{range_id}">
    <nc:RangeConstraint.GridStateAlteration rdf:resource="#_{action_id}"/>
    <nc:StaticPropertyRange.PropertyReference rdf:resource="{PROPERTY_REFERENCE}Switch.open"/>
    <nc:RangeConstraint.normalValue>1</nc:RangeConstraint.normalValue>
  </nc:StaticPropertyRange>"""))


# ---------------------------------------------------------------------------
# SIS
# ---------------------------------------------------------------------------

def _convert_sis(tso: str, data: bytes) -> bytes:
    doc = Doc(f"{tso}_SIS.xml", data)
    root = doc.root
    _convert_bids(tso, doc)
    _convert_shift_keys(doc)
    ET.indent(root, space="  ")
    doc.changed = True
    return doc.dump()


def _positive_p(doc: Doc) -> None:
    for point in doc.elements("PowerBidScheduleTimePoint"):
        p = _child(point, _nc("PowerBidScheduleTimePoint.p"))
        if p is not None and (p.text or "").strip():
            p.text = p.text.strip().lstrip("-+")


def _convert_bids(tso: str, doc: Doc) -> None:
    _positive_p(doc)
    for bid in doc.elements("PowerBidSchedule"):
        direction = _child(bid, _nc("PowerBidSchedule.direction"))
        word = direction.get(_rdf("resource"), "").rsplit(".", 1)[-1]
        if tso == NO_DIRECTION_TSO:
            bid.remove(direction)
            name = _child(bid, conv._cim("IdentifiedObject.name"))
            name.text = re.sub(r"_(UP|DOWN)_(\d+)$", r"_\2_\1", name.text)
        elif tso == BID_DIRECTION_KIND_TSO:
            direction.set(_rdf("resource"), f"{NC_URI}BidDirectionKind.{word}")


def _convert_shift_keys(doc: Doc) -> None:
    """The bid route of the standard chain becomes the GLSKSchedule chain (same ids); the strategy route is dropped."""
    root = doc.root
    strategy_schedules = set()
    for distribution in doc.elements("PowerShiftKeyDistribution"):
        if _child(distribution, _nc("PowerShiftKeyDistribution.PowerShiftKeyStrategy")) is not None:
            strategy_schedules.add(_ref(distribution, _nc("PowerShiftKeyDistribution.PowerShiftKeySchedule")))
            root.remove(distribution)
    for schedule in doc.elements("PowerShiftKeySchedule"):
        if Doc.ident(schedule) in strategy_schedules:
            root.remove(schedule)
    for point in doc.elements("ParticipationFactorTimePoint"):
        if _ref(point, _nc("ParticipationFactorTimePoint.PowerShiftKeySchedule")) in strategy_schedules:
            root.remove(point)
            continue
        point.remove(_child(point, _nc("ParticipationFactorTimePoint.atTime")))
        _rename_children(point, {"ParticipationFactorTimePoint.PowerShiftKeySchedule": "ParticipationFactorTimePoint.GLSKSchedule"})
    for schedule in doc.elements("PowerShiftKeySchedule"):
        schedule.tag = _nc("GLSKSchedule")
        _rename_children(schedule, {"PowerShiftKeySchedule.GeneratingUnit": "GLSKSchedule.GeneratingUnit"})
    for distribution in doc.elements("PowerShiftKeyDistribution"):
        distribution.tag = _nc("GLSKBidActionDistribution")
        _rename_children(distribution, {"PowerShiftKeyDistribution.PowerBidSchedule": "GLSKBidActionDistribution.PowerBidSchedule",
                                        "PowerShiftKeyDistribution.PowerShiftKeySchedule": "GLSKBidActionDistribution.GLSKSchedule"})


def _rename_children(element, names: dict) -> None:
    for child in element:
        local = child.tag.rsplit("}", 1)[-1]
        if local in names:
            child.tag = _nc(names[local])


# ---------------------------------------------------------------------------
# other profiles
# ---------------------------------------------------------------------------

def _ra_mrids(ra_data: bytes) -> list:
    doc = Doc("ra", ra_data)
    return [(e.tag.rsplit("}", 1)[-1], Doc.ident(e)) for e in doc.root
            if e.tag.rsplit("}", 1)[-1] in ("RedispatchRemedialAction", "CountertradeRemedialAction", "GridStateAlterationRemedialAction")
            and e.tag.startswith("{" + NC_URI)]


def _ssi(tso: str, ra_data: bytes) -> bytes:
    body = "".join(f'  <nc:{cls} rdf:about="#_{ident}">\n    <nc:RemedialAction.available>true</nc:RemedialAction.available>\n  </nc:{cls}>\n'
                   for cls, ident in _ra_mrids(ra_data))
    return _document(tso, "SSI", body)


def _iam(tso: str, ra_data: bytes) -> bytes:
    ra_id = _ra_mrids(ra_data)[0][1]
    ident = conv.new_id("ncp22-impact", tso)
    body = f"""  <nc:QualitativeRemedialActionImpact rdf:ID="_{ident}">
    <cim:IdentifiedObject.mRID>{ident}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>IMPACT_MOCK</cim:IdentifiedObject.name>
    <nc:QualitativeRemedialActionImpact.RemedialAction rdf:resource="#_{ra_id}"/>
  </nc:QualitativeRemedialActionImpact>
"""
    return _document(tso, "IAM", body)


# ---------------------------------------------------------------------------
# driver
# ---------------------------------------------------------------------------

def _legacy_namespaces(data: bytes) -> bytes:
    """The namespaces of the legacy form: nc, cim and eu declared as in the form, xml:base on rdf:RDF, enum values and
    every other nc / cim URI in these namespaces."""
    text = data.decode("utf-8").replace(NC_URI, LEGACY_NC).replace("https://cim.ucaiug.io/ns#", LEGACY_CIM)
    if "xmlns:eu=" not in text:
        text = _ROOT.sub(lambda m: f'<rdf:RDF xmlns:eu="{LEGACY_EU}"', text, count=1)
    if "xml:base=" not in text:
        text = _ROOT.sub(lambda m: f'<rdf:RDF xml:base="{LEGACY_XML_BASE}"', text, count=1)
    return text.encode("utf-8")


def legacy_files(source_files: dict | None = None) -> dict:
    """{file name: bytes} of the mock in the legacy form, made from the shipped standard-form mock (or `source_files`)."""
    if source_files is None:
        from . import standard
        source_files = standard.shipped_files()
    files = {}
    for tso in EIC_BY_TSO:
        ra = _convert_ra(tso, source_files[f"{tso}_RA.xml"])
        files[file_name(tso, "AE")] = _with_header(tso, "AE", source_files[f"{tso}_AE.xml"])
        files[file_name(tso, "CO")] = _with_header(tso, "CO", source_files[f"{tso}_CO.xml"])
        files[file_name(tso, "RA")] = _with_header(tso, "RA", ra)
        files[file_name(tso, "SIS")] = _with_header(tso, "SIS", _convert_sis(tso, source_files[f"{tso}_SIS.xml"]))
        files[file_name(tso, "SSI")] = _ssi(tso, ra)
        files[file_name(tso, "IAM")] = _iam(tso, ra)
        files[file_name(tso, "PS")] = _document(tso, "PS")
        files[file_name(tso, "ER")] = _document(tso, "ER")
    return {name: _legacy_namespaces(data) for name, data in files.items()}


def build_legacy(dest) -> Path:
    """Write the legacy-form mock zip (flat, no organisation file) to dest and return it."""
    write_zip(legacy_files(), dest)
    return Path(dest)


def eq_snippet_2_4_15() -> bytes:
    """A small EQ file in the CGMES 2.4.15 namespace: two ControlAreas with an EIC, three generating units, and no
    ControlAreaGeneratingUnit (the zone-to-units fallback of the legacy form reads exactly this)."""
    areas = "".join(f"""  <cim:ControlArea rdf:ID="_{conv.new_id('ncp22-eq-area', name)}">
    <cim:IdentifiedObject.mRID>{conv.new_id('ncp22-eq-area', name)}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>{name}</cim:IdentifiedObject.name>
    <entsoe:IdentifiedObject.energyIdentCodeEic>{eic}</entsoe:IdentifiedObject.energyIdentCodeEic>
    <cim:ControlArea.type rdf:resource="{CGMES_2_4_15}ControlAreaTypeKind.Interchange"/>
  </cim:ControlArea>
""" for name, eic in EQ_SNIPPET_ZONE_EICS.items())
    units = "".join(f"""  <cim:ThermalGeneratingUnit rdf:ID="_{conv.new_id('ncp22-eq-unit', name)}">
    <cim:IdentifiedObject.mRID>{conv.new_id('ncp22-eq-unit', name)}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>{name}</cim:IdentifiedObject.name>
    <cim:GeneratingUnit.maxOperatingP>100</cim:GeneratingUnit.maxOperatingP>
    <cim:GeneratingUnit.minOperatingP>0</cim:GeneratingUnit.minOperatingP>
  </cim:ThermalGeneratingUnit>
""" for name in EQ_SNIPPET_UNITS)
    header = f"""  <md:FullModel rdf:about="urn:uuid:{conv.new_id('ncp22-eq-header', 'eq')}">
    <md:Model.profile>http://entsoe.eu/CIM/EquipmentCore/3/1</md:Model.profile>
    <md:Model.scenarioTime>2022-06-15T10:30:00Z</md:Model.scenarioTime>
    <md:Model.modelingAuthoritySet>http://example.invalid/MOCK_AUTHORITY</md:Model.modelingAuthoritySet>
  </md:FullModel>
"""
    return (f'<?xml version="1.0" encoding="UTF-8"?>\n<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
            f'xmlns:md="{MD}" xmlns:cim="{CGMES_2_4_15}" xmlns:entsoe="{ENTSOE_EXTENSION}">\n{header}{areas}{units}{_eq_snippet_pst()}</rdf:RDF>\n').encode("utf-8")


def _snippet_id(kind: str) -> str:
    return conv.new_id("ncp22-eq-pst", kind)


def eq_snippet_pst_ids() -> dict:
    """The ids (no mRID in the file, as in the 2.4.15 form: the rdf:ID without its underscore) of the PST and the current
    limit of the snippet: transformer, tap_changer, limit, and the side of the limit."""
    return {"transformer": _snippet_id("transformer"), "tap_changer": _snippet_id("tap_changer"), "limit": _snippet_id("limit"), "side": 2}


def _eq_snippet_pst() -> str:
    """One PowerTransformer with an end, a PhaseTapChangerAsymmetrical, and a CurrentLimit on the second terminal."""
    ids = {kind: _snippet_id(kind) for kind in ("transformer", "end", "tap_changer", "terminal", "limit_set", "limit")}
    return f"""  <cim:PowerTransformer rdf:ID="_{ids['transformer']}">
    <cim:IdentifiedObject.name>MOCK_PT_1</cim:IdentifiedObject.name>
  </cim:PowerTransformer>
  <cim:PowerTransformerEnd rdf:ID="_{ids['end']}">
    <cim:PowerTransformerEnd.PowerTransformer rdf:resource="#_{ids['transformer']}"/>
  </cim:PowerTransformerEnd>
  <cim:PhaseTapChangerAsymmetrical rdf:ID="_{ids['tap_changer']}">
    <cim:IdentifiedObject.name>MOCK_PTC_1</cim:IdentifiedObject.name>
    <cim:PhaseTapChanger.TransformerEnd rdf:resource="#_{ids['end']}"/>
  </cim:PhaseTapChangerAsymmetrical>
  <cim:Terminal rdf:ID="_{ids['terminal']}">
    <cim:ACDCTerminal.sequenceNumber>2</cim:ACDCTerminal.sequenceNumber>
  </cim:Terminal>
  <cim:OperationalLimitSet rdf:ID="_{ids['limit_set']}">
    <cim:OperationalLimitSet.Terminal rdf:resource="#_{ids['terminal']}"/>
  </cim:OperationalLimitSet>
  <cim:CurrentLimit rdf:ID="_{ids['limit']}">
    <cim:OperationalLimit.OperationalLimitSet rdf:resource="#_{ids['limit_set']}"/>
  </cim:CurrentLimit>
"""


def eq_snippet_unit_ids() -> list:
    return [conv.new_id("ncp22-eq-unit", name) for name in EQ_SNIPPET_UNITS]
