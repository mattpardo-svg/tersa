"""paths.py - where the test data files are and what they are called: the one place to rename a zip.
Imports nothing but pathlib. Everything is under tests/fixtures."""
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
FIXTURES = REPO_ROOT / "tests" / "fixtures"

CGM_ZIP = FIXTURES / "CGM_package.zip"                       # official ReliCapGrid CGM sample
STANDARD_ZIP = FIXTURES / "NCP_mock_standard.zip"            # the shipped standard-form mock NCP (base plus countertrade RAs)
STANDARD_BASE_ZIP = FIXTURES / "NCP_mock_standard_base.zip"  # the standard-form mock without countertrade: start of every builder
SAMPLE_GENERIC_ZIP = FIXTURES / "NCP_sample_generic_2_4.zip" # official ReliCapGrid NCP sample (profile 2.4)
FINGERPRINTS_JSON = FIXTURES / "milp_model_fingerprints.json"
