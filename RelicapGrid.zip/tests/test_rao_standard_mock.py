"""
tests/test_rao_standard_mock.py - the standard-form mock NCP of tests/fixtures (the shipped mock, its base without
countertrade) and the builders that start from it: they are what they are said to be, byte for byte, and they follow the
rules of the profiles (no old-form element).
"""
import hashlib
import logging
import re
import zipfile

import pytest
from rdflib import Graph, RDF, Namespace

from mock_builders import ct_mock, hvdc_mock, ncp_xml, paths, standard
from helpers import _MOCK_NX_CGM_ZIP, _MOCK_NX_NCP_ZIP, mock_generators_by_unit

NC = Namespace("https://cim4.eu/ns/nc#")
TS = "1030Z"
RD_TSOS = ["Belgovia", "Espheim", "Galia", "Svedala"]
POWER_RA = ("RedispatchRemedialAction", "CountertradeRemedialAction", "HvdcRemedialAction", "GridStateAlterationRemedialAction")
PSKS_RESOURCES = ("GeneratingUnit", "PowerElectronicsUnit", "HydroPump", "EnergyConsumer", "EnergySource", "EquivalentInjection",
                  "ExternalNetworkInjection", "DCEquivalentInjection", "DCPole", "EnergyBlockOrder", "EnergyResourceGroupCapacity",
                  "ScheduleResource", "SchedulingArea")
BASE_SHA256 = "c48ceb778870e1bc0443571eea88679bcb332326313635ac1dfc963ac59121e5"


def _extract(zip_path, dest):
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(dest)
    return dest


def _graph(path):
    g = Graph()
    g.parse(str(path), format="xml", publicID="urn:ncp")
    return g


def _frag(uri):
    return str(uri).rsplit("#", 1)[-1].lstrip("_")


def _local(uri):
    return str(uri).rsplit("#", 1)[-1]


@pytest.fixture(scope="module")
def work(tmp_path_factory):
    return tmp_path_factory.mktemp("standard_mock")


@pytest.fixture(scope="module")
def generating_units():
    return ncp_xml.generating_unit_by_machine(ncp_xml._read_zip(_MOCK_NX_CGM_ZIP))[1]


def standard_form_violations(directory, generating_units):
    """Rules of the profiles that the mock keeps; an empty list for standard-form data."""
    found = []
    for ra_path in sorted(directory.glob("*_RA.xml")):
        tso = ra_path.name.removesuffix("_RA.xml")
        ra, sis_path = _graph(ra_path), directory / f"{tso}_SIS.xml"
        class_of = {_frag(s): _local(o) for s, _, o in ra.triples((None, RDF.type, None))}
        for subject, cls in class_of.items():
            if cls == "RotatingMachineAction":
                found.append(f"{tso}: RotatingMachineAction {subject}")
        for s, p, o in ra:
            if _local(p) in ("CountertradeRemedialAction.gLSKStrategy", "CountertradeRemedialAction.powerShiftKey",
                             "CountertradeRemedialAction.method", "RemedialActionDependency.RemedialActionGroup"):
                found.append(f"{tso}: {_local(p)}")
            if _local(p).endswith("PowerShiftKeyStrategy") and class_of.get(_frag(s), "").endswith("RemedialAction"):
                found.append(f"{tso}: a strategy reference on the RA {s}")
        for strategy in [s for s in ra.subjects(RDF.type, NC.PowerShiftKeyStrategy)]:
            target = ra.value(strategy, NC["PowerShiftKeyStrategy.PowerRemedialAction"])
            if target is None or class_of.get(_frag(target)) not in POWER_RA:
                found.append(f"{tso}: strategy {strategy} does not point at a power remedial action")
        if not sis_path.exists():
            continue
        sis = _graph(sis_path)
        for pbs in sis.subjects(RDF.type, NC.PowerBidSchedule):
            target = sis.value(pbs, NC["PowerBidSchedule.PowerRemedialAction"])
            if target is not None and class_of.get(_frag(target)) not in POWER_RA:
                found.append(f"{tso}: bid {_frag(pbs)} points at {class_of.get(_frag(target))}")
            direction = sis.value(pbs, NC["PowerBidSchedule.direction"])
            if direction is not None and "MarketRegulationDirectionKind" not in str(direction):
                found.append(f"{tso}: direction literal {direction}")
            if sis.value(pbs, NC["BaseTimeSeries.interpolationKind"]) is None:
                found.append(f"{tso}: bid without interpolationKind")
            for attribute in ("penaltyFactor", "minEnergyBid", "maxEnergyBid", "stepSizeCTRD", "gLSKStrategy"):
                if sis.value(pbs, NC[f"PowerBidSchedule.{attribute}"]) is not None:
                    found.append(f"{tso}: PowerBidSchedule.{attribute}")
        for psks in sis.subjects(RDF.type, NC.PowerShiftKeySchedule):
            resources = [(p, o) for p, o in sis.predicate_objects(psks) if _local(p).startswith("PowerShiftKeySchedule.")
                         and _local(p).split(".")[1] in PSKS_RESOURCES]
            if len(resources) != 1:
                found.append(f"{tso}: key {psks} has {len(resources)} resources")
            for p, o in resources:
                if _local(p) == "PowerShiftKeySchedule.GeneratingUnit" and _frag(o) not in generating_units:
                    found.append(f"{tso}: key {psks} names {_frag(o)}, not a GeneratingUnit")
            if sis.value(psks, NC["BaseTimeSeries.interpolationKind"]) is None:
                found.append(f"{tso}: key without interpolationKind")
        for dist in sis.subjects(RDF.type, NC.PowerShiftKeyDistribution):
            ends = [sis.value(dist, NC["PowerShiftKeyDistribution.PowerBidSchedule"]),
                    sis.value(dist, NC["PowerShiftKeyDistribution.PowerShiftKeyStrategy"])]
            if sum(e is not None for e in ends) != 1:
                found.append(f"{tso}: distribution {dist} needs exactly one of bid and strategy")
        for point in sis.subjects(RDF.type, NC.RemedialActionGroupTimePoint):
            if sis.value(point, NC["RemedialActionGroupTimePoint.RemedialActionGroupSchedule"]) is None:
                found.append(f"{tso}: group time point {point} has no schedule")
            if sis.value(point, NC["RemedialActionGroupTimePoint.RemedialActionGroup"]) is not None:
                found.append(f"{tso}: group time point {point} links the group directly")
            for limit in ("maxRegulatingUp", "maxRegulatingDown"):
                if sis.value(point, NC[f"RemedialActionGroup.{limit}"]) is not None:
                    found.append(f"{tso}: {limit} declared by RemedialActionGroup")
    return found


def _rd_snapshot(directory):
    from pre_milp import ncp_parser

    machines = {m for ms in mock_generators_by_unit().values() for m in ms}
    gens = {m: {"name": m, "target_p": 10.0, "max_p": 100.0, "min_p": 0.0} for m in machines}
    units, bids = [], []
    for tso in RD_TSOS:
        u, b = ncp_parser.parse_rd_units(directory / f"{tso}_RA.xml", directory / f"{tso}_SIS.xml", f"TSO-{tso}", TS, gens,
                                         generators_by_unit=mock_generators_by_unit())
        units += u
        bids += b
    return units, bids


# ---------------------------------------------------------------------------
# the fixtures and the builders
# ---------------------------------------------------------------------------

def test_rao_the_shipped_mock_is_the_base_plus_the_countertrade_ras(work):
    """NCP_mock_standard.zip is what mock_builders.standard generates: the base without countertrade
    (tests/fixtures/NCP_mock_standard_base.zip) plus the countertrade RAs and bids of the four regions
    (regenerate it with `python tests/tools/fixture_cli.py standard` when the base or the countertrade data change)."""
    assert standard.build_standard(work / "regenerated.zip").read_bytes() == _MOCK_NX_NCP_ZIP.read_bytes()


def test_rao_the_base_of_the_builders_is_the_frozen_standard_mock_without_countertrade(work):
    """The base that the countertrade, HVDC, dataset and shared-bid builders start from is a fixture (SHA-256 fixed)."""
    base = standard.build_base(work / "base.zip").read_bytes()
    assert base == paths.STANDARD_BASE_ZIP.read_bytes()
    assert hashlib.sha256(base).hexdigest() == BASE_SHA256
    assert sorted(zipfile.ZipFile(paths.STANDARD_BASE_ZIP).namelist()) == sorted(zipfile.ZipFile(_MOCK_NX_NCP_ZIP).namelist())


def test_rao_the_shipped_mock_and_its_base_follow_the_rules_of_the_profiles(work, generating_units):
    shipped = _extract(_MOCK_NX_NCP_ZIP, work / "shipped_p")
    assert standard_form_violations(shipped, generating_units) == []
    base = _extract(standard.build_base(work / "base_for_rules.zip"), work / "base_p")
    assert standard_form_violations(base, generating_units) == []


def test_rao_the_countertrade_and_hvdc_mocks_follow_the_rules_of_the_profiles(work, generating_units):
    for name, builder in (("ct", ct_mock.build_ct_mock_ncp), ("hvdc", hvdc_mock.build_hvdc_mock_ncp)):
        directory = _extract(builder(work / f"{name}.zip"), work / f"{name}_dir")
        assert standard_form_violations(directory, generating_units) == [], name


def test_rao_the_shipped_mock_gives_no_unsupported_element_or_sign_warning(work, caplog):
    shipped = _extract(_MOCK_NX_NCP_ZIP, work / "shipped_warnings")
    with caplog.at_level(logging.WARNING):
        units, bids = _rd_snapshot(shipped)
    assert len(units) == 32 and len(bids) == 32
    assert [r.getMessage() for r in caplog.records if any(w in r.getMessage() for w in ("not supported", "sign of p", "not in the profile"))] == []
