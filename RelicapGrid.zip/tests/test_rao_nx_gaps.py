"""
tests/test_rao_nx_gaps.py - the NCP 2.2 legacy form (docs/specs/ncp_data_requirements.md section 13):
1. branches that are not monitored in N-X, dropped for one contingency or tripped by it are not tried and logged again for
   every contingency; the remaining skipped pairs and the skipped contingencies are one summary per cause;
3. a pair of the contingency's own equipment is debug only;
4. a contingency without a result gets its real reason ("no impact: equipment already disconnected" is information, a failed
   load flow a warning);
5. a contingency that islands a monitored branch is evaluated without that branch (decision 5a);
2. the warning for a NaN N-0 sensitivity says what the branch is.
The network is a small synthetic pypowsybl network.
"""
import csv
import logging
from types import SimpleNamespace

import pytest

pytest.importorskip("pypowsybl")
import pypowsybl as pp

from data_model import AEType, AssessedElement, Contingency, ContingencyType, LfNx

LINE_1, LINE_2, TRAFO_GEN, TRAFO_LOAD = "NHV1_NHV2_1", "NHV1_NHV2_2", "NGEN_NHV1", "NHV2_NLOAD"


def _network():
    """The eurostag network with line 2 open at both ends: line 1 carries everything, so tripping it islands the load side."""
    network = pp.network.create_eurostag_tutorial_example1_network()
    network.update_lines(id=LINE_2, connected1=False, connected2=False)
    pp.loadflow.run_ac(network)
    return network


def _ae(branch):
    return AssessedElement(mrid=f"AE_{branch}", name="AE", tso="TSO-X", ae_type=AEType.SECURED, branch_mrid=branch, secured_for_region="R",
                           scanned_for_region=None, exclusion_reason=None, patl_ka={"1030Z": 1.0}, branch_side=1)


def _contingency(mrid, *equipment):
    return Contingency(mrid=mrid, name=mrid, tso="TSO-X", contingency_type=ContingencyType.ORDINARY, must_study={"1030Z": True},
                       equipment_mrids=list(equipment), equipment_types=["line"] * len(equipment))


def _compute(network, contingencies, branches):
    from pre_milp.nx_security_analysis import compute_lf_nx

    return compute_lf_nx(network, contingencies, [_ae(b) for b in branches], "1030Z")


# ---------------------------------------------------------------------------
# 5: a contingency that islands a monitored branch
# ---------------------------------------------------------------------------

def test_rao_a_contingency_that_islands_a_monitored_branch_is_evaluated_without_it(caplog):
    with caplog.at_level(logging.WARNING):
        lf_nx, skipped = _compute(_network(), [_contingency("C_ISLAND", LINE_1)], [LINE_1, TRAFO_GEN, TRAFO_LOAD])
    assert skipped == {} and list(lf_nx) == ["C_ISLAND"]
    assert set(lf_nx["C_ISLAND"]) == {TRAFO_GEN}                       # the load side is islanded: no result for it
    assert lf_nx.dropped == {"C_ISLAND": [TRAFO_LOAD]} and lf_nx.tripped == {"C_ISLAND": [LINE_1]}
    warnings = [r.getMessage() for r in caplog.records if "evaluated without" in r.getMessage()]
    assert len(warnings) == 1 and "C_ISLAND" in warnings[0] and "1 (branch, contingency) pair" in warnings[0]
    assert "likely network split" not in caplog.text


# ---------------------------------------------------------------------------
# 4: the real reason of a contingency without a result
# ---------------------------------------------------------------------------

def test_rao_a_contingency_on_equipment_that_is_already_open_is_labelled_no_impact(caplog):
    with caplog.at_level(logging.INFO):
        lf_nx, skipped = _compute(_network(), [_contingency("C_OPEN", LINE_2), _contingency("C_OK", TRAFO_LOAD)], [LINE_1, TRAFO_GEN])
    assert skipped == {"C_OPEN": "no impact: equipment already disconnected"} and "C_OK" in lf_nx
    records = [r for r in caplog.records if "skipped - no impact" in r.getMessage()]
    assert len(records) == 1 and records[0].levelno == logging.INFO


def test_rao_a_failed_load_flow_is_a_warning_with_its_status(caplog):
    with caplog.at_level(logging.INFO):
        lf_nx, skipped = _compute(_network(), [_contingency("C_GEN", TRAFO_GEN)], [LINE_1])
    assert skipped["C_GEN"].startswith("load flow failed") and "SOLVER_FAILED" in skipped["C_GEN"]
    records = [r for r in caplog.records if "skipped - load flow failed" in r.getMessage()]
    assert len(records) == 1 and records[0].levelno == logging.WARNING


def test_rao_the_security_analysis_status_per_contingency_is_counted_in_one_info_line(caplog):
    with caplog.at_level(logging.INFO):
        _compute(_network(), [_contingency("C_OPEN", LINE_2), _contingency("C_GEN", TRAFO_GEN), _contingency("C_ISLAND", LINE_1)],
                 [LINE_1, TRAFO_LOAD])
    lines = [r.getMessage() for r in caplog.records if "status per must-study contingency" in r.getMessage()]
    assert len(lines) == 1 and "1 CONVERGED" in lines[0] and "1 SOLVER_FAILED" in lines[0] and "1 no result" in lines[0]


# ---------------------------------------------------------------------------
# 1 and 3: the pairs
# ---------------------------------------------------------------------------

def _nx_model(lf_nx, sensitivity):
    from test_rao_milp_builder_nx import _nx_model

    return _nx_model(lf_nx, sensitivity)


GOOD = {("B1", "PST1"): -10.0, ("B2", "PST1"): -10.0}


def _pair_lines(caplog):
    return [r for r in caplog.records if "pair(s) in" in r.getMessage() and "skipped -" in r.getMessage()]


def test_rao_branches_that_are_not_monitored_dropped_or_tripped_are_not_reported_as_skipped_pairs(caplog):
    lf_nx = LfNx({"CO1": {"B1": {1: 900.0}}, "CO2": {"B1": {1: 900.0}}})            # B2 has no entry anywhere
    lf_nx.not_monitored = {"B2"}
    lf_nx.tripped = {"CO1": ["B2"]}
    lf_nx.dropped = {"CO2": ["B2"]}
    with caplog.at_level(logging.DEBUG):
        model = _nx_model(lf_nx, {"CO1": GOOD, "CO2": GOOD})
    assert set(model.nx_branch_contingency_pairs) == {("B1", "CO1"), ("B1", "CO2")}
    assert not [r for r in _pair_lines(caplog) if r.levelno >= logging.INFO]
    # the own equipment is still visible at debug level
    assert not [r for r in caplog.records if "skipped - no usable" in r.getMessage() and r.levelno >= logging.INFO]


def test_rao_the_own_equipment_of_a_contingency_is_debug_only(caplog):
    lf_nx = LfNx({"CO1": {"B1": {1: 900.0}}})
    lf_nx.tripped = {"CO1": ["B2"]}
    with caplog.at_level(logging.DEBUG):
        _nx_model(lf_nx, {"CO1": GOOD})
    tripped = [r for r in caplog.records if "its own tripped equipment" in r.getMessage()]
    assert tripped and all(r.levelno == logging.DEBUG for r in tripped)


def test_rao_the_remaining_skipped_pairs_are_one_summary_per_cause(caplog):
    nan = float("nan")
    lf_nx = LfNx({f"CO{i}": {"B1": {1: 900.0}, "B2": {1: nan}} for i in range(1, 8)})        # B2: a NaN current everywhere
    with caplog.at_level(logging.DEBUG):
        _nx_model(lf_nx, {c: GOOD for c in lf_nx})
    summary = [r for r in caplog.records if r.levelno == logging.WARNING and "no usable N-X current" in r.getMessage()]
    assert len(summary) == 1
    assert "7 pair(s) in 7 contingency(ies)" in summary[0].getMessage() and "CO1/B2" in summary[0].getMessage()
    assert "CO6/B2" not in summary[0].getMessage() and "2 more" in summary[0].getMessage()
    assert [r for r in caplog.records if r.levelno == logging.DEBUG and "contingency CO7" in r.getMessage()]


def test_rao_a_plain_dict_without_gap_information_still_reports_its_missing_pairs(caplog):
    with caplog.at_level(logging.WARNING):
        _nx_model({"CO1": {"B1": {1: 900.0}}}, {"CO1": GOOD})                     # B2 has no entry
    assert len([r for r in caplog.records if "no usable N-X current" in r.getMessage()]) == 1


def test_rao_the_skipped_contingencies_summary_is_not_repeated_for_the_same_skip(caplog):
    from pre_milp.nx_security_analysis import log_skipped_contingencies

    skipped = {f"CO{i}": "load flow failed (non-convergent, status=FAILED)" for i in range(12)}
    with caplog.at_level(logging.DEBUG):
        log_skipped_contingencies(skipped)
        log_skipped_contingencies(skipped)
    warnings = [r for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warnings) == 1 and "12 must-study" in warnings[0].getMessage() and "7 more" in warnings[0].getMessage()


# ---------------------------------------------------------------------------
# 2: the reason in the NaN sensitivity warning
# ---------------------------------------------------------------------------

def test_rao_the_nan_n_0_sensitivity_warning_says_what_the_branch_is(caplog):
    from pre_milp.n0_sensitivity import _warn_unreadable_entries, _why_unreadable

    network = _network()
    describe = _why_unreadable(network, {LINE_2: 2, TRAFO_GEN: 1}, {TRAFO_GEN}, [TRAFO_GEN])
    with caplog.at_level(logging.WARNING):
        _warn_unreadable_entries("PST", {(LINE_2, "P1"): float("nan"), (TRAFO_GEN, "P1"): float("nan")}, describe)
    text = " ".join(r.getMessage() for r in caplog.records)
    assert "line, disconnected" in text and "side 2" in text and "returned no column for it" in text
    assert "2W transformer, connected" in text and "itself a variable (PST)" in text and "returned NaN" in text

