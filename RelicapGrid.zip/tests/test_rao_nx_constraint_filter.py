"""tests/test_rao_nx_constraint_filter.py - N-X rows that can never bind are not built (exact model reduction)."""

import logging

import pyomo.environ as pyo
import pytest

from data_model import AEType, HvdcUnit, RAKind
from helpers import _make_ae_nx_filters as _ae, _make_pst_nx_filters as _pst
from milp.milp_builder import HvdcMilpInputs, NxMilpInputs, PstMilpInputs, build_n0_milp_model

TS = "1030Z"


def _build(i_b2=300.0, s_b2=-10.0, enabled=True, margin=1.0, r0=0, tatl=None, scanned=None, hvdc=None):
    """B1 is overloaded after CO1 (1100 A against 1000 A) and PST1 relieves it; B2 sits at i_b2.
    PST1: 10 A per tap on B1, s_b2 A per tap on B2, taps -10..10 from r0."""
    branches = [_ae("a1", "B1"), _ae("a2", "B2")]
    lf_initial = {"B1": {1: 500.0}, "B2": {1: 300.0}}
    lf_nx = {"CO1": {"B1": {1: 1100.0}, "B2": {1: i_b2}}}
    if scanned is not None:
        branches.append(_ae("a3", "B3", ae_type=AEType.SCANNED))
        lf_initial["B3"] = {1: 100.0}
        lf_nx["CO1"]["B3"] = {1: scanned}
    sens = {("B1", "PST1"): -10.0, ("B2", "PST1"): s_b2, ("B3", "PST1"): -10.0}
    pst_inputs = PstMilpInputs(
        pst_list=[_pst("PST1", r0=r0)], pst_tap_bounds={"PST1": (-10, 10)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={}, pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx=lf_nx, sensitivity_pst_nx={"CO1": sens}, sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=10_000.0, penalty_cost_overload_nx_scanned=10_000.0,
        penalty_cost_overload_nx_tatl=10_000.0,
        tatl_data=({"B2": {"tatl_limit_ampere": tatl, "tatl_duration_seconds": 1200, "side": 1, "was_corrected": False}}
                   if tatl else None),
        constraint_filter_enabled=enabled, constraint_filter_margin_ampere=margin,
    )
    return build_n0_milp_model(
        branches, TS, lf_initial, 1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs, hvdc_inputs=hvdc,
    )


def _solve(model):
    result = pyo.SolverFactory("appsi_highs").solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    return model


def test_far_pair_is_skipped_and_the_solution_equals_the_unfiltered_run():
    filtered, full = _build(enabled=True), _build(enabled=False)
    assert list(filtered.nx_branch_contingency_pairs) == [("B1", "CO1")]
    assert ("B2", "CO1") in filtered.nx_skipped_pairs["nx_patl"]
    assert sorted(full.nx_branch_contingency_pairs) == [("B1", "CO1"), ("B2", "CO1")]
    assert len(filtered.nx_patl_loading) == 1 and len(full.nx_patl_loading) == 2
    _solve(filtered), _solve(full)
    assert pyo.value(filtered.objective) == pytest.approx(pyo.value(full.objective), rel=1e-9, abs=1e-9)
    for name in ("tap_change_upward", "tap_change_downward"):
        assert pyo.value(getattr(filtered, name)["PST1"]) == pytest.approx(pyo.value(getattr(full, name)["PST1"]))
    assert pyo.value(full.nx_patl_overload_slack["B2", "CO1"]) == pytest.approx(0.0, abs=1e-9)


@pytest.mark.parametrize("i_b2, kept", [(899.0, False), (900.0, True)])
def test_a_row_at_the_limit_minus_margin_is_skipped_and_one_above_it_is_kept(i_b2, kept):
    # bound = i_b2 + 10 A per tap x 10 taps; limit 1000 A, margin 1 A
    model = _build(i_b2=i_b2)
    assert (("B2", "CO1") in list(model.nx_branch_contingency_pairs)) is kept


def test_the_bound_uses_the_current_tap_not_the_original_range():
    # from tap 8 the taps can move 18 down: 830 + 180 = 1010 > 999 (from tap 0: 830 + 100 = 930)
    assert ("B2", "CO1") not in list(_build(i_b2=830.0, r0=0).nx_branch_contingency_pairs)
    assert ("B2", "CO1") in list(_build(i_b2=830.0, r0=8).nx_branch_contingency_pairs)


def test_the_margin_is_configurable():
    assert ("B2", "CO1") not in list(_build(i_b2=830.0, margin=50.0).nx_branch_contingency_pairs)
    assert ("B2", "CO1") in list(_build(i_b2=830.0, margin=100.0).nx_branch_contingency_pairs)


def test_disabled_keeps_every_row_and_skips_nothing():
    model = _build(enabled=False)
    assert model.nx_skipped_pairs == {"nx_patl": set(), "nx_tatl": set(), "nx_scanned": set()}


def test_tatl_and_scanned_rows_are_filtered_too():
    model = _build(i_b2=300.0, tatl=1200.0, scanned=200.0)
    assert ("B2", "CO1") in model.nx_skipped_pairs["nx_tatl"]
    assert ("B3", "CO1") in model.nx_skipped_pairs["nx_scanned"]
    assert list(model.nx_tatl_branch_contingency_pairs) == []
    assert list(model.nx_scanned_branch_contingency_pairs) == []
    kept = _build(i_b2=300.0, tatl=1200.0, scanned=200.0, enabled=False)
    assert list(kept.nx_tatl_branch_contingency_pairs) == [("B2", "CO1")]
    assert list(kept.nx_scanned_branch_contingency_pairs) == [("B3", "CO1")]


def test_one_info_line_per_build_with_considered_added_skipped_and_share(caplog):
    with caplog.at_level(logging.INFO, logger="milp.nx_constraint_filter"):
        _build()
    lines = [r.getMessage() for r in caplog.records if "N-X constraint filter" in r.getMessage()]
    assert len(lines) == 1
    assert "considered 2" in lines[0] and "added 1" in lines[0] and "skipped 1" in lines[0] and "50.0%" in lines[0]


def _build_with_rd(i_b2, enabled=True):
    """One UP bid of 50 MW; 0.3 A per MW on B2 (largest possible change 15 A), -0.5 A per MW on the overloaded B1."""
    from data_model import BidDirection, PowerBid, RDUnit
    from milp.milp_builder import RdMilpInputs
    unit = RDUnit(
        mrid="RD1", name="RD1", tso="T", gu_mrid="GU1", gu_name="GU1", available=True, kind=RAKind.PREVENTIVE,
        initial_p=50.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None,
    )
    bid = PowerBid(mrid="BID1", ra_mrid="RD1", direction=BidDirection.UP, available_mw={TS: 50.0}, price_eur_mw=10.0,
                   lead_time_h=0.0, activation_cost_eur=None)
    rd_inputs = RdMilpInputs(
        rd_list=[unit], bid_list=[bid], glsk={"RD1": {"GU1": 1.0}}, sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}}, penalty_reference_rd_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: 1100.0}, "B2": {1: i_b2}}}, sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("B1", "GU1"): -0.5, ("B2", "GU1"): 0.3}}, penalty_cost_overload_nx_patl=10_000.0,
        constraint_filter_enabled=enabled,
    )
    return build_n0_milp_model(
        [_ae("a1", "B1"), _ae("a2", "B2")], TS, {"B1": {1: 500.0}, "B2": {1: 300.0}}, 1000.0,
        rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )


def test_the_bound_of_an_rd_row_uses_the_volume_bounds_of_the_bids():
    assert ("B2", "CO1") in _build_with_rd(300.0).nx_skipped_pairs["nx_patl"]
    assert ("B2", "CO1") in _build_with_rd(984.0).nx_skipped_pairs["nx_patl"]          # 984 + 15 = 999
    assert ("B2", "CO1") in list(_build_with_rd(985.0).nx_branch_contingency_pairs)    # 1000 > 999
    filtered, full = _solve(_build_with_rd(300.0)), _solve(_build_with_rd(300.0, enabled=False))
    assert pyo.value(filtered.objective) == pytest.approx(pyo.value(full.objective), rel=1e-9, abs=1e-9)
    assert pyo.value(filtered.rd_volume_upward["BID1"]) == pytest.approx(pyo.value(full.rd_volume_upward["BID1"]))


def _curative_hvdc():
    units = [
        HvdcUnit(mrid=m, name=m, tso="T", ei_mrid=e, available=True, kind=RAKind.CURATIVE, penalty_factor=1.0,
                 reaction_time_minutes=None, linked_contingency_mrids=[], group_mrid="GC")
        for m, e in (("C1U", "E1"), ("C2U", "E2"))
    ]
    return HvdcMilpInputs(
        units=units, limits={"C1U": (-500.0, 500.0), "C2U": (-500.0, 500.0)},
        original_p_mw={"E1": 100.0, "E2": 50.0}, current_p_mw={"E1": 100.0, "E2": 50.0},
        sensitivity_hvdc_n0={}, penalty_reference_pra=10.0, penalty_reference_cra=10.0,
    )


def _build_with_curative_hvdc(i_b2_sensitivity, enabled=True):
    branches = [_ae("a1", "B1"), _ae("a2", "B2")]
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: 1100.0}, "B2": {1: 300.0}}}, sensitivity_pst_nx={}, sensitivity_rd_nx={},
        sensitivity_hvdc_nx={"CO1": {("B1", "E1"): -2.0, ("B2", "E1"): i_b2_sensitivity}},
        penalty_cost_overload_nx_patl=10_000.0, constraint_filter_enabled=enabled,
    )
    return build_n0_milp_model(
        branches, TS, {"B1": {1: 500.0}, "B2": {1: 300.0}}, 1000.0,
        hvdc_inputs=_curative_hvdc(), nx_inputs=nx_inputs,
    )


def test_a_row_with_a_variable_that_has_no_finite_bound_is_kept():
    # the curative HVDC variables carry no bound of their own: the far B2 row stays while it has a term on them
    model = _build_with_curative_hvdc(0.1)
    assert ("B2", "CO1") in list(model.nx_branch_contingency_pairs)
    assert not model.nx_skipped_pairs["nx_patl"]
    # without a term on them the row has only a constant and is skipped
    assert ("B2", "CO1") in _build_with_curative_hvdc(0.0).nx_skipped_pairs["nx_patl"]
