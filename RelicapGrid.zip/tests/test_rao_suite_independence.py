"""
tests/test_rao_suite_independence.py - the test suite needs only src/, tests/ and tests/fixtures. Fails when the code of src/
or a test file, a helper or a builder under tests/ (not the developer scripts in tests/tools/) names a top-level folder of the repository
other than the allowed ones (and the runtime folders), either as a path built from the repository root, as a path written in a string, or as an
import. The allowed folders are listed once, below; nothing else is named here.
A real run with the other folders renamed is the proof (documented in tests/tools/README.md); this test keeps it from
regressing.
"""
import ast
import pathlib
import re

TESTS = pathlib.Path(__file__).resolve().parent
REPO = TESTS.parent
ALLOWED = {"src", "tests", "docs", ".github", ".devcontainer", "input", "output", "logs"}      # the last three are the runtime folders
ROOT_NAMES = {"REPO_ROOT", "ROOT", "REPO", "repo", "repo_root"}              # the repository root in the code of the tests
PATH_TEXT = re.compile(r"^[\w.-]+[/\\][\w./\\-]*\.(py|md|csv|yaml|yml|json|txt)$")


def _docstrings(tree):
    found = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            body = getattr(node, "body", [])
            if body and isinstance(body[0], ast.Expr) and isinstance(getattr(body[0], "value", None), ast.Constant):
                found.add(id(body[0].value))
    return found


def _top_level_folders() -> set:
    """The folders in the repository root that are not allowed: their names must not be imported."""
    return {p.name for p in REPO.iterdir() if p.is_dir() and p.name not in ALLOWED and not p.name.startswith(".")}


def _path_chain(node):
    """(base name, first string after it) of a path built with `/`, or None."""
    parts = []
    while isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
        parts.append(node.right)
        node = node.left
    if isinstance(node, ast.Name) and parts:
        first = parts[-1]
        if isinstance(first, ast.Constant) and isinstance(first.value, str):
            return node.id, first.value
    return None


def _violations(path, outside_modules=None):
    outside_modules = _top_level_folders() if outside_modules is None else outside_modules
    tree = ast.parse(path.read_text(encoding="utf-8"))
    skip = _docstrings(tree)
    found = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found += [f"{path.name}:{node.lineno} imports {a.name}" for a in node.names if a.name.split(".")[0] in outside_modules]
        elif isinstance(node, ast.ImportFrom) and node.module and node.module.split(".")[0] in outside_modules:
            found.append(f"{path.name}:{node.lineno} imports from {node.module}")
        elif isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
            chain = _path_chain(node)
            if chain and (chain[0] in ROOT_NAMES or chain[0].endswith("REPO_ROOT")) and chain[1] not in ALLOWED and "." not in chain[1]:
                found.append(f"{path.name}:{node.lineno} builds a path to {chain[1]}")
        elif isinstance(node, ast.Constant) and isinstance(node.value, str) and id(node) not in skip:
            text = node.value.replace("\\", "/")
            if PATH_TEXT.match(node.value) and text.split("/")[0] in outside_modules:
                found.append(f"{path.name}:{node.lineno} names the path {node.value}")
    return sorted(set(found))


def test_no_source_test_helper_or_builder_reaches_outside_the_allowed_folders():
    problems = []
    for path in sorted(TESTS.rglob("*.py")) + sorted((REPO / "src").rglob("*.py")):
        if path.name == pathlib.Path(__file__).name or "__pycache__" in path.parts:
            continue
        if path.is_relative_to(TESTS) and path.relative_to(TESTS).parts[0] == "tools":
            continue
        problems += _violations(path)
    assert problems == []


def test_the_checker_finds_each_kind_of_reference_outside_the_allowed_folders(tmp_path):
    bad = tmp_path / "bad.py"
    bad.write_text(
        "import elsewhere\nfrom elsewhere import cli\nimport pathlib\n"
        "REPO_ROOT = pathlib.Path('.')\nA = REPO_ROOT / 'some_folder' / 'x.csv'\nB = 'elsewhere/y.py'\n", encoding="utf-8")
    kinds = [v.split(" ", 1)[1] for v in _violations(bad, {"elsewhere"})]
    assert len(kinds) == 4 and sum(k.startswith("imports") for k in kinds) == 2
    good = tmp_path / "good.py"
    good.write_text(
        '"""other_folder/readme.md is only text here."""\nimport pathlib\nREPO_ROOT = pathlib.Path(".")\n'
        'X = pathlib.Path(__file__).parent / "fixtures"\nY = REPO_ROOT / "tests" / "fixtures"\nZ = "docs/readme.md"\n', encoding="utf-8")
    assert _violations(good, {"elsewhere"}) == []
