"""
tests/test_rao_cgm_branches.py - the NCP 2.2 legacy form (docs/specs/ncp_data_requirements.md section 13):
A. a dangling line (and a tie line) is a branch wherever a branch is resolved, on side 1 (its network side);
B. a contingency is a network split only for branches that the N-0 result has;
C. static PATL / TATL of dangling lines and 2W transformers, and a PATL of 0 is never used silently;
D. a TapPositionAction that names the PowerTransformer is read; all four CGMES 2.4.15 phase tap changer classes are mapped;
and the log summaries (counts and the first 5 ids, the full list at debug level).
The network is a small synthetic pypowsybl network.
"""
import logging
import re

import pytest

pytest.importorskip("pypowsybl")
import pandas as pd
import pypowsybl as pp

from data_model import AEType, AssessedElement, Contingency, ContingencyType
from mock_builders import standard
from mock_builders import legacy_writer as legacy_form
from pre_milp import cgmes_loader, ncp_parser

DL, TIE, TIE_A, TIE_B = "MOCK_DL", "MOCK_TIE", "MOCK_DL_A", "MOCK_DL_B"
TRAFO, LINE_1, LINE_2 = "NGEN_NHV1", "NHV1_NHV2_1", "NHV1_NHV2_2"
TS = "1030Z"


def _limit(element, side, name, value, duration):
    return dict(element_id=element, side=side, name=name, type="CURRENT", value=float(value), acceptable_duration=duration)


def _network(line_2_open=False):
    network = pp.network.create_eurostag_tutorial_example1_network()
    network.create_dangling_lines(id=DL, name="MOCK_DL_NAME", voltage_level_id="VLHV1", bus_id="NHV1", p0=50, q0=10, r=1, x=10, g=0, b=0)
    network.create_dangling_lines(id=TIE_A, voltage_level_id="VLHV1", bus_id="NHV1", p0=30, q0=5, r=1, x=10, g=0, b=0, pairing_key="K")
    network.create_dangling_lines(id=TIE_B, voltage_level_id="VLHV2", bus_id="NHV2", p0=-30, q0=-5, r=1, x=10, g=0, b=0, pairing_key="K")
    network.create_tie_lines(id=TIE, dangling_line1_id=TIE_A, dangling_line2_id=TIE_B)
    limits = pd.DataFrame.from_records([
        _limit(DL, "NONE", "patl", 900, -1), _limit(DL, "NONE", "tatl", 1100, 600),
        _limit(TRAFO, "ONE", "patl", 800, -1), _limit(TRAFO, "TWO", "patl", 500, -1), _limit(TRAFO, "TWO", "tatl", 700, 900),
        _limit(TIE_A, "NONE", "patl", 400, -1), _limit(TIE_B, "NONE", "patl", 300, -1),
    ]).set_index(["element_id", "side", "name"])
    network.create_operational_limits(limits)
    if line_2_open:
        network.update_lines(id=LINE_2, connected1=False, connected2=False)
    pp.loadflow.run_ac(network)
    return network


@pytest.fixture(scope="module")
def network():
    return _network()


def _ae(branch, side=1, patl=1.0, ae_type=AEType.SECURED):
    return AssessedElement(mrid=f"AE_{branch}", name=f"AE_{branch}", tso="TSO-X", ae_type=ae_type, branch_mrid=branch,
                           secured_for_region="R", scanned_for_region=None, exclusion_reason=None, patl_ka={"1030Z": patl}, branch_side=side)


def _contingency(mrid, equipment):
    return Contingency(mrid=mrid, name=mrid, tso="TSO-X", contingency_type=ContingencyType.ORDINARY, must_study={"1030Z": True},
                       equipment_mrids=[equipment], equipment_types=["line"])


# ---------------------------------------------------------------------------
# A: dangling lines and tie lines are branches
# ---------------------------------------------------------------------------

def test_rao_the_branch_names_include_dangling_lines_and_tie_lines(network):
    names = cgmes_loader.build_branch_mrid_to_name(network)
    assert {DL, TIE, TIE_A, TIE_B, LINE_1, TRAFO} <= set(names)
    assert names[DL] == "MOCK_DL_NAME"


def test_rao_the_equipment_types_include_dangling_lines_and_tie_lines_as_lines(network):
    types = cgmes_loader.build_equipment_mrid_to_type(network)
    assert types[DL] == types[TIE] == types[TIE_A] == "line"


def test_rao_the_initial_currents_of_a_dangling_line_are_on_side_1_only(network):
    import math

    lf_initial = cgmes_loader.build_lf_initial(network)
    expected = float(network.get_dangling_lines().loc[DL, "i"])
    assert lf_initial[DL][1] == pytest.approx(expected) and math.isnan(lf_initial[DL][2])
    assert lf_initial[TIE][1] == pytest.approx(float(network.get_dangling_lines().loc[TIE_A, "i"]))
    assert lf_initial[TIE][2] == pytest.approx(float(network.get_dangling_lines().loc[TIE_B, "i"]))


def test_rao_the_one_side_branches_are_the_dangling_lines(network):
    assert cgmes_loader.one_side_branch_mrids(network) == {DL, TIE_A, TIE_B}


def test_rao_the_static_patl_of_a_dangling_line_is_side_1_of_a_tie_line_by_its_two_lines(network):
    static_patl = cgmes_loader.build_cgm_static_patl(network)
    assert static_patl[DL] == {1: 900.0}
    assert static_patl[TIE] == {1: 400.0, 2: 300.0}
    assert static_patl[TIE_A] == {1: 400.0}


def test_rao_the_static_patl_of_a_2w_transformer_has_both_sides(network):
    assert cgmes_loader.build_cgm_static_patl(network)[TRAFO] == {1: 800.0, 2: 500.0}


def test_rao_the_dc_converter_knows_the_network_side_of_a_dangling_line(network):
    import math
    from pre_milp.dc_conversion import DcCurrentConverter

    converter = DcCurrentConverter.from_network(network, 1.0, {"default": 1.0})
    assert converter.scale(DL, 1) > 0 and math.isnan(converter.scale(DL, 2))
    assert cgmes_loader.build_lf_initial(network, converter)[DL][1] >= 0


def _ae_file_on_the_dangling_line(tmp_path):
    text = standard.shipped_files()["Belgovia_AE.xml"].decode("utf-8")
    first = re.search(r'(<nc:AssessedElement\.ConductingEquipment rdf:resource="#_)[^"]+', text)
    text = text[:first.start()] + first.group(1) + DL + text[first.end():]
    path = tmp_path / "Belgovia_AE.xml"
    path.write_text(text, encoding="utf-8")
    return path, re.search(r'<nc:AssessedElement\.OperationalLimit rdf:resource="#_([^"]+)', text).group(1)


def test_rao_an_assessed_element_on_a_dangling_line_is_read_on_side_1(tmp_path, network):
    path, limit_id = _ae_file_on_the_dangling_line(tmp_path)
    aes = ncp_parser.parse_assessed_elements(
        path, None, "TSO-X", TS, cgmes_loader.build_cgm_static_patl(network),
        cgm_branch_mrids=set(cgmes_loader.build_branch_mrid_to_name(network)),
        current_limit_side={limit_id: 2},                    # the terminal of the line on the boundary side numbers 2
        one_side_branch_mrids=cgmes_loader.one_side_branch_mrids(network),
    )
    assert [(a.branch_mrid, a.branch_side) for a in aes] == [(DL, 1)]
    assert aes[0].patl_ka["1030Z"] > 0


def test_rao_a_contingency_on_a_dangling_line_is_kept(network, tmp_path):
    text = standard.shipped_files()["Belgovia_CO.xml"].decode("utf-8")
    match = re.search(r'(<cim:ContingencyEquipment\.Equipment rdf:resource="#_)[^"]+', text)
    path = tmp_path / "Belgovia_CO.xml"
    path.write_text(text[:match.start()] + match.group(1) + DL + text[match.end():], encoding="utf-8")
    contingencies = ncp_parser.parse_contingencies(path, "TSO-X", TS, cgmes_loader.build_equipment_mrid_to_type(network))
    assert any(DL in c.equipment_mrids for c in contingencies)


def test_rao_the_n_x_currents_of_a_dangling_line_are_read_on_side_1(network):
    from pre_milp.nx_security_analysis import compute_lf_nx

    lf_nx, skipped = compute_lf_nx(network, [_contingency("C_L1", LINE_1)], [_ae(DL), _ae(LINE_2)], "1030Z")
    assert not skipped and lf_nx["C_L1"][DL][1] > 0


# ---------------------------------------------------------------------------
# B: a split is a branch missing in the contingency but present in N-0
# ---------------------------------------------------------------------------

def test_rao_a_branch_missing_in_n_0_too_is_no_split_and_is_excluded_once(caplog):
    from pre_milp import log_summary
    from pre_milp.nx_security_analysis import compute_lf_nx

    network = _network(line_2_open=True)                     # line 2 has no result in N-0 and in every contingency
    log_summary.reset_once()
    aes = [_ae(LINE_1), _ae(LINE_2), _ae(TRAFO)]
    with caplog.at_level(logging.WARNING):
        lf_nx, skipped = compute_lf_nx(network, [_contingency("C_DL", DL)], aes, "1030Z")
        compute_lf_nx(network, [_contingency("C_DL", DL)], aes, "1030Z")       # a second call of the same run
    assert not skipped and "C_DL" in lf_nx
    assert LINE_2 not in lf_nx["C_DL"] and LINE_1 in lf_nx["C_DL"]
    messages = [r.getMessage() for r in caplog.records if LINE_2 in r.getMessage() and "N-0" in r.getMessage()]
    assert len(messages) == 1


def test_rao_a_branch_present_in_n_0_but_missing_after_the_contingency_is_dropped_for_it_not_a_split():
    from pre_milp.nx_security_analysis import _contingency_result_is_usable, missing_branches

    contingency = _contingency("C", "OWN")
    assert _contingency_result_is_usable("CONVERGED") == (True, None)
    assert missing_branches(contingency, {"B1"}, {"B1", "B2"}, baseline_present={"B1", "B2"}) == ([], ["B2"])
    assert missing_branches(contingency, {"B1"}, {"B1", "B2"}, baseline_present={"B1"}) == ([], [])


# ---------------------------------------------------------------------------
# C: TATL of dangling lines and transformers; a PATL of 0 is never used silently
# ---------------------------------------------------------------------------

def test_rao_the_tatl_of_a_dangling_line_and_of_a_transformer_side(network):
    from pre_milp.nx_security_analysis import compute_tatl_data

    aes = [_ae(DL, side=1, patl=0.5), _ae(TRAFO, side=2, patl=0.4), _ae(TIE, side=2, patl=0.2)]
    tatl = compute_tatl_data(network, aes, "1030Z")
    assert tatl[DL]["tatl_limit_ampere"] == 1100.0 and tatl[DL]["tatl_duration_seconds"] == 600
    assert tatl[TRAFO]["tatl_limit_ampere"] == 700.0 and tatl[TRAFO]["tatl_duration_seconds"] == 900


def _ae_file_without_limits(tmp_path):
    """The mock AE file without the references to the operational limits (so the NCP gives no PATL)."""
    text = standard.shipped_files()["Belgovia_AE.xml"].decode("utf-8")
    path = tmp_path / "Belgovia_AE.xml"
    path.write_text(re.sub(r"\s*<nc:AssessedElement\.OperationalLimit [^>]*/>", "", text), encoding="utf-8")
    return path


def test_rao_an_assessed_element_without_any_patl_is_excluded_with_one_summary_warning(tmp_path, caplog):
    path = _ae_file_without_limits(tmp_path)
    with caplog.at_level(logging.WARNING):
        parsed = ncp_parser.parse_assessed_elements(path, None, "TSO-X", "1030Z", {})
        aes = ncp_parser.exclude_without_usable_patl(parsed, "TSO-X", "1030Z")
    assert aes and all(a.ae_type == AEType.EXCLUDED for a in aes)
    assert all("no usable PATL" in (a.exclusion_reason or "") for a in aes)
    warnings = [r.getMessage() for r in caplog.records if "no usable PATL" in r.getMessage()]
    assert len(warnings) == 1 and f"{len(aes)} assessed element" in warnings[0]
    assert len([r for r in caplog.records if "PATL" in r.getMessage()]) == 2          # one per cause, not one per element and timestamp


def test_rao_an_assessed_element_with_a_patl_is_not_touched():
    aes = [_ae(DL, patl=0.5)]
    assert ncp_parser.exclude_without_usable_patl(aes, "TSO-X", "1030Z") == aes


# ---------------------------------------------------------------------------
# D: a TapPositionAction that names the PowerTransformer
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def tap_changer_maps(tmp_path_factory):
    from helpers import _MOCK_NX_CGM_ZIP

    folder = tmp_path_factory.mktemp("cgm_branches")
    cgmes_loader.extract_cgm_zip(_MOCK_NX_CGM_ZIP, folder)
    mapping = {}
    for eq in cgmes_loader.find_eq_files(folder):
        mapping.update(ncp_parser.build_tap_changer_to_transformer_map(eq))
    return mapping


def _ra_file(tmp_path, mapping, by_transformer):
    text = standard.shipped_files()["Belgovia_RA.xml"].decode("utf-8")
    if by_transformer:
        def swap(match):
            return match.group(1) + mapping.get(match.group(2), match.group(2)) + '"'
        text = re.sub(r'(<nc:TapPositionAction\.TapChanger rdf:resource="#_)([^"]+)"', swap, text)
    path = tmp_path / "Belgovia_RA.xml"
    path.write_text(text, encoding="utf-8")
    return path


def test_rao_a_tap_position_action_naming_the_transformer_is_read_with_one_summary_warning(tmp_path, tap_changer_maps, caplog):
    cgm = {t: {"low_tap": -16, "high_tap": 16, "tap": 0} for t in set(tap_changer_maps.values())}
    expected = ncp_parser.parse_psts(_ra_file(tmp_path, tap_changer_maps, False), "TSO-X", cgm, tap_changer_maps)
    assert expected
    with caplog.at_level(logging.INFO):
        found = ncp_parser.parse_psts(_ra_file(tmp_path, tap_changer_maps, True), "TSO-X", cgm,
                                      ncp_parser.add_transformer_references({}, set(cgm)))
    assert sorted((p.mrid, p.name, p.kind.value) for p in found) == sorted((p.mrid, p.name, p.kind.value) for p in expected)
    summaries = [r for r in caplog.records if r.levelno == logging.WARNING and "names the PowerTransformer" in r.getMessage()]
    assert len(summaries) == 1


def test_rao_a_tap_position_action_naming_a_transformer_without_a_phase_tap_changer_is_skipped(tmp_path, tap_changer_maps):
    cgm = {t: {"low_tap": -16, "high_tap": 16, "tap": 0} for t in set(tap_changer_maps.values())}
    found = ncp_parser.parse_psts(_ra_file(tmp_path, tap_changer_maps, True), "TSO-X", cgm, ncp_parser.add_transformer_references({}, set()))
    assert found == []


def test_rao_all_four_cgmes_2_4_15_phase_tap_changer_classes_are_mapped(tmp_path):
    ids = legacy_form.eq_snippet_pst_ids()
    text = legacy_form.eq_snippet_2_4_15().decode("utf-8")
    block = re.search(r'  <cim:PhaseTapChangerAsymmetrical rdf:ID="_[^"]+">.*?</cim:PhaseTapChangerAsymmetrical>\n', text, re.S).group(0)
    extra = ""
    for index, name in enumerate(("Symmetrical", "Linear", "Tabular")):
        extra += (block.replace("Asymmetrical", name).replace(f'rdf:ID="_{ids["tap_changer"]}"', f'rdf:ID="_TC_{name}"'))
    path = tmp_path / "x_EQ_1.xml"
    path.write_text(text.replace("</rdf:RDF>", extra + "</rdf:RDF>"), encoding="utf-8")
    for graph in (ncp_parser.load_eq_graph(path), ncp_parser._load_graph(path, cache=False)):
        mapping = ncp_parser.build_tap_changer_to_transformer_map(path, graph)
        assert set(mapping) == {ids["tap_changer"], "TC_Symmetrical", "TC_Linear", "TC_Tabular"}


# ---------------------------------------------------------------------------
# log volume: counts and the first 5 ids, the full list at debug level
# ---------------------------------------------------------------------------

def test_rao_the_skipped_contingencies_are_logged_as_a_count_and_the_first_5_ids(caplog):
    from pre_milp.nx_security_analysis import log_skipped_contingencies

    skipped = {f"MOCK_CO_{i:02d}": "non-convergent (status=FAILED)" for i in range(12)}
    with caplog.at_level(logging.DEBUG):
        log_skipped_contingencies(skipped)
    warnings = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warnings) == 1 and "12" in warnings[0] and "MOCK_CO_04" in warnings[0] and "MOCK_CO_05" not in warnings[0]
    assert "7 more" in warnings[0] and "non-convergent" in warnings[0]
    debug = " ".join(r.getMessage() for r in caplog.records if r.levelno == logging.DEBUG)
    assert "MOCK_CO_11" in debug


def test_rao_the_patl_warnings_of_the_assessed_elements_are_one_summary_per_cause(tmp_path, caplog):
    path = _ae_file_without_limits(tmp_path)
    branches = {ae_branch: {1: 700.0, 2: 700.0} for ae_branch in re.findall(r'ConductingEquipment rdf:resource="#_([^"]+)"', path.read_text(encoding="utf-8"))}
    with caplog.at_level(logging.WARNING):
        aes = ncp_parser.parse_assessed_elements(path, None, "TSO-X", "1030Z", branches)
    static = [r.getMessage() for r in caplog.records if "CGM static PATL" in r.getMessage()]
    assert aes and len(static) == 1 and "assessed element" in static[0] and "more" in static[0]


def test_rao_the_switched_off_assessed_elements_are_a_count_and_the_first_5_ids(caplog):
    from pre_milp import log_summary

    log = logging.getLogger("test_summary")
    with caplog.at_level(logging.DEBUG, logger="test_summary"):
        log_summary.warn_ids(log, "%d assessed element(s) switched off", [f"AE_{i}" for i in range(9)])
    warning = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING][0]
    assert "9 assessed element(s) switched off" in warning and "AE_4" in warning and "AE_5" not in warning and "4 more" in warning
    assert "AE_8" in " ".join(r.getMessage() for r in caplog.records if r.levelno == logging.DEBUG)


def test_rao_the_unusable_limits_of_the_milp_are_one_summary_per_cause(caplog):
    from milp.milp_builder import _log_unusable_branches

    with caplog.at_level(logging.WARNING):
        _log_unusable_branches({"missing or invalid PATL": [f"B{i}" for i in range(8)], "limit of 0.0 A": ["B_A", "B_B"]})
    messages = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert len(messages) == 2 and any("8 branch" in m and "3 more" in m for m in messages)
