"""tests/test_rao_sensitivity_guard_floor.py - the guard drops deviating pairs instead of stopping the run: a pair deviates
only above the relative tolerance AND an absolute floor in ampere; the run stops only when no valid N-X data is left or
when too large a share of the pairs was dropped. Both analyses get the same provider parameters."""

import copy
from pathlib import Path

import pytest
import yaml

from data_model import LfNx
from pre_milp import lf_parameters, sensitivity_checks as sv
from text_encoding import TEXT_ENCODING

SIDES = {"L1": 1, "L2": 1}
CONFIG_DIR = Path(__file__).resolve().parents[1] / "src" / "rao" / "config"


def _lf(**per_branch):
    return {name: {1: value, 2: value} for name, value in per_branch.items()}


# --- N-X: the floor and the drop ---------------------------------------------------------------------------

def test_a_relative_gap_below_the_absolute_floor_is_kept():
    deviating = {}
    invalid = sv.find_invalid_nx_contingencies(
        {"C1": {"L1": 10.5, "L2": 50.0}}, set(), {"C1": _lf(L1=10.0, L2=50.0)}, SIDES,
        deviating_out=deviating, absolute_floor_ampere=5.0)
    assert invalid == {} and deviating == {}                      # 4.8 % but 0.5 A


def test_a_gap_above_both_the_tolerance_and_the_floor_drops_the_pair_not_the_contingency():
    deviating = {}
    invalid = sv.find_invalid_nx_contingencies(
        {"C1": {"L1": 1050.0, "L2": 50.0}}, set(), {"C1": _lf(L1=1000.0, L2=50.0)}, SIDES,
        deviating_out=deviating, absolute_floor_ampere=5.0)
    assert invalid == {} and deviating == {"C1": [("L1", 50.0)]}


def test_a_gap_above_the_floor_but_within_the_relative_tolerance_is_kept():
    deviating = {}
    sv.find_invalid_nx_contingencies(
        {"C1": {"L1": 1008.0, "L2": 50.0}}, set(), {"C1": _lf(L1=1000.0, L2=50.0)}, SIDES,
        deviating_out=deviating, absolute_floor_ampere=5.0)
    assert deviating == {}                                        # 8 A but 0.8 %


def test_the_dc_tolerance_and_the_floor_work_together():
    deviating = {}
    sv.find_invalid_nx_contingencies(
        {"C1": {"L1": 1030.0, "L2": 50.0}}, set(), {"C1": _lf(L1=1000.0, L2=50.0)}, SIDES,
        tolerance=sv.DC_NX_RELATIVE_TOLERANCE, deviating_out=deviating, absolute_floor_ampere=5.0)
    assert deviating == {}                                        # 30 A but 3 % (DC tolerance 5 %)


def test_a_zero_reference_still_invalidates_the_contingency():
    invalid = sv.find_invalid_nx_contingencies(
        {"C1": {"L1": 0.0, "L2": 50.0}}, set(), {"C1": _lf(L1=88.9, L2=50.0)}, SIDES,
        deviating_out={}, absolute_floor_ampere=5.0)
    assert list(invalid) == ["C1"] and "zero reference" in invalid["C1"]


def test_a_contingency_where_every_pair_deviates_is_invalid_when_no_other_has_valid_data():
    invalid = sv.find_invalid_nx_contingencies(
        {"C1": {"L1": 1050.0, "L2": 80.0}}, set(), {"C1": _lf(L1=1000.0, L2=50.0)}, SIDES,
        deviating_out={}, absolute_floor_ampere=5.0)
    assert list(invalid) == ["C1"] and "no monitored branch has a reference" in invalid["C1"]


def test_the_drop_summary_gives_pairs_contingencies_gaps_and_the_first_ids(caplog):
    lf_nx = LfNx({c: _lf(**{f"B{n}": 100.0 for n in range(8)}) for c in ("C1", "C2")})
    deviating = {"C1": [(f"B{n}", 10.0 + n) for n in range(6)], "C2": [("B0", 30.0)]}
    with caplog.at_level("DEBUG"):
        sv.drop_guard_pairs_nx(lf_nx, {}, deviating, "initial state")
    warnings = [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]
    assert len(warnings) == 1
    assert "7 (branch, contingency) pair(s) in 2 contingency(ies)" in warnings[0]
    assert "deviate" in warnings[0] and "max 30.0 A" in warnings[0] and "median 13.0 A" in warnings[0]
    assert "C1/B0" in warnings[0] and "C1/B4" in warnings[0] and "C1/B5" not in warnings[0] and "and 2 more" in warnings[0]
    assert any("C2/B0" in r.getMessage() for r in caplog.records if r.levelname == "DEBUG")
    assert "B0" not in lf_nx["C1"] and lf_nx.dropped["C1"][0] == "B0" and len(lf_nx.guard_dropped["deviation"]) == 7


# --- the stop condition ------------------------------------------------------------------------------------

def _lf_nx_with_drops(deviating):
    lf_nx = LfNx({c: _lf(**{f"B{n}": 100.0 for n in range(10)}) for c in ("C1", "C2")})        # 20 monitored pairs
    sv.drop_guard_pairs_nx(lf_nx, {}, deviating, "initial state")
    return lf_nx


def test_a_dropped_share_above_the_maximum_stops_with_the_share_the_counts_and_the_first_ids():
    lf_nx = _lf_nx_with_drops({"C1": [("B0", 9.0)]})
    sv.drop_guard_pairs_nx(lf_nx, {"C2": ["B7"]}, {}, "initial state")
    error = sv.guard_share_error(lf_nx, 0.05)
    assert error is not None and "10.00 %" in error and "no reference current 1" in error and "deviation 1" in error
    assert "C1/B0" in error and "C2/B7" in error


def test_a_dropped_share_within_the_maximum_continues_and_the_coverage_is_logged(caplog):
    lf_nx = _lf_nx_with_drops({"C1": [("B0", 9.0)]})
    with caplog.at_level("INFO"):
        assert sv.guard_share_error(lf_nx, 0.1) is None
    lines = [r.getMessage() for r in caplog.records if "guard coverage" in r.getMessage()]
    assert lines == ["N-X guard coverage: 20 monitored pairs, 1 dropped (no reference current 0, deviation 1, "
                     "network split 0), share 5.00 %"]


def test_pairs_missing_after_a_network_split_are_reported_but_are_not_a_guard_cause(caplog):
    lf_nx = LfNx({c: _lf(**{f"B{n}": 100.0 for n in range(10)}) for c in ("C1", "C2")})
    lf_nx["C1"].pop("B9")
    lf_nx.dropped["C1"] = ["B9"]
    with caplog.at_level("INFO"):
        assert sv.guard_share_error(lf_nx, 0.0) is None            # not a guard drop: share 0 even with a maximum of 0
    assert any("network split 1" in r.getMessage() for r in caplog.records)


# --- N-0 ---------------------------------------------------------------------------------------------------

def test_n0_a_deviating_branch_is_left_out_and_a_gap_below_the_floor_is_kept():
    deviating = []
    invalid = sv.find_invalid_n0_branches(
        {"L1": 1050.0, "L2": 10.5}, _lf(L1=1000.0, L2=10.0), {"L1": 1, "L2": 1},
        deviating_out=deviating, absolute_floor_ampere=5.0)
    assert invalid == {} and deviating == [("L1", 50.0)]
    sensitivity = {("L1", "P"): 1.0, ("L2", "P"): 2.0}
    sv.blank_dropped_n0(sensitivity, ["L1"], "PST")
    assert sensitivity[("L1", "P")] != sensitivity[("L1", "P")] and sensitivity[("L2", "P")] == 2.0


# --- the parameters of both analyses -----------------------------------------------------------------------

@pytest.mark.parametrize("threads", [1, 3])
def test_the_sensitivity_and_the_security_analysis_get_the_same_provider_parameters(monkeypatch, threads):
    monkeypatch.setattr(lf_parameters, "LF_THREAD_COUNT", threads)
    security = lf_parameters.build_security_analysis_parameters(False, {"distributed_slack": True})
    sensitivity = lf_parameters.build_sensitivity_parameters(False, {"distributed_slack": True})
    assert sensitivity.provider_parameters == security.provider_parameters
    assert sensitivity.provider_parameters["contingencyPropagation"] == "false"


# --- configuration -----------------------------------------------------------------------------------------

@pytest.mark.parametrize("name", ["rao_config.yaml", "rao_config.default.yaml"])
def test_the_guard_keys_are_in_both_config_files_with_their_defaults(name):
    section = yaml.safe_load((CONFIG_DIR / name).read_text(encoding=TEXT_ENCODING))["sensitivity_guard"]
    assert section == {"absolute_floor_ampere": 5.0, "max_dropped_share": 0.01}


def test_the_guard_keys_are_validated():
    import run_pipeline
    path = Path("/x/rao_config.yaml")
    run_pipeline.validate_config_ranges(copy.deepcopy(run_pipeline._rao_config), path)
    for key, bad in (("absolute_floor_ampere", -1.0), ("absolute_floor_ampere", "x"), ("max_dropped_share", 1.5), ("max_dropped_share", -0.1)):
        config = copy.deepcopy(run_pipeline._rao_config)
        config["sensitivity_guard"][key] = bad
        with pytest.raises(ValueError, match=key):
            run_pipeline.validate_config_ranges(config, path)
    config = copy.deepcopy(run_pipeline._rao_config)
    del config["sensitivity_guard"]["max_dropped_share"]
    with pytest.raises(run_pipeline.ConfigKeyError):
        run_pipeline.validate_config_ranges(config, path)
