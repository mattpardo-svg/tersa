"""
tests/test_rao_ncp_legacy_files.py - the NCP 2.2 legacy form (docs/specs/ncp_data_requirements.md section 13):
the profile of a file comes from its header, the TSO from the organisation file or else from the creator EIC, the unused
profiles are logged, and the current layout is classified as before.
"""
import logging
import zipfile

import pytest

from mock_builders import legacy_writer as legacy_form
from mock_builders import standard
from helpers import _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs
from pre_milp import ncp_header, ncp_loader, tso_name_resolver

HEADER = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:dcat="http://www.w3.org/ns/dcat#" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:md="http://iec.ch/TC57/61970-552/ModelDescription/1#">
  <{tag} rdf:about="urn:uuid:00000000-0000-4000-8000-000000000001">
{lines}
  </{tag}>
</rdf:RDF>
"""


def _header_file(path, lines, tag="dcat:Dataset"):
    path.write_text(HEADER.format(tag=tag, lines="\n".join(f"    {line}" for line in lines)), encoding="utf-8")
    return path


@pytest.fixture(scope="module")
def legacy_dir(tmp_path_factory):
    folder = tmp_path_factory.mktemp("legacy_files")
    for name, data in legacy_form.legacy_files().items():
        (folder / name).write_bytes(data)
    return folder


@pytest.fixture(scope="module")
def current_dir(tmp_path_factory):
    folder = tmp_path_factory.mktemp("current_files")
    with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as z:
        z.extractall(folder)
    return folder


# ---------------------------------------------------------------------------
# the header reader
# ---------------------------------------------------------------------------

def test_rao_header_profile_is_the_keyword(tmp_path):
    path = _header_file(tmp_path / "a.xml", ["<dcat:keyword>RA</dcat:keyword>"])
    assert ncp_header.read_header(path) == ncp_header.NcpHeader(profile="RA", creator=None)


@pytest.mark.parametrize("url, profile", [
    ("https://ap.cim4.eu/StateInstructionSchedule/2.5", "SIS"),
    ("http://entsoe.eu/ns/CIM/AssessedElement-EU/2.2", "AE"),
    ("http://entsoe.eu/ns/CIM/Contingency-EU/2.2", "CO"),
])
def test_rao_header_profile_falls_back_to_the_name_in_conforms_to(tmp_path, url, profile):
    path = _header_file(tmp_path / "a.xml", ['<dcterms:conformsTo rdf:resource="https://cim4.eu/ns/nc/2.4#"/>', f'<dcterms:conformsTo rdf:resource="{url}"/>'])
    assert ncp_header.read_header(path).profile == profile


def test_rao_header_keyword_wins_over_conforms_to_and_the_file_name(tmp_path):
    path = _header_file(tmp_path / "Belgovia_RA.xml", ["<dcat:keyword>SIS</dcat:keyword>",
                                                       '<dcterms:conformsTo rdf:resource="https://ap.cim4.eu/RemedialAction/2.5"/>'])
    assert ncp_header.read_header(path).profile == "SIS"


def test_rao_header_creator_is_the_last_path_segment(tmp_path):
    path = _header_file(tmp_path / "a.xml", ["<dcat:keyword>CO</dcat:keyword>", '<dcterms:creator rdf:resource="https://example.test/party/10X-MOCK-TSO-A"/>'],
                        tag="md:FullModel")
    assert ncp_header.read_header(path) == ncp_header.NcpHeader(profile="CO", creator="10X-MOCK-TSO-A")


def test_rao_header_of_the_organisation_file_and_its_registry(current_dir):
    assert ncp_header.read_header(current_dir / "Org-NineRealms_CD.xml").profile == "CD"
    assert ncp_header.read_header(current_dir / "Org-NineRealms_CD_OR.xml").profile == "OR"


@pytest.mark.parametrize("content", ["content", "<rdf:RDF/>", ""])
def test_rao_header_of_a_file_without_one_is_none(tmp_path, content):
    path = tmp_path / "a.xml"
    path.write_text(content, encoding="utf-8")
    assert ncp_header.read_header(path) is None


def test_rao_every_legacy_file_has_its_profile_and_creator_in_the_header(legacy_dir):
    for country, eic in legacy_form.EIC_BY_TSO.items():
        for profile in legacy_form.PROFILES:
            header = ncp_header.read_header(legacy_dir / legacy_form.file_name(country, profile))
            assert header == ncp_header.NcpHeader(profile=profile, creator=eic)


# ---------------------------------------------------------------------------
# L1: the profile from the header
# ---------------------------------------------------------------------------

def test_rao_the_profile_is_taken_from_the_header_not_the_file_name(tmp_path):
    folder = tmp_path / "ncp"
    folder.mkdir()
    _header_file(folder / "Belgovia_RA.xml", ["<dcat:keyword>SIS</dcat:keyword>"])          # named RA, header SIS
    _header_file(folder / "Belgovia_SIS.xml", ["<dcat:keyword>RA</dcat:keyword>"])          # named SIS, header RA
    for profile in ("AE", "CO"):
        _header_file(folder / f"Belgovia_{profile}.xml", [f"<dcat:keyword>{profile}</dcat:keyword>"])
    files = ncp_loader.classify_extracted_ncp_files(folder, {"TSO-Belgovia"}).by_label()
    assert [p.name for p in files["TSO-Belgovia"]["RA"]] == ["Belgovia_SIS.xml"] and [p.name for p in files["TSO-Belgovia"]["SIS"]] == ["Belgovia_RA.xml"]


def test_rao_a_file_with_a_header_but_a_name_that_names_no_profile_is_classified(tmp_path):
    folder = tmp_path / "ncp"
    folder.mkdir()
    for profile in ("AE", "CO", "RA"):
        _header_file(folder / f"Belgovia_{profile}_extra.xml", [f"<dcat:keyword>{profile}</dcat:keyword>"])
    files = ncp_loader.classify_extracted_ncp_files(folder, {"TSO-Belgovia"}).by_label()
    assert sorted(files["TSO-Belgovia"]) == ["AE", "CO", "RA"]


def test_rao_files_in_a_sub_folder_with_entsoe_names_are_found(tmp_path):
    folder = tmp_path / "ncp"
    (folder / "inner").mkdir(parents=True)
    for profile in ("AE", "CO", "RA"):
        _header_file(folder / "inner" / f"20220615T1030Z_1D_X_{profile}_001.xml",
                     [f"<dcat:keyword>{profile}</dcat:keyword>", '<dcterms:creator rdf:resource="https://example.test/party/10X-MOCK-TSO-A"/>'])
    assert sorted(ncp_loader.classify_extracted_ncp_files(folder, {}).by_label()["10X-MOCK-TSO-A"]) == ["AE", "CO", "RA"]


def _name_based_classification(directory, known_tsos):
    result = {}
    for path in sorted(directory.iterdir()):
        category, country, profile = ncp_loader._classify_ncp_zip_entry(path.name, known_tsos)
        if category == "recognized":
            result.setdefault(f"TSO-{country}", {}).setdefault(profile, []).append(path)
    return result


def test_rao_the_current_layout_is_classified_as_by_the_file_names(current_dir):
    names = tso_name_resolver.build_tso_name_map(current_dir / "Org-NineRealms_CD.xml")
    known = {name.removeprefix("TSO-") for name in names.values()}
    assert ncp_loader.classify_extracted_ncp_files(current_dir, names).by_label() == _name_based_classification(current_dir, known)


# ---------------------------------------------------------------------------
# L2: the TSO without an organisation file
# ---------------------------------------------------------------------------

def test_rao_without_an_organisation_file_the_tso_is_the_creator_eic(legacy_dir):
    files = ncp_loader.classify_extracted_ncp_files(legacy_dir, {}).by_label()
    assert sorted(files) == sorted(legacy_form.EIC_BY_TSO.values())
    for eic, profiles in files.items():
        assert sorted(profiles) == ["AE", "CO", "ER", "RA", "SIS"]


def test_rao_a_missing_organisation_file_can_be_allowed(tmp_path):
    zip_path = tmp_path / "ncp.zip"
    legacy_form.build_legacy(zip_path)
    assert ncp_loader.extract_ncp_zip(zip_path, tmp_path / "extracted", require_organisation=False) is None
    assert len(list((tmp_path / "extracted").glob("*.xml"))) == len(legacy_form.EIC_BY_TSO) * len(legacy_form.PROFILES)


def test_rao_a_missing_organisation_file_still_stops_by_default(tmp_path):
    zip_path = tmp_path / "ncp.zip"
    legacy_form.build_legacy(zip_path)
    with pytest.raises(FileNotFoundError, match="Org-NineRealms_CD.xml"):
        ncp_loader.extract_ncp_zip(zip_path, tmp_path / "extracted")


def test_rao_the_organisation_file_is_found_by_its_header_in_any_name(tmp_path):
    zip_path = tmp_path / "ncp.zip"
    with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as z, zipfile.ZipFile(zip_path, "w") as out:
        for item in z.infolist():
            name = "any_name.xml" if item.filename == "Org-NineRealms_CD.xml" else item.filename
            out.writestr(name, z.read(item.filename))
    found = ncp_loader.extract_ncp_zip(zip_path, tmp_path / "extracted")
    assert found.name == "any_name.xml"


def test_rao_a_creator_less_file_without_an_organisation_file_is_unrecognized(tmp_path, caplog):
    folder = tmp_path / "ncp"
    folder.mkdir()
    _header_file(folder / "x_RA.xml", ["<dcat:keyword>RA</dcat:keyword>"])
    with caplog.at_level(logging.WARNING):
        with pytest.raises(ValueError, match="missing required"):          # the only file is skipped, nothing is left
            ncp_loader.classify_extracted_ncp_files(folder, {})
    assert "did not match" in caplog.text


# ---------------------------------------------------------------------------
# L8: unused profiles
# ---------------------------------------------------------------------------

def test_rao_unused_profiles_are_logged_once_each_and_do_not_stop_the_load(legacy_dir, caplog):
    with caplog.at_level(logging.INFO, logger="pre_milp.ncp_loader"):
        files = ncp_loader.classify_extracted_ncp_files(legacy_dir, {}).by_label()
    assert len(files) == 4
    for profile in ("SSI", "IAM", "PS"):
        lines = [r.getMessage() for r in caplog.records if f"profile {profile} is not used" in r.getMessage()]
        assert len(lines) == 1 and "4 file" in lines[0], profile
    assert not any(f"profile {p} is not used" in r.getMessage() for r in caplog.records for p in ("AE", "CO", "RA", "SIS", "ER"))


# ---------------------------------------------------------------------------
# the run
# ---------------------------------------------------------------------------

def test_rao_a_run_on_the_legacy_form_loads_without_an_organisation_file(tmp_path, caplog):
    zip_path = legacy_form.build_legacy(tmp_path / "ncp_legacy.zip")
    with caplog.at_level(logging.INFO):
        run = run_pipeline_on_fixture_inputs(tmp_path / "run", zip_path, enable_nx_analysis=False, ra_types=("pst",))
    assert run.output_dir.is_dir()
    no_organisation = [r for r in caplog.records if r.levelno == logging.WARNING and "no organisation (cd) file" in r.getMessage().lower()]
    assert len(no_organisation) == 1
    text = caplog.text
    for eic in legacy_form.EIC_BY_TSO.values():
        assert f"--- Parsing {eic} ---" in text


# ---------------------------------------------------------------------------
# EQ files of the CGM: all of them, not by TSO country name
# ---------------------------------------------------------------------------

def test_rao_all_eq_files_of_the_cgm_are_found(tmp_path):
    from helpers import _MOCK_NX_CGM_ZIP
    from pre_milp import cgmes_loader

    cgmes_loader.extract_cgm_zip(_MOCK_NX_CGM_ZIP, tmp_path)
    found = cgmes_loader.find_eq_files(tmp_path)
    assert found == sorted(found) and len(found) >= 4
    assert {p.name for p in found if "_EQ_" in p.name} == {p.name for p in tmp_path.iterdir() if "_EQ_" in p.name}
    for country in ("Belgovia", "Espheim", "Galia", "Svedala"):
        assert any(f"_{country}_EQ" in p.name for p in found)


# ---------------------------------------------------------------------------
# per-TSO settings: the key is the TSO name or the EIC
# ---------------------------------------------------------------------------

def test_rao_a_per_tso_key_may_be_the_tso_name_or_the_eic(caplog):
    import run_pipeline

    with caplog.at_level(logging.WARNING):
        resolved = run_pipeline.resolve_tso_keyed_setting(
            "max_taps_per_tso_overrides", {"TSO-Belgovia": 4, legacy_form.EIC_BY_TSO["Espheim"]: 2}, ["TSO-Belgovia", "TSO-Espheim"],
            {"TSO-Espheim": legacy_form.EIC_BY_TSO["Espheim"]}, "max_taps_per_tso")
    assert resolved == {"TSO-Belgovia": 4, "TSO-Espheim": 2}
    assert caplog.text == ""


def test_rao_a_tso_without_a_matching_key_gets_one_warning_naming_the_setting(caplog):
    import run_pipeline

    with caplog.at_level(logging.WARNING):
        resolved = run_pipeline.resolve_tso_keyed_setting(
            "pst_group_kind_per_tso", {"TSO-Belgovia": "reducedGroup"}, ["TSO-Belgovia", "TSO-Espheim", "TSO-Galia"], {}, "the default kind")
    assert resolved == {"TSO-Belgovia": "reducedGroup"}
    lines = [r.getMessage() for r in caplog.records]
    assert len(lines) == 2 and all("pst_group_kind_per_tso" in line for line in lines)
    assert "TSO-Espheim" in lines[0] and "TSO-Galia" in lines[1]


def test_rao_an_unset_per_tso_setting_gives_no_warning(caplog):
    import run_pipeline

    with caplog.at_level(logging.WARNING):
        assert run_pipeline.resolve_tso_keyed_setting("max_ra_count_per_timestamp_tso", None, ["TSO-Belgovia"], {}, "no limit") is None
        assert run_pipeline.resolve_tso_keyed_setting("pst_group_kind_per_tso", {}, ["TSO-Belgovia"], {}, "the default kind") == {}
    assert caplog.text == ""


def test_rao_a_key_that_is_no_tso_of_the_run_is_reported_as_before(caplog):
    import run_pipeline

    with caplog.at_level(logging.WARNING):
        run_pipeline.resolve_tso_keyed_setting("max_taps_per_tso_overrides", {"TSO-Nowhere": 3}, ["TSO-Belgovia"], {}, "max_taps_per_tso")
    assert "TSO-Nowhere" in caplog.text and "not a TSO of this run" in caplog.text


def test_rao_the_eic_of_a_tso_is_the_creator_of_its_files(legacy_dir, current_dir):
    files = ncp_loader.classify_extracted_ncp_files(legacy_dir, {})
    assert files.label_eics() == {eic: eic for eic in legacy_form.EIC_BY_TSO.values()}
    names = tso_name_resolver.build_tso_name_map(current_dir / "Org-NineRealms_CD.xml")
    assert ncp_loader.classify_extracted_ncp_files(current_dir, names).label_eics() == {}


# ---------------------------------------------------------------------------
# the extraction folders are cleared at the start of a run
# ---------------------------------------------------------------------------

def test_rao_clear_directory_removes_files_and_folders_but_keeps_the_folder(tmp_path):
    (tmp_path / "inner").mkdir()
    (tmp_path / "inner" / "old.xml").write_text("x", encoding="utf-8")
    (tmp_path / "old.xml").write_text("x", encoding="utf-8")
    ncp_loader.clear_directory(tmp_path)
    assert tmp_path.is_dir() and list(tmp_path.iterdir()) == []
    ncp_loader.clear_directory(tmp_path / "missing")


def test_rao_a_run_ignores_files_left_in_the_extraction_folders(tmp_path):
    zip_path = legacy_form.build_legacy(tmp_path / "ncp_legacy.zip")

    def leave_stale_files(run_pipeline, monkeypatch):
        for folder in ("_extracted_ncp", "_extracted_cgm"):
            (run_pipeline.INPUT_DIR / folder).mkdir(parents=True)
            (run_pipeline.INPUT_DIR / folder / "Belgovia_RA_EQ_stale.xml").write_text("stale", encoding="utf-8")
            (run_pipeline.INPUT_DIR / folder / "Belgovia_RA.xml").write_text("stale", encoding="utf-8")

    run = run_pipeline_on_fixture_inputs(tmp_path / "run", zip_path, enable_nx_analysis=False, ra_types=("pst",), customize_pipeline=leave_stale_files)
    for folder in ("_extracted_ncp", "_extracted_cgm"):
        assert not list((tmp_path / "run" / "input" / folder).glob("*stale*")) and not (tmp_path / "run" / "input" / folder / "Belgovia_RA.xml").exists()
    assert run.output_dir.is_dir()


def test_rao_the_legacy_run_finds_the_eq_data_of_a_tso_named_by_its_eic(tmp_path, caplog):
    zip_path = legacy_form.build_legacy(tmp_path / "ncp_legacy.zip")
    with caplog.at_level(logging.INFO):
        run_pipeline_on_fixture_inputs(tmp_path / "run", zip_path, enable_nx_analysis=False, ra_types=("pst",))
    assert "no EQ file found" not in caplog.text
    assert any(r.getMessage().startswith(legacy_form.EIC_BY_TSO["Belgovia"] + ": ") and "PSTs parsed" in r.getMessage() and not r.getMessage().endswith(" 0 PSTs parsed")
               for r in caplog.records)