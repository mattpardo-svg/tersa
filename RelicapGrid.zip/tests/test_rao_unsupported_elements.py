"""
tests/test_rao_unsupported_elements.py - elements that no profile of the ENTSO-E sources has (a bid with penaltyFactor,
minEnergyBid, maxEnergyBid or stepSizeCTRD, a shift key naming a network generator, a countertrade RA with
powerShiftKey or method, a group limit linked directly from the time point, the plain group predicate of a
dependency) are not read: the file gives ONE summary warning "not supported, ignored" naming each class or attribute with
its count, the rest of the file is read as usual, and nothing crashes.
"""
import logging
import re
import zipfile

import pytest

from helpers import _MOCK_NX_NCP_ZIP, mock_generators_by_unit
from pre_milp import ncp_parser, ct_units

TS = "1030Z"
HEADER = ('<?xml version="1.0" encoding="UTF-8"?>\n<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:nc="https://cim4.eu/ns/nc#">\n')
NC = "https://cim4.eu/ns/nc#"


def _write(folder, name, body):
    path = folder / name
    path.write_text(HEADER + body + "\n</rdf:RDF>\n", encoding="utf-8")
    return path


def _messages(caplog, *words):
    return [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING and all(w in r.getMessage() for w in words)]


def _summaries(caplog):
    return _messages(caplog, "not supported, ignored")


def _bid(mrid, direction, extra=""):
    return f"""
    <nc:PowerBidSchedule rdf:ID="_{mrid}">
      <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/>
      <nc:PowerBidSchedule.direction rdf:resource="{NC}MarketRegulationDirectionKind.{direction}"/>
      <nc:BaseTimeSeries.interpolationKind rdf:resource="{NC}TimeSeriesInterpolationKind.none"/>{extra}
    </nc:PowerBidSchedule>
    <nc:PowerBidScheduleTimePoint rdf:ID="_{mrid}-TP">
      <nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{mrid}"/>
      <nc:PowerBidScheduleTimePoint.atTime>2022-06-15T10:30:00Z</nc:PowerBidScheduleTimePoint.atTime>
      <nc:PowerBidScheduleTimePoint.p>50</nc:PowerBidScheduleTimePoint.p>
      <nc:PowerBidScheduleTimePoint.price>10</nc:PowerBidScheduleTimePoint.price>
    </nc:PowerBidScheduleTimePoint>"""


def test_bid_attributes_that_the_profile_does_not_have_are_ignored_with_one_summary(tmp_path, caplog):
    extra = ("<nc:PowerBidSchedule.penaltyFactor>2.0</nc:PowerBidSchedule.penaltyFactor>"
             "<nc:PowerBidSchedule.minEnergyBid>1</nc:PowerBidSchedule.minEnergyBid>")
    path = _write(tmp_path, "Bids_SIS.xml", _bid("PB-1", "up", extra) + _bid("PB-2", "down", extra) + _bid("PB-3", "up"))
    with caplog.at_level(logging.WARNING):
        bids = ncp_parser.parse_power_bids(ncp_parser._load_graph(path), {"RA1"}, "TestTSO", TS)
    assert sorted(b.mrid for b in bids) == ["PB-1", "PB-2", "PB-3"]
    assert [b.available_mw["1030Z"] for b in bids] == [50.0, 50.0, 50.0]
    assert not any(hasattr(b, name) for b in bids for name in ("penalty_factor", "min_energy_mwh", "max_energy_mwh", "step_size_mw"))
    summaries = _summaries(caplog)
    assert len(summaries) == 1
    assert "PowerBidSchedule.penaltyFactor (2)" in summaries[0] and "PowerBidSchedule.minEnergyBid (2)" in summaries[0]


def _mock_files(tmp_path):
    folder = tmp_path / "mock"
    with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as archive:
        archive.extractall(folder)
    return folder


def _parse_belgovia_rd(folder, generators_by_unit):
    machines = {m for ms in mock_generators_by_unit().values() for m in ms}
    generators = {m: {"name": m, "target_p": 10.0, "max_p": 100.0, "min_p": 0.0} for m in machines}
    return ncp_parser.parse_rd_units(folder / "Belgovia_RA.xml", folder / "Belgovia_SIS.xml", "TSO-Belgovia", TS, generators,
                                     generators_by_unit=generators_by_unit)


def test_a_shift_key_that_names_a_network_generator_is_ignored_with_one_summary(tmp_path, caplog):
    folder = _mock_files(tmp_path)
    units, _bids = _parse_belgovia_rd(folder, mock_generators_by_unit())
    sis = (folder / "Belgovia_SIS.xml").read_text(encoding="utf-8")
    unit = units[0].gu_mrid                                                              # a network generator id
    cim_unit = next(u for u, machines in mock_generators_by_unit().items() if unit in machines)
    changed = sis.replace(f'PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_{cim_unit}"',
                          f'PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_{unit}"')
    assert changed != sis
    (folder / "Belgovia_SIS.xml").write_text(changed, encoding="utf-8")
    with caplog.at_level(logging.WARNING):
        fewer, _bids = _parse_belgovia_rd(folder, mock_generators_by_unit())
    assert len(fewer) < len(units) and unit not in {u.gu_mrid for u in fewer if u.mrid == units[0].mrid}
    summaries = _summaries(caplog)
    assert len(summaries) == 1 and "Belgovia_SIS.xml" in summaries[0] and "not a CIM GeneratingUnit of the CGM" in summaries[0]


def test_countertrade_attributes_that_the_profile_does_not_have_are_ignored_with_one_summary(tmp_path, caplog):
    folder = _mock_files(tmp_path)
    ra = (folder / "Belgovia_RA.xml").read_text(encoding="utf-8")
    opened = re.findall(r'<nc:CountertradeRemedialAction rdf:ID="[^"]+">', ra)
    assert len(opened) >= 2
    extra = "<nc:CountertradeRemedialAction.powerShiftKey>x</nc:CountertradeRemedialAction.powerShiftKey>"
    ra = ra.replace(opened[0], opened[0] + extra).replace(opened[1], opened[1] + extra
                                                           + "<nc:CountertradeRemedialAction.method>y</nc:CountertradeRemedialAction.method>")
    (folder / "Belgovia_RA.xml").write_text(ra, encoding="utf-8")
    with caplog.at_level(logging.WARNING):
        ras, _bids = ct_units.parse_ct_remedial_actions(folder / "Belgovia_RA.xml", folder / "Belgovia_SIS.xml", "TSO-Belgovia", TS)
    assert len(ras) == len(opened)                                                       # no RA is lost
    summaries = _summaries(caplog)
    assert len(summaries) == 1
    assert "CountertradeRemedialAction.powerShiftKey (2)" in summaries[0] and "CountertradeRemedialAction.method (1)" in summaries[0]


def test_a_declared_strategy_is_ignored_with_a_warning_and_the_ra_is_kept(tmp_path, caplog):
    folder = _mock_files(tmp_path)
    ra = (folder / "Belgovia_RA.xml").read_text(encoding="utf-8")
    opened = re.findall(r'<nc:CountertradeRemedialAction rdf:ID="[^"]+">', ra)[0]
    strategy = f'<nc:CountertradeRemedialAction.gLSKStrategy rdf:resource="{NC}GLSKStrategyKind.proportionalForRemainingCapacity"/>'
    (folder / "Belgovia_RA.xml").write_text(ra.replace(opened, opened + strategy), encoding="utf-8")
    with caplog.at_level(logging.WARNING):
        ras, _bids = ct_units.parse_ct_remedial_actions(folder / "Belgovia_RA.xml", folder / "Belgovia_SIS.xml", "TSO-Belgovia", TS)
    assert len(ras) == len(re.findall(r'<nc:CountertradeRemedialAction rdf:ID="[^"]+">', ra))
    assert len(_messages(caplog, "gLSKStrategy proportionalForRemainingCapacity", "ignored")) == 1
    assert _messages(caplog, "deprecated") == []


GROUP_RA = """
    <nc:RemedialActionGroup rdf:ID="_G1"><cim:IdentifiedObject.mRID>G1</cim:IdentifiedObject.mRID></nc:RemedialActionGroup>
    <nc:RemedialActionDependency rdf:ID="_D1">
      <nc:RemedialActionDependency.kind rdf:resource="{nc}RemedialActionDependencyKind.restrictive"/>
      <nc:RemedialActionDependency.{predicate} rdf:resource="#_G1"/>
      <nc:RemedialActionDependency.RemedialAction rdf:resource="#_RA1"/>
    </nc:RemedialActionDependency>"""
LINKED_POINT = """
    <nc:RemedialActionGroupTimePoint rdf:ID="_P1">
      <nc:RemedialActionGroupTimePoint.RemedialActionGroup rdf:resource="#_G1"/>
      <nc:RemedialActionGroupTimePoint.atTime>2022-06-15T10:30:00Z</nc:RemedialActionGroupTimePoint.atTime>
      <nc:RemedialActionGroup.maxRegulatingUp>100</nc:RemedialActionGroup.maxRegulatingUp>
    </nc:RemedialActionGroupTimePoint>"""
STANDARD_POINT = """
    <nc:RemedialActionGroupSchedule rdf:ID="_S1"><nc:RemedialActionGroupSchedule.RemedialActionGroup rdf:resource="#_G1"/></nc:RemedialActionGroupSchedule>
    <nc:RemedialActionGroupTimePoint rdf:ID="_P2">
      <nc:RemedialActionGroupTimePoint.RemedialActionGroupSchedule rdf:resource="#_S1"/>
      <nc:RemedialActionGroupTimePoint.atTime>2022-06-15T10:30:00Z</nc:RemedialActionGroupTimePoint.atTime>
      <nc:RemedialActionGroupTimePoint.maxRegulatingUp>80</nc:RemedialActionGroupTimePoint.maxRegulatingUp>
    </nc:RemedialActionGroupTimePoint>"""


def test_the_plain_group_predicate_of_a_dependency_is_ignored_with_one_summary(tmp_path, caplog):
    ra = _write(tmp_path, "T_RA.xml", GROUP_RA.format(nc=NC, predicate="RemedialActionGroup"))
    sis = _write(tmp_path, "T_SIS.xml", STANDARD_POINT)
    with caplog.at_level(logging.WARNING):
        groups = ncp_parser.parse_ra_groups(ra, sis, "TestTSO", "1030Z")
    assert groups == {}                                                                  # the dependency has no group the reader knows
    summaries = _summaries(caplog)
    assert len(summaries) == 1 and "T_RA.xml" in summaries[0] and "RemedialActionDependency.RemedialActionGroup (1)" in summaries[0]


def test_a_group_limit_linked_directly_from_the_time_point_is_ignored_with_one_summary(tmp_path, caplog):
    ra = _write(tmp_path, "T_RA.xml", GROUP_RA.format(nc=NC, predicate="DependingRemedialActionGroup"))
    sis = _write(tmp_path, "T_SIS.xml", LINKED_POINT + STANDARD_POINT)
    with caplog.at_level(logging.WARNING):
        groups = ncp_parser.parse_ra_groups(ra, sis, "TestTSO", "1030Z")
    assert groups["G1"]["max_regulating_up"] == 80.0                                     # the standard chain is read as usual
    summaries = _summaries(caplog)
    assert len(summaries) == 1 and "T_SIS.xml" in summaries[0]
    assert "RemedialActionGroupTimePoint.RemedialActionGroup (a time point linked to the group directly) (1)" in summaries[0]


def test_a_group_limit_given_only_in_the_direct_form_leaves_the_limits_unresolved(tmp_path, caplog):
    ra = _write(tmp_path, "T_RA.xml", GROUP_RA.format(nc=NC, predicate="DependingRemedialActionGroup"))
    sis = _write(tmp_path, "T_SIS.xml", LINKED_POINT)
    with caplog.at_level(logging.WARNING):
        groups = ncp_parser.parse_ra_groups(ra, sis, "TestTSO", "1030Z")
    assert groups["G1"]["max_regulating_up"] is None and groups["G1"]["max_regulating_down"] is None
    assert len(_summaries(caplog)) == 1


def test_the_summary_is_logged_once_per_file_however_often_the_file_is_read(tmp_path, caplog):
    ra = _write(tmp_path, "T_RA.xml", GROUP_RA.format(nc=NC, predicate="RemedialActionGroup"))
    sis = _write(tmp_path, "T_SIS.xml", STANDARD_POINT)
    with caplog.at_level(logging.WARNING):
        for _ in range(3):
            ncp_parser.parse_ra_groups(ra, sis, "TestTSO", "1030Z")
    assert len(_summaries(caplog)) == 1


@pytest.mark.parametrize("name", ["warn_deprecated_form_once", "_DEPRECATION_WARNED"])
def test_the_deprecation_machinery_of_the_old_form_is_gone(name):
    assert not hasattr(ncp_parser, name)
