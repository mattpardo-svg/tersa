"""
tests/test_rao_ncp_legacy_ncp_namespaces.py - the NCP 2.2 legacy form (docs/specs/ncp_data_requirements.md section 13):
the NCP files declare nc as http://entsoe.eu/ns/nc#, cim as http://iec.ch/TC57/CIM100#, eu as CIM100-European and an
xml:base on rdf:RDF. A file that declares such a namespace is read as if it used the current URI; any other file, and
every CGM file, is read as before. Ids do not depend on xml:base.
"""
import dataclasses
import logging
import zipfile

import pytest
from rdflib import RDF

from mock_builders import legacy_writer as legacy_form
from helpers import _MOCK_NX_NCP_ZIP
from pre_milp import ncp_parser

NC_LEGACY = "http://entsoe.eu/ns/nc#"
CIM_LEGACY = "http://iec.ch/TC57/CIM100#"
FILE = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:nc="{nc}" xmlns:cim="{cim}" {base}>
  <nc:RemedialAction rdf:ID="_00000000-0000-4000-8000-000000000001">
    <cim:IdentifiedObject.mRID>00000000-0000-4000-8000-000000000001</cim:IdentifiedObject.mRID>
    <nc:RemedialAction.kind rdf:resource="{nc}RemedialActionKind.preventive"/>
    <nc:RemedialAction.other rdf:resource="#_00000000-0000-4000-8000-000000000002"/>
  </nc:RemedialAction>
</rdf:RDF>
"""


def _graph(tmp_path, nc=NC_LEGACY, cim=CIM_LEGACY, base='xml:base="http://entsoe.eu/ns/nc"', cache=True):
    path = tmp_path / "a.xml"
    path.write_text(FILE.format(nc=nc, cim=cim, base=base), encoding="utf-8")
    return ncp_parser._load_graph(path, cache=cache)


@pytest.fixture(scope="module")
def legacy_dir(tmp_path_factory):
    folder = tmp_path_factory.mktemp("legacy_ncp_namespaces")
    for name, data in legacy_form.legacy_files().items():
        (folder / name).write_bytes(data)
    return folder


@pytest.fixture(scope="module")
def current_dir(tmp_path_factory):
    folder = tmp_path_factory.mktemp("current_ncp_namespaces")
    with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as z:
        z.extractall(folder)
    return folder


def test_rao_legacy_mock_declares_the_namespaces_and_the_base_of_the_form(legacy_dir):
    for country in legacy_form.EIC_BY_TSO:
        for profile in ("AE", "CO", "RA", "SIS", "SSI", "IAM"):
            text = (legacy_dir / legacy_form.file_name(country, profile)).read_text(encoding="utf-8")
            root = text[text.index("<rdf:RDF"):text.index(">", text.index("<rdf:RDF"))]
            for declaration in (f'xmlns:nc="{NC_LEGACY}"', f'xmlns:cim="{CIM_LEGACY}"', 'xmlns:eu="http://iec.ch/TC57/CIM100-European#"',
                                'xml:base="http://entsoe.eu/ns/nc"'):
                assert declaration in root, (country, profile, declaration)
            assert "https://cim4.eu/ns/nc#" not in text and "https://cim.ucaiug.io/ns#" not in text


def test_rao_a_file_in_the_legacy_namespaces_is_read_under_the_current_ones(tmp_path):
    graph = _graph(tmp_path)
    ras = list(graph.subjects(RDF.type, ncp_parser.NC.RemedialAction))
    assert len(ras) == 1
    assert str(graph.value(ras[0], ncp_parser.NC["RemedialAction.kind"])) == "https://cim4.eu/ns/nc#RemedialActionKind.preventive"
    assert str(graph.value(ras[0], ncp_parser.CIM["IdentifiedObject.mRID"])) == "00000000-0000-4000-8000-000000000001"


@pytest.mark.parametrize("base", ['xml:base="http://entsoe.eu/ns/nc"', 'xml:base="http://example.invalid/other"', ""])
def test_rao_ids_do_not_depend_on_the_xml_base(tmp_path, base):
    graph = _graph(tmp_path, base=base)
    subject = next(graph.subjects(RDF.type, ncp_parser.NC.RemedialAction))
    reference = graph.value(subject, ncp_parser.NC["RemedialAction.other"])
    assert ncp_parser._frag(str(subject)) == "00000000-0000-4000-8000-000000000001"
    assert ncp_parser._frag(str(reference)) == "00000000-0000-4000-8000-000000000002"


def test_rao_a_file_in_the_current_namespaces_is_returned_as_parsed(tmp_path):
    graph = _graph(tmp_path, nc="https://cim4.eu/ns/nc#", cim="https://cim.ucaiug.io/ns#", base="")
    assert ncp_parser._use_current_namespaces(graph) is graph
    assert len(list(graph.subjects(RDF.type, ncp_parser.NC.RemedialAction))) == 1


def test_rao_a_current_ncp_file_is_not_rewritten_when_it_only_mentions_a_legacy_uri(current_dir):
    graph = ncp_parser._load_graph(current_dir / "Belgovia_RA.xml")
    assert any(str(o) == CIM_LEGACY for o in graph.objects(None, None))          # the conformsTo value stays
    assert ncp_parser._use_current_namespaces(graph) is graph


def test_rao_a_cgm_file_in_the_cim100_namespace_is_not_rewritten(tmp_path):
    graph = _graph(tmp_path, nc="https://cim4.eu/ns/nc#", base="", cache=False)
    assert any(str(s).startswith(CIM_LEGACY) or str(p).startswith(CIM_LEGACY) for s, p, _ in graph)
    assert not list(graph.subjects(RDF.type, ncp_parser.CIM.RemedialAction))


def test_rao_the_legacy_ae_and_co_files_have_the_classes_of_the_current_ones_and_no_legacy_uri_is_left(legacy_dir, current_dir):
    from collections import Counter

    for country in legacy_form.EIC_BY_TSO:
        for profile in ("AE", "CO", "RA", "SIS"):
            old = ncp_parser._load_graph(current_dir / f"{country}_{profile}.xml")
            new = ncp_parser._load_graph(legacy_dir / legacy_form.file_name(country, profile))
            assert not [t for t in new if any(str(x).startswith(NC_LEGACY) or str(x).startswith(CIM_LEGACY) for x in t)]
            if profile in ("AE", "CO"):
                classes = lambda graph: Counter(str(o) for o in graph.objects(None, RDF.type) if not str(o).endswith(("#FullModel", "#Dataset")))
                assert classes(new) == classes(old)


def test_rao_the_legacy_parsers_return_objects(legacy_dir, current_dir):
    for country in legacy_form.EIC_BY_TSO:
        tso = f"TSO-{country}"
        new = ncp_parser.parse_assessed_elements(legacy_dir / legacy_form.file_name(country, "AE"), None, tso, "1030Z", {})
        old = ncp_parser.parse_assessed_elements(current_dir / f"{country}_AE.xml", None, tso, "1030Z", {})
        assert new and len(new) == len(old)
