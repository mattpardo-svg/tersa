"""
tests/test_rao_nan_sensitivity_component.py - the warning for a branch with a NaN sensitivity says when the branch is not in
the main network component (a small island next to the main network); the wording is unchanged for a branch in it.
Synthetic network: the tutorial network plus one island of two buses and one connected line.
"""
import logging

import pypowsybl.network as pn
import pytest

from pre_milp import cgmes_loader, n0_sensitivity


@pytest.fixture(scope="module")
def network_with_island():
    network = pn.create_eurostag_tutorial_example1_network()
    network.create_substations(id=["SUB-ISLAND"])
    network.create_voltage_levels(id=["VL-I1", "VL-I2"], substation_id=["SUB-ISLAND"] * 2,
                                  topology_kind=["BUS_BREAKER"] * 2, nominal_v=[380.0, 380.0])
    network.create_buses(id=["BUS-I1", "BUS-I2"], voltage_level_id=["VL-I1", "VL-I2"])
    network.create_lines(id=["LINE-ISLAND"], voltage_level1_id=["VL-I1"], bus1_id=["BUS-I1"],
                         voltage_level2_id=["VL-I2"], bus2_id=["BUS-I2"],
                         r=[1.0], x=[10.0], g1=[0.0], b1=[0.0], g2=[0.0], b2=[0.0])
    return network


def test_a_branch_in_the_island_is_said_to_be_outside_the_main_component(network_with_island):
    text = cgmes_loader.describe_branch(network_with_island, "LINE-ISLAND")
    assert "line, connected" in text and "not in the main network component (component 1)" in text


def test_a_branch_in_the_main_component_keeps_the_wording(network_with_island):
    text = cgmes_loader.describe_branch(network_with_island, "NHV1_NHV2_1")
    assert text == "line, connected"


def test_the_nan_warning_names_the_component(network_with_island, caplog):
    sensitivities = {("LINE-ISLAND", "PST-1"): float("nan"), ("NHV1_NHV2_1", "PST-1"): float("nan")}
    describe = n0_sensitivity._why_unreadable(network_with_island, {}, set(), ["PST-1"])
    with caplog.at_level(logging.DEBUG):
        n0_sensitivity._warn_unreadable_entries("PST", sensitivities, describe)
    by_branch = {name: next(r.getMessage() for r in caplog.records if f"branch {name} " in r.getMessage())
                 for name in ("LINE-ISLAND", "NHV1_NHV2_1")}
    assert "not in the main network component (component 1)" in by_branch["LINE-ISLAND"]
    assert "component" not in by_branch["NHV1_NHV2_1"]
    summary = next(r.getMessage() for r in caplog.records if r.levelno == logging.WARNING)
    assert "excluded from the MILP" in summary and "LINE-ISLAND" in summary and "NHV1_NHV2_1" in summary
