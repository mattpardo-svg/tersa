"""tests/test_rao_nx_pst_threshold.py - the N-X PST sensitivity threshold applied while the sensitivities are read
(one contingency at a time), the N-X sensitivity CSV switch, and the compact table after pruning."""

import csv
import logging
import sys

import numpy as np
import pandas as pd
import pytest

from data_model import AEType, AssessedElement, Contingency, ContingencyType, PST, RAKind
from pre_milp.nx_sensitivity import compute_sensitivity_pst_nx
from pre_milp.sensitivity_table import SensitivityTable, table_from_matrices
from helpers import run_pipeline_on_fixture_inputs, _MOCK_NX_NCP_ZIP


@pytest.fixture(autouse=True)
def _no_guard_drops(monkeypatch):
    """These tests build their own lf_nx, unrelated to the sensitivity references: the guard must not drop its pairs."""
    from pre_milp import sensitivity_checks
    monkeypatch.setattr(sensitivity_checks, "ABSOLUTE_FLOOR_AMPERE", 1e12)


class _Context:
    NONE, SPECIFIC, ALL = "NONE", "SPECIFIC", "ALL"


class _FunctionType:
    BRANCH_CURRENT_1, BRANCH_CURRENT_2 = "BRANCH_CURRENT_1", "BRANCH_CURRENT_2"


class _VariableType:
    TRANSFORMER_PHASE, INJECTION_ACTIVE_POWER = "TRANSFORMER_PHASE", "INJECTION_ACTIVE_POWER"


class _Result:
    def __init__(self, matrices):
        self._matrices = matrices

    def get_sensitivity_matrix(self, matrix_id, contingency_id=None):
        return self._matrices.get((matrix_id, contingency_id))


class _Analysis:
    def __init__(self, matrices):
        self._matrices = matrices

    def add_single_element_contingency(self, element_id, contingency_id):
        pass

    def add_multiple_elements_contingency(self, element_ids, contingency_id):
        pass

    def add_factor_matrix(self, **kwargs):
        pass

    def run(self, network, parameters=None):
        return _Result(self._matrices)


class _FakePypowsybl:
    """Just enough of pypowsybl.sensitivity for the AC N-X analysis."""

    def __init__(self, matrices):
        self.sensitivity = type("S", (), {
            "ContingencyContextType": _Context, "SensitivityFunctionType": _FunctionType,
            "SensitivityVariableType": _VariableType, "create_ac_analysis": lambda self_: _Analysis(matrices),
            "Parameters": staticmethod(lambda **kw: type("SP", (), kw)()),
        })()
        self.loadflow = type("L", (), {"Parameters": staticmethod(lambda **kw: type("P", (), kw)())})()


def _assessed_element(branch, patl_ka):
    return AssessedElement(
        mrid=f"ae-{branch}", name="a", tso="TSO", ae_type=AEType.SECURED, branch_mrid=branch,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={"1030Z": patl_ka}, branch_side=1,
    )


def _pst(mrid):
    return PST(mrid=mrid, name="pst", tso="TSO", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0,
               low_step=-10, high_step=10, r0=0, operating_tap_min=-10, operating_tap_max=10, group_id=None)


def _contingency(mrid):
    return Contingency(mrid=mrid, name=mrid, tso="TSO", contingency_type=ContingencyType.ORDINARY,
                       must_study={"1030Z": True}, equipment_mrids=["eq-" + mrid])


def _synthetic_case(monkeypatch):
    """Two branches (limit 1 kA = 1000 A), two PSTs, two contingencies; values in A per degree."""
    matrices = {
        ("nx_side1", "co-1"): pd.DataFrame([[5.0, 20.0], [-30.0, -2.0]], index=["pst-1", "pst-2"], columns=["b1", "b2"]),
        ("nx_side1", "co-2"): pd.DataFrame([[0.5, 11.0], [9.0, 40.0]], index=["pst-1", "pst-2"], columns=["b1", "b2"]),
    }
    monkeypatch.setitem(sys.modules, "pypowsybl", _FakePypowsybl(matrices))
    return dict(
        co_flat_list=[_contingency("co-1"), _contingency("co-2")], pst_list=[_pst("pst-1"), _pst("pst-2")],
        ae_flat_list=[_assessed_element("b1", 1.0), _assessed_element("b2", 1.0)], timestamp="1030Z",
        lf_nx={c: {"b1": {1: 100.0}, "b2": {1: 100.0}} for c in ("co-1", "co-2")},
        lf_initial={"b1": {1: 50.0}, "b2": {1: 50.0}},
    )


def _compute(network_args, **extra):
    return compute_sensitivity_pst_nx(
        object(), network_args["co_flat_list"], network_args["pst_list"], network_args["ae_flat_list"],
        network_args["timestamp"], lf_nx=network_args["lf_nx"], lf_initial=network_args["lf_initial"], **extra,
    )


def test_a_threshold_above_zero_drops_the_small_entries_and_keeps_the_large_ones(monkeypatch):
    """1 % of a 1000 A limit = 10 A per degree: 5, -2, 0.5 and 9 go; 20, -30, 11 and 40 stay."""
    result = _compute(_synthetic_case(monkeypatch), sensitivity_threshold_pct_pst_nx=1.0)
    assert dict(result["co-1"]) == {("b2", "pst-1"): 20.0, ("b1", "pst-2"): -30.0}
    assert dict(result["co-2"]) == {("b2", "pst-1"): 11.0, ("b2", "pst-2"): 40.0}


def test_the_default_threshold_drops_nothing(monkeypatch):
    result = _compute(_synthetic_case(monkeypatch))
    assert len(result["co-1"]) == 4 and len(result["co-2"]) == 4


def test_the_log_gives_the_entries_kept_and_dropped_and_the_threshold(monkeypatch, caplog):
    with caplog.at_level(logging.INFO):
        _compute(_synthetic_case(monkeypatch), sensitivity_threshold_pct_pst_nx=1.0)
    lines = [r.getMessage() for r in caplog.records if "threshold" in r.getMessage() and "kept" in r.getMessage()]
    assert len(lines) == 1 and "kept 4" in lines[0] and "dropped 4" in lines[0] and "1" in lines[0]


def _two_psts_same_per_degree_value(monkeypatch):
    """Both PSTs have 10 A per degree on branch b1 (limit 1000 A): per tap 5 A (0.5 degree) and 20 A (2 degrees)."""
    matrices = {("nx_side1", "co-1"): pd.DataFrame([[10.0], [10.0]], index=["pst-small", "pst-large"], columns=["b1"])}
    monkeypatch.setitem(sys.modules, "pypowsybl", _FakePypowsybl(matrices))
    return dict(
        co_flat_list=[_contingency("co-1")], pst_list=[_pst("pst-small"), _pst("pst-large")],
        ae_flat_list=[_assessed_element("b1", 1.0)], timestamp="1030Z",
        lf_nx={"co-1": {"b1": {1: 100.0}}}, lf_initial={"b1": {1: 50.0}},
    )


def test_n_x_threshold_compares_the_effect_per_tap_not_per_degree(monkeypatch):
    """1 % of 1000 A = 10 A per tap: the PST with 0.5 degree per tap (5 A) goes, the one with 2 degrees (20 A) stays."""
    result = _compute(_two_psts_same_per_degree_value(monkeypatch), sensitivity_threshold_pct_pst_nx=1.0,
                      degrees_per_tap={"pst-small": 0.5, "pst-large": -2.0})
    assert dict(result["co-1"]) == {("b1", "pst-large"): 10.0}          # the stored value stays A per degree


def test_n_x_a_pst_without_degrees_per_tap_is_kept(monkeypatch):
    result = _compute(_two_psts_same_per_degree_value(monkeypatch), sensitivity_threshold_pct_pst_nx=1.0,
                      degrees_per_tap={"pst-small": 0.5})
    assert set(dict(result["co-1"])) == {("b1", "pst-large")}


def test_n_0_threshold_compares_the_effect_per_tap_not_per_degree():
    from pre_milp.n0_sensitivity import prune_sensitivity_by_threshold
    matrix = {("b1", "pst-small"): 10.0, ("b2", "pst-large"): 10.0}
    aes = [_assessed_element("b1", 1.0), _assessed_element("b2", 1.0)]
    kept = prune_sensitivity_by_threshold(matrix, aes, "1030Z", {"b1": {1: 50.0}, "b2": {1: 50.0}},
                                          sensitivity_threshold_pct=1.0,
                                          degrees_per_tap={"pst-small": 0.5, "pst-large": 2.0})
    assert kept == {("b2", "pst-large"): 10.0}


def test_n_0_without_degrees_per_tap_the_rule_is_unchanged():
    from pre_milp.n0_sensitivity import prune_sensitivity_by_threshold
    matrix = {("b1", "pst-small"): 10.0}
    kept = prune_sensitivity_by_threshold(matrix, [_assessed_element("b1", 1.0)], "1030Z", {"b1": {1: 50.0}},
                                          sensitivity_threshold_pct=1.0)
    assert kept == matrix                                              # 10 A per degree is not below 10 A


def test_a_pruned_table_keeps_only_the_rows_and_columns_that_have_entries():
    table = table_from_matrices([(["b1", "b2", "b3"], ["p1", "p2"], np.array([[1.0, 50.0, 0.0], [2.0, 60.0, 0.0]]))])
    pruned = table.without_entries_below(lambda branch: 10.0).compacted()
    assert dict(pruned) == {("b2", "p1"): 50.0, ("b2", "p2"): 60.0}
    assert pruned.branches == ["b2"] and pruned._base.shape == (1, 2)


def test_a_nan_entry_survives_pruning_and_compaction():
    table = table_from_matrices([(["b1", "b2"], ["p1"], np.array([[1.0, float("nan")]]))])
    pruned = table.without_entries_below(lambda branch: 10.0).compacted()
    assert pruned.nan_branches() == {"b2"} and len(pruned) == 1


@pytest.mark.parametrize("mode", ["ac_single_pass", "ac_iterative"])
def test_the_threshold_applies_in_every_calculation_mode(mode, tmp_path, monkeypatch, caplog):
    """On the shipped mock a threshold of 0.2 % of the limit per tap (N-0 and N-X) drops some entries and keeps others, in both modes."""
    import re

    def customize(rp, patcher):
        patcher.setattr(rp, "SENSITIVITY_THRESHOLD_PCT_PST_NX", 0.2)
        patcher.setattr(rp, "SENSITIVITY_THRESHOLD_PCT_PST", 0.2)
    with caplog.at_level(logging.INFO):
        run_pipeline_on_fixture_inputs(tmp_path, _MOCK_NX_NCP_ZIP, True, customize_pipeline=customize,
                                       ra_types=("pst", "rd"), calculation_mode=mode)
    lines = [r.getMessage() for r in caplog.records if "N-X PST sensitivity threshold" in r.getMessage()]
    assert lines, "no summary line"
    kept, dropped = map(int, re.search(r"kept (\d+), dropped (\d+)", lines[0]).groups())
    assert kept > 0 and dropped > 0, lines[0]


def test_the_dict_form_of_a_contingency_is_pruned_per_tap_too():
    """The DC read-back and a matrix with a duplicate row give a dict, not a table: the same rule."""
    from pre_milp.nx_sensitivity import _prune_by_magnitude
    values = {"co-1": {("b1", "pst-small"): 10.0, ("b1", "pst-large"): -10.0, ("b1", "pst-unknown"): 0.0}}
    kept = _prune_by_magnitude(values, {"b1": 1000.0}, 1.0, {"pst-small": 0.5, "pst-large": 2.0})
    assert kept == {"co-1": {("b1", "pst-large"): -10.0, ("b1", "pst-unknown"): 0.0}}

