"""
tests/test_rao_ncp_legacy_bids.py - the NCP 2.2 legacy form (docs/specs/ncp_data_requirements.md section 13, DECISIONS 165):
the direction of a bid is the last word of PowerBidSchedule.direction, else the suffix _UP / _DOWN of its name (case
insensitive, trimmed), else the bid is skipped; one summary warning per SIS file; the sign of p is not checked (in the legacy form
down bids have p > 0), the size is |p|.
"""
import logging

import pytest

from data_model import BidDirection
from pre_milp import ncp_parser

HEADER = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:nc="https://cim4.eu/ns/nc#" xmlns:cim="https://cim.ucaiug.io/ns#">
"""


def _bid(ident, name, direction=None, p=40.0, ra="RA_1"):
    direction_xml = f'<nc:PowerBidSchedule.direction rdf:resource="https://cim4.eu/ns/nc#{direction}"/>' if direction else ""
    return f"""  <nc:PowerBidSchedule rdf:ID="_{ident}">
    <cim:IdentifiedObject.mRID>{ident}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>{name}</cim:IdentifiedObject.name>
    <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{ra}"/>
    {direction_xml}
    <nc:BaseTimeSeries.interpolationKind rdf:resource="https://cim4.eu/ns/nc#InterpolationKind.none"/>
  </nc:PowerBidSchedule>
  <nc:PowerBidScheduleTimePoint rdf:ID="_TP_{ident}">
    <nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{ident}"/>
    <nc:PowerBidScheduleTimePoint.atTime>2022-06-15T10:30:00Z</nc:PowerBidScheduleTimePoint.atTime>
    <nc:PowerBidScheduleTimePoint.p>{p}</nc:PowerBidScheduleTimePoint.p>
    <nc:PowerBidScheduleTimePoint.price>12.5</nc:PowerBidScheduleTimePoint.price>
  </nc:PowerBidScheduleTimePoint>
"""


def _parse(tmp_path, *bids, tso="TSO-X"):
    path = tmp_path / "x_SIS.xml"
    path.write_text(HEADER + "".join(bids) + "</rdf:RDF>\n", encoding="utf-8")
    return {b.mrid: b for b in ncp_parser.parse_power_bids(ncp_parser._load_graph(path), {"RA_1"}, tso, "1030Z")}


def test_rao_a_bid_without_direction_takes_it_from_the_name_suffix_case_insensitive_and_trimmed(tmp_path):
    bids = _parse(tmp_path, _bid("B1", "MOCK_BID_1_UP"), _bid("B2", "mock_bid_2_down"), _bid("B3", "  MOCK_BID_3_Up  "))
    assert {k: v.direction for k, v in bids.items()} == {"B1": BidDirection.UP, "B2": BidDirection.DOWN, "B3": BidDirection.UP}


def test_rao_a_bid_with_neither_a_direction_nor_a_suffix_is_skipped(tmp_path):
    bids = _parse(tmp_path, _bid("B1", "MOCK_BID_1_UP"), _bid("B2", "MOCK_BID_2"), _bid("B3", "MOCK_BID_UPPER"))
    assert set(bids) == {"B1"}


def test_rao_the_direction_literal_wins_over_the_name_and_is_matched_by_its_last_word(tmp_path):
    bids = _parse(tmp_path, _bid("B1", "MOCK_BID_1_UP", "BidDirectionKind.down"), _bid("B2", "MOCK_BID_2", "MarketRegulationDirectionKind.up"),
                  _bid("B3", "MOCK_BID_3_UP", "MarketRegulationDirectionKind.upAndDown"))
    assert {k: v.direction for k, v in bids.items()} == {"B1": BidDirection.DOWN, "B2": BidDirection.UP}      # upAndDown: skipped


def test_rao_the_sign_of_p_is_not_checked_and_the_size_is_the_absolute_value(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        bids = _parse(tmp_path, _bid("B1", "MOCK_BID_1_DOWN", p=40.0), _bid("B2", "MOCK_BID_2_UP", p=-30.0))
    assert bids["B1"].available_mw == {"1030Z": 40.0} and bids["B2"].available_mw == {"1030Z": 30.0}
    assert "sign of p" not in caplog.text


def test_rao_the_directions_read_from_the_name_and_the_skipped_bids_are_one_summary_warning(tmp_path, caplog):
    many = [_bid(f"N{i}", f"MOCK_BID_{i}_UP") for i in range(7)] + [_bid(f"S{i}", f"MOCK_BID_{i}") for i in range(6)]
    with caplog.at_level(logging.DEBUG):
        _parse(tmp_path, *many)
    summary = [r for r in caplog.records if r.levelno == logging.WARNING]
    assert len(summary) == 1
    text = summary[0].getMessage()
    assert "7 bid(s) with the direction from the name" in text and "6 bid(s) skipped" in text and "N0" in text and "N5" not in text
    assert "S0" in text and "S5" not in text and "more" in text
    assert "N6" in " ".join(r.getMessage() for r in caplog.records if r.levelno == logging.DEBUG)


def test_rao_no_summary_warning_when_every_bid_has_a_direction(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        _parse(tmp_path, _bid("B1", "MOCK_BID_1", "BidDirectionKind.up"), _bid("B2", "MOCK_BID_2", "BidDirectionKind.down"))
    assert not [r for r in caplog.records if r.levelno == logging.WARNING]

def test_rao_the_redispatch_and_the_countertrade_parse_of_one_file_give_one_summary_warning(tmp_path, caplog):
    path = tmp_path / "x_SIS.xml"
    path.write_text(HEADER + _bid("B1", "MOCK_BID_1_UP", ra="RA_1") + _bid("B2", "MOCK_BID_2_DOWN", ra="RA_2") + _bid("B3", "MOCK_BID_3", ra="RA_2")
                    + "</rdf:RDF>\n", encoding="utf-8")
    graph = ncp_parser._load_graph(path)
    with caplog.at_level(logging.WARNING):
        first = ncp_parser.parse_power_bids(graph, {"RA_1"}, "TSO-X", "1030Z")          # for example the redispatch RAs
        second = ncp_parser.parse_power_bids(graph, {"RA_2"}, "TSO-X", "1030Z")         # for example the countertrade RAs
    assert [b.mrid for b in first] == ["B1"] and [b.mrid for b in second] == ["B2"]
    summary = [r.getMessage() for r in caplog.records if "bid direction" in r.getMessage()]
    assert len(summary) == 1 and "2 bid(s) with the direction from the name" in summary[0] and "1 bid(s) skipped" in summary[0]
