"""
test_rao_ct_pipeline.py â€” countertrade end to end on the generated mock (tests/mock_builders/ct_mock.py,
docs/specs/countertrade_ra_specs.md C6, C12): run_pipeline.main() on CGM_package.zip + the mock NCP.
Sections: the preventive model and the curative model in ac_single_pass; the other calculation modes
are covered in test_rao_ct_modes.py.
"""
import csv
import logging
from types import SimpleNamespace

import pyomo.environ as pyo
import pytest
from pyomo.core.expr.visitor import identify_variables

from mock_builders import ct_mock
from helpers import _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs

BELGOVIA_BO4 = ct_mock.BRANCH_GA_BO4_BELGOVIA
CT_FILES = {
    "results_countertrade.csv", "results_curative_countertrade.csv", "countertrade_glsk_resolved.csv",
    "ct_cra_availability.csv", "results_net_positions.csv", "results_zone_exchange.csv",
}


def _read_csv(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _summary(output_dir):
    from helpers import read_summary
    return read_summary(output_dir)


def _run(tmp_path, ras=None, ra_types=("countertrade",), mode="ac_single_pass", nx=False, ncp_zip=None, **mock_kwargs):
    """One pipeline run; returns the output folder, the models built and the log records of the CT modules."""
    tmp_path.mkdir(parents=True, exist_ok=True)
    ncp = ncp_zip or ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip", ras=ras, **mock_kwargs)
    models = []

    def keep_models(rp, monkeypatch):
        monkeypatch.setattr(rp, "LOADINGS_N0_MIN_LOADING_PCT", 0)        # every monitored branch is listed in loadings_n0.csv
        build = rp.ac_convergence_loop.build_n0_milp_model

        def keeping_build(*args, **kwargs):
            model = build(*args, **kwargs)
            models.append(model)
            return model

        monkeypatch.setattr(rp.ac_convergence_loop, "build_n0_milp_model", keeping_build)

    run = run_pipeline_on_fixture_inputs(
        tmp_path / "run", ncp, enable_nx_analysis=nx, ra_types=ra_types, calculation_mode=mode, customize_pipeline=keep_models,
    )
    return SimpleNamespace(output_dir=run.output_dir, models=models)


@pytest.fixture(scope="module")
def ct_only(tmp_path_factory):
    return _run(tmp_path_factory.mktemp("ct_only"))


def _bids_by_direction(model):
    """{(zone, direction): bid mRID} of the default mock: the bid names are in the mock spec."""
    return {name: ct_mock._uid("bid", *name.split("/")) for name in ("BO/BO-up", "BO/BO-down", "GA/GA-up", "GA/GA-down")}


def _volume(model, mock_name):
    bid = _bids_by_direction(model)[mock_name]
    return pyo.value(model.rd_volume_upward[bid]) - pyo.value(model.rd_volume_downward[bid])


# ---------------------------------------------------------------------------
# relief, balance, limits, cost
# ---------------------------------------------------------------------------

def test_the_net_injection_of_the_units_follows_the_remaining_capacity_weights(ct_only):
    model = ct_only.models[-1]
    volume = -_volume(model, "BO/BO-down")
    expected = {gu: -volume * w for gu, w in ct_mock.EXPECTED_WEIGHTS[("Belgovia", "down")].items()}
    expected.update({gu: volume * w for gu, w in ct_mock.EXPECTED_WEIGHTS[("Galia", "up")].items()})
    assert {gu: pyo.value(model.rd_net_injection_g[gu]) for gu in model.gu_ids} == pytest.approx(expected, abs=1e-4)
    assert sum(pyo.value(model.rd_net_injection_g[gu]) for gu in model.gu_ids) == pytest.approx(0.0, abs=1e-6)


def test_the_unit_limits_hold_in_the_solution(ct_only):
    model = ct_only.models[-1]
    for gu in model.gu_ids:
        target = model.rd_baseline_target_p_mw[gu]
        status = model.rd_unit_status[gu]
        total = target + pyo.value(model.rd_net_injection_g[gu])
        assert status.pmin_mw - 1e-6 <= total <= status.pmax_mw + 1e-6


# ---------------------------------------------------------------------------
# RD together with CT, ra_types combinations
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# restrictive groups, penalty factors, bids without volume
# ---------------------------------------------------------------------------

def test_a_restrictive_group_caps_the_countertrade_bid(tmp_path):
    ras = ct_mock.default_ras()
    result = _run(tmp_path, ras, groups=[ct_mock.group("cap", [ras[0]], max_down=30.0)])
    model = result.models[-1]
    assert hasattr(model, "ra_group_volume_downward_limit")
    assert -_volume(model, "BO/BO-down") == pytest.approx(30.0, abs=1e-6)


def test_penalty_factor_zero_and_two_scale_the_penalty_cost(tmp_path):
    for factors, expected in (((0.0, 0.0), 0.0), ((2.0, 2.0), 2.0)):
        result = _run(tmp_path / str(expected), ct_mock.default_ras(penalties=factors))
        model = result.models[-1]
        volume = -_volume(model, "BO/BO-down")
        assert pyo.value(model.objective_penalty_term_expressions["ct_pra_penalty_cost"]) == pytest.approx(
            expected * 100.0 * 2 * volume, rel=1e-6, abs=1e-9,
        )


def test_a_bid_without_volume_cannot_be_used(tmp_path):
    ras = [ct_mock.ra("no-volume", ct_mock.ZONE_BELGOVIA, [ct_mock.bid("nv-up", "up", volume=None), ct_mock.bid("nv-down", "down", 100.0)])]
    ras += [ct_mock.default_ras()[1]]
    result = _run(tmp_path, ras)
    model = result.models[-1]
    up = ct_mock._uid("bid", "no-volume", "nv-up")
    assert pyo.value(model.rd_volume_upward[up]) == pytest.approx(0.0, abs=1e-9) and model.rd_volume_upward[up].ub == 0.0


# ---------------------------------------------------------------------------
# negative cases: no usable CT RA
# ---------------------------------------------------------------------------

def test_all_units_at_pmax_give_an_up_bid_of_volume_zero(tmp_path, monkeypatch, caplog):
    from pre_milp import ct_units

    original = ct_units.read_generator_table

    def at_pmax(network):
        table = original(network)
        for gu in (ct_mock.GA_G1, ct_mock.GA_G2, ct_mock.GA_G3):
            table[gu].prod = table[gu].pmax
        return table

    monkeypatch.setattr(ct_units, "read_generator_table", at_pmax)
    with caplog.at_level(logging.WARNING):
        result = _run(tmp_path)
    # Galia cannot move up: its up bid is bounded to 0 (one warning); the run goes on with the rest
    assert result.models
    galia_up = ct_mock._uid("bid", "GA", "GA-up")
    for model in result.models:
        assert model.rd_volume_upward[galia_up].ub == 0.0 and model.rd_volume_downward[galia_up].ub == 0.0
    assert sum("no unit can move up" in r.getMessage() and "fixed to 0" in r.getMessage() for r in caplog.records) == 1


# ---------------------------------------------------------------------------
# curative countertrade (N-X on), ac_single_pass
# ---------------------------------------------------------------------------

CO = ct_mock.CONTINGENCY_GA_BO5
CURATIVE_BIDS = [ct_mock._uid("bid", ra, name) for ra, name in (
    ("BO-cur", "BO-cur-up"), ("BO-cur", "BO-cur-down"), ("GA-cur", "GA-cur-up"), ("GA-cur", "GA-cur-down"))]


def _curative_run(tmp_path, ras=None, ra_types=("countertrade",)):
    return _run(
        tmp_path, ras or ct_mock.curative_ras(), ra_types=ra_types, nx=True, patl_a=ct_mock.CURATIVE_PATL_A,
        contingencies=[ct_mock.ga_bo5_outage()],
    )


@pytest.fixture(scope="module")
def curative(tmp_path_factory):
    return _curative_run(tmp_path_factory.mktemp("ct_curative"))


def _cur_volume(model, name, contingency=CO):
    bid = ct_mock._uid("bid", *name.split("/"))
    return (pyo.value(model.curative_rd_volume_upward[bid, contingency])
            - pyo.value(model.curative_rd_volume_downward[bid, contingency]))


def test_the_curative_terms_are_in_the_rows_of_the_linked_contingency_only(curative):
    model = curative.models[-1]
    assert sorted(model.curative_bid_contingency_pairs) == sorted((bid, CO) for bid in CURATIVE_BIDS)
    for (branch, contingency) in model.nx_branch_contingency_pairs:
        names = {v.name for v in identify_variables(model.nx_patl_loading[branch, contingency].body)}
        curative = {n for n in names if n.startswith("curative_rd_volume")}
        assert all(n.endswith(f",{CO}]") for n in curative)
        if contingency != CO:
            assert not curative


def test_a_reaction_time_above_the_tatl_duration_keeps_the_curative_ra_off_the_branch(tmp_path):
    result = _curative_run(tmp_path, ct_mock.curative_ras(time_to_implement="PT20M"))
    model = result.models[-1]
    assert _cur_volume(model, "BO-cur/BO-cur-down") == pytest.approx(0.0, abs=1e-9)
    assert pyo.value(model.nx_patl_overload_slack[BELGOVIA_BO4, CO]) == pytest.approx(ct_mock.N1_CURRENT_A - ct_mock.CURATIVE_PATL_A, abs=0.2)


def test_a_curative_ra_without_a_link_is_available_in_every_contingency(tmp_path):
    result = _curative_run(tmp_path, ct_mock.curative_ras(contingencies=()))
    model = result.models[-1]
    contingencies = {c for _, c in model.curative_bid_contingency_pairs}
    assert CO in contingencies and len(contingencies) > 5
    used = [c for c in contingencies if abs(_cur_volume(model, "BO-cur/BO-cur-down", c)) > 1e-6]
    assert CO in used


def test_per_ra_volume_caps_in_the_sis_are_warned_about_in_a_run(tmp_path, caplog):
    """A PowerRemedialActionSchedule in a TSO's SIS file is not read: the run goes on and logs one warning."""
    import zipfile
    caps = """
  <nc:PowerRemedialActionSchedule rdf:ID="_cap-schedule">
    <nc:PowerRemedialActionSchedule.PowerRemedialAction rdf:resource="#_none"/>
  </nc:PowerRemedialActionSchedule>"""
    source = tmp_path / "with_caps.zip"
    with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as archive, zipfile.ZipFile(source, "w") as out:
        for item in archive.infolist():
            data = archive.read(item.filename)
            if item.filename == "Belgovia_SIS.xml":
                data = ct_mock._append(data, caps)
            out.writestr(item, data)
    with caplog.at_level(logging.WARNING):
        run_pipeline_on_fixture_inputs(tmp_path / "run", source, enable_nx_analysis=False, ra_types=("rd",))
    assert [r for r in caplog.records if "PowerRemedialActionSchedule" in r.getMessage() and "Belgovia_SIS.xml" in r.getMessage()]


def test_pst_and_countertrade_run_together(tmp_path):
    result = _run(tmp_path, ra_types=("pst", "countertrade"))
    assert _summary(result.output_dir)["ra_types"] == "pst+countertrade"
    assert "pst_results.csv" in {p.name for p in result.output_dir.glob("*")}
    assert any(hasattr(m, "ct_bid_ids") and m.ct_bid_ids for m in result.models)


def test_curative_actions_are_never_applied_to_the_network(curative):
    row = next(r for r in _read_csv(curative.output_dir / "loadings_n0.csv") if r["branch_id"] == BELGOVIA_BO4)
    assert float(row["current_after_pra_a"]) == pytest.approx(float(row["current_initial_a"]), abs=1e-6)
    assert not hasattr(curative.models[-1], "rd_net_injection_g")

