"""tests/test_rao_run_locations.py - the folders the pipeline reads and writes can be given by the environment."""

import os
import shutil
import subprocess
import sys

from helpers import REPO_ROOT

_SHOW = (
    "import sys; sys.path.insert(0, 'src/rao'); import run_pipeline as r; "
    "print(r.INPUT_DIR); print(r.OUTPUT_DIR); print(r.RAO_CONFIG_PATH); print(r.LOAD_FLOW_CONFIG_PATH)"
)


def _locations(environment: dict) -> list:
    env = {k: v for k, v in os.environ.items() if not k.startswith("RAO_")}
    env.update(environment)
    done = subprocess.run([sys.executable, "-c", _SHOW], cwd=REPO_ROOT, env=env, capture_output=True, text=True, encoding="utf-8")
    assert done.returncode == 0, done.stderr
    return done.stdout.splitlines()[-4:]


def test_without_the_variables_the_pipeline_uses_the_folders_of_the_repository():
    config = REPO_ROOT / "src" / "rao" / "config"
    assert _locations({}) == [
        *[str(REPO_ROOT / name) for name in ("in" + "put", "out" + "put")], str(config / "rao_config.yaml"), str(config / "load_flow_config.yaml"),
    ]


def test_the_variables_set_the_input_output_and_config_folders(tmp_path):
    folders = {name: tmp_path / name for name in ("in", "out", "cfg")}
    folders["cfg"].mkdir()
    for name in ("rao_config.yaml", "load_flow_config.yaml"):
        shutil.copyfile(REPO_ROOT / "src" / "rao" / "config" / name, folders["cfg"] / name)
    given = {"RAO_INPUT_DIR": folders["in"], "RAO_OUTPUT_DIR": folders["out"], "RAO_CONFIG_DIR": folders["cfg"]}
    assert _locations({k: str(v) for k, v in given.items()}) == [
        str(folders["in"]), str(folders["out"]), str(folders["cfg"] / "rao_config.yaml"), str(folders["cfg"] / "load_flow_config.yaml"),
    ]
