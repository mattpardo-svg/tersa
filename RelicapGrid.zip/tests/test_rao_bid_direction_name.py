"""tests/test_rao_bid_direction_name.py - the direction of a bid: the PowerBidSchedule.direction property wins; without it the
name is split on whitespace, "_" and "-" and its LAST token must be up or down (any case), else the bid is skipped.
One summary per SIS file. Synthetic names only."""

import logging

import pytest

from data_model import BidDirection
from pre_milp import ncp_parser

HEADER = ('<?xml version="1.0" encoding="UTF-8"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:nc="https://cim4.eu/ns/nc#" xmlns:cim="https://cim.ucaiug.io/ns#">')


def _bid(ident, name, direction=None):
    direction_xml = (f'<nc:PowerBidSchedule.direction rdf:resource="https://cim4.eu/ns/nc#BidDirectionKind.{direction}"/>'
                     if direction else "")
    return (f'<nc:PowerBidSchedule rdf:ID="_{ident}"><cim:IdentifiedObject.mRID>{ident}</cim:IdentifiedObject.mRID>'
            f'<cim:IdentifiedObject.name>{name}</cim:IdentifiedObject.name>{direction_xml}'
            f'<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/></nc:PowerBidSchedule>'
            f'<nc:PowerBidScheduleTimePoint rdf:ID="_TP_{ident}"><nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{ident}"/>'
            f'<nc:PowerBidScheduleTimePoint.atTime>2030-01-01T10:30:00Z</nc:PowerBidScheduleTimePoint.atTime>'
            f'<nc:PowerBidScheduleTimePoint.p>10</nc:PowerBidScheduleTimePoint.p>'
            f'<nc:PowerBidScheduleTimePoint.price>5</nc:PowerBidScheduleTimePoint.price></nc:PowerBidScheduleTimePoint>')


def _parse(tmp_path, *bids):
    path = tmp_path / "X_SIS.xml"
    path.write_text(HEADER + "".join(bids) + "</rdf:RDF>", encoding="utf-8")
    return {bid.mrid: bid.direction for bid in ncp_parser.parse_power_bids(ncp_parser._load_graph(path), {"RA1"}, "X", "1030Z")}


@pytest.mark.parametrize("name, direction", [
    ("Bid A down", BidDirection.DOWN), ("Bid A up", BidDirection.UP), ("Bid_A_DOWN", BidDirection.DOWN),
    ("Bid-A-Up", BidDirection.UP), ("Bid A up and down", BidDirection.DOWN), ("bid A UP", BidDirection.UP),
    ("  Bid A Down  ", BidDirection.DOWN), ("Bid A-up", BidDirection.UP), ("Bid_A DOWN", BidDirection.DOWN),
])
def test_rao_the_last_token_of_the_name_is_the_direction(tmp_path, name, direction):
    assert _parse(tmp_path, _bid("B1", name)) == {"B1": direction}


@pytest.mark.parametrize("name", ["Bid A up Y", "Bid up 1", "Bid A", "upward", "Bid A updown", "Bid A_UP_1", ""])
def test_rao_a_name_whose_last_token_is_not_up_or_down_skips_the_bid(tmp_path, name):
    assert _parse(tmp_path, _bid("B1", name)) == {}


def test_rao_the_direction_property_beats_a_misleading_name(tmp_path):
    assert _parse(tmp_path, _bid("B1", "Bid A down", "up"), _bid("B2", "Bid A up", "down")) == {
        "B1": BidDirection.UP, "B2": BidDirection.DOWN}


def test_rao_the_summary_counts_the_names_used_and_the_bids_skipped_once_per_file(tmp_path, caplog):
    with caplog.at_level(logging.INFO):
        _parse(tmp_path, _bid("B1", "Bid A down"), _bid("B2", "Bid A_UP"), _bid("B3", "Bid up Y"), _bid("B4", "Bid A", "up"))
    lines = [r.getMessage() for r in caplog.records if "bid direction" in r.getMessage()]
    assert len(lines) == 1
    assert "2 bid(s) with the direction from the name" in lines[0] and "1 bid(s) skipped" in lines[0] and "B3" in lines[0]
