# Instructions for contributors

This repo is a prototype of a security-constrained remedial action optimisation (RAO) on CGMES and NCP data (pypowsybl, Pyomo, HiGHS). It runs one timestamp per run, in one of three calculation modes: `ac_iterative`, `ac_single_pass` or `dc`. Remedial action types: PST, redispatch, countertrade and HVDC, preventive and curative.

## Source of truth
1. Code and tests are the source of truth.
2. Then `docs/DECISIONS.md` and `docs/ASSUMPTIONS.md`: decisions that cannot be seen from the code. Read both before changing behaviour.
3. `docs/specs/` holds the specs of the tool; `docs/specs/README.md` lists each one with its status. The output files follow `docs/specs/output_files_specs.md`, the NCP input `docs/specs/ncp_data_requirements.md`.
4. `docs/specs/functional_specs_25_1.md` is the functional specification. Read it to check a requirement; search it by CORNET or BUC number. It is read-only: code tasks never change it. It may be outdated; conflicts with it are not your problem.
5. If code and a document in `docs/` disagree, stop and ask. Do not guess which is right.

## Scope
- Change only code under `src/rao/`, the tests under `tests/`, the files in `docs/` (except `docs/specs/functional_specs_25_1.md`) and the tools in `tests/tools/` (fixture builders and golden-check scripts; nothing in `src/` imports them).
- Never change the GUI (`src/rao_pages/`, `src/app.py`), `input/`, `output/`, `logs/` or the config files in `src/rao/config/`, unless asked to.
- The GUI imports from `src/rao`. Do not rename or move any module, function, class or constant that `src/rao_pages/` imports. If a change in `src/rao` would break the GUI, stop and ask.
- Nothing in `src/` or `tests/` may refer to a folder outside the repo. Allowed top-level folders: `src`, `tests`, `docs`, `.github`, `.devcontainer`, and the runtime folders `input`, `output` and `logs`.
- A new requirement spec is drafted in `docs/` while it is open. When it is implemented and accepted, the maintainer moves it to `docs/specs/`. Contributors do not move it.

## How to work
- One small increment at a time. Write a failing test first, then the fix.
- During work, run the tests of the touched modules and the golden check. Run the full suite before a task is handed over.
- For a rule that matters, add a test. Tests test code only. Never write a test that reads markdown or any document.
- No behaviour change inside a refactor: the golden check must show 0 differences. The test count may drop only for tests of removed code or true duplicates.
- Never change a golden file to make a test pass. Goldens are replaced only on request, after the changed values are explained.
- Do not add silent defaults. A missing or invalid input must halt, exclude with a warning, or fall back with a warning.
- Do not change results-affecting behaviour (model, objective, convergence, defaults) without asking. State the question and wait.
- Keep modules small and readable. Do not create new markdown files.

## After every task
1. Add a short entry to `docs/CHANGELOG.md`: date, what changed (file, function), tests added, suite result, open items.
2. If you made or changed a decision, add or update it in `docs/DECISIONS.md` (ask first). Do not renumber entries.
3. If you learned or confirmed an assumption about the data or the spec, update `docs/ASSUMPTIONS.md`.
4. If you rename or add an output file or a config key, update `docs/specs/output_files_specs.md` or `docs/User_Guide.md`, and both `src/rao/config/rao_config.yaml` and `rao_config.default.yaml`. The GUI settings page must show every config key.
5. Every new, changed or deferred requirement gets a row in `docs/Spec_Coverage.md` with its CORNET or BUC reference, and every deviation from the specification is listed there.
Keep entries short: facts, no history.

## Commands (from the repo root)
- Tests: `python -m pytest tests -q`. The whole gate (suite in parallel, 52-run golden matrix against `tests/tools/golden/baseline.zip`, fingerprints, link check of the docs) is `python tests/tools/golden/run_gate.py OUTDIR TAG none`.
- Tests use only `tests/fixtures`; none reads `input/`.
- Run: `python src/rao/run_pipeline.py` (see `docs/README.md`). The GUI: `streamlit run src/app.py`.
- Modules import each other flat (`from data_model import ...`); `tests/conftest.py` adds `src/rao` to `sys.path`. Do not convert to package imports unless asked. Shared test builders live in `tests/helpers.py` (fixtures stay in `tests/conftest.py`); a test file never imports another test file.

## Output files
- Each run writes all its files and `run_log.txt` into `output/<CGM time>/` (e.g. `output/20250506T0030Z/`). A rerun of the same timestamp empties that folder first; no other folder is touched.
- Names and columns follow `docs/specs/output_files_specs.md`: lower case, the unit as the last part of a column name (`_a`, `_mw`, `_eur`, `_pct`, ...), `tso` as the first column. A file is written only when its feature is on. What a run leaves out, and why, goes to the log, not to a file.
- Log one summary line (count and the first 5 ids) instead of one line per object.

## Hard rules for this code
- Non-public data is never part of the repo: one set is placed by hand in `input/` (one `cgm*.zip`, one `ncp*.zip`) for a run. `input/` currently holds the HVDC mock pair (`CGM_package_hvdc.zip`, `NCP_mock_hvdc.zip`).
- Contingency propagation must stay off. Load-flow and sensitivity parameters come only from `pre_milp/lf_parameters.py`.
- `ACTIVATE_CRA_XNE_LINKAGE` stays hardcoded in `run_pipeline.py` on purpose.
- Comments and docstrings must not cite documents (no "see R3_NX_CRA.md"); say the rule in the comment itself.
- Comments describe the current code in 1 to 6 lines. History and decisions go to `docs/DECISIONS.md`.
- No personal, company-internal, tool or model names anywhere, and no notes about how or where the work was done.

## Tests and data
- Non-public data means any grid or market data that is not part of the public mock data in tests/fixtures/.
- Write every test against the ReliCapGrid mock data in `tests/fixtures/`, or against small networks or XML built inside the test.
- Never use values from non-public data in a test. Never copy its values, names, mRIDs or file contents into `tests/`, fixtures, docs, logs or comments.
- If a run on non-public data shows a bug, rebuild the same case on the mock data, or as a small synthetic case, and write the test on that. The test must fail before the fix and pass after it.
- If the mock data cannot show the case (for example a different XML structure), build a minimal synthetic input with fake values in the test. Do not add non-public data to `tests/fixtures/`.
- Test names start with `test_rao_`. Tests check the code's behaviour, not the text of docs.