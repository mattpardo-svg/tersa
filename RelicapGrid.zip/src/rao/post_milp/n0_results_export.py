"""n0_results_export.py — N-0-level result CSVs of the MILP (PST, curative PST, RD, RA
count, RA groups, lead times, summary, generating units, lf_post_n0, completeness iterations).
Curative and preventive tap changes are whole numbers when pst_taping_discrete is true (the
default) and continuous model values, written unrounded, otherwise.
"""

import logging
from pathlib import Path
from typing import Dict, Optional

from data_model import AcVerificationStatus, BidDirection, PST, PowerBid, RAKind, RDUnit, select_by_side
from milp.milp_builder import (
    _lead_time_is_usable,
    curative_rd_reservation_price_eur_mw,
    describe_decision_point,
    get_effective_rd_penalty_cost_per_mw,
)
from text_encoding import TEXT_ENCODING

log = logging.getLogger(__name__)

# values at or below these count as zero: tap headroom, MW volume, overload slack (A)
_ZERO_TAPS = 1e-6
_ZERO_VOLUME_MW = 1e-9
_ZERO_SLACK_AMPERE = 1e-6


# ---------------------------------------------------------------------------
# From milp_solver.py
# ---------------------------------------------------------------------------

def extract_curative_pst_results(
    milp_model,
    pst_list: Optional[list[PST]],
    penalty_reference_pst_pra: float,
    penalty_reference_pst_pra_per_tso: Optional[dict[str, float]] = None,
) -> Dict[str, Dict[str, object]]:
    """Per-transformer curative PST totals: curative_tap_change_total = sum over contingencies
    of (up + down); curative_penalty_cost_eur = curative RA penalty_factor x (per-TSO override
    or penalty_reference_pst_pra) x that total, as in the objective (no max). Only curative
    PST objects are read. {} when the model has no curative PST pairs."""
    if not hasattr(milp_model, "curative_pst_contingency_pairs") or not pst_list:
        return {}
    try:
        import pyomo.environ as pyo
    except ImportError as exc:
        raise ImportError("pyomo is required to extract curative PST results") from exc

    per_tso = penalty_reference_pst_pra_per_tso or {}
    curative_pst_by_mrid = {str(p.mrid): p for p in pst_list if p.kind == RAKind.CURATIVE}
    totals: Dict[str, float] = {}
    for pst_mrid, co_mrid in milp_model.curative_pst_contingency_pairs:
        totals[str(pst_mrid)] = totals.get(str(pst_mrid), 0.0) + float(
            pyo.value(milp_model.curative_tap_change_upward[pst_mrid, co_mrid])
            + pyo.value(milp_model.curative_tap_change_downward[pst_mrid, co_mrid])
        )

    results: Dict[str, Dict[str, object]] = {}
    for pst_mrid, total in sorted(totals.items()):
        pst = curative_pst_by_mrid.get(pst_mrid)
        if pst is None:
            continue
        reference = float(per_tso.get(pst.tso, penalty_reference_pst_pra))
        cost_per_tap = float(pst.penalty_factor) * reference
        results[pst_mrid] = {
            "pst_name": pst.name,
            "tso": pst.tso,
            "current_tap_position": int(getattr(pst, "r0", 0)),
            "pst_penalty_factor": float(pst.penalty_factor),
            "penalty_reference_pst_pra": reference,
            "effective_penalty_cost_per_tap_eur": cost_per_tap,
            "curative_tap_change_total": total,
            "curative_penalty_cost_eur": cost_per_tap * total,
        }
    return results


def extract_curative_pst_delta_results(
    milp_model,
    pst_list: Optional[list[PST]],
    pst_tap_bounds_curative: Optional[dict[str, tuple[int, int]]],
    pst_cra_availability: Optional[dict[tuple[str, str, str], dict]],
    penalty_reference_pst_pra: float,
    penalty_reference_pst_pra_per_tso: Optional[dict[str, float]] = None,
) -> list[dict]:
    """One row per (curative PST, contingency) pair with variables in the model, sorted.
    curative_delta_taps_up/_down: optimised (continuous) values; net = up - down.
    curative_tap_lower/upper_bound: the absolute bounds the builder used
    (pst_tap_bounds_curative), blank when none. available: from pst_cra_availability (blank
    without it). penalty_cost_eur = penalty_factor x reference x (up + down), so the rows add
    up to the curative penalty cost of pst_results.csv. [] without curative PST pairs.
    """
    if not hasattr(milp_model, "curative_pst_contingency_pairs") or not pst_list:
        return []
    try:
        import pyomo.environ as pyo
    except ImportError as exc:
        raise ImportError("pyomo is required to extract curative PST delta results") from exc

    per_tso = penalty_reference_pst_pra_per_tso or {}
    bounds = pst_tap_bounds_curative or {}
    curative_pst_by_mrid = {str(p.mrid): p for p in pst_list if p.kind == RAKind.CURATIVE}
    available_pairs = None
    if pst_cra_availability is not None:
        available_pairs = {
            (str(pst_mrid), str(co_mrid))
            for (pst_mrid, _xne_mrid, co_mrid), entry in pst_cra_availability.items()
            if entry.get("available")
        }

    rows: list[dict] = []
    for pst_mrid, co_mrid in sorted(milp_model.curative_pst_contingency_pairs):
        pst = curative_pst_by_mrid.get(str(pst_mrid))
        if pst is None:
            continue
        up = float(pyo.value(milp_model.curative_tap_change_upward[pst_mrid, co_mrid]))
        down = float(pyo.value(milp_model.curative_tap_change_downward[pst_mrid, co_mrid]))
        reference = float(per_tso.get(pst.tso, penalty_reference_pst_pra))
        lower, upper = bounds.get(str(pst_mrid), (None, None))
        rows.append({
            "tso": pst.tso,
            "pst_mrid": str(pst_mrid),
            "contingency_mrid": str(co_mrid),
            "curative_delta_taps_up": up,
            "curative_delta_taps_down": down,
            "curative_delta_taps_net": up - down,
            "curative_tap_lower_bound": lower,
            "curative_tap_upper_bound": upper,
            "available": None if available_pairs is None else (str(pst_mrid), str(co_mrid)) in available_pairs,
            "penalty_cost_eur": float(pst.penalty_factor) * reference * (up + down),
        })
    return rows


def extract_tso_tap_limit_results(milp_model, pst_list: Optional[list[PST]]) -> list[dict]:
    """Per TSO with preventive PSTs: taps used (sum of up + down over its PSTs), the applied
    limit (model.tso_tap_limit_values), the headroom and whether it binds. [] without a
    preventive PST block (header-only file)."""
    if not hasattr(milp_model, "tso_ids_for_tap_change_limit") or not hasattr(milp_model, "tap_change_upward"):
        return []
    try:
        import pyomo.environ as pyo
    except ImportError as exc:
        raise ImportError("pyomo is required to extract TSO tap limit results") from exc

    model_pst_ids = set(milp_model.pst_ids)
    tso_by_mrid: Dict[str, str] = {}
    for pst in pst_list or []:
        if pst.kind == RAKind.PREVENTIVE and str(pst.mrid) in model_pst_ids:
            tso_by_mrid[str(pst.mrid)] = pst.tso   # one entry per transformer

    rows = []
    for tso in sorted(milp_model.tso_ids_for_tap_change_limit):
        total = sum(
            float(pyo.value(milp_model.cum_tap_up_term[m])) + float(pyo.value(milp_model.cum_tap_down_term[m]))
            if hasattr(milp_model, "cum_tap_up_term")
            else float(pyo.value(milp_model.tap_change_upward[m])) + float(pyo.value(milp_model.tap_change_downward[m]))
            for m, t in tso_by_mrid.items() if t == tso
        )
        limit = float(milp_model.tso_tap_limit_values[tso])
        remaining = limit - total
        rows.append({
            "tso": tso, "tap_total": total, "max_taps_per_tso": limit,
            "remaining": remaining, "binding": remaining <= _ZERO_TAPS,
        })
    return rows


def extract_curative_rd_results(
    milp_model,
    rd_list: list[RDUnit],
    bid_list: list[PowerBid],
    penalty_reference_rd_pra: float,
    penalty_reference_rd_pra_per_tso: Optional[dict[str, float]] = None,
) -> list[dict]:
    """One row per (curative bid, contingency) pair (model.curative_bid_contingency_pairs).
    curative_volume_mw: the variable of the bid's own direction; max_curative_volume_mw: its
    max-over-contingencies variable; penalty_cost_eur_per_mw from
    get_effective_rd_penalty_cost_per_mw. curative_cost_eur = (penalty/MW + reservation price) x
    (max_up + max_down), on the bid's first row only (0.0 on the others), so the column sums to
    the curative RD part of the objective; reservation price = the bid's reservePrice, else its
    energy price (curative_rd_reservation_price_eur_mw, as the objective). [] without curative RD."""
    if not hasattr(milp_model, "curative_bid_contingency_pairs"):
        return []
    try:
        import pyomo.environ as pyo
    except ImportError as exc:
        raise ImportError("pyomo is required to extract curative RD results") from exc

    penalty_cost_per_mw_and_tso = get_effective_rd_penalty_cost_per_mw(
        rd_list, penalty_reference_rd_pra, penalty_reference_rd_pra_per_tso,
    )
    bid_by_mrid = {str(bid.mrid): bid for bid in bid_list}

    rows: list[dict] = []
    costed_bids: set[str] = set()
    ct_curative_bid_ids = getattr(milp_model, "ct_curative_bid_ids", frozenset())    # not RD results
    for bid_mrid, co_mrid in sorted(milp_model.curative_bid_contingency_pairs):
        if str(bid_mrid) in ct_curative_bid_ids:
            continue
        bid = bid_by_mrid.get(str(bid_mrid))
        if bid is None:
            log.warning("MILP model references curative PowerBid %s not found in PowerBidList — skipped", bid_mrid)
            continue
        is_up = bid.direction == BidDirection.UP
        volume_var = milp_model.curative_rd_volume_upward if is_up else milp_model.curative_rd_volume_downward
        max_var = milp_model.max_curative_rd_volume_upward if is_up else milp_model.max_curative_rd_volume_downward
        penalty_cost_per_mw, tso = penalty_cost_per_mw_and_tso.get(str(bid.ra_mrid), (0.0, ""))

        cost = 0.0
        if bid_mrid not in costed_bids:
            costed_bids.add(bid_mrid)
            max_total = float(pyo.value(milp_model.max_curative_rd_volume_upward[bid_mrid])) + float(
                pyo.value(milp_model.max_curative_rd_volume_downward[bid_mrid])
            )
            cost = (penalty_cost_per_mw + curative_rd_reservation_price_eur_mw(bid)) * max_total
        rows.append({
            "bid_mrid": str(bid_mrid),
            "ra_mrid": str(bid.ra_mrid),
            "tso": tso,
            "contingency_mrid": str(co_mrid),
            "direction": bid.direction.value,
            "curative_volume_mw": float(pyo.value(volume_var[bid_mrid, co_mrid])) + 0.0,  # + 0.0: no "-0.0"
            "max_curative_volume_mw": float(pyo.value(max_var[bid_mrid])) + 0.0,
            "price_eur_mw": float(bid.price_eur_mw),
            "reservation_price_eur_mw": curative_rd_reservation_price_eur_mw(bid),
            "penalty_cost_eur_per_mw": penalty_cost_per_mw,
            "curative_cost_eur": cost,
        })
    return rows


def _last_solve_signed_rd_volume_mw(milp_model, bid_mrid: str) -> float:
    """Change the LAST solve made to this bid (up - down), in MW."""
    import pyomo.environ as pyo
    return float(pyo.value(milp_model.rd_volume_upward[bid_mrid])) - float(
        pyo.value(milp_model.rd_volume_downward[bid_mrid])
    )


def _cumulative_signed_rd_volume_mw(milp_model, bid_mrid: str) -> float:
    """Net volume of this bid against the ORIGINAL network: what earlier
    iterations already applied (model.rd_used_signed_volume_mw, signed: UP bids
    positive) plus the last solve's change. For a model built on the original
    network the used volume is 0 and this equals the last-solve change."""
    used = float(getattr(milp_model, "rd_used_signed_volume_mw", {}).get(bid_mrid, 0.0))
    return used + _last_solve_signed_rd_volume_mw(milp_model, bid_mrid)


def extract_rd_results(
    milp_model,
    rd_list: list[RDUnit],
    bid_list: list[PowerBid],
    penalty_reference_rd_pra: float,
    penalty_reference_rd_pra_per_tso: Optional[dict[str, float]] = None,
) -> Dict[str, Dict[str, object]]:
    """Per-bid RD results of an already-solved model (the RA penalty_factor and per-TSO
    override as in the objective). {} when the model has no rd_volume_upward (no RD block); the CSV
    is still written, header-only (an empty file means "checked, nothing to report")."""
    if not hasattr(milp_model, "rd_volume_upward"):
        return {}

    try:
        import pyomo.environ as pyo
    except ImportError as exc:
        raise ImportError("pyomo is required to extract RD results") from exc

    ra_penalty_factor_and_tso: dict[str, tuple[float, str]] = {
        str(rd.mrid): (float(rd.penalty_factor), rd.tso) for rd in rd_list
    }
    penalty_reference_rd_pra_per_tso = penalty_reference_rd_pra_per_tso or {}

    ct_bid_ids = getattr(milp_model, "ct_bid_ids", frozenset())    # countertrade bids are not RD results
    model_bid_ids = [str(b) for b in getattr(milp_model, "bid_ids", []) if str(b) not in ct_bid_ids]
    bid_by_mrid: dict[str, PowerBid] = {str(bid.mrid): bid for bid in bid_list}

    rd_results: Dict[str, Dict[str, object]] = {}
    for bid_mrid in model_bid_ids:
        bid = bid_by_mrid.get(bid_mrid)
        if bid is None:
            log.warning(
                "MILP model references PowerBid %s not found in PowerBidList — skipped",
                bid_mrid,
            )
            continue

        penalty_factor, tso = ra_penalty_factor_and_tso.get(str(bid.ra_mrid), (None, None))
        if penalty_factor is None:
            log.warning(
                "PowerBid %s references RA %s not found in RDList — "
                "penalty_cost_eur defaults to 0.0 for this bid",
                bid_mrid, bid.ra_mrid,
            )
            penalty_factor, tso = 0.0, ""

        # cumulative against the original network (== last solve on a first solve)
        last_solve_volume_net_mw = _last_solve_signed_rd_volume_mw(milp_model, bid_mrid)
        rd_volume_net_mw = _cumulative_signed_rd_volume_mw(milp_model, bid_mrid)

        effective_penalty_reference_rd_pra = float(
            penalty_reference_rd_pra_per_tso.get(tso, penalty_reference_rd_pra)
        )
        # each bid is one-directional, so abs(net) equals the objective's (up + down)
        activated_volume_mw = abs(rd_volume_net_mw)
        penalty_cost_eur = penalty_factor * effective_penalty_reference_rd_pra * activated_volume_mw
        rd_cost_eur = (
            penalty_factor * effective_penalty_reference_rd_pra + float(bid.price_eur_mw)
        ) * activated_volume_mw

        rd_results[bid_mrid] = {
            "ra_mrid": str(bid.ra_mrid),
            "tso": tso,
            "rd_volume_net_mw": rd_volume_net_mw,
            "last_solve_rd_volume_net_mw": last_solve_volume_net_mw,
            "price_eur_mw": float(bid.price_eur_mw),
            "rd_penalty_factor": penalty_factor,
            "penalty_cost_eur": penalty_cost_eur,
            "rd_cost_eur": rd_cost_eur,
        }

    log.info(
        "RD results extracted: %d bid(s), %d with non-zero net volume",
        len(rd_results),
        sum(1 for r in rd_results.values() if abs(r["rd_volume_net_mw"]) > _ZERO_VOLUME_MW),
    )

    return rd_results


# An RA counts as "activated" in results_ra_count when the absolute net RD volume of at least
# one of its bids exceeds this tolerance (MW). The model binary is reported separately
# (ra_activated_model_binary): it is bounded by the volume only from above and can be 1 at 0 MW.
RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW = 1e-6


def extract_ra_count_results(
    milp_model,
    rd_list: list[RDUnit],
    bid_list: list[PowerBid],
    max_ra_count_per_timestamp_tso: Optional[dict[str, int]] = None,
) -> Dict[str, Dict[str, object]]:
    """Per-TSO RA activation counts and count-limit slack of a solved model.
    activated_ra_count: RAs with a bid |up - down| > RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW
    (bid_list is required to map volumes to RAs); ra_activated_model_binary: sum of binaries.
    Every TSO with an RA in the model or a limit is reported. {} without ra_activated (the
    CSV is still written, header-only).
    """
    max_ra_count_per_timestamp_tso = max_ra_count_per_timestamp_tso or {}

    if not hasattr(milp_model, "ra_activated"):
        return {}

    try:
        import pyomo.environ as pyo
    except ImportError as exc:
        raise ImportError("pyomo is required to extract RA count results") from exc

    ra_mrid_to_tso: dict[str, str] = {str(rd.mrid): rd.tso for rd in rd_list}
    ra_mrids_in_model = [str(m) for m in getattr(milp_model, "ra_mrids", [])]

    tsos_with_limit_defined = set(max_ra_count_per_timestamp_tso.keys())
    tsos_with_ra_in_model = {ra_mrid_to_tso.get(ra) for ra in ra_mrids_in_model if ra_mrid_to_tso.get(ra) is not None}
    all_tsos = sorted(tsos_with_limit_defined | tsos_with_ra_in_model)

    timestamp_limit_tsos = set(getattr(milp_model, "tsos_with_timestamp_ra_limit", []))

    bid_by_mrid: dict[str, PowerBid] = {str(bid.mrid): bid for bid in bid_list}
    ra_mrids_with_net_volume: set[str] = set()
    for bid_mrid in (str(b) for b in getattr(milp_model, "bid_ids", [])):
        bid = bid_by_mrid.get(bid_mrid)
        if bid is None:
            continue
        net_volume_mw = _cumulative_signed_rd_volume_mw(milp_model, bid_mrid)
        if abs(net_volume_mw) > RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW:
            ra_mrids_with_net_volume.add(str(bid.ra_mrid))

    ra_count_results: Dict[str, Dict[str, object]] = {}
    for tso in all_tsos:
        activated_ra_count = float(sum(
            1 for ra_mrid in ra_mrids_in_model
            if ra_mrid_to_tso.get(ra_mrid) == tso and ra_mrid in ra_mrids_with_net_volume
        ))
        ra_activated_model_binary = sum(
            float(pyo.value(milp_model.ra_activated[ra_mrid]))
            for ra_mrid in ra_mrids_in_model
            if ra_mrid_to_tso.get(ra_mrid) == tso
        )

        limit_per_timestamp = max_ra_count_per_timestamp_tso.get(tso)
        slack_per_timestamp = None
        if tso in timestamp_limit_tsos:
            if hasattr(milp_model, "ra_count_slack_per_timestamp"):
                slack_per_timestamp = float(pyo.value(milp_model.ra_count_slack_per_timestamp[tso]))
            else:
                slack_per_timestamp = 0.0  # hard mode — no slack variable exists, always 0

        ra_count_results[tso] = {
            "activated_ra_count": activated_ra_count,
            "ra_activated_model_binary": ra_activated_model_binary,
            "limit_per_timestamp": limit_per_timestamp,
            "slack_per_timestamp": slack_per_timestamp,
        }

    log.info("RA count results extracted: %d TSO(s)", len(ra_count_results))

    return ra_count_results


def extract_ra_group_results(
    milp_model,
    ra_groups: Optional[dict[str, dict]],
    bid_list: list[PowerBid],
) -> Dict[str, Dict[str, object]]:
    """Per-group total dispatched volume against its limit. Every group of ra_groups gets a
    row (a group without a limit: totals from its bids, max_* blank). {} when ra_groups is
    empty or there is no RD block (header-only CSV still written)."""
    ra_groups = ra_groups or {}
    if not ra_groups or not hasattr(milp_model, "rd_volume_upward"):
        return {}

    try:
        import pyomo.environ as pyo
    except ImportError as exc:
        raise ImportError("pyomo is required to extract RA group results") from exc

    bid_by_mrid: dict[str, PowerBid] = {str(bid.mrid): bid for bid in bid_list}
    model_bid_ids = [str(b) for b in getattr(milp_model, "bid_ids", [])]

    ra_group_results: Dict[str, Dict[str, object]] = {}
    for group_mrid, group_data in ra_groups.items():
        member_ra_mrids = set(group_data.get("ra_mrids", []))
        group_bid_ids = [
            b for b in model_bid_ids
            if b in bid_by_mrid and str(bid_by_mrid[b].ra_mrid) in member_ra_mrids
        ]

        total_upward = sum(
            float(pyo.value(milp_model.rd_cumulative_up_term[b])) if hasattr(milp_model, "rd_cumulative_up_term")
            else float(pyo.value(milp_model.rd_volume_upward[b])) for b in group_bid_ids
        )
        total_downward = sum(
            float(pyo.value(milp_model.rd_cumulative_down_term[b])) if hasattr(milp_model, "rd_cumulative_down_term")
            else float(pyo.value(milp_model.rd_volume_downward[b])) for b in group_bid_ids
        )

        ra_group_results[group_mrid] = {
            "total_volume_upward_mw": total_upward,
            "max_volume_upward_mw": group_data.get("max_regulating_up"),
            "total_volume_downward_mw": total_downward,
            "max_volume_downward_mw": group_data.get("max_regulating_down"),
        }

    log.info("RA group results extracted: %d group(s)", len(ra_group_results))

    return ra_group_results


def extract_hvdc_results(model, penalty_reference_pra: float) -> dict[str, dict[str, object]]:
    """Preventive HVDC rows of a solved (or described) model, {unit RA mRID: row}, against the ORIGINAL
    network: the set point of the operating point the model was built on plus this solve's change is the
    result; the change and the penalty (factor x reference x |change|) are cumulative, as the objective
    charges them. Floats throughout (docs/specs/hvdc_ra_specs.md H10.2). {} for a model without an HVDC block."""
    if not hasattr(model, "hvdc_change"):
        return {}
    import pyomo.environ as pyo

    rows: dict[str, dict[str, object]] = {}
    for unit_mrid in sorted(model.hvdc_unit_ids):
        info = model.hvdc_info[unit_mrid]
        last_change = float(pyo.value(model.hvdc_change[unit_mrid]))
        result = info["p_current_mw"] + last_change
        change = result - info["p_original_mw"]
        rows[unit_mrid] = {
            "unit_mrid": unit_mrid,
            "unit_name": info["name"],
            "ei_mrid": info["ei_mrid"],
            "group_mrid": info["group_mrid"],
            "tso": info["tso"],
            "original_p_mw": float(info["p_original_mw"]),
            "result_p_mw": float(result),
            "change_mw": float(change),
            "last_solve_start_p_mw": float(info["p_current_mw"]),
            "last_solve_change_mw": last_change,
            "pmin_op_mw": info["pmin_op_mw"],
            "pmax_op_mw": info["pmax_op_mw"],
            "penalty_factor": info["penalty_factor"],
            "penalty_reference_eur_per_mw": float(penalty_reference_pra),
            "penalty_cost_eur": info["penalty_factor"] * float(penalty_reference_pra) * abs(change),
        }
    return rows


def extract_curative_hvdc_results(model, penalty_reference_cra: float) -> list[dict[str, object]]:
    """Curative HVDC rows of a solved model, one per (unit, contingency) pair, sorted: the curative change
    (up - down, MW) of the pair, the set point after the preventive actions of the model (the curative change is
    never applied), the unit's maximum over its contingencies and its penalty (factor x reference x maximum, the
    term of the objective). Floats (docs/specs/hvdc_ra_specs.md H10.2). [] for a model without curative HVDC pairs."""
    if not hasattr(model, "hvdc_cur_up"):
        return []
    import pyomo.environ as pyo

    preventive_change: dict[str, float] = {}
    if hasattr(model, "hvdc_change"):
        for unit_mrid in model.hvdc_unit_ids:
            ei = model.hvdc_info[unit_mrid]["ei_mrid"]
            preventive_change[ei] = preventive_change.get(ei, 0.0) + float(pyo.value(model.hvdc_change[unit_mrid]))
    rows = []
    for unit_mrid, contingency_mrid in sorted(model.hvdc_cur_pairs):
        info = model.hvdc_cur_info[unit_mrid]
        up = float(pyo.value(model.hvdc_cur_up[unit_mrid, contingency_mrid]))
        down = float(pyo.value(model.hvdc_cur_down[unit_mrid, contingency_mrid]))
        # the maximum of the unit's actual changes (the model variable is only lower-bounded: free at factor 0)
        maximum = max(
            0.0, *(float(pyo.value(model.hvdc_cur_up[unit_mrid, c])) + float(pyo.value(model.hvdc_cur_down[unit_mrid, c]))
            for u, c in model.hvdc_cur_pairs if u == unit_mrid)
        )
        before = info["p_current_mw"] + preventive_change.get(info["ei_mrid"], 0.0)
        rows.append({
            "unit_mrid": unit_mrid, "unit_name": info["name"], "ei_mrid": info["ei_mrid"], "group_mrid": info["group_mrid"],
            "tso": info["tso"], "contingency_mrid": contingency_mrid,
            "p_after_preventive_mw": before, "curative_change_mw": up - down + 0.0, "p_after_curative_mw": before + up - down,
            "pmin_op_mw": info["pmin_op_mw"], "pmax_op_mw": info["pmax_op_mw"],
            "max_curative_change_mw": maximum, "penalty_factor": info["penalty_factor"],
            "penalty_reference_eur_per_mw": float(penalty_reference_cra),
            "penalty_cost_eur": info["penalty_factor"] * float(penalty_reference_cra) * maximum,
        })
    return rows


def extract_results_summary(
    milp_model,
    objective_value: Optional[float],
    pst_list: Optional[list[PST]] = None,
    penalty_reference_pst_pra: float = 0.0,
    penalty_reference_pst_pra_per_tso: Optional[dict[str, float]] = None,
    rd_results: Optional[Dict[str, Dict[str, object]]] = None,
    curative_rd_results: Optional[list[dict]] = None,
    ac_verification_status: Optional[AcVerificationStatus] = None,
    ac_verification_termination_reason: Optional[str] = None,
    ac_iteration_count: Optional[int] = None,
    max_stale_reused_sensitivity_contingencies: Optional[int] = None,
    completeness_limit_reached: Optional[bool] = None,
    calculation_mode: Optional[str] = None,
    ra_types: Optional[list[str]] = None,
    completeness_iteration_count: Optional[int] = None,
    final_check: Optional[Dict[str, object]] = None,
) -> Dict[str, object]:
    """Combined PST + RD summary metrics. Every metric is always present (0.0 for an inactive
    RA type). Cost metrics: preventive PST (penalty_factor x reference x (up + down), from the
    model), curative PST, preventive RD (from rd_results), curative RD (curative_rd_results),
    RA-count penalty, the five slack penalties and the start-up / shut-down / bid activation
    costs (model.objective_penalty_term_expressions);
    objective_unaccounted_eur = objective - all of them (~0 when every term is accounted for).
    Optional rows appended at the end: ac_iteration_count, completeness_iteration_limit_reached,
    ac_verification status/reason, calculation_mode, ra_types ("pst+rd"), completeness_iterations and,
    in ac_single_pass, the final-check overload metrics (final_check, see single_pass.py).
    objective_value None: objective and unaccounted cost are blank.
    """
    rd_results = rd_results or {}

    sum_rd_volume_upward_mw = sum(max(r["rd_volume_net_mw"], 0.0) for r in rd_results.values())
    sum_rd_volume_downward_mw = sum(max(-r["rd_volume_net_mw"], 0.0) for r in rd_results.values())
    sum_rd_cost_eur = sum(r["rd_cost_eur"] for r in rd_results.values())
    sum_rd_penalty_cost_eur = sum(r["penalty_cost_eur"] for r in rd_results.values())

    sum_pst_penalty_cost_eur = 0.0
    if hasattr(milp_model, "tap_change_upward") and pst_list:
        try:
            import pyomo.environ as pyo
        except ImportError as exc:
            raise ImportError("pyomo is required to extract PST results") from exc

        penalty_reference_pst_pra_per_tso = penalty_reference_pst_pra_per_tso or {}
        counted_pst_mrids: set[str] = set()
        for pst in pst_list:
            if pst.kind != RAKind.PREVENTIVE:
                # a transformer with a preventive and a curative RA is two PST objects with
                # one mrid: only the preventive object is costed
                continue
            pst_mrid = str(pst.mrid)
            if pst_mrid not in getattr(milp_model, "pst_ids", []):
                continue
            if pst_mrid in counted_pst_mrids:
                continue  # two preventive RAs on one transformer: one variable pair, costed once
            counted_pst_mrids.add(pst_mrid)
            # cumulative against the ORIGINAL network, as the objective prices it
            tap_up = float(pyo.value(milp_model.cum_tap_up_term[pst_mrid]))
            tap_down = float(pyo.value(milp_model.cum_tap_down_term[pst_mrid]))
            effective_penalty_reference_pst_pra = float(
                penalty_reference_pst_pra_per_tso.get(pst.tso, penalty_reference_pst_pra)
            )
            sum_pst_penalty_cost_eur += (
                float(pst.penalty_factor) * effective_penalty_reference_pst_pra * (tap_up + tap_down)
            )

    remaining_overload_count = 0
    if hasattr(milp_model, "overload_slack_n0"):
        try:
            import pyomo.environ as pyo
        except ImportError as exc:
            raise ImportError("pyomo is required to extract overload results") from exc
        # overload_slack_n0 exists for the secured branches only (scanned ones have their own slack)
        remaining_overload_count = sum(
            1 for branch_mrid in milp_model.secured_branch_ids
            if float(pyo.value(milp_model.overload_slack_n0[branch_mrid])) > _ZERO_SLACK_AMPERE
        )

    # curative PST penalty (0.0 when none), appended after the existing metrics
    sum_curative_pst_penalty_cost_eur = sum(
        float(r["curative_penalty_cost_eur"])
        for r in extract_curative_pst_results(
            milp_model, pst_list, penalty_reference_pst_pra, penalty_reference_pst_pra_per_tso,
        ).values()
    )

    sum_curative_rd_cost_eur = sum(float(r["curative_cost_eur"]) for r in (curative_rd_results or []))

    penalty_term_values: Dict[str, float] = {}
    if getattr(milp_model, "objective_penalty_term_expressions", None):
        try:
            import pyomo.environ as pyo
        except ImportError as exc:
            raise ImportError("pyomo is required to extract penalty terms") from exc
        penalty_term_values = {
            name: float(pyo.value(expression))
            for name, expression in milp_model.objective_penalty_term_expressions.items()
        }
    sum_ra_count_penalty_eur = (
        penalty_term_values.get("ra_count_timestamp", 0.0)
    )
    slack_penalties = {
        "sum_overload_slack_penalty_n0_eur": penalty_term_values.get("overload_n0", 0.0),
        "sum_overload_slack_penalty_n0_scanned_eur": penalty_term_values.get("overload_n0_scanned", 0.0),
        "sum_overload_slack_penalty_nx_patl_eur": penalty_term_values.get("overload_nx_patl", 0.0),
        "sum_overload_slack_penalty_nx_tatl_eur": penalty_term_values.get("overload_nx_tatl", 0.0),
        "sum_overload_slack_penalty_nx_scanned_eur": penalty_term_values.get("overload_nx_scanned", 0.0),
    }
    # start-up, shut-down and bid activation costs (preventive, from their binaries)
    on_off_costs = {
        "sum_startup_cost_eur": penalty_term_values.get("startup_cost", 0.0),
        "sum_shutdown_cost_eur": penalty_term_values.get("shutdown_cost", 0.0),
        "sum_bid_activation_cost_eur": penalty_term_values.get("bid_activation_cost", 0.0),
    }
    # HVDC penalty costs (docs/specs/hvdc_ra_specs.md H7.5): rows only for a run with hvdc in ra_types
    hvdc_costs: Dict[str, float] = {}
    if ra_types is not None and "hvdc" in ra_types:
        pra = penalty_term_values.get("hvdc_pra_penalty_cost", 0.0) + 0.0      # + 0.0: no "-0.0" in the file
        cra = penalty_term_values.get("hvdc_cra_penalty_cost", 0.0) + 0.0
        hvdc_costs = {
            "sum_hvdc_penalty_cost_eur": pra + cra,
            "sum_pra_penalty_cost_hvdc_eur": pra,
            "sum_cra_penalty_cost_hvdc_eur": cra,
        }
    ct_costs: Dict[str, float] = {}
    ct_cost_names = (
        "ct_pra_penalty_cost", "ct_pra_energy_cost", "ct_bid_activation_cost", "ct_cra_penalty_cost", "ct_cra_reservation_cost",
    )
    ct_cost_eur = sum(penalty_term_values.get(name, 0.0) for name in ct_cost_names)
    # countertrade rows (docs/specs/countertrade_ra_specs.md C11.2): only for a run with countertrade in ra_types
    if ra_types is not None and "countertrade" in ra_types:
        ct_bid_ids = getattr(milp_model, "ct_bid_ids", frozenset())
        ct_volume_up = ct_volume_down = 0.0
        if ct_bid_ids and hasattr(milp_model, "rd_cumulative_up_term"):
            import pyomo.environ as pyo
            ct_volume_up = sum(float(pyo.value(milp_model.rd_cumulative_up_term[b])) for b in ct_bid_ids)
            ct_volume_down = sum(float(pyo.value(milp_model.rd_cumulative_down_term[b])) for b in ct_bid_ids)
        ct_costs = {
            "sum_ct_volume_upward_mw": ct_volume_up + 0.0,           # + 0.0: no "-0.0" in the file
            "sum_ct_volume_downward_mw": ct_volume_down + 0.0,
            "sum_pra_penalty_cost_ct_eur": penalty_term_values.get("ct_pra_penalty_cost", 0.0) + 0.0,
            "sum_cra_penalty_cost_ct_eur": penalty_term_values.get("ct_cra_penalty_cost", 0.0) + 0.0,
            "sum_cra_reservation_cost_ct_eur": penalty_term_values.get("ct_cra_reservation_cost", 0.0) + 0.0,
            "sum_ct_cost_eur": ct_cost_eur + 0.0,
        }
    # sum_rd_penalty_cost_eur is a PART of sum_rd_cost_eur (penalty + price) and
    # is deliberately not added a second time; sum_hvdc_penalty_cost_eur is the total of the two HVDC rows.
    accounted_cost_eur = (
        sum_pst_penalty_cost_eur + sum_curative_pst_penalty_cost_eur + sum_rd_cost_eur
        + sum_curative_rd_cost_eur + sum_ra_count_penalty_eur + sum(slack_penalties.values())
        + sum(on_off_costs.values()) + hvdc_costs.get("sum_hvdc_penalty_cost_eur", 0.0) + ct_cost_eur
    )

    summary = {
        "sum_rd_volume_upward_mw": sum_rd_volume_upward_mw,
        "sum_rd_volume_downward_mw": sum_rd_volume_downward_mw,
        "sum_rd_cost_eur": sum_rd_cost_eur,
        "sum_rd_penalty_cost_eur": sum_rd_penalty_cost_eur,
        "sum_pst_penalty_cost_eur": sum_pst_penalty_cost_eur,
        "objective_value": "" if objective_value is None else float(objective_value),
        "remaining_overload_count": remaining_overload_count,
        "sum_curative_pst_penalty_cost_eur": sum_curative_pst_penalty_cost_eur,
        "sum_curative_rd_cost_eur": sum_curative_rd_cost_eur,
        "sum_ra_count_penalty_eur": sum_ra_count_penalty_eur,
        **slack_penalties,
        **on_off_costs,
        **hvdc_costs,
        **ct_costs,
        "objective_unaccounted_eur": "" if objective_value is None else float(objective_value) - accounted_cost_eur,
    }
    if ac_verification_status is not None:
        summary["ac_verification_status"] = ac_verification_status.value
        summary["ac_verification_termination_reason"] = ac_verification_termination_reason or ""
    if ac_iteration_count is not None:
        summary["ac_iteration_count"] = int(ac_iteration_count)
    if max_stale_reused_sensitivity_contingencies is not None:
        # the largest number of contingencies, in any one solve, whose MILP sensitivities were the
        # last valid ones instead of the (invalid) fresh ones
        summary["max_stale_reused_sensitivity_contingencies"] = int(max_stale_reused_sensitivity_contingencies)
    if completeness_limit_reached is not None:
        summary["completeness_iteration_limit_reached"] = bool(completeness_limit_reached)
    if completeness_iteration_count is not None:
        summary["completeness_iterations"] = int(completeness_iteration_count)
    if calculation_mode is not None:
        summary["calculation_mode"] = calculation_mode
    if ra_types is not None:
        summary["ra_types"] = "+".join(ra_types)
    if final_check:
        summary.update(final_check)

    return summary


# ---------------------------------------------------------------------------
# lf_post_n0.csv (one block per AC iteration)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Completeness loop
# ---------------------------------------------------------------------------

