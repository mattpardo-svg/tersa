"""nx_results_export.py

N-X result files from the final model: the N-X loadings (loadings_nx.csv), the contingency status and the
scanned elements. The linearised post-PRA / post-PRA+CRA loadings use the
model's variables and the N-X sensitivities with the same formula as the N-X constraints; the
actual post-PRA loading comes from the N-X load flow of the final applied state when given.
Corridor (PowerTransferCorridor) results are not built: no corridor data is parsed.
"""

import csv
import logging
from pathlib import Path
from typing import Optional

from data_model import AssessedElement, Contingency, select_by_side
from milp import nx_constraint_filter
from pre_milp import ct_sensitivity
from text_encoding import TEXT_ENCODING

log = logging.getLogger(__name__)


class _SolvedValues:
    """The solved values of the final model that the linearised effect reads, each evaluated once on first use
    (a Pyomo evaluation per branch and contingency row is the slow part of the export). The model is not changed
    while an export runs. Same arithmetic as reading the variables in the formula: up - down for a tap change, the
    value of the unit's net injection expression."""

    def __init__(self, model):
        self._model = model
        self._tap_change: dict[str, float] = {}
        self._rd_net_injection: dict[tuple[str, bool], float] = {}
        self._bid_volume: dict[str, float] = {}

    def bid_volume(self, bid_mrid: str) -> float:
        """up - down of a preventive bid of this solve."""
        if bid_mrid not in self._bid_volume:
            import pyomo.environ as pyo
            self._bid_volume[bid_mrid] = (
                pyo.value(self._model.rd_volume_upward[bid_mrid]) - pyo.value(self._model.rd_volume_downward[bid_mrid])
            )
        return self._bid_volume[bid_mrid]

    def tap_change(self, pst_mrid: str) -> float:
        if pst_mrid not in self._tap_change:
            import pyomo.environ as pyo
            self._tap_change[pst_mrid] = (
                pyo.value(self._model.tap_change_upward[pst_mrid]) - pyo.value(self._model.tap_change_downward[pst_mrid])
            )
        return self._tap_change[pst_mrid]

    def rd_net_injection(self, gu_mrid: str, rd_only: bool = False) -> float:
        """The unit's net injection; rd_only: its RD part, without the countertrade volumes."""
        if (gu_mrid, rd_only) not in self._rd_net_injection:
            import pyomo.environ as pyo
            expression = self._model.rd_only_net_injection_g if rd_only else self._model.rd_net_injection_g
            self._rd_net_injection[(gu_mrid, rd_only)] = pyo.value(expression[gu_mrid])
        return self._rd_net_injection[(gu_mrid, rd_only)]


def _linearised_pst_rd_effect(
    model,
    branch_mrid: str,
    contingency_mrid: str,
    sensitivity_pst_nx: dict,
    sensitivity_rd_nx: dict,
    pst_degrees_per_tap: dict,
    include_curative: bool,
    solved: Optional["_SolvedValues"] = None,
) -> float:
    """Evaluate the SAME linear PST+RD effect formula the N-X PATL/TATL
    constraints use (see milp_builder._nx_pst_and_rd_effect), reading
    SOLVED variable values from the final model — used to derive
    loading_pct_nx_post_pra (include_curative=False) and
    loading_pct_nx_post_pra_cra (include_curative=True).
    solved: the solved values read once per export (_SolvedValues); None reads them from the model each time.
    """
    solved = solved if solved is not None else _SolvedValues(model)

    sensitivity_for_pst = sensitivity_pst_nx.get(contingency_mrid, {})
    sensitivity_for_rd = sensitivity_rd_nx.get(contingency_mrid, {})

    effect = 0.0
    if hasattr(model, "tap_change_upward"):
        for pst_mrid in model.pst_ids:
            if pst_mrid not in pst_degrees_per_tap:
                continue
            sensitivity = float(sensitivity_for_pst.get((branch_mrid, pst_mrid), 0.0))
            if sensitivity == 0.0:
                continue
            effect += sensitivity * float(pst_degrees_per_tap[pst_mrid]) * solved.tap_change(pst_mrid)

    # curative terms from the builder's own evaluator (model.nx_curative_effect_ampere), so the
    # export applies the constraints' pair gating (curative magnitude triples, xne linkage)
    if include_curative and hasattr(model, "nx_curative_effect_ampere"):
        effect += model.nx_curative_effect_ampere(branch_mrid, contingency_mrid)

    if hasattr(model, "nx_hvdc_preventive_effect_ampere"):
        effect += model.nx_hvdc_preventive_effect_ampere(branch_mrid, contingency_mrid)

    if hasattr(model, "rd_net_injection_g"):
        # with countertrade bids: the RD part of the unit totals through the units, the CT volumes through the
        # sensitivity of their RA and direction (the same split as the constraints)
        ct_bid_ids = getattr(model, "ct_bid_ids", frozenset())
        for gu_mrid in (model.rd_effect_unit_ids if ct_bid_ids else model.gu_ids):
            sensitivity = float(sensitivity_for_rd.get((branch_mrid, gu_mrid), 0.0))
            if sensitivity == 0.0:
                continue
            effect += sensitivity * solved.rd_net_injection(gu_mrid, rd_only=bool(ct_bid_ids))
        for bid_mrid in sorted(ct_bid_ids):
            variable_id, weights = model.ct_bid_variable[bid_mrid]
            coefficient = ct_sensitivity.coefficient(sensitivity_for_rd, branch_mrid, variable_id, weights)
            if coefficient != 0.0:
                effect += coefficient * solved.bid_volume(bid_mrid)

    return effect


def nx_loading_pairs(
    model,
    records: dict[str, dict],
    lf_nx_initial: dict[str, dict[str, dict[int, float]]],
    sensitivity_pst_nx: dict,
    sensitivity_rd_nx: dict,
    pst_degrees_per_tap: dict[str, float],
    tatl_data: Optional[dict],
    lf_nx_final: Optional[dict[str, dict[str, dict[int, float]]]] = None,
) -> list[dict]:
    """Every (monitored branch side, contingency) pair of the original N-X load flow with its currents (A): initial =
    after the contingency before any RA; after_pra_cra = the actual flow at the final state (lf_nx_final, else the
    model's prediction) plus the effect of the curative actions of the contingency (never applied to the network).
    The same arithmetic as the old N-X loadings and scanned-element files. limit_a: PATL, for a scanned element the
    limit of the pair (max of PATL and its flow after the contingency). `records`: monitored_branches()."""
    from data_model import AEType
    build_baseline = getattr(model, "nx_build_baseline", None)
    model_lf_nx = build_baseline["lf_nx"] if build_baseline else lf_nx_initial
    model_sensitivity_pst_nx = build_baseline["sensitivity_pst_nx"] if build_baseline else sensitivity_pst_nx
    model_sensitivity_rd_nx = build_baseline["sensitivity_rd_nx"] if build_baseline else sensitivity_rd_nx
    pair_limits = getattr(model, "nx_scanned_pair_limit_ampere", {})
    solved = _SolvedValues(model)
    pairs: list[dict] = []
    for contingency_mrid in sorted(lf_nx_initial):
        for branch_mrid in sorted(lf_nx_initial[contingency_mrid]):
            record = records.get(branch_mrid)
            if record is None:
                continue
            side = record["side"]
            initial = select_by_side(lf_nx_initial[contingency_mrid][branch_mrid], side, branch_mrid)
            if initial is None:
                continue
            scanned = record["ae_type"] == AEType.SCANNED
            limit_a = float(pair_limits.get((branch_mrid, contingency_mrid), record["limit_a"])) if scanned else record["patl_a"]
            if limit_a <= 0.0:
                continue
            args = (model, branch_mrid, contingency_mrid, model_sensitivity_pst_nx, model_sensitivity_rd_nx, pst_degrees_per_tap)
            preventive_effect = _linearised_pst_rd_effect(*args, include_curative=False, solved=solved)
            full_effect = _linearised_pst_rd_effect(*args, include_curative=True, solved=solved)
            baseline = select_by_side(model_lf_nx.get(contingency_mrid, {}).get(branch_mrid, {}), side, branch_mrid)
            baseline = initial if baseline is None else baseline
            actual = None
            if lf_nx_final is not None:
                actual = select_by_side(lf_nx_final.get(contingency_mrid, {}).get(branch_mrid, {}), side, branch_mrid)
            after = actual + (full_effect - preventive_effect) if actual is not None else baseline + full_effect
            after_preventive = actual if actual is not None else baseline + preventive_effect
            tatl = (tatl_data or {}).get(branch_mrid) if not scanned else None
            pairs.append({
                "tso": record["element"].tso, "branch_id": branch_mrid, "side": side, "contingency_id": contingency_mrid,
                "limit_a": limit_a, "tatl_a": None if tatl is None else float(tatl["tatl_limit_ampere"]),
                "current_initial_a": float(initial), "current_after_pra_cra_a": float(after), "current_after_pra_a": float(after_preventive),
                "loading_initial_pct": float(initial) / limit_a * 100.0, "loading_after_pra_cra_pct": float(after) / limit_a * 100.0,
                "scanned": scanned,
            })
    return pairs


