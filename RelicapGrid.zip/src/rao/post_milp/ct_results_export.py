"""ct_results_export.py - the countertrade results of the solved model (docs/specs/countertrade_ra_specs.md C11):
the rows of the preventive and curative CT bids, the curative availability per RA and branch, the net positions per bidding
zone and the units at their limits. The files are written by run_outputs.py (ct_results.csv, zone_net_positions.csv)."""

from __future__ import annotations

import logging
from typing import Optional

from data_model import BidDirection, CtRa, PowerBid
from milp.milp_builder import _participation_of_bid, curative_rd_reservation_price_eur_mw
from post_milp.n0_results_export import _cumulative_signed_rd_volume_mw
from pre_milp import log_summary
from pre_milp.cra_preprocessing import branch_tatl_duration_seconds, rd_cra_is_available
from pre_milp.ct_units import CtZone

log = logging.getLogger(__name__)

# a volume below this (MW) is reported as 0 (no "-0.0" and no solver noise in the files)
_ZERO_MW = 1e-9
UNASSIGNED_ZONE_NAME = "(no bidding zone)"


def _clean(value: float) -> float:
    return 0.0 if abs(value) < _ZERO_MW else float(value)


# ---------------------------------------------------------------------------
# preventive and curative bids
# ---------------------------------------------------------------------------

def extract_ct_results(model, ct_ras: list[CtRa], ct_bids: list[PowerBid], penalty_reference_pra: float) -> list[dict]:
    """One row per preventive CT bid of the solved model (model.ct_bid_ids ∩ model.bid_ids), in the order of
    the bid mRIDs: volume_mw (against the ORIGINAL network, a magnitude: each bid has one direction),
    price_cost_eur = price x volume, penalty_cost_eur = penalty factor x PRA reference x volume,
    activation_cost_eur = the activation cost when the bid is used. [] without CT bids."""
    ct_bid_ids = getattr(model, "ct_bid_ids", frozenset())
    if not ct_bid_ids or not hasattr(model, "bid_ids"):
        return []
    import pyomo.environ as pyo

    ra_by_mrid = {ra.mrid: ra for ra in ct_ras}
    bid_by_mrid = {str(bid.mrid): bid for bid in ct_bids}
    activation_ids = set(getattr(model, "rd_activation_bid_ids", []))
    rows = []
    missing = []
    for bid_mrid in sorted(str(b) for b in model.bid_ids if str(b) in ct_bid_ids):
        bid = bid_by_mrid.get(bid_mrid)
        ra = ra_by_mrid.get(str(bid.ra_mrid)) if bid is not None else None
        if bid is None or ra is None:
            missing.append(bid_mrid)
            continue
        volume = _clean(abs(_cumulative_signed_rd_volume_mw(model, bid_mrid)))
        activation = 0.0
        if bid_mrid in activation_ids and float(pyo.value(model.rd_bid_activated[bid_mrid])) > 0.5:
            activation = float(bid.activation_cost_eur or 0.0)
        rows.append({
            "ra_mrid": ra.mrid, "bid_mrid": bid_mrid, "tso": ra.tso, "zone_mrid": ra.zone_mrid, "zone_name": ra.zone_name,
            "direction": bid.direction.value, "volume_mw": volume, "price_eur_mw": float(bid.price_eur_mw),
            "price_cost_eur": float(bid.price_eur_mw) * volume, "penalty_factor": float(ra.penalty_factor),
            "penalty_cost_eur": float(ra.penalty_factor) * float(penalty_reference_pra) * volume,
            "activation_cost_eur": activation,
        })
    if missing:
        log_summary.warn_ids(log, "The MILP model references %d countertrade bid(s) not found in the countertrade RAs - skipped", missing)
    return rows


def extract_curative_ct_results(
    model, ct_ras: list[CtRa], ct_bids: list[PowerBid], penalty_reference_cra: float,
) -> list[dict]:
    """One row per (curative CT bid, contingency) pair of the solved model. curative_volume_mw: the variable of
    the bid's own direction; max_curative_volume_mw: its maximum over the contingencies. penalty_cost_eur
    (penalty factor x CRA reference x the maximum) and reservation_cost_eur (reservation price x the maximum;
    reservePrice, else the energy price) are per bid and repeated on its rows; the cost terms of the objective
    are these once per bid. [] without curative CT bids."""
    ct_curative = getattr(model, "ct_curative_bid_ids", frozenset())
    if not ct_curative or not hasattr(model, "curative_bid_contingency_pairs"):
        return []
    import pyomo.environ as pyo

    ra_by_mrid = {ra.mrid: ra for ra in ct_ras}
    bid_by_mrid = {str(bid.mrid): bid for bid in ct_bids}
    rows = []
    missing = []
    for bid_mrid, co_mrid in sorted(model.curative_bid_contingency_pairs):
        if str(bid_mrid) not in ct_curative:
            continue
        bid = bid_by_mrid.get(str(bid_mrid))
        ra = ra_by_mrid.get(str(bid.ra_mrid)) if bid is not None else None
        if bid is None or ra is None:
            if str(bid_mrid) not in missing:
                missing.append(str(bid_mrid))
            continue
        is_up = bid.direction == BidDirection.UP
        volume_var = model.curative_rd_volume_upward if is_up else model.curative_rd_volume_downward
        max_total = float(pyo.value(model.max_curative_rd_volume_upward[bid_mrid])) + float(
            pyo.value(model.max_curative_rd_volume_downward[bid_mrid])
        )
        reservation_price = curative_rd_reservation_price_eur_mw(bid)
        rows.append({
            "ra_mrid": ra.mrid, "bid_mrid": str(bid_mrid), "tso": ra.tso, "zone_mrid": ra.zone_mrid, "zone_name": ra.zone_name,
            "contingency_mrid": str(co_mrid), "direction": bid.direction.value,
            "curative_volume_mw": _clean(float(pyo.value(volume_var[bid_mrid, co_mrid]))),
            "max_curative_volume_mw": _clean(max_total), "price_eur_mw": float(bid.price_eur_mw),
            "reservation_price_eur_mw": reservation_price, "penalty_factor": float(ra.penalty_factor),
            "penalty_cost_eur": float(ra.penalty_factor) * float(penalty_reference_cra) * max_total,
            "reservation_cost_eur": reservation_price * max_total,
        })
    if missing:
        log_summary.warn_ids(log, "The MILP model references %d curative countertrade bid(s) not found - skipped", missing)
    return rows


# ---------------------------------------------------------------------------
# weights and availability
# ---------------------------------------------------------------------------

REASON_REACTION_TIME = "reaction time above the TATL duration of the branch"


def compute_ct_cra_availability(
    ct_ras: list[CtRa], tatl_data: dict, branch_mrids: list[str], fallback_duration_seconds: float,
) -> list[dict]:
    """One row per available curative CT RA and branch: the reaction time against the TATL duration of the branch
    (the rule and the duration of the RD availability file, R9) and, when the RA cannot act there, the reason."""
    rows = []
    for ra in sorted(ct_ras, key=lambda r: r.mrid):
        if not (ra.available and ra.kind.value == "curative"):
            continue
        for branch_mrid in sorted(set(branch_mrids)):
            duration = branch_tatl_duration_seconds(branch_mrid, tatl_data, fallback_duration_seconds)
            available = rd_cra_is_available(ra.reaction_time_minutes, duration)
            rows.append({
                "ra_mrid": ra.mrid, "tso": ra.tso, "zone_mrid": ra.zone_mrid, "zone_name": ra.zone_name,
                "branch_mrid": branch_mrid,
                "reaction_time_minutes": "" if ra.reaction_time_minutes is None else ra.reaction_time_minutes,
                "tatl_duration_seconds": duration, "available": available, "reason": "" if available else REASON_REACTION_TIME,
            })
    return rows


# ---------------------------------------------------------------------------
# net positions
# ---------------------------------------------------------------------------

def extract_net_positions(
    model, rd_inputs, zone_of_unit: dict[str, str], zones: dict[str, CtZone], tso_of_zone: dict[str, str],
) -> list[dict]:
    """Per bidding zone the change of net injection (MW, against the ORIGINAL network, generation sign) of the
    units of the zone: rd_change_mw from the RD bids, ct_change_mw from the CT bids, total_change_mw their
    sum. Units outside every zone are one extra row (UNASSIGNED_ZONE_NAME). Every zone of a CT RA is listed;
    the sum of total_change_mw over the rows is 0 (the balance)."""
    ct_bid_ids = getattr(model, "ct_bid_ids", frozenset())
    rd_change: dict[str, float] = {}
    ct_change: dict[str, float] = {}
    model_bid_ids = {str(b) for b in getattr(model, "bid_ids", [])}
    for bid in rd_inputs.bid_list:
        bid_mrid = str(bid.mrid)
        if bid_mrid not in model_bid_ids:
            continue
        signed = _cumulative_signed_rd_volume_mw(model, bid_mrid)
        target = ct_change if bid_mrid in ct_bid_ids else rd_change
        for gu_mrid, factor in _participation_of_bid(rd_inputs, bid).items():
            zone = zone_of_unit.get(gu_mrid, "")
            target[zone] = target.get(zone, 0.0) + float(factor) * signed
    zones_of_ct_ras = {zone_of_unit[rd.gu_mrid] for rd in rd_inputs.rd_list if rd.countertrade and rd.gu_mrid in zone_of_unit}
    rows = []
    for zone_mrid in sorted(set(rd_change) | set(ct_change) | zones_of_ct_ras, key=lambda z: (z == "", zones[z].name if z in zones else z)):
        rd, ct = _clean(rd_change.get(zone_mrid, 0.0)), _clean(ct_change.get(zone_mrid, 0.0))
        rows.append({
            "zone_mrid": zone_mrid, "zone_name": zones[zone_mrid].name if zone_mrid in zones else UNASSIGNED_ZONE_NAME,
            "tso": tso_of_zone.get(zone_mrid, ""), "rd_change_mw": rd, "ct_change_mw": ct, "total_change_mw": _clean(rd + ct),
        })
    return rows



# ---------------------------------------------------------------------------
# units at their limits
# ---------------------------------------------------------------------------

LIMIT_TOLERANCE_MW = 1e-6


def log_units_at_limits(model, rd_inputs) -> list[tuple[str, str]]:
    """C5.2: one log line for every unit of a model with countertrade bids whose final combined dispatch (the original
    set point plus the cumulative RD and CT movement of every bid, against the original network) reaches Pmax or
    Pmin; a unit that has not moved is not logged. Returns [(unit, "Pmax" | "Pmin")]."""
    ct_bid_ids = getattr(model, "ct_bid_ids", frozenset())
    if not ct_bid_ids or not hasattr(model, "rd_net_injection_g") or not hasattr(model, "rd_unit_status"):
        return []

    bid_by_mrid = {str(bid.mrid): bid for bid in rd_inputs.bid_list}
    movement: dict[str, float] = {}
    for bid_mrid in (str(b) for b in model.bid_ids):
        signed = _cumulative_signed_rd_volume_mw(model, bid_mrid)
        for gu_mrid, factor in _participation_of_bid(rd_inputs, bid_by_mrid[bid_mrid]).items():
            movement[gu_mrid] = movement.get(gu_mrid, 0.0) + float(factor) * signed
    hits = []
    for gu_mrid in sorted(str(g) for g in model.gu_ids):
        status = model.rd_unit_status.get(gu_mrid)
        if status is None:
            continue
        total = float(model.rd_original_target_p_mw[gu_mrid]) + movement.get(gu_mrid, 0.0)
        moved = abs(movement.get(gu_mrid, 0.0)) > LIMIT_TOLERANCE_MW
        if moved and total >= status.pmax_mw - LIMIT_TOLERANCE_MW:
            hits.append((gu_mrid, "Pmax"))
            log.info("generating unit %s reaches Pmax %.3f MW (dispatch %.3f MW, redispatch and countertrade together)",
                     gu_mrid, status.pmax_mw, total)
        elif moved and total <= status.pmin_mw + LIMIT_TOLERANCE_MW:
            hits.append((gu_mrid, "Pmin"))
            log.info("generating unit %s reaches Pmin %.3f MW (dispatch %.3f MW, redispatch and countertrade together)",
                     gu_mrid, status.pmin_mw, total)
    return hits
