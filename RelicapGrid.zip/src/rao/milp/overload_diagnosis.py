"""
overload_diagnosis.py - after the final check, one INFO block per overloaded N-X (branch, contingency) pair: the limit,
the AC current, the overload and what the preventive PSTs could do about it. Log only; no result file changes.
"""

import logging

log = logging.getLogger(__name__)

MAX_PAIRS_AT_INFO = 20
_KIND_LABEL = {"nx_patl": "N-X PATL", "nx_tatl": "N-X TATL", "nx_scanned": "N-X scanned"}


def _applied_tap_change(model, pst_mrid: str) -> float:
    """Up - down of the solved model (0 where the variables have no value)."""
    import pyomo.environ as pyo
    up = pyo.value(model.tap_change_upward[pst_mrid], exception=False)
    down = pyo.value(model.tap_change_downward[pst_mrid], exception=False)
    return float(up or 0.0) - float(down or 0.0)


def _pst_effects(model, branch_mrid: str, contingency_mrid: str) -> tuple[float, float]:
    """(largest |A per tap| of one PST, best possible relief in A over all preventive PSTs within their tap ranges
    from the applied taps) on the pair, from the sensitivities the model was built on."""
    baseline = getattr(model, "nx_build_baseline", None) or {}
    sensitivities = (baseline.get("sensitivity_pst_nx") or {}).get(contingency_mrid, {})
    degrees = getattr(model, "pst_degrees_per_tap_by_mrid", {})
    largest, relief = 0.0, 0.0
    for pst_mrid, (tap_low, tap_high) in getattr(model, "pst_tap_range_by_mrid", {}).items():
        if pst_mrid not in degrees:
            continue
        per_tap = float(sensitivities.get((branch_mrid, pst_mrid), 0.0)) * degrees[pst_mrid]
        current_tap = model.pst_start_tap_by_mrid[pst_mrid] + _applied_tap_change(model, pst_mrid)
        largest = max(largest, abs(per_tap))
        # the flow changes by per_tap x (move); the relief is the largest decrease the range allows
        relief += max(-per_tap * (tap_low - current_tap), -per_tap * (tap_high - current_tap), 0.0)
    return largest, relief


def _value(variable) -> float:
    import pyomo.environ as pyo
    return float(pyo.value(variable, exception=False) or 0.0)


def _bid_room(model, bid_mrid: str, participation: dict) -> tuple[float, float]:
    """(MW the bid can still move up, MW it can still move down) from the applied volumes: its volume bounds and the
    Pmax / Pmin of the units of its participation (a unit that can be shut down may fall to 0)."""
    net = _value(model.rd_volume_upward[bid_mrid]) - _value(model.rd_volume_downward[bid_mrid])
    up = (model.rd_volume_upward[bid_mrid].ub or 0.0) - net
    down = (model.rd_volume_downward[bid_mrid].ub or 0.0) + net
    status = getattr(model, "rd_unit_status", {})
    for gu_mrid, factor in participation.items():
        if gu_mrid not in status or float(factor) <= 0.0:
            continue
        unit = status[gu_mrid]
        current = unit.original_p_mw + _value(model.rd_net_injection_g[gu_mrid]) if gu_mrid in model.rd_net_injection_g else unit.original_p_mw
        lowest = 0.0 if unit.unit_class == "stoppable" else unit.pmin_mw
        up = min(up, max(unit.pmax_mw - current, 0.0) / float(factor))
        down = min(down, max(current - lowest, 0.0) / float(factor))
    return max(up, 0.0), max(down, 0.0)


def _bid_room_by_cause(model, bid_mrid: str, participation: dict) -> tuple[tuple[float, str], tuple[float, str]]:
    """((MW up, what limits it), (MW down, what limits it)) of a bid: the same room as _bid_room, with the limit named:
    "volume limit", "unit limit", or, where the room is 0, "lead time", "no unit" or "no volume"."""
    net = _value(model.rd_volume_upward[bid_mrid]) - _value(model.rd_volume_downward[bid_mrid])
    volume = ((model.rd_volume_upward[bid_mrid].ub or 0.0) - net, (model.rd_volume_downward[bid_mrid].ub or 0.0) + net)
    status = getattr(model, "rd_unit_status", {})
    unit_up = unit_down = float("inf")
    for gu_mrid, factor in participation.items():
        if gu_mrid not in status or float(factor) <= 0.0:
            continue
        unit = status[gu_mrid]
        current = unit.original_p_mw + _value(model.rd_net_injection_g[gu_mrid]) if gu_mrid in model.rd_net_injection_g else unit.original_p_mw
        lowest = 0.0 if unit.unit_class == "stoppable" else unit.pmin_mw
        unit_up = min(unit_up, max(unit.pmax_mw - current, 0.0) / float(factor))
        unit_down = min(unit_down, max(current - lowest, 0.0) / float(factor))
    blocked = bid_mrid in getattr(model, "rd_lead_time_blocked_bid_ids", ())
    result = []
    for volume_room, unit_room in ((volume[0], unit_up), (volume[1], unit_down)):
        room = max(min(volume_room, unit_room), 0.0)
        if room > 0.0:
            result.append((room, "unit limit" if unit_room < volume_room else "volume limit"))
        elif blocked:
            result.append((0.0, "lead time"))
        elif not participation:
            result.append((0.0, "no unit"))
        else:
            result.append((0.0, "unit limit" if volume_room > 0.0 else "no volume"))
    return result[0], result[1]


_CAUSE_TEXT = {"volume limit": "at their volume limit", "unit limit": "at a unit limit", "lead time": "blocked by the lead time",
               "no unit": "without a unit", "no volume": "with no volume"}


def _within_balance(model, branch_mrid: str, contingency_mrid: str) -> dict:
    """The preventive redispatch and countertrade bids share one balance (sum of all injections = 0). One option per bid
    and side: (A per MW of balance, MW of balance, cause, kind). Returns the best relief with and without the balance,
    the useful room per side and the limit."""
    from pre_milp import ct_sensitivity
    baseline = getattr(model, "nx_build_baseline", None) or {}
    sensitivities = (baseline.get("sensitivity_rd_nx") or {}).get(contingency_mrid, {})
    ct_variable = getattr(model, "ct_bid_variable", {})
    ups: list[tuple[float, float, str, str]] = []
    downs: list[tuple[float, float, str, str]] = []
    for bid_mrid, (direction, participation) in getattr(model, "rd_bid_diagnosis", {}).items():
        counter = bid_mrid in getattr(model, "ct_bid_ids", ())
        if bid_mrid in ct_variable:
            per_mw = ct_sensitivity.coefficient(sensitivities, branch_mrid, ct_variable[bid_mrid][0], ct_variable[bid_mrid][1])
        else:
            per_mw = sum(float(factor) * float(sensitivities.get((branch_mrid, gu), 0.0)) for gu, factor in participation.items())
        weight = sum(float(factor) for factor in participation.values()) or 1.0
        (up_room, up_cause), (down_room, down_cause) = _bid_room_by_cause(model, bid_mrid, participation)
        kind = "countertrade" if counter else "redispatch"
        if getattr(direction, "value", direction) == "up" or str(direction).lower().endswith("up"):
            ups.append((-per_mw / weight, up_room * weight, up_cause, kind))
        else:
            downs.append((per_mw / weight, down_room * weight, down_cause, kind))
    ups.sort(key=lambda option: -option[0])
    downs.sort(key=lambda option: -option[0])
    free = sum(g * mw for g, mw, _, _ in ups + downs if g > 0.0)
    balanced, i, j = 0.0, 0, 0
    up_left = ups[0][1] if ups else 0.0
    down_left = downs[0][1] if downs else 0.0
    while i < len(ups) and j < len(downs) and ups[i][0] + downs[j][0] > 1e-12:
        moved = min(up_left, down_left)
        balanced += moved * (ups[i][0] + downs[j][0])
        up_left -= moved
        down_left -= moved
        if up_left <= 1e-9:
            i += 1
            up_left = ups[i][1] if i < len(ups) else 0.0
        if down_left <= 1e-9:
            j += 1
            down_left = downs[j][1] if j < len(downs) else 0.0
    return {"free": free, "balanced": balanced, "ups": ups, "downs": downs}


def _side_text(options: list) -> str:
    """"500.0 MW (1 redispatch bid(s) at their volume limit; ...)" of the helpful options of one side."""
    helpful = [option for option in options if option[0] > 0.0]
    counts: dict[tuple[str, str], int] = {}
    for _, _, cause, kind in helpful:
        counts[(kind, cause)] = counts.get((kind, cause), 0) + 1
    text = "; ".join(f"{n} {kind} bid(s) {_CAUSE_TEXT[cause]}" for (kind, cause), n in sorted(counts.items()))
    return f"{sum(mw for _, mw, _, _ in helpful):.1f} MW" + (f" ({text})" if text else " (no helpful bid)")


def _balance_line(model, branch_mrid: str, contingency_mrid: str) -> str:
    """The best relief of the preventive redispatch and countertrade bids together within the shared balance, and the limit
    that binds: the balance (one side has less useful room than the other), else the bid volume or a unit limit."""
    result = _within_balance(model, branch_mrid, contingency_mrid)
    free, balanced = result["free"], result["balanced"]
    up_text, down_text = _side_text(result["ups"]), _side_text(result["downs"])
    if balanced < free - 1e-6:
        limit = "balance"
    else:
        used = [option for option in result["ups"] + result["downs"] if option[0] > 0.0 and option[1] > 0.0]
        by_cause: dict[str, float] = {}
        for _, mw, cause, _ in used:
            by_cause[cause] = by_cause.get(cause, 0.0) + mw
        limit = max(by_cause, key=lambda name: by_cause[name]) if by_cause else "no helpful bid"
        limit = "bid volume" if limit == "volume limit" else limit
    return (f"  preventive redispatch + countertrade within the shared balance (the injections of all of them sum to 0): "
            f"best possible relief {balanced:.1f} A (without the balance {free:.1f} A); binding limit: {limit}; "
            f"useful room: up {up_text}, down {down_text}")


def _bid_effects(model, branch_mrid: str, contingency_mrid: str, countertrade: bool) -> tuple[float, float]:
    """(largest |A per 100 MW| of one preventive bid, best possible relief in A over all of them within their volumes and
    unit limits) on the pair, redispatch bids or countertrade bids; an upper bound (the balance between bids is not
    modelled). A per MW of a bid: the weighted sum of the unit sensitivities (the variable of the RA for countertrade)."""
    from pre_milp import ct_sensitivity
    baseline = getattr(model, "nx_build_baseline", None) or {}
    sensitivities = (baseline.get("sensitivity_rd_nx") or {}).get(contingency_mrid, {})
    ct_variable = getattr(model, "ct_bid_variable", {})
    largest = relief = 0.0
    for bid_mrid, (direction, participation) in getattr(model, "rd_bid_diagnosis", {}).items():
        if (bid_mrid in getattr(model, "ct_bid_ids", ())) != countertrade:
            continue
        if bid_mrid in ct_variable:
            per_mw = ct_sensitivity.coefficient(sensitivities, branch_mrid, ct_variable[bid_mrid][0], ct_variable[bid_mrid][1])
        else:
            per_mw = sum(float(factor) * float(sensitivities.get((branch_mrid, gu), 0.0)) for gu, factor in participation.items())
        largest = max(largest, abs(per_mw) * 100.0)
        up, down = _bid_room(model, bid_mrid, participation)
        relief += max(-per_mw * up, per_mw * down, 0.0)
    return largest, relief


def _block(model, key: tuple, detail: dict) -> str:
    kind, branch_mrid, contingency_mrid = key
    largest, relief = _pst_effects(model, branch_mrid, contingency_mrid)
    pruned = bool(getattr(model, "nx_pst_sensitivity_pruned", False))
    before = lambda value: "pruned" if pruned else f"{value:.1f} A"      # noqa: E731 (the raw table is gone once pruned)
    effect = float(detail.get("curative_effect", 0.0))
    lines = [
        f"overload diagnosis {_KIND_LABEL[kind]}: branch {branch_mrid}, contingency {contingency_mrid}: "
        f"limit {detail['limit']:.1f} A, AC current {detail['current']:.1f} A, overload {detail['overload']:.1f} A"
        + (f" (with the curative effect {effect:.1f} A)" if effect else ""),
        f"  preventive PSTs: largest effect per tap {largest:.1f} A (before the threshold {before(largest)}), "
        f"best possible relief {relief:.1f} A (before the threshold {before(relief)})",
    ]
    if relief < detail["overload"]:
        lines.append(f"  no PST can relieve this overload by more than {relief:.1f} A")
    reliefs = {"PST": relief}
    rd_pruned = bool(getattr(model, "nx_rd_sensitivity_pruned", False))
    rd_before = lambda value: "pruned" if rd_pruned else f"{value:.1f} A"        # noqa: E731
    for label, countertrade in (("redispatch", False), ("countertrade", True)):
        if not hasattr(model, "rd_bid_diagnosis"):
            break
        largest_per_100, bid_relief = _bid_effects(model, branch_mrid, contingency_mrid, countertrade)
        reliefs[label] = bid_relief
        lines.append(
            f"  preventive {label}: largest effect per 100 MW {largest_per_100:.1f} A (before the threshold "
            f"{rd_before(largest_per_100)}), best possible relief {bid_relief:.1f} A (before the threshold {rd_before(bid_relief)})")
    if hasattr(model, "rd_bid_diagnosis") and getattr(model, "rd_bid_diagnosis"):
        lines.append(_balance_line(model, branch_mrid, contingency_mrid))
    best = max(reliefs, key=lambda name: reliefs[name])                       # the first of equal reliefs (PST first)
    lines.append(
        f"  best RA type: {best}, relief {reliefs[best]:.1f} A" if reliefs[best] > 0.0
        else "  best RA type: none, no preventive RA type can relieve this pair")
    return "\n".join(lines)


def log_overload_diagnosis(model, details: dict, max_pairs_at_info: int = MAX_PAIRS_AT_INFO) -> None:
    """details: {(kind, branch, contingency): {"limit", "current", "curative_effect", "overload"}} of the overloaded N-X
    pairs. The largest overloads first; the first max_pairs_at_info at INFO, the rest at DEBUG. Never raises."""
    try:
        ordered = sorted(details.items(), key=lambda item: (-item[1]["overload"], item[0]))
        for index, (key, detail) in enumerate(ordered):
            log.log(logging.INFO if index < max_pairs_at_info else logging.DEBUG, "%s", _block(model, key, detail))
    except Exception:
        log.debug("overload diagnosis could not be written", exc_info=True)
