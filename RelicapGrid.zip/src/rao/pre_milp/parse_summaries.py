"""parse_summaries.py - one log line per TSO and cause after the NCP parse: excluded assessed elements, RAs without a usable
bid, the bids parsed. Each line gives the count and the first 5 ids; the full list is at debug level."""

import logging

from data_model import AEType
from pre_milp import log_summary

log = logging.getLogger(__name__)


def _exclusion_cause(reason) -> str:
    """The cause of an excluded assessed element, from its exclusion_reason text."""
    text = str(reason or "")
    if text.startswith("SecuredExclusionReasonKind."):
        return f"exclusionReason {text.rsplit('.', 1)[-1]} without ScannedForRegion"
    if text == "disabled by the NCP":
        return "disabled by normalEnabled or a time point"
    return text or "no reason given"


def log_excluded_assessed_elements(ae_list) -> None:
    """Per TSO and cause: the excluded assessed elements, and how many of them have inBaseCase=false."""
    groups: dict[tuple[str, str], list] = {}
    for ae in ae_list:
        if ae.ae_type == AEType.EXCLUDED:
            groups.setdefault((ae.tso, _exclusion_cause(ae.exclusion_reason)), []).append(ae)
    for (tso, cause), elements in sorted(groups.items()):
        not_in_base_case = sum(1 for ae in elements if not ae.in_base_case)
        log_summary.log_ids(
            log, logging.INFO, f"{tso}: %d assessed element(s) excluded - {cause} ({not_in_base_case} with inBaseCase=false)",
            [ae.mrid for ae in elements])


def _without_usable_bid(ras, bids, timestamp: str) -> list:
    """The RAs (by mrid) none of whose bids has a volume above 0 at the timestamp."""
    usable = {str(bid.ra_mrid) for bid in bids if float(bid.available_mw.get(timestamp, 0.0)) > 0.0}
    seen: set = set()
    result = []
    for ra in ras:
        if str(ra.mrid) not in usable and str(ra.mrid) not in seen:
            seen.add(str(ra.mrid))
            result.append(ra)
    return result


def log_ras_without_usable_bid(rd_list, bid_list, ct_ra_list, ct_bid_list, timestamp: str) -> None:
    """Per TSO: the redispatch and countertrade RAs that have units but no usable bid: no bid refers to them, or every bid has
    volume 0 at the run time."""
    for label, ras, bids in (("RD", rd_list, bid_list), ("CT", ct_ra_list, ct_bid_list)):
        by_tso: dict[str, list] = {}
        for ra in _without_usable_bid(ras, bids, timestamp):
            by_tso.setdefault(ra.tso, []).append(ra.mrid)
        for tso, ids in sorted(by_tso.items()):
            log_summary.warn_ids(
                log, f"{tso}: %d {label} RA(s) have units but no usable bid (no bid refers to them, or every bid has volume 0 "
                     f"at {timestamp})", ids)


def log_bids_parsed(rd_list, bid_list, ct_ra_list, ct_bid_list) -> None:
    """One total per TSO (the TSO of the RA a bid belongs to): the power bids parsed, redispatch and countertrade."""
    tso_of_ra = {str(ra.mrid): ra.tso for ra in rd_list}
    tso_of_ct = {str(ra.mrid): ra.tso for ra in ct_ra_list}
    counts: dict[str, list[int]] = {}
    for bid in bid_list:
        counts.setdefault(tso_of_ra.get(str(bid.ra_mrid), "unknown TSO"), [0, 0])[0] += 1
    for bid in ct_bid_list:
        counts.setdefault(tso_of_ct.get(str(bid.ra_mrid), "unknown TSO"), [0, 0])[1] += 1
    for tso, (redispatch, countertrade) in sorted(counts.items()):
        log.info("%s: %d power bids parsed (%d redispatch, %d countertrade)", tso, redispatch + countertrade, redispatch, countertrade)
