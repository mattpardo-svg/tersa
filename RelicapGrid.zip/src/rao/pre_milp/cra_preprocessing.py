"""cra_preprocessing.py

Curative PST availability (does a curative PST have time to act within a TATL window, from
its reaction time and time per stage), curative RD availability per branch (reaction time
against the branch's TATL duration) and the curative PST group rules. Reads the tatl_data
that nx_security_analysis.compute_tatl_data returns. Preventive availability needs no
computation (normalAvailable and kind PREVENTIVE).
"""

import csv
import logging
import math
from collections import defaultdict
from itertools import combinations
from pathlib import Path
from typing import Optional

from data_model import PST, RDUnit
from pre_milp import log_summary
from text_encoding import TEXT_ENCODING

log = logging.getLogger(__name__)


TATL_FALLBACK_DURATION_S_DEFAULT = 600
"""TATL duration (s) of a branch without a real TATL: the default of the config value
curative_ra.tatl_fallback_duration_s (config/rao_config.default.yaml holds the same number, kept
equal by a test). Used for the curative RD reaction-time check and the curative PST cap; a finite
value keeps compute_pst_cra_availability's (tatl_duration_seconds/60 - reaction_time_minutes) /
time_per_stage_minutes bounded."""


REASON_REACTION_TIME = "reaction time above the TATL duration of the branch"
REASON_NO_TAP_IN_TIME = "no tap fits within the TATL duration (reaction time and time per stage)"


def log_availability_summary(ra_type: str, pairs: list, what: str) -> None:
    """One line per RA type for the curative availability: pairs available, pairs not available and why.
    pairs: (available, reason when not available) per pair."""
    reasons: dict[str, int] = {}
    for available, reason in pairs:
        if not available:
            reasons[reason] = reasons.get(reason, 0) + 1
    log.info(
        "Curative %s availability: %d %s, %d available, %d not available%s", ra_type, len(pairs), what,
        sum(1 for available, _ in pairs if available), sum(reasons.values()),
        "".join(f" ({count}: {reason})" for reason, count in sorted(reasons.items())),
    )


def rd_cra_is_available(reaction_time_minutes: Optional[float], tatl_duration_seconds: float) -> bool:
    """CORNET-613: a curative RD RA acts on a branch if its reaction time is <= the branch's
    TATL duration. No reaction time given = 0 (always available). No volume cap, no ramp."""
    reaction = 0.0 if reaction_time_minutes is None else float(reaction_time_minutes)
    return reaction <= float(tatl_duration_seconds) / 60.0


def branch_tatl_duration_seconds(
    branch_mrid: str, tatl_data: Optional[dict[str, dict]], fallback_duration_seconds: float,
) -> float:
    """The TATL duration of a branch: its tatl_data entry, else fallback_duration_seconds (a
    scanned branch, or a secured branch skipped by compute_tatl_data)."""
    entry = (tatl_data or {}).get(branch_mrid)
    if entry is None or entry.get("tatl_duration_seconds") is None:
        return fallback_duration_seconds
    return entry["tatl_duration_seconds"]


def compute_rd_cra_availability(
    rd_list: list[RDUnit],
    tatl_data: dict[str, dict],
    branch_mrids: Optional[list[str]] = None,
    fallback_duration_seconds: float = TATL_FALLBACK_DURATION_S_DEFAULT,
) -> dict[tuple[str, str], dict]:
    """{(ra_mrid, branch_mrid): {"reaction_time_minutes", "tatl_duration_seconds", "available"}}
    for every available curative RD RA and every branch of branch_mrids (None: the branches of
    tatl_data), with the duration of branch_tatl_duration_seconds and the rule of
    rd_cra_is_available. The one source of the rule (R9 rule 10): the MILP
    (milp_builder._add_nx_block, over every branch it evaluates) and the pipeline (over every
    monitored branch) both call it. Independent of the contingency: the rule has no contingency
    term. The count of available pairs is logged."""
    from data_model import RAKind

    branches = sorted(tatl_data) if branch_mrids is None else sorted(set(branch_mrids))
    availability: dict[tuple[str, str], dict] = {}
    for rd in rd_list:
        if not (rd.available and rd.kind == RAKind.CURATIVE):
            continue
        for branch_mrid in branches:
            duration = branch_tatl_duration_seconds(branch_mrid, tatl_data, fallback_duration_seconds)
            availability[(str(rd.mrid), branch_mrid)] = {
                "reaction_time_minutes": rd.reaction_time_minutes,
                "tatl_duration_seconds": duration,
                "available": rd_cra_is_available(rd.reaction_time_minutes, duration),
            }
    return availability


def compute_pst_cra_availability(
    pst_list: list[PST],
    tatl_data: dict[str, dict],
    contingencies: Optional[list] = None,
) -> dict[tuple[str, str, str], dict]:
    """For every available curative PST linked to a contingency and every SECURED branch with
    a TATL: max_curative_taps = floor((tatl_duration_seconds / 60 - reaction_time_minutes)
    / time_per_stage_minutes); available = max_curative_taps > 0.
    Returns {(pst_mrid, xne_mrid, co_mrid): {"max_curative_taps", "available"}}. A PST without
    timing data is skipped (one warning), never defaulted. With `contingencies`, a PST that is
    an outage element of contingency c gets no entry for c. linked_xne_mrids is not used here.
    """
    from data_model import RAKind

    curative_psts = [pst for pst in pst_list if pst.available and pst.kind == RAKind.CURATIVE]
    if not curative_psts:
        log.warning(
            "compute_pst_cra_availability: no available curative PSTs in PSTList — "
            "returning empty result (not an error; e.g. 'pst' "
            "may be missing from ra_types, or none are marked available)."
        )
        return {}

    pst_cra_availability: dict[tuple[str, str, str], dict] = {}

    tripped_by_contingency: dict[str, set[str]] = {
        str(co.mrid): {str(m) for m in co.equipment_mrids} for co in (contingencies or [])
    }

    without_link, without_timing = [], []
    for pst in curative_psts:
        if not pst.linked_contingency_mrids:
            without_link.append(pst.mrid)
            continue

        # a time per stage of 0 (or less) is as unusable as a missing one: it is the divisor below
        if pst.reaction_time_minutes is None or pst.time_per_stage_minutes is None or pst.time_per_stage_minutes <= 0:
            without_timing.append(pst.mrid)
            continue

        for xne_mrid in sorted(tatl_data):
            tatl_duration_seconds = tatl_data[xne_mrid]["tatl_duration_seconds"]
            max_curative_taps = math.floor(
                (tatl_duration_seconds / 60.0 - pst.reaction_time_minutes) / pst.time_per_stage_minutes
            )
            available = max_curative_taps > 0

            for co_mrid in pst.linked_contingency_mrids:
                if co_mrid in pst.excluded_contingency_mrids:
                    continue  # ContingencyWithRemedialAction excluded: the PST is not used in this contingency
                if str(pst.mrid) in tripped_by_contingency.get(str(co_mrid), ()):
                    continue  # the PST is an outage element of this contingency
                pst_cra_availability[(pst.mrid, xne_mrid, co_mrid)] = {
                    "max_curative_taps": max_curative_taps,
                    "available": available,
                }

    if without_link:
        log_summary.log_ids(
            log, logging.INFO,
            "compute_pst_cra_availability: %d curative PST(s) have no linked contingency (ContingencyWithRemedialAction) "
            "and contribute no CRA availability", without_link)
    if without_timing:
        log_summary.warn_ids(
            log,
            "compute_pst_cra_availability: %d curative PST(s) lack reaction_time_minutes and/or time_per_stage_minutes - "
            "skipped entirely (not guessed or defaulted)", without_timing)
    if tripped_by_contingency:
        outage_psts = [
            str(pst.mrid) for pst in curative_psts
            if any(str(pst.mrid) in tripped_by_contingency.get(str(co), ()) for co in pst.linked_contingency_mrids)
        ]
        if outage_psts:
            log_summary.log_ids(
                log, logging.INFO,
                "compute_pst_cra_availability: %d curative PST(s) are themselves an outage element of a linked contingency "
                "and are not available as a curative RA there", outage_psts)

    log_availability_summary(
        "PST", [(entry["available"], REASON_NO_TAP_IN_TIME) for entry in pst_cra_availability.values()],
        "(PST, branch, contingency) triples",
    )

    return pst_cra_availability


# ---------------------------------------------------------------------------
# Curative PST groups: curative PSTs sharing one group_id (one remedial action with several
# TapPositionActions). Per (group, contingency c):
#   * only members with an available curative entry for c are considered;
#   * a member that is an outage element of c: reducedGroup -> the other members stay a
#     group, blockedGroup -> the whole group is unavailable in c;
#   * no common rectified delta tap (up/down headroom from the current tap, limited by the
#     TATL tap cap) -> the group is excluded for c (warning);
#   * otherwise each pair gets (up_1 - down_1) == (up_2 - down_2).
# The group kind is not in the data: config curative_ra.pst_group_kind_default (blockedGroup)
# and the per-TSO map curative_ra.pst_group_kind_per_tso.
# ---------------------------------------------------------------------------

REDUCED_GROUP = "reducedGroup"
BLOCKED_GROUP = "blockedGroup"
VALID_PST_GROUP_KINDS = (REDUCED_GROUP, BLOCKED_GROUP)


def validate_pst_group_kind(value: str) -> str:
    if value not in VALID_PST_GROUP_KINDS:
        raise ValueError(
            f"pst_group_kind_default must be one of {VALID_PST_GROUP_KINDS}, got {value!r}"
        )
    return value


def build_curative_pst_group_constraints(
    curative_pst_list: list[PST],
    pst_cra_availability: dict[tuple[str, str, str], dict],
    pst_tap_bounds_curative: dict[str, tuple[int, int]],
    contingencies: Optional[list],
    pst_group_kind_default: str,
    pst_group_kind_per_tso: Optional[dict[str, str]] = None,
) -> tuple[dict[tuple[str, str, str], dict], list[tuple[str, str, str]]]:
    """Returns (filtered pst_cra_availability, sorted (pst_1, pst_2, contingency) triples).
    The availability is a copy without the entries of excluded or blocked groups; without
    groups it equals the input."""
    validate_pst_group_kind(pst_group_kind_default)
    kind_overrides = {
        str(tso): validate_pst_group_kind(kind) for tso, kind in (pst_group_kind_per_tso or {}).items()
    }
    filtered = dict(pst_cra_availability)

    members_by_group: dict[str, dict[str, PST]] = defaultdict(dict)
    for pst in curative_pst_list:
        if pst.group_id and pst.available:
            members_by_group[str(pst.group_id)][str(pst.mrid)] = pst

    tripped_by_contingency = {
        str(co.mrid): {str(m) for m in co.equipment_mrids} for co in (contingencies or [])
    }

    triples: list[tuple[str, str, str]] = []
    several_tsos: list[str] = []
    blocked_pairs: list[str] = []
    reduced_pairs: list[str] = []
    no_common_delta: list[str] = []

    for group_id, members in sorted(members_by_group.items()):
        if len(members) < 2:
            continue
        # the group's TSO (one remedial action, one TSO) picks the per-TSO kind, else the default
        group_tsos = {str(pst.tso) for pst in members.values()}
        if len(group_tsos) > 1:
            several_tsos.append(str(group_id))
            group_kind = pst_group_kind_default
        else:
            group_kind = kind_overrides.get(next(iter(group_tsos)), pst_group_kind_default)

        contingency_mrids = sorted({
            str(co) for pst in members.values() for co in pst.linked_contingency_mrids
            if co not in pst.excluded_contingency_mrids
        } | {co for (m, _x, co) in filtered if m in members})

        for co_mrid in contingency_mrids:
            tripped = sorted(m for m in members if m in tripped_by_contingency.get(co_mrid, ()))
            if tripped and group_kind == BLOCKED_GROUP:
                for key in [k for k in filtered if k[0] in members and k[2] == co_mrid]:
                    del filtered[key]
                blocked_pairs.append(f"{group_id}/{co_mrid}")
                continue
            if tripped:
                reduced_pairs.append(f"{group_id}/{co_mrid}")

            # tap cap per member in c: the shared variable pair must satisfy every
            # available (xne) magnitude row, so the binding cap is the minimum
            caps: dict[str, int] = {}
            for (m, _x, co), entry in filtered.items():
                if co == co_mrid and m in members and entry.get("available"):
                    cap = int(entry["max_curative_taps"])
                    caps[m] = min(cap, caps[m]) if m in caps else cap
            considered = sorted(m for m in caps if m not in tripped)
            if len(considered) < 2:
                continue

            low, high = [], []
            for m in considered:
                pst = members[m]
                bounds = pst_tap_bounds_curative.get(m, (pst.operating_tap_min, pst.operating_tap_max))
                current = int(getattr(pst, "r0", 0))
                low.append(max(int(bounds[0]) - current, -caps[m]))
                high.append(min(int(bounds[1]) - current, caps[m]))
            if max(low) > min(high):
                for key in [k for k in filtered if k[0] in considered and k[2] == co_mrid]:
                    del filtered[key]
                no_common_delta.append(f"{group_id}/{co_mrid}")
                continue

            triples.extend((a, b, co_mrid) for a, b in combinations(considered, 2))

    if several_tsos:
        log_summary.warn_ids(log, "Curative PST groups: %d group(s) have members of several TSOs - the default kind is used", several_tsos)
    if blocked_pairs:
        log_summary.warn_ids(
            log, "Curative PST groups: %d (group/contingency) pair(s) with a member that is an outage element and the group kind "
            "blockedGroup - the whole group is unavailable as curative RA there", blocked_pairs)
    if reduced_pairs:
        log_summary.log_ids(
            log, logging.INFO, "Curative PST groups: %d (group/contingency) pair(s) with a member that is an outage element "
            "(reducedGroup) - the remaining available members still operate as a group", reduced_pairs)
    if no_common_delta:
        log_summary.warn_ids(
            log, "Curative PST groups: %d (group/contingency) pair(s) have no common rectified delta tap - the whole group is "
            "excluded for that contingency", no_common_delta)

    return filtered, sorted(triples)
