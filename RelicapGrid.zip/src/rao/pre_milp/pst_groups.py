"""pst_groups.py — equality pairs for the PSTs of one preventive group (MILP input)."""

import logging
from collections import defaultdict
from typing import Dict

from data_model import PST
from pre_milp import log_summary

log = logging.getLogger(__name__)


def build_pst_group_equality_pairs(
    pst_list: list[PST],
    pst_tap_bounds: dict[str, tuple[int, int]],
) -> list[tuple[str, str]]:
    """Build equality constraint pairs for PSTs sharing the same group_id."""
    groups: Dict[str, list[PST]] = defaultdict(list)
    for pst in pst_list:
        if pst.group_id:
            groups[pst.group_id].append(pst)

    equality_pairs: list[tuple[str, str]] = []
    with_unavailable, without_bounds, empty_range, valid_groups = [], [], [], []

    for group_id, group_psts in groups.items():
        if len(group_psts) < 2:
            continue

        if any(not pst.available for pst in group_psts):
            with_unavailable.append(str(group_id))
            continue

        missing_bounds = [pst.mrid for pst in group_psts if pst.mrid not in pst_tap_bounds]
        if missing_bounds:
            without_bounds.append(str(group_id))
            continue

        bounds = [pst_tap_bounds[pst.mrid] for pst in group_psts]
        effective_min = max(b[0] for b in bounds)
        effective_max = min(b[1] for b in bounds)

        if effective_min > effective_max:
            empty_range.append(str(group_id))
            continue

        # Build an equality pair for each unique PST pair in the valid group.
        for i in range(len(group_psts)):
            for j in range(i + 1, len(group_psts)):
                equality_pairs.append((group_psts[i].mrid, group_psts[j].mrid))

        valid_groups.append(str(group_id))

    if with_unavailable:
        log_summary.warn_ids(log, "%d PST group(s) excluded because unavailable PSTs present", with_unavailable)
    if without_bounds:
        log_summary.warn_ids(
            log, "%d PST group(s) excluded because a member has no valid tap bounds (empty effective range upstream)", without_bounds)
    if empty_range:
        log_summary.warn_ids(log, "%d PST group(s) excluded because the effective group range is empty", empty_range)
    if valid_groups:
        log_summary.log_ids(log, logging.INFO, "%d PST group(s) valid", valid_groups)

    return equality_pairs
