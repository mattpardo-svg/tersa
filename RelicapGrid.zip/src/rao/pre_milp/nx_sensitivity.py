"""nx_sensitivity.py — N-X sensitivities of PSTs (A per degree) and RD units (A per MW) per
must-study contingency, for preventive AND curative available remedial actions, with the
loading filter (Filter 1) and the magnitude pruning (Filter 2). _get_must_study_contingencies
and _register_contingencies come from nx_security_analysis, _get_monitored_branch_sides from
milp_builder.
"""

import csv
import logging
from collections import Counter
from pathlib import Path
from collections.abc import Mapping
from typing import Optional

import numpy as np

from data_model import AEType, AssessedElement, Contingency, PST, RDUnit, select_by_side
from pre_milp import ct_sensitivity
from pre_milp.lf_parameters import build_loadflow_parameters, build_sensitivity_parameters
from milp.milp_builder import _get_monitored_branch_sides
from pre_milp.nx_security_analysis import _get_must_study_contingencies, _register_contingencies
from pre_milp.sensitivity_table import SensitivityTable, table_from_matrices
from pre_milp import sensitivity_checks
from pre_milp.sensitivity_checks import DC_NX_RELATIVE_TOLERANCE, NO_VALID_BRANCH, find_invalid_nx_contingencies
from text_encoding import TEXT_ENCODING

log = logging.getLogger(__name__)

# the MW the N-X redispatch and countertrade threshold looks at: percent of the branch limit per 100 MW
RD_THRESHOLD_MW = 100.0


def _get_limit_and_ae_type_by_branch_nx(
    ae_flat_list: list[AssessedElement], timestamp: str, lf_initial: dict[str, dict[int, float]],
) -> tuple[dict[str, float], dict[str, "AEType"]]:
    """({branch_mrid: limit_ampere}, {branch_mrid: AEType}) from milp_builder's limit resolver
    (PATL for SECURED, effective limit for SCANNED); imported lazily to avoid a circular import."""
    from milp.milp_builder import _get_monitored_branch_limits_and_ae_types

    return _get_monitored_branch_limits_and_ae_types(ae_flat_list, timestamp, lf_initial)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _get_available_pst_ids_nx(pst_list: list[PST], network=None) -> list[str]:
    """Available PST (PowerTransformer) mRIDs, preventive and curative, de-duplicated: a
    transformer with a preventive and a curative remedial action is one sensitivity variable
    (the same ID twice makes pypowsybl return a duplicate matrix row).
    With `network`, PSTs on a 3-winding transformer are left out (logged): pypowsybl's
    TRANSFORMER_PHASE variable does not support them.
    """
    candidates = sorted({str(pst.mrid) for pst in pst_list if pst.available})

    if network is None:
        return candidates

    try:
        two_w_ids = set(network.get_2_windings_transformers().index)
    except Exception:
        log.exception("Failed to fetch 2-winding transformer IDs — skipping 3W-transformer PST filter")
        return candidates

    filtered = [pst_mrid for pst_mrid in candidates if pst_mrid in two_w_ids]
    excluded = [pst_mrid for pst_mrid in candidates if pst_mrid not in two_w_ids]
    if excluded:
        log.warning(
            "Excluding %d PST(s) backed by a 3-winding transformer from N-X AC "
            "sensitivity (unsupported by pypowsybl's TRANSFORMER_PHASE "
            "variable type for 3W transformers): %s",
            len(excluded), excluded,
        )
    return filtered


def _get_available_rd_gu_ids_nx(rd_list: list[RDUnit]) -> list[str]:
    """Sorted, de-duplicated generating-unit mRIDs of the available RD units, preventive and
    curative (the sensitivity variable is the unit, shared by its remedial actions). The units of the
    countertrade RAs have a variable per RA and direction instead (compute_ct_nx)."""
    return ct_sensitivity.individual_unit_ids(rd_list)


def compute_ct_nx(
    network, contingencies: list[Contingency], branch_sides: dict[str, int], weights: dict[str, dict[str, float]],
    dc_converter=None, use_reactive_limits: bool = False, extra_lf_params: Optional[dict] = None,
    prune_limits: Optional[dict[str, float]] = None, prune_threshold_pct: float = 0.0,
) -> tuple[dict[str, dict[int, tuple]], dict[str, dict[str, float]]]:
    """The countertrade variables of every contingency: ({contingency: {side: (branches, variables, array (variables,
    branches))}}, {contingency: {branch: reference value}}). The per-unit sensitivities (INJECTION_ACTIVE_POWER, the
    parameters and conversion of the RD units) are read in batches of contingencies (ct_sensitivity.batch_size) and
    summed with the weights right away (ct_sensitivity.aggregate_units); the per-unit values of a batch are dropped
    before the next one. prune_limits / prune_threshold_pct: Filter 2 as it applies to a unit entry, before the sum."""
    import pypowsybl as pp
    blocks: dict[str, dict[int, tuple]] = {}
    references: dict[str, dict[str, float]] = {}
    if not weights or not contingencies:
        return blocks, references
    unit_ids = ct_sensitivity.countertrade_unit_ids(weights)
    step = ct_sensitivity.batch_size(len(unit_ids), len(branch_sides))
    for start in range(0, len(contingencies), step):
        batch = contingencies[start:start + step]
        result, matrix_ids_by_prefix = _run_nx_sensitivity_analysis(
            network, batch, branch_sides, [("nx_ct", unit_ids, pp.sensitivity.SensitivityVariableType.INJECTION_ACTIVE_POWER)],
            use_reactive_limits=use_reactive_limits, extra_lf_params=extra_lf_params, dc_converter=dc_converter,
        )
        matrix_ids = matrix_ids_by_prefix["nx_ct"]
        p_ref_mw = _reference_currents_nx(result, matrix_ids)
        references.update(p_ref_mw)
        for contingency in batch:
            side_blocks: dict[int, tuple] = {}
            for side, matrix_id in matrix_ids[contingency.mrid].items():
                matrix = result.get_sensitivity_matrix(matrix_id, contingency.mrid)
                if matrix is None:
                    log.warning("compute_ct_nx: no matrix for contingency %s side %d", contingency.mrid, side)
                    continue
                branches = [str(b) for b in matrix.columns]
                values = matrix.to_numpy().T                                       # (branches, units)
                if dc_converter is not None:                                       # the factor of a branch is the same for every unit
                    reference = p_ref_mw.get(contingency.mrid, {})
                    values = values * np.array([
                        dc_converter.sensitivity(b, branch_sides.get(b, 1), 1.0, reference.get(b, float("nan"))) for b in branches
                    ])[:, None]
                thresholds = None
                if prune_limits is not None and float(prune_threshold_pct) > 0.0:
                    thresholds = np.array([
                        float(prune_threshold_pct) * float(prune_limits.get(b) or 0.0) / 100.0 / RD_THRESHOLD_MW for b in branches])
                variables, aggregate = ct_sensitivity.aggregate_units(values, [str(u) for u in matrix.index], weights, thresholds)
                side_blocks[side] = (branches, variables, np.ascontiguousarray(aggregate.T))
            blocks[contingency.mrid] = side_blocks
        del result
    return blocks, references


def _run_nx_sensitivity_analysis(
    network,
    must_study_contingencies: list[Contingency],
    branch_sides: dict[str, int],
    variable_sets: list[tuple[str, list[str], object]],
    use_reactive_limits: bool = False,
    extra_lf_params: Optional[dict] = None,
    dc_converter=None,
):
    """One pypowsybl AC sensitivity analysis with, per variable set (prefix, variable ids,
    variable type), one factor matrix per side for ALL registered contingencies
    (ContingencyContextType.ALL; several contingency IDs with SPECIFIC raise
    ArrayIndexOutOfBoundsException), run once with the pipeline's load-flow parameters.
    Returns (result, {prefix: {contingency: {side: matrix_id}}}), a side only when it has
    monitored branches; get_sensitivity_matrix(matrix_id, contingency) reads one contingency.
    A variable set without ids adds no matrix.
    dc_converter (calculation_mode dc): a DC analysis with BRANCH_ACTIVE_POWER_1/2 instead (the
    only functions it supports); the matrices are then in MW per unit.
    """
    import pypowsybl as pp

    side1_branch_ids = sorted(b for b, s in branch_sides.items() if s == 1)
    side2_branch_ids = sorted(b for b, s in branch_sides.items() if s == 2)

    functions = pp.sensitivity.SensitivityFunctionType
    if dc_converter is None:
        sensitivity_analysis = pp.sensitivity.create_ac_analysis()
        function_type_side1, function_type_side2 = functions.BRANCH_CURRENT_1, functions.BRANCH_CURRENT_2
    else:
        sensitivity_analysis = pp.sensitivity.create_dc_analysis()
        function_type_side1, function_type_side2 = functions.BRANCH_ACTIVE_POWER_1, functions.BRANCH_ACTIVE_POWER_2
    _register_contingencies(sensitivity_analysis, must_study_contingencies)

    matrix_ids_by_prefix: dict[str, dict[str, dict[int, str]]] = {}
    for prefix, variable_ids, sensitivity_variable_type in variable_sets:
        side_matrix_ids: dict[int, str] = {}
        for side, branch_ids, function_type in (
            (1, side1_branch_ids, function_type_side1),
            (2, side2_branch_ids, function_type_side2),
        ):
            if not branch_ids or not variable_ids:
                continue
            matrix_id = f"{prefix}_side{side}"
            sensitivity_analysis.add_factor_matrix(
                functions_ids=branch_ids,
                variables_ids=variable_ids,
                contingencies_ids=[],
                contingency_context_type=pp.sensitivity.ContingencyContextType.ALL,
                sensitivity_function_type=function_type,
                sensitivity_variable_type=sensitivity_variable_type,
                matrix_id=matrix_id,
            )
            side_matrix_ids[side] = matrix_id
        matrix_ids_by_prefix[prefix] = {
            contingency.mrid: dict(side_matrix_ids) for contingency in must_study_contingencies
        }

    result = sensitivity_analysis.run(
        network, parameters=build_sensitivity_parameters(use_reactive_limits, extra_lf_params),
    )
    return result, matrix_ids_by_prefix


def _matrix_entries(matrix, contingency_mrid: str, function_name: str, variable_label: str) -> dict[tuple[str, str], float]:
    """{(branch, variable): value} of one sensitivity matrix (index = variables, columns =
    branches), read with numpy in column-then-row order. A duplicated label uses its FIRST
    row/column (warning per cell, as pandas .loc would return several values); NaN stays NaN."""
    matrix_variable_ids = [str(v) for v in matrix.index]
    matrix_branch_ids = [str(b) for b in matrix.columns]
    values = matrix.to_numpy()
    row_of: dict[str, int] = {}
    for position, variable_id in enumerate(matrix_variable_ids):
        row_of.setdefault(variable_id, position)
    column_of: dict[str, int] = {}
    for position, branch_id in enumerate(matrix_branch_ids):
        column_of.setdefault(branch_id, position)
    row_count = Counter(matrix_variable_ids)
    column_count = Counter(matrix_branch_ids)
    entries: dict[tuple[str, str], float] = {}
    for branch_mrid in matrix_branch_ids:
        for variable_mrid in matrix_variable_ids:
            duplicates = row_count[variable_mrid] if row_count[variable_mrid] > 1 else column_count[branch_mrid]
            if duplicates > 1:
                log.warning(
                    "%s: matrix.loc[%s, %s] returned %d value(s) instead of one (contingency %s) — "
                    "matrix.index has a duplicate entry for this %s despite the input list having "
                    "none. Using the first value; root cause not yet confirmed.",
                    function_name, variable_mrid, branch_mrid, duplicates, contingency_mrid, variable_label,
                )
            entries[(branch_mrid, variable_mrid)] = float(values[row_of[variable_mrid], column_of[branch_mrid]])
    return entries


def _merged_blocks(unit_blocks: dict, ct_blocks: dict) -> list:
    """The blocks of the unit matrices and of the countertrade variable matrices, side by side (variables of the
    units first); a side whose two matrices have other branches makes a table impossible (None)."""
    merged = []
    for side in sorted(set(unit_blocks) | set(ct_blocks)):
        if side in unit_blocks and side in ct_blocks:
            (branches, variables, values), (ct_branches, ct_variables, ct_values) = unit_blocks[side], ct_blocks[side]
            if branches != ct_branches:
                return None
            merged.append((branches, variables + ct_variables, np.concatenate([values, ct_values], axis=0)))
        else:
            merged.append(unit_blocks.get(side) or ct_blocks[side])
    return merged


def _contingency_sensitivities(
    result, contingency_mrid: str, matrix_ids: dict, function_name: str, variable_label: str,
    branch_sides: dict, p_ref_mw: dict, dc_converter, ct_blocks: Optional[dict] = None,
):
    """The sensitivities of one contingency over its side matrices: a SensitivityTable (numpy) in the AC case when
    the matrices are consistent, otherwise the {(branch, variable): value} dict of _matrix_entries. The DC conversion
    (a function per entry) always works on the dict. ct_blocks ({side: (branches, variables, array (variables,
    branches))}, from compute_ct_nx, already in A per MW): the countertrade variables, added to the same table."""
    unit_blocks, matrices = {}, []
    for side, matrix_id in matrix_ids.items():
        matrix = result.get_sensitivity_matrix(matrix_id, contingency_mrid)
        if matrix is None:
            log.warning("%s: no matrix for contingency %s side %d", function_name, contingency_mrid, side)
            continue
        matrices.append(matrix)
        unit_blocks[side] = ([str(b) for b in matrix.columns], [str(v) for v in matrix.index], matrix.to_numpy())
    ct_blocks = ct_blocks or {}
    if dc_converter is None:
        merged = _merged_blocks(unit_blocks, ct_blocks)
        table = table_from_matrices(merged) if merged is not None else None
        if table is not None:
            return table
    # pypowsybl's matrix can hold a duplicate row for one variable (cause unknown): the first value is used and a
    # warning is logged
    per_contingency: dict[tuple[str, str], float] = {}
    for matrix in matrices:
        entries = _matrix_entries(matrix, contingency_mrid, function_name, variable_label)
        if dc_converter is not None:
            entries = _dc_convert_entries(entries, contingency_mrid, branch_sides, p_ref_mw, dc_converter)
        per_contingency.update(entries)
    for branches, variables, values in ct_blocks.values():
        for column, branch in enumerate(branches):
            for row, variable in enumerate(variables):
                per_contingency[(branch, variable)] = float(values[row, column])
    return per_contingency

def _all_zero(values) -> bool:
    return values.all_zero() if isinstance(values, SensitivityTable) else all(v == 0.0 for v in values.values())


def _reference_currents_nx(result, matrix_ids_by_contingency) -> dict[str, dict[str, float]]:
    """{contingency_mrid: {branch_mrid: reference (post-contingency) current in A}} as seen by
    the sensitivity analysis itself: the value the sensitivities are linearised around. The
    guard compares it with the N-X load flow (lf_nx) of the same state. A (contingency, side)
    the analysis returned no reference for is simply absent."""
    references: dict[str, dict[str, float]] = {}
    for contingency_mrid, matrix_ids in matrix_ids_by_contingency.items():
        per_branch: dict[str, float] = {}
        for matrix_id in matrix_ids.values():
            try:
                reference_matrix = result.get_reference_matrix(matrix_id, contingency_mrid)
            except Exception:
                reference_matrix = None
            if reference_matrix is None:
                continue
            for branch_mrid in reference_matrix.columns:
                per_branch[str(branch_mrid)] = float(reference_matrix.iloc[0][branch_mrid])
        references[contingency_mrid] = per_branch
    return references


def _guard_tolerance(dc_converter) -> dict:
    """Keyword argument of the N-X guard: the DC mode compares the reference with the DC security
    analysis with DC_NX_RELATIVE_TOLERANCE (see sensitivity_checks); the AC analyses keep the default."""
    return {} if dc_converter is None else {"tolerance": DC_NX_RELATIVE_TOLERANCE}



def _dc_references_to_currents(p_ref_mw: dict, branch_sides: dict, dc_converter) -> dict[str, dict[str, float]]:
    """{contingency: {branch: reference flow (MW)}} -> reference currents (A) for the guard."""
    return {
        contingency_mrid: {
            branch_mrid: dc_converter.current(branch_mrid, branch_sides.get(branch_mrid, 1), p)
            for branch_mrid, p in per_branch.items()
        }
        for contingency_mrid, per_branch in p_ref_mw.items()
    }


def _dc_convert_entries(entries: dict, contingency_mrid: str, branch_sides: dict, p_ref_mw: dict, dc_converter) -> dict:
    """{(branch, variable): MW per unit} of one contingency -> A per unit, with the sign of the
    reference flow of that branch side and contingency (NaN without a reference)."""
    references = p_ref_mw.get(contingency_mrid, {})
    return {
        (branch_mrid, variable_mrid): dc_converter.sensitivity(
            branch_mrid, branch_sides.get(branch_mrid, 1), value, references.get(branch_mrid, float("nan")),
        )
        for (branch_mrid, variable_mrid), value in entries.items()
    }


def _apply_loading_threshold_filter_nx(
    sensitivity_nx: dict[str, dict[tuple[str, str], float]],
    lf_nx: dict[str, dict[str, dict[int, float]]],
    branch_sides: dict[str, int],
    limit_by_branch: dict[str, float],
    min_loading_threshold_pct_nx: float,
) -> dict[str, dict[tuple[str, str], float]]:
    """Filter 1 (loading): drop every (branch, RA) entry of a (branch, contingency) pair whose
    lf_nx[c][b] / limit_by_branch[b] is below min_loading_threshold_pct_nx (PATL for secured,
    effective limit for scanned branches). Applied after the analysis, which computes every
    monitored branch. A pair without a limit or without an N-X current is dropped.
    """
    def branch_passes(per_branch_currents, branch_mrid) -> bool:
        limit_ampere = limit_by_branch.get(branch_mrid)
        if not limit_ampere or limit_ampere <= 0.0:
            return False
        side = branch_sides.get(branch_mrid, 1)
        nx_current_ampere = select_by_side(
            per_branch_currents.get(branch_mrid, {}), side, branch_mrid,
        )
        if nx_current_ampere is None:
            return False
        loading_pct = (float(nx_current_ampere) / limit_ampere) * 100.0
        return not loading_pct < float(min_loading_threshold_pct_nx)

    filtered: dict[str, Mapping[tuple[str, str], float]] = {}
    for contingency_mrid, per_branch_ra in sensitivity_nx.items():
        per_branch_currents = lf_nx.get(contingency_mrid, {})
        if isinstance(per_branch_ra, SensitivityTable):
            # the decision depends on the branch only: one per row, not one per entry
            filtered[contingency_mrid] = per_branch_ra.restricted_to_branches(
                lambda branch_mrid: branch_passes(per_branch_currents, branch_mrid)
            )
            continue
        filtered_for_contingency: dict[tuple[str, str], float] = {}
        for (branch_mrid, ra_mrid), value in per_branch_ra.items():
            if branch_passes(per_branch_currents, branch_mrid):
                filtered_for_contingency[(branch_mrid, ra_mrid)] = value
        filtered[contingency_mrid] = filtered_for_contingency
    return filtered


def _contingency_batches(contingencies: list[Contingency], batch_size: Optional[int]) -> list[list[Contingency]]:
    """The contingencies of one analysis in batches. None (or a size that holds them all): one batch in the given order;
    otherwise chunks of the contingencies sorted by mRID (the order of the CSV files), so that the batches read one after the
    other give the rows of one analysis."""
    if batch_size is not None and (isinstance(batch_size, bool) or not isinstance(batch_size, int) or batch_size < 1):
        raise ValueError(f"contingency_batch_size must be an integer >= 1 (or None for one analysis), got {batch_size!r}")
    if batch_size is None or batch_size >= len(contingencies):
        return [list(contingencies)]
    ordered = sorted(contingencies, key=lambda c: c.mrid)
    return [ordered[start:start + batch_size] for start in range(0, len(ordered), batch_size)]


class _NxKindReader:
    """Reads the N-X sensitivities of one kind (the PSTs, the RD units or the HVDC injections) of one analysis, one batch
    of contingencies at a time: read, zero-unit check on the raw values, guard decision, Filter 1, CSV rows, then the
    threshold (Filter 2) and a compact table, so that neither the full table of all contingencies nor the pypowsybl result of
    a finished batch is kept. What the batches leave behind adds up to the result of one analysis over all contingencies:
    the tables (put back in must-study order by finish), the references, the guard decisions, the pairs left out and the
    entry counts of the threshold line.

    The guard of a batch runs when the batch is read and its pairs leave lf_nx at once: the next kind (RD after PST, HVDC after
    both) reads the same contingency without them, as after one analysis. One rule looks at all contingencies together (no
    contingency has a valid branch: all are invalid); finish applies it to the union of the batches and, when it holds, puts
    the pairs back, so that lf_nx is the one of one analysis."""

    def __init__(
        self, kind: str, prefix: str, variable_ids: list[str], variable_type, contingencies: list[Contingency], *,
        branch_sides, ae_flat_list, timestamp, lf_nx, lf_initial, min_loading_threshold_pct_nx,
        output_path: Optional[Path] = None, ct_output_path: Optional[Path] = None,
        reference_out: Optional[dict] = None, guard_out: Optional[dict] = None, guard: Optional[bool] = None, guard_all_zero: bool = True, dc_converter=None, threshold_pct: float = 0.0,
        degrees_per_tap: Optional[Mapping[str, float]] = None, zero_units_out: Optional[dict] = None,
    ):
        self.kind, self.prefix, self.variable_ids, self.variable_type = kind, prefix, variable_ids, variable_type
        self.contingencies = contingencies
        self.branch_sides, self.lf_nx = branch_sides, lf_nx
        self.min_loading_threshold_pct_nx, self.dc_converter = min_loading_threshold_pct_nx, dc_converter
        self.reference_out, self.guard_out, self.zero_units_out = reference_out, guard_out, zero_units_out
        self.guard = guard_out is not None if guard is None else guard
        self.guard_all_zero, self.threshold_pct = guard_all_zero, threshold_pct
        self.takes_countertrade = kind == "rd"
        self.guard_after_logs = kind == "hvdc"                 # the HVDC guard line follows the totals, as for one analysis
        self.function_name = "compute_sensitivity_pst_nx" if kind == "pst" else "compute_sensitivity_rd_nx"
        self.variable_label = "PST" if kind == "pst" else "generating unit"
        self.prune_arguments = {"degrees_per_tap": degrees_per_tap} if kind == "pst" else {"per_mw_basis": RD_THRESHOLD_MW}
        self.limit_by_branch, self.branch_ae_types = _get_limit_and_ae_type_by_branch_nx(ae_flat_list, timestamp, lf_initial)
        self.timestamp, self.output_path = timestamp, output_path
        self.branch_count = len(branch_sides)
        self.references: dict[str, dict[str, float]] = {}
        self.by_contingency: dict[str, Mapping[tuple[str, str], float]] = {}
        self.entries_before_threshold = self.entries_kept = 0
        self.invalid: dict[str, str] = {}
        self.considered: set[str] = set()
        self.without_valid_branch: set[str] = set()
        self.drops = sensitivity_checks.GuardDrops()
        self.csv_file = self.csv_writer = None
        if reference_out is not None:
            reference_out.clear()
        if zero_units_out is not None:
            zero_units_out.clear()
        self.ct_csv_file = self.ct_csv_writer = None
        self.degrees_per_tap = degrees_per_tap
        if output_path is not None:
            self.branch_tso = {str(ae.branch_mrid): ae.tso for ae in ae_flat_list if ae.branch_mrid}
            output_path.parent.mkdir(parents=True, exist_ok=True)
            self.csv_file = open(output_path, "w", newline="", encoding=TEXT_ENCODING)
            self.csv_writer = csv.writer(self.csv_file)
            self.csv_writer.writerow(_PST_NX_CSV_HEADER if kind == "pst" else _RD_NX_CSV_HEADER)
            if ct_output_path is not None and kind == "rd":
                self.ct_csv_file = open(ct_output_path, "w", newline="", encoding=TEXT_ENCODING)
                self.ct_csv_writer = csv.writer(self.ct_csv_file)
                self.ct_csv_writer.writerow(_CT_NX_CSV_HEADER)

    def _write_csv(self, contingency_mrid, entries) -> None:
        if self.kind == "pst":
            self.csv_writer.writerows(_pst_nx_csv_rows(
                contingency_mrid, entries, self.branch_sides, self.branch_tso, self.degrees_per_tap))
            return
        unit_rows, ct_rows = _rd_nx_csv_rows(contingency_mrid, entries, self.branch_sides, self.branch_tso)
        self.csv_writer.writerows(unit_rows)
        if self.ct_csv_writer is not None:
            self.ct_csv_writer.writerows(ct_rows)

    def close(self) -> None:
        for name in ("csv_file", "ct_csv_file"):
            if getattr(self, name) is not None:
                getattr(self, name).close()
                setattr(self, name, None)

    def read_batch(self, result, matrix_ids_by_contingency, batch: list[Contingency], ct_result=None) -> None:
        """Read the contingencies of `batch` (in sorted order) from `result`. ct_result: (blocks, references) of
        compute_ct_nx for the batch: the countertrade variables, whose entries join those of the units; a run with
        countertrade units only has no unit matrix and takes its references from them."""
        ct_blocks, ct_references = ct_result or ({}, {})
        p_ref_mw = (_reference_currents_nx(result, matrix_ids_by_contingency)
                    if self.variable_ids or not ct_references else ct_references)
        references = p_ref_mw
        if self.dc_converter is not None:
            references = _dc_references_to_currents(p_ref_mw, self.branch_sides, self.dc_converter)
        self.references.update(references)
        all_zero_contingencies: set[str] = set()
        for contingency in sorted(batch, key=lambda c: c.mrid):
            # duplicate matrix row: the first value is used (see _contingency_sensitivities)
            raw = _contingency_sensitivities(
                result, contingency.mrid, matrix_ids_by_contingency[contingency.mrid], self.function_name, self.variable_label,
                self.branch_sides, p_ref_mw, self.dc_converter, ct_blocks.get(contingency.mrid),
            )
            if self.zero_units_out is not None:
                # NaN entries (the branches the contingency itself disconnects) do not count
                zero_units = sorted(
                    unit for unit in self.variable_ids
                    if any(v == 0.0 for (_b, u), v in raw.items() if u == unit)
                    and all(v == 0.0 for (_b, u), v in raw.items() if u == unit and v == v)
                )
                if zero_units:
                    self.zero_units_out[contingency.mrid] = zero_units
            if raw and _all_zero(raw):
                all_zero_contingencies.add(contingency.mrid)
            filtered = _apply_loading_threshold_filter_nx(
                {contingency.mrid: raw}, self.lf_nx, self.branch_sides, self.limit_by_branch, self.min_loading_threshold_pct_nx,
            )[contingency.mrid]
            del raw
            if self.csv_writer is not None:
                self._write_csv(contingency.mrid, filtered)
            pruned = _prune_by_magnitude(
                {contingency.mrid: filtered}, self.limit_by_branch, self.threshold_pct, **self.prune_arguments)[contingency.mrid]
            if isinstance(pruned, SensitivityTable):
                pruned = pruned.compacted()
            self.entries_before_threshold += len(filtered)
            self.entries_kept += len(pruned)
            self.by_contingency[contingency.mrid] = pruned
            del filtered
        self._guard_batch(references, all_zero_contingencies if self.guard_all_zero else set())

    def _guard_batch(self, references: dict, all_zero_contingencies: set) -> None:
        if not self.guard:
            return
        unreferenced: dict = {}
        deviating: dict = {}
        without_valid_branch: set = set()
        invalid = find_invalid_nx_contingencies(
            references, all_zero_contingencies, self.lf_nx, self.branch_sides, unreferenced_out=unreferenced,
            deviating_out=deviating, absolute_floor_ampere=sensitivity_checks.ABSOLUTE_FLOOR_AMPERE, apply_global_rule=False,
            without_valid_branch_out=without_valid_branch, **_guard_tolerance(self.dc_converter),
        )
        self.invalid.update(invalid)
        self.considered.update(set(references) | set(all_zero_contingencies))
        self.without_valid_branch.update(without_valid_branch)
        self.drops.extend(sensitivity_checks.apply_guard_drops(self.lf_nx, unreferenced, deviating))

    def _finish_guard(self) -> None:
        if not self.guard:
            return
        if self.without_valid_branch and len(self.without_valid_branch) == len(self.considered):
            self.invalid = {contingency_mrid: NO_VALID_BRANCH for contingency_mrid in sorted(self.considered)}
            sensitivity_checks.restore_guard_drops(self.lf_nx, self.drops)
        else:
            sensitivity_checks.log_guard_drops(self.lf_nx, self.drops, "sensitivity analysis")
        if self.guard_out is not None:
            self.guard_out.clear()
            self.guard_out.update(self.invalid)

    def finish(self) -> dict[str, Mapping[tuple[str, str], float]]:
        """The guard (applied to all contingencies), the totals in the log and the tables in the given contingency order."""
        self.close()
        if self.reference_out is not None:
            self.reference_out.update(self.references)
        sensitivity = {contingency.mrid: self.by_contingency[contingency.mrid] for contingency in self.contingencies}
        written = self.output_path is not None
        if written and self.kind == "pst":
            log.info("Written N-X PST sensitivity CSV: %s", self.output_path)
        if not self.guard_after_logs:
            self._finish_guard()
        secured_branch_count = sum(1 for t in self.branch_ae_types.values() if t == AEType.SECURED)
        scanned_branch_count = sum(1 for t in self.branch_ae_types.values() if t == AEType.SCANNED)
        if self.kind == "pst":
            log.info(
                "compute_sensitivity_pst_nx: N-X PST sensitivity threshold %g %% of the branch limit per tap: "
                "kept %d, dropped %d entries",
                float(self.threshold_pct), self.entries_kept, self.entries_before_threshold - self.entries_kept)
            log.info(
                "compute_sensitivity_pst_nx: computed for %d must-study contingencies, "
                "%d PST(s), %d monitored branch(es) [%d secured, %d scanned] "
                "(post Filter 1 and threshold: %d total (branch, pst) pairs)",
                len(sensitivity), len(self.variable_ids), self.branch_count,
                secured_branch_count, scanned_branch_count, self.entries_kept)
        else:
            if self.zero_units_out is None:                    # not for the HVDC call (no threshold of its own here)
                log.info(
                    "compute_sensitivity_rd_nx: N-X RD sensitivity threshold %g %% of the branch limit per 100 MW: kept %d, "
                    "dropped %d entries", float(self.threshold_pct), self.entries_kept,
                    self.entries_before_threshold - self.entries_kept)
            log.info(
                "compute_sensitivity_rd_nx: computed for %d must-study contingencies, "
                "%d generating unit(s), %d monitored branch(es) [%d secured, %d scanned] "
                "(post Filter 1 and threshold: %d total (branch, gu) pairs)",
                len(sensitivity), len(self.variable_ids), self.branch_count,
                secured_branch_count, scanned_branch_count, self.entries_kept)
        if self.guard_after_logs:
            self._finish_guard()
        if written and self.kind != "pst":
            log.info("Written N-X RD sensitivity CSV: %s", self.output_path)
        return sensitivity


def _run_in_batches(
    network, contingencies: list[Contingency], branch_sides: dict[str, int], readers: list[_NxKindReader],
    contingency_batch_size: Optional[int], use_reactive_limits: bool, extra_lf_params: Optional[dict], dc_converter=None,
    weights: Optional[dict] = None, ct_prune_limits: Optional[dict[str, float]] = None, ct_prune_threshold_pct: float = 0.0,
) -> None:
    """One pypowsybl sensitivity analysis per batch of contingencies, with the variable sets of all readers (and, with
    countertrade weights, compute_ct_nx for the batch); every reader reads its tables from the batch, then the result of
    the batch is released before the next analysis starts. The readers keep the CSV files open until close."""
    variable_sets = [(reader.prefix, reader.variable_ids, reader.variable_type) for reader in readers]
    try:
        for batch in _contingency_batches(contingencies, contingency_batch_size):
            result, matrix_ids_by_prefix = _run_nx_sensitivity_analysis(
                network, batch, branch_sides, variable_sets,
                use_reactive_limits=use_reactive_limits, extra_lf_params=extra_lf_params, dc_converter=dc_converter,
            )
            ct_result = compute_ct_nx(
                network, batch, branch_sides, weights, dc_converter, use_reactive_limits, extra_lf_params,
                ct_prune_limits, ct_prune_threshold_pct,
            ) if weights is not None else None
            for reader in readers:
                reader.read_batch(
                    result, matrix_ids_by_prefix[reader.prefix], batch, ct_result if reader.takes_countertrade else None)
            del result, ct_result
    finally:
        for reader in readers:
            reader.close()


def compute_sensitivity_pst_nx(
    network,
    co_flat_list: list[Contingency],
    pst_list: list[PST],
    ae_flat_list: list[AssessedElement],
    timestamp: str,
    lf_nx: dict[str, dict[str, dict[int, float]]],
    lf_initial: dict[str, dict[int, float]],
    min_loading_threshold_pct_nx: float = 0.0,
    output_path: Optional[Path] = None,
    use_reactive_limits: bool = False,
    extra_lf_params: Optional[dict] = None,
    reference_out: Optional[dict] = None,
    guard_out: Optional[dict] = None,
    dc_converter=None,
    sensitivity_threshold_pct_pst_nx: float = 0.0,
    degrees_per_tap: Optional[Mapping[str, float]] = None,
    contingency_batch_size: Optional[int] = None,
) -> dict[str, dict[tuple[str, str], float]]:
    """N-X PST sensitivities dI/ds per must-study contingency:
    {contingency: {(branch, pst): A per degree}} (the A/tap conversion happens in the builder).
    Variables: preventive and curative available PSTs. Runs with the parameters of compute_lf_nx.
    reference_out: filled with {contingency: {branch: reference current A}}; guard_out: filled with
    {contingency: reason} for the guard failures (before Filter 1). Filter 1 is applied here, and the entries below
    sensitivity_threshold_pct_pst_nx % of the branch limit per tap (|A per degree| x |degrees_per_tap|; None = per degree) are dropped as
    each contingency is read (0 = none). contingency_batch_size: contingencies per pypowsybl analysis (None = one analysis
    for all; the result is the same).
    """
    must_study_contingencies = _get_must_study_contingencies(co_flat_list, timestamp)
    if not must_study_contingencies:
        raise ValueError(f"No must-study contingencies found for timestamp {timestamp}")

    branch_sides = _get_monitored_branch_sides(ae_flat_list)
    if not branch_sides:
        raise ValueError("No monitored branch IDs found in AEFlatList")

    pst_ids = _get_available_pst_ids_nx(pst_list, network=network)
    if not pst_ids:
        raise ValueError("No available PSTs found in PSTList")

    try:
        import pypowsybl as pp
    except Exception as exc:
        raise ImportError("pypowsybl is required to compute sensitivities") from exc

    _contingency_batches([], contingency_batch_size)           # the size is checked before the first analysis
    reader = _NxKindReader(
        "pst", "nx", pst_ids, pp.sensitivity.SensitivityVariableType.TRANSFORMER_PHASE, must_study_contingencies,
        branch_sides=branch_sides, ae_flat_list=ae_flat_list, timestamp=timestamp, lf_nx=lf_nx,
        lf_initial=lf_initial, min_loading_threshold_pct_nx=min_loading_threshold_pct_nx, output_path=output_path,
        reference_out=reference_out, guard_out=guard_out, dc_converter=dc_converter,
        threshold_pct=sensitivity_threshold_pct_pst_nx, degrees_per_tap=degrees_per_tap,
    )
    _run_in_batches(network, must_study_contingencies, branch_sides, [reader], contingency_batch_size, use_reactive_limits,
                    extra_lf_params, dc_converter)
    return reader.finish()


_PST_NX_CSV_HEADER = ["tso", "branch_id", "side", "contingency_id", "pst_id", "sensitivity_a_per_tap"]


def _pst_nx_csv_rows(contingency_mrid, entries, branch_sides, branch_tso, degrees_per_tap):
    """The rows of sensitivity_pst_nx.csv for one contingency, sorted by (branch, PST): A per tap (the table holds A per
    degree; a PST without degrees per tap has no row)."""
    for (branch_mrid, pst_mrid), per_degree in sorted(entries.items()):
        if degrees_per_tap is None or pst_mrid not in degrees_per_tap:
            continue
        yield [
            branch_tso.get(branch_mrid, ""), branch_mrid, branch_sides.get(branch_mrid, 1), contingency_mrid, pst_mrid,
            per_degree * float(degrees_per_tap[pst_mrid]),
        ]


def compute_sensitivity_rd_nx(
    network,
    co_flat_list: list[Contingency],
    rd_list: list[RDUnit],
    ae_flat_list: list[AssessedElement],
    timestamp: str,
    lf_nx: dict[str, dict[str, dict[int, float]]],
    lf_initial: dict[str, dict[int, float]],
    min_loading_threshold_pct_nx: float = 0.0,
    output_path: Optional[Path] = None,
    use_reactive_limits: bool = False,
    extra_lf_params: Optional[dict] = None,
    reference_out: Optional[dict] = None,
    guard_out: Optional[dict] = None,
    dc_converter=None,
    ct_prune_limits: Optional[dict[str, float]] = None,
    ct_prune_threshold_pct: float = 0.0,
    sensitivity_threshold_pct_rd_nx: float = 0.0,
    contingency_batch_size: Optional[int] = None,
) -> dict[str, dict[tuple[str, str], float]]:
    """N-X RD sensitivities dI/dP per must-study contingency:
    {contingency: {(branch, unit): A per MW}}, for preventive and curative available units.
    Filter 1 is applied here, as in compute_sensitivity_pst_nx. The countertrade RAs have one variable per RA and
    direction (compute_ct_nx); ct_prune_limits / ct_prune_threshold_pct: Filter 2 of the units, applied before the sum
    (default: the limits of the assessed elements and sensitivity_threshold_pct_rd_nx). sensitivity_threshold_pct_rd_nx
    (percent of the branch limit per 100 MW): the entries below it are dropped as each contingency is read, so the returned
    table is already pruned. contingency_batch_size: contingencies per pypowsybl analysis (None = one analysis for all; the
    result is the same)."""
    ct_prune_threshold_pct = ct_prune_threshold_pct or sensitivity_threshold_pct_rd_nx
    if ct_prune_limits is None and ct_prune_threshold_pct > 0.0:
        ct_prune_limits = _get_limit_and_ae_type_by_branch_nx(ae_flat_list, timestamp, lf_initial)[0]
    must_study_contingencies = _get_must_study_contingencies(co_flat_list, timestamp)
    if not must_study_contingencies:
        raise ValueError(f"No must-study contingencies found for timestamp {timestamp}")

    branch_sides = _get_monitored_branch_sides(ae_flat_list)
    if not branch_sides:
        raise ValueError("No monitored branch IDs found in AEFlatList")

    gu_ids = _get_available_rd_gu_ids_nx(rd_list)
    weights = ct_sensitivity.ct_weights(rd_list)
    if not gu_ids and not weights:
        raise ValueError("No available RD units found in RDList")

    try:
        import pypowsybl as pp
    except Exception as exc:
        raise ImportError("pypowsybl is required to compute sensitivities") from exc

    _contingency_batches([], contingency_batch_size)           # the size is checked before the first analysis
    reader = _NxKindReader(
        "rd", "nx", gu_ids, pp.sensitivity.SensitivityVariableType.INJECTION_ACTIVE_POWER, must_study_contingencies,
        branch_sides=branch_sides, ae_flat_list=ae_flat_list, timestamp=timestamp, lf_nx=lf_nx,
        lf_initial=lf_initial, min_loading_threshold_pct_nx=min_loading_threshold_pct_nx, output_path=output_path,
        reference_out=reference_out, guard_out=guard_out, dc_converter=dc_converter,
        threshold_pct=sensitivity_threshold_pct_rd_nx,
    )
    _run_in_batches(network, must_study_contingencies, branch_sides, [reader], contingency_batch_size, use_reactive_limits,
                    extra_lf_params, dc_converter, weights, ct_prune_limits, ct_prune_threshold_pct)
    return reader.finish()


def compute_sensitivities_nx(
    network,
    co_flat_list: list[Contingency],
    pst_list: list[PST],
    rd_list: list[RDUnit],
    ae_flat_list: list[AssessedElement],
    timestamp: str,
    lf_nx: dict[str, dict[str, dict[int, float]]],
    lf_initial: dict[str, dict[int, float]],
    min_loading_threshold_pct_nx: float = 0.0,
    with_pst: bool = True,
    with_rd: bool = True,
    pst_output_path: Optional[Path] = None,
    rd_output_path: Optional[Path] = None,
    ct_output_path: Optional[Path] = None,
    use_reactive_limits: bool = False,
    extra_lf_params: Optional[dict] = None,
    pst_guard_out: Optional[dict] = None,
    rd_guard_out: Optional[dict] = None,
    pst_reference_out: Optional[dict] = None,
    rd_reference_out: Optional[dict] = None,
    dc_converter=None,
    hvdc_ei_mrids: Optional[list[str]] = None,
    hvdc_out: Optional[dict] = None,
    ct_prune_limits: Optional[dict[str, float]] = None,
    ct_prune_threshold_pct: float = 0.0,
    sensitivity_threshold_pct_pst_nx: float = 0.0,
    degrees_per_tap: Optional[Mapping[str, float]] = None,
    sensitivity_threshold_pct_rd_nx: float = 0.0,
    contingency_batch_size: Optional[int] = None,
) -> tuple[dict, dict]:
    """compute_sensitivity_pst_nx (when with_pst) and compute_sensitivity_rd_nx (when with_rd)
    from ONE sensitivity analysis per batch of contingencies with both variable sets (same values as two analyses):
    returns (sensitivity_pst_nx, sensitivity_rd_nx), {} for a kind that is not requested.
    contingency_batch_size: contingencies per pypowsybl analysis (None = one analysis for all). pypowsybl keeps the
    result of every contingency of an analysis until it is released: with a batch the result is read, filtered and
    released before the next analysis, which lowers the peak memory. The tables, the guard, the pairs left out and the
    log totals are those of one analysis (the pairs the guard leaves out of lf_nx are put back when it declares every
    contingency invalid, as there).
    dc_converter (calculation_mode dc): one DC analysis; the sensitivities are converted to A per
    unit by dc_converter (dc_conversion). None = the AC analysis.
    hvdc_ei_mrids (HVDC RAs, docs/specs/hvdc_ra_specs.md H8): the EIs of the available HVDC units (preventive
    and curative) are a third variable set of the same analysis (INJECTION_ACTIVE_POWER, like RD).
    Their result goes to hvdc_out, which is cleared and filled with "sensitivity" ({contingency:
    {(branch, EI): A per MW}}, Filter 1 applied), "zero_units" ({contingency: [EI]} of units whose
    sensitivities are all exactly zero there, H8.2: the group is unavailable in it) and "guard" ({contingency:
    reason} of the reference check, only computed here when neither PST nor RD is requested; otherwise
    the PST / RD guards cover the same references). The return value is unchanged.
    ct_prune_limits / ct_prune_threshold_pct: as in compute_sensitivity_rd_nx. sensitivity_threshold_pct_pst_nx: the PST
    entries below it are dropped as each contingency is read (the returned PST table is already pruned).
    sensitivity_threshold_pct_rd_nx (percent of the branch limit per 100 MW): the same for the RD table and, before the
    sum, for the countertrade units (the HVDC table is pruned by the caller)."""
    if not with_pst and not with_rd and not hvdc_ei_mrids:
        return {}, {}
    ct_prune_threshold_pct = ct_prune_threshold_pct or sensitivity_threshold_pct_rd_nx
    if ct_prune_limits is None and ct_prune_threshold_pct > 0.0:
        ct_prune_limits = _get_limit_and_ae_type_by_branch_nx(ae_flat_list, timestamp, lf_initial)[0]
    must_study_contingencies = _get_must_study_contingencies(co_flat_list, timestamp)
    if not must_study_contingencies:
        raise ValueError(f"No must-study contingencies found for timestamp {timestamp}")
    branch_sides = _get_monitored_branch_sides(ae_flat_list)
    if not branch_sides:
        raise ValueError("No monitored branch IDs found in AEFlatList")
    pst_ids = _get_available_pst_ids_nx(pst_list, network=network) if with_pst else []
    if with_pst and not pst_ids:
        raise ValueError("No available PSTs found in PSTList")
    gu_ids = _get_available_rd_gu_ids_nx(rd_list) if with_rd else []
    weights = ct_sensitivity.ct_weights(rd_list) if with_rd else {}
    if with_rd and not gu_ids and not weights:
        raise ValueError("No available RD units found in RDList")
    try:
        import pypowsybl as pp
    except Exception as exc:
        raise ImportError("pypowsybl is required to compute sensitivities") from exc

    _contingency_batches([], contingency_batch_size)           # the size is checked before the first analysis
    common = dict(
        branch_sides=branch_sides, ae_flat_list=ae_flat_list, timestamp=timestamp, lf_nx=lf_nx,
        lf_initial=lf_initial, min_loading_threshold_pct_nx=min_loading_threshold_pct_nx, dc_converter=dc_converter,
    )
    injection = pp.sensitivity.SensitivityVariableType.INJECTION_ACTIVE_POWER
    pst_reader = _NxKindReader(
        "pst", "nx_pst", pst_ids, pp.sensitivity.SensitivityVariableType.TRANSFORMER_PHASE, must_study_contingencies,
        output_path=pst_output_path, reference_out=pst_reference_out, guard_out=pst_guard_out,
        threshold_pct=sensitivity_threshold_pct_pst_nx, degrees_per_tap=degrees_per_tap, **common,
    ) if with_pst else None
    rd_reader = _NxKindReader(
        "rd", "nx_rd", gu_ids, injection, must_study_contingencies, output_path=rd_output_path, ct_output_path=ct_output_path,
        reference_out=rd_reference_out, guard_out=rd_guard_out, threshold_pct=sensitivity_threshold_pct_rd_nx, **common,
    ) if with_rd else None
    hvdc_ids = sorted({str(e) for e in hvdc_ei_mrids}) if hvdc_ei_mrids else []
    zero_units: dict = {}
    hvdc_reader = _NxKindReader(
        "hvdc", "nx_hvdc", hvdc_ids, injection, must_study_contingencies, guard=not with_pst and not with_rd,
        guard_all_zero=False, zero_units_out=zero_units, **common,
    ) if hvdc_ids else None
    readers = [reader for reader in (pst_reader, rd_reader, hvdc_reader) if reader is not None]
    _run_in_batches(network, must_study_contingencies, branch_sides, readers, contingency_batch_size, use_reactive_limits,
                    extra_lf_params, dc_converter, weights, ct_prune_limits, ct_prune_threshold_pct)
    sensitivity_pst_nx = pst_reader.finish() if pst_reader is not None else {}
    sensitivity_rd_nx = rd_reader.finish() if rd_reader is not None else {}
    if hvdc_reader is not None:
        sensitivity_hvdc_nx = hvdc_reader.finish()
        guard = dict(hvdc_reader.invalid) if hvdc_reader.guard else {}
        if zero_units:
            log.warning(
                "HVDC sensitivities exactly zero (unit unavailable in that contingency, its group with it): %s",
                "; ".join(f"{co}: {units}" for co, units in sorted(zero_units.items())),
            )
        if hvdc_out is not None:
            hvdc_out.clear()
            hvdc_out.update(sensitivity=sensitivity_hvdc_nx, zero_units=zero_units, guard=guard)
    return sensitivity_pst_nx, sensitivity_rd_nx


# ---------------------------------------------------------------------------
# Filter 2 (sensitivity magnitude pruning)
# ---------------------------------------------------------------------------


def _prune_by_magnitude(
    sensitivity_nx: dict[str, Mapping[tuple[str, str], float]],
    limit_by_branch: dict[str, float],
    threshold_pct: float,
    degrees_per_tap: Optional[Mapping[str, float]] = None,
    per_mw_basis: float = 1.0,
) -> dict[str, Mapping[tuple[str, str], float]]:
    """Filter 2 of both kinds: drop an entry if |value| x basis < threshold_pct * limit_by_branch[branch] / 100; a branch
    without a limit (or <= 0) is dropped with all its entries. The countertrade variables are not pruned by entry: their
    units were pruned before the sum (compute_ct_nx). degrees_per_tap (PST): the value is first multiplied by the
    |degrees per tap| of its variable (the effect of one tap); a variable without one is kept. per_mw_basis: the MW the
    effect is taken over (RD: 100, so the threshold is in percent of the limit per 100 MW); 1 for the PST kinds."""
    def scale(variable) -> float:
        return per_mw_basis * (1.0 if degrees_per_tap is None else abs(float(degrees_per_tap.get(str(variable), float("nan")))))

    def threshold_ampere(branch_mrid: str) -> float:
        return float(threshold_pct) * limit_by_branch[branch_mrid] / 100.0

    def has_limit(branch_mrid: str) -> bool:
        limit_ampere = limit_by_branch.get(branch_mrid)
        return bool(limit_ampere) and limit_ampere > 0.0

    pruned: dict[str, Mapping[tuple[str, str], float]] = {}
    for contingency_mrid, per_branch_ra in sensitivity_nx.items():
        if isinstance(per_branch_ra, SensitivityTable):
            pruned[contingency_mrid] = per_branch_ra.restricted_to_branches(has_limit).without_entries_below(
                threshold_ampere, exempt=lambda variable: variable.startswith(ct_sensitivity.CT_VARIABLE_PREFIX),
                scale_by_variable=None if degrees_per_tap is None and per_mw_basis == 1.0 else scale)
            continue
        pruned_for_contingency: dict[tuple[str, str], float] = {}
        for (branch_mrid, element_mrid), value in per_branch_ra.items():
            limit_ampere = limit_by_branch.get(branch_mrid)
            if not limit_ampere or limit_ampere <= 0.0:
                continue
            if abs(value) * scale(element_mrid) < float(threshold_pct) * limit_ampere / 100.0 and not str(element_mrid).startswith(ct_sensitivity.CT_VARIABLE_PREFIX):
                continue
            pruned_for_contingency[(branch_mrid, element_mrid)] = value
        pruned[contingency_mrid] = pruned_for_contingency
    return pruned


def prune_sensitivity_rd_nx(
    sensitivity_rd_nx: dict[str, Mapping[tuple[str, str], float]],
    limit_by_branch: dict[str, float],
    sensitivity_threshold_pct_rd_nx: float = 0.0,
    per_mw_basis: float = RD_THRESHOLD_MW,
) -> dict[str, Mapping[tuple[str, str], float]]:
    """Filter 2 for RD: an entry is dropped when |A per MW| x per_mw_basis < sensitivity_threshold_pct_rd_nx * limit / 100,
    i.e. the threshold is in percent of the branch limit per 100 MW (per_mw_basis 100)."""
    return _prune_by_magnitude(sensitivity_rd_nx, limit_by_branch, sensitivity_threshold_pct_rd_nx, per_mw_basis=per_mw_basis)


# ---------------------------------------------------------------------------
# CSV export
# ---------------------------------------------------------------------------

_RD_NX_CSV_HEADER = ["tso", "branch_id", "side", "contingency_id", "unit_id", "sensitivity_a_per_mw"]
_CT_NX_CSV_HEADER = ["tso", "branch_id", "side", "contingency_id", "ra_id", "direction", "sensitivity_a_per_mw"]


def _rd_nx_csv_rows(contingency_mrid, entries, branch_sides, branch_tso):
    """(unit rows, countertrade rows) of one contingency, sorted by (branch, variable): the table holds the units and the
    countertrade variables 'CT|<RA>|<direction>' together."""
    unit_rows, ct_rows = [], []
    for (branch_mrid, variable), sensitivity in sorted(entries.items()):
        head = [branch_tso.get(branch_mrid, ""), branch_mrid, branch_sides.get(branch_mrid, 1), contingency_mrid]
        if str(variable).startswith(ct_sensitivity.CT_VARIABLE_PREFIX):
            _, ra_id, direction = str(variable).split("|", 2)
            ct_rows.append([*head, ra_id, direction, sensitivity])
        else:
            unit_rows.append([*head, variable, sensitivity])
    return unit_rows, ct_rows


