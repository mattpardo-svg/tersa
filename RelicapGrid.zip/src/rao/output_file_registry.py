"""output_file_registry.py

The single place that names the files the pipeline writes into its output folder:
OUTPUT_FILE_REGISTRY (every file name), RENAMED_OUTPUT_FILES (old name -> current name)
and delete_registered_output_files (removes stale files of earlier runs at start).
A test fails if a writer produces a file that is not registered here.
"""

import datetime
import shutil
from pathlib import Path
from typing import Iterable

# Every file name the pipeline can write into its run folder (docs/specs/output_files_specs.md).
OUTPUT_FILE_REGISTRY: list[str] = [
    "assessed_elements.csv",
    "contingencies.csv",
    "generating_units.csv",
    "pst_ra.csv",
    "hvdc_ra.csv",
    "rd_bids.csv",
    "ct_bids.csv",
    "pst_results.csv",
    "rd_results.csv",
    "ct_results.csv",
    "hvdc_results.csv",
    "zone_net_positions.csv",
    "tso_limits.csv",
    "summary.csv",
    "loadings_n0.csv",
    "loadings_nx.csv",                 # N-X on and outputs.write_loadings_nx
    "iterations.csv",                  # ac_iterative only
    "sensitivity_pst_n0.csv",          # the six sensitivity files: outputs.write_sensitivity_csvs
    "sensitivity_rd_n0.csv",
    "sensitivity_ct_n0.csv",
    "sensitivity_pst_nx.csv",
    "sensitivity_rd_nx.csv",
    "sensitivity_ct_nx.csv",
    "run_log.txt",
]

# The log file is (re)opened by the pipeline itself before the cleanup runs.
LOG_FILE_NAME = "run_log.txt"

# Log lines of a run that stopped before its CGM time (and so its folder) was known.
FAILED_LOG_FILE_NAME = "run_log_failed.txt"


def run_folder_name(cgm_time: datetime.datetime) -> str:
    """Folder of a run: the CGM time in UTC as YYYYMMDDTHHMMZ."""
    if cgm_time.tzinfo is None:
        raise ValueError("the CGM time needs a time zone")
    return cgm_time.astimezone(datetime.timezone.utc).strftime("%Y%m%dT%H%MZ")


def empty_run_folder(run_dir: Path) -> int:
    """Create the run folder, or empty it when it exists (files and subfolders inside it only).
    Returns the number of entries removed."""
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    removed = 0
    for entry in run_dir.iterdir():
        if entry.is_dir() and not entry.is_symlink():
            shutil.rmtree(entry)
        else:
            entry.unlink()
        removed += 1
    return removed
