"""src/rao_pages/_output_widgets.py

The Streamlit side of the run view: the output files of the run folder of a CGM time as tabs (summary, results, loadings,
inputs, debug files). The reading is in _output_view.py. Column names are shown as they are in the files, with their
units; a file that the run did not write shows "not written in this run" and is not an error.
"""

from __future__ import annotations

import io
import zipfile
from pathlib import Path
from typing import Optional

import _output_view as view


def _show_file(st, run_folder: Optional[Path], name: str, title: str) -> None:
    import pandas as pd
    from _gui_common import TEXT_ENCODING

    st.markdown(f"**{title}** (`{name}`)")
    rows, message = view.read_output_file(run_folder, name)
    if rows is None:
        st.info(message)
        return
    table = pd.read_csv(Path(run_folder) / name, encoding=TEXT_ENCODING, keep_default_na=False)
    if table.empty:
        st.caption("no rows in this run")
    else:
        st.dataframe(table, width="stretch")
    st.download_button(f"Download {name}", data=(Path(run_folder) / name).read_bytes(), file_name=name, key=f"dl_{name}")


def render_run(st, run_folder: Optional[Path], message: str) -> None:
    """The run folder of the selected CGM time. message: why there is no folder (see view.find_run_folder)."""
    if run_folder is None:
        st.info(message)
        return
    st.caption(f"Files of output/{run_folder.name}/")
    tabs = st.tabs(list(view.FILE_GROUPS))
    for tab, (group, files) in zip(tabs, view.FILE_GROUPS.items()):
        with tab:
            for name, title in files:
                _show_file(st, run_folder, name, title)
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        for path in view.files_in(run_folder):
            archive.write(path, arcname=path.name)
    st.download_button(
        "Download all files of this run (.zip)", data=buffer.getvalue(), file_name=f"{run_folder.name}.zip",
        mime="application/zip", key="dl_run_zip",
    )
    log_path = run_folder / "run_log.txt"
    if log_path.is_file():
        with st.expander("Run log"):
            from _gui_common import TEXT_ENCODING
            st.code(log_path.read_text(encoding=TEXT_ENCODING), language=None)
