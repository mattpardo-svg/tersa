"""src/rao_pages/_output_view.py

What the GUI shows of a run: the run folder of a CGM time and the output files in it (docs/specs/output_files_specs.md).
Plain Python without Streamlit calls, so every function can be tested on its own. The pages call render_run() of
_output_widgets.py, which uses these functions.

A run writes output/<CGM time>/ with the CGM time in UTC as YYYYMMDDTHHMMZ. The GUI reads the scenario time from the
header of the CGM package (no network is loaded), so the folder of a CGM is known before and after a run. A file is only
written when its feature was on in the run: a missing file is a normal case, not an error.
"""

from __future__ import annotations

import csv
import datetime
import importlib.util
import io
import re
import zipfile
from collections import Counter
from pathlib import Path
from typing import Optional

MESSAGE_NO_RUN = "no run for this CGM time yet"
MESSAGE_NOT_WRITTEN = "not written in this run"
MESSAGE_NO_SCENARIO_TIME = "the CGM has no scenario time in its header"

_SCENARIO_TIME = re.compile(rb"scenarioTime[^>]*>\s*([^<\s]+)\s*<")
_HEADER_BYTES = 8000                    # the model header is at the start of every CGMES file

# the output files by group: (file name, title)
FILE_GROUPS: dict[str, list[tuple[str, str]]] = {
    "Summary": [("summary.csv", "Summary of the run")],
    "Results": [
        ("pst_results.csv", "PST results"), ("rd_results.csv", "Redispatch results"),
        ("ct_results.csv", "Countertrade results"), ("hvdc_results.csv", "HVDC results"),
        ("zone_net_positions.csv", "Zone net positions"), ("tso_limits.csv", "TSO limits"),
    ],
    "Loadings": [("loadings_n0.csv", "Loadings N-0"), ("loadings_nx.csv", "Loadings N-X")],
    "Inputs": [
        ("assessed_elements.csv", "Assessed elements"), ("contingencies.csv", "Contingencies"),
        ("generating_units.csv", "Generating units"), ("pst_ra.csv", "PST remedial actions"),
        ("rd_bids.csv", "Redispatch bids"), ("ct_bids.csv", "Countertrade bids"), ("hvdc_ra.csv", "HVDC remedial actions"),
    ],
    "Debug": [
        ("iterations.csv", "Iterations"),
        ("sensitivity_pst_n0.csv", "Sensitivities PST N-0"), ("sensitivity_rd_n0.csv", "Sensitivities redispatch N-0"),
        ("sensitivity_ct_n0.csv", "Sensitivities countertrade N-0"), ("sensitivity_pst_nx.csv", "Sensitivities PST N-X"),
        ("sensitivity_rd_nx.csv", "Sensitivities redispatch N-X"), ("sensitivity_ct_nx.csv", "Sensitivities countertrade N-X"),
    ],
}


def scenario_time_from_cgm(zip_bytes: bytes) -> Optional[datetime.datetime]:
    """The scenario time (UTC) of a CGM package, read from the model headers of its files without loading the network.
    The time of the state-variable file when the package has one, else the most common time of the files. None when no file
    has one or the zip cannot be read."""
    found: list[tuple[str, datetime.datetime]] = []
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
            for name in archive.namelist():
                if not name.lower().endswith(".xml"):
                    continue
                with archive.open(name) as handle:
                    match = _SCENARIO_TIME.search(handle.read(_HEADER_BYTES))
                if match is None:
                    continue
                try:
                    text = match.group(1).decode("ascii").replace("Z", "+00:00")
                    moment = datetime.datetime.fromisoformat(text)
                except ValueError:
                    continue
                if moment.tzinfo is None:
                    moment = moment.replace(tzinfo=datetime.timezone.utc)
                found.append((name, moment.astimezone(datetime.timezone.utc)))
    except zipfile.BadZipFile:
        return None
    if not found:
        return None
    state_variables = [moment for name, moment in found if re.search(r"_SV_", name, re.IGNORECASE)]
    if state_variables:
        return state_variables[0]
    return Counter(moment for _, moment in found).most_common(1)[0][0]


# the name of the run folder of a CGM time (UTC, YYYYMMDDTHHMMZ) is the one rule of the pipeline, loaded by file path
# because the GUI does not put src/rao on sys.path
_registry_spec = importlib.util.spec_from_file_location(
    "rao_output_file_registry", Path(__file__).resolve().parents[1] / "rao" / "output_file_registry.py")
_registry = importlib.util.module_from_spec(_registry_spec)
_registry_spec.loader.exec_module(_registry)
run_folder_name = _registry.run_folder_name


def find_run_folder(output_root: Path, moment: Optional[datetime.datetime]) -> tuple[Optional[Path], str]:
    """(run folder, message): the folder output/<CGM time>/ when it exists, else None and the reason."""
    if moment is None:
        return None, MESSAGE_NO_SCENARIO_TIME
    folder = Path(output_root) / run_folder_name(moment)
    if not folder.is_dir():
        return None, f"{MESSAGE_NO_RUN} ({folder.name})"
    return folder, ""


def read_output_file(run_folder: Optional[Path], name: str) -> tuple[Optional[list[dict]], str]:
    """(rows, message) of one output file; rows None with the message "not written in this run" when the file is not there
    (the feature was off) or there is no run folder. The columns are those of the file, in its order, with their units."""
    if run_folder is None or not (Path(run_folder) / name).is_file():
        return None, MESSAGE_NOT_WRITTEN
    from _gui_common import TEXT_ENCODING                    # the one encoding rule of the pipeline and the GUI
    with open(Path(run_folder) / name, newline="", encoding=TEXT_ENCODING) as handle:
        return list(csv.DictReader(handle)), ""


def read_header(run_folder: Optional[Path], name: str) -> list[str]:
    """The column names of an output file, in order (empty when the file is not there)."""
    if run_folder is None or not (Path(run_folder) / name).is_file():
        return []
    from _gui_common import TEXT_ENCODING
    with open(Path(run_folder) / name, newline="", encoding=TEXT_ENCODING) as handle:
        return next(csv.reader(handle), [])


def files_in(run_folder: Optional[Path]) -> list[Path]:
    """The files of a run folder, sorted by name."""
    if run_folder is None:
        return []
    return sorted(p for p in Path(run_folder).iterdir() if p.is_file())
