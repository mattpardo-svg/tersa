"""src/rao_pages/3_RAO_Settings.py

RAO settings: every key of src/rao/config/rao_config.yaml, section by section, with the comment of the file as help text.
Saving writes the file itself and keeps every comment and every key the page does not change; the values are checked by
the pipeline's own config check (run_pipeline.validate_config_ranges) before anything is written. Does NOT call
st.set_page_config()/st.logo() — already called once, globally, in the platform's own app.py.
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _gui_common as gc

# the settings the one-pass modes (ac_single_pass, dc) ignore
LOOP_SETTINGS = {
    ("thresholds", "max_change_ra_sum_threshold"), ("thresholds", "max_change_ra"), ("thresholds", "max_change_overload"),
    ("iteration_caps", "max_linearisation_iterations"), ("iteration_caps", "max_completeness_iterations"),
}
INTEGER_WHEN_NULL = {"max_ra_count_per_timestamp_tso"}       # a key that is null in the file and is a whole number when set
RA_TYPE_OPTIONS = ["pst", "rd", "hvdc", "countertrade"]

st.write("# RAO Settings")
st.caption(
    "The keys of src/rao/config/rao_config.yaml. Saving writes that file: its comments and the keys this page does not "
    "change stay as they are."
)

config_text = gc.RAO_CONFIG_PATH.read_text(encoding=gc.TEXT_ENCODING)
fields = gc.config_fields(config_text)
settings = gc.load_settings()
for note in settings["notes"]:
    st.warning(note)
# ac_single_pass and dc ignore the iteration caps and the convergence thresholds (chosen on the Main page; read from
# the non-widget key, which survives the page change)
selected_mode = gc.selected_calculation_mode(st.session_state, settings["rao_config"]["workflow_toggles"])
single_pass = gc.ignores_loop_settings(selected_mode)
if single_pass:
    st.info(
        f"Calculation mode {selected_mode}: the linearisation and completeness caps and the convergence "
        "thresholds are ignored (the incremental fallback steps still apply)."
    )

new_values: dict = {}
shown: list[str] = []
current_section = None
for field in fields:
    section, key, value, help_text = field["section"], field["key"], field["value"], field["help"] or None
    if section != current_section:
        st.subheader(section)
        current_section = section
    widget_key = f"config.{section}.{key}"
    shown.append(f"{section}.{key}")
    disabled = single_pass and (section, key) in LOOP_SETTINGS
    if section == "workflow_toggles" and key == "ra_types":
        new_values[(section, key)] = st.multiselect(key, RA_TYPE_OPTIONS, default=list(value), help=help_text, key=widget_key)
    elif key == "calculation_mode":
        options = gc.CALCULATION_MODE_OPTIONS
        new_values[(section, key)] = st.selectbox(
            key, options, index=options.index(value) if value in options else 0, help=help_text, key=widget_key,
        )
    elif isinstance(value, bool):
        new_values[(section, key)] = st.toggle(key, value=value, help=help_text, key=widget_key)
    elif value is None:
        if st.checkbox(f"set {key}", value=False, help=help_text, key=widget_key + ".set"):
            if key in INTEGER_WHEN_NULL:
                new_values[(section, key)] = int(st.number_input(key, value=1, step=1, key=widget_key))
            else:
                new_values[(section, key)] = float(st.number_input(key, value=0.0, format="%g", key=widget_key))
        else:
            new_values[(section, key)] = None
    elif isinstance(value, int):
        new_values[(section, key)] = int(st.number_input(key, value=value, step=1, disabled=disabled, help=help_text, key=widget_key))
    elif isinstance(value, float):
        new_values[(section, key)] = float(st.number_input(
            key, value=value, format="%g", disabled=disabled, help=help_text, key=widget_key,
        ))
    elif isinstance(value, str):
        new_values[(section, key)] = st.text_input(key, value=value, help=help_text, key=widget_key)
    else:
        # a list or a table: shown as in the file, edited in the file
        st.markdown(f"**{key}**", help=help_text)
        st.code(yaml.safe_dump(value, default_flow_style=False).rstrip(), language="yaml")
        new_values[(section, key)] = value
st.session_state["config_keys_shown"] = shown

st.divider()

if st.button("Save settings", type="primary"):
    original = {(f["section"], f["key"]): f["value"] for f in fields}
    changes = {k: v for k, v in new_values.items() if v != original[k]}
    candidate = yaml.safe_load(config_text)
    for (section, key), value in changes.items():
        candidate[section][key] = value
    problems = gc.validate_rao_config(candidate)
    if problems:
        for problem in problems:
            st.error(problem)
    else:
        gc.save_rao_config(changes)
        st.success(f"RAO Settings saved ({len(changes)} value(s) changed).")
