import streamlit as st
from PIL import Image
from pathlib import Path


# Script-relative, not CWD-relative — found directly from a real failure:
# the original ".\src\images\..." path only resolved correctly when the
# command was launched from one specific working directory, and broke
# silently otherwise. Path(__file__).resolve().parent always finds
# app.py's own directory regardless of where `streamlit run` is invoked
# from — same fix pattern already used throughout this project's own
# GUI code (_gui_common.py) for exactly this reason.
_IMAGES_DIR = Path(__file__).resolve().parent / "images"
sidebar_logo = Image.open(_IMAGES_DIR / "TSCNET_Logo_Medium.png")
main_body_logo = Image.open(_IMAGES_DIR / "TSCNET_Full_Logo_3400px.png")

st.set_page_config(
    page_title="RAO Prototype",
    page_icon=sidebar_logo,
    layout="wide", # Layout options: "centered" or "wide"
    initial_sidebar_state="expanded", # Sidebar state: "auto", "expanded", or "collapsed"
    menu_items={
    'Get Help': 'https://www.example.com/help',
    'Report a Bug': 'https://www.example.com/bug',
    'About': "# Welcome to the RAO Prototype\nRemedial action optimiser"
    }
)

st.logo(sidebar_logo, size="large", icon_image=main_body_logo)

pages = {
    "RAO": [
        st.Page("rao_pages/1_Main.py", title="Main"),
        st.Page("rao_pages/2_Load_Flow_Settings.py", title="Load Flow Settings"),
        st.Page("rao_pages/3_RAO_Settings.py", title="RAO Settings"),
    ]
}

pg = st.navigation(pages, expanded=False)
pg.run()

st.divider()
st.caption("Prototype developed by TSCNET Services GmbH")



