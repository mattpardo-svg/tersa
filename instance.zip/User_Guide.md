# User Guide

A plain-language guide to running this pipeline and understanding its output. For decisions and assumptions behind the code, see `DECISIONS.md` and `ASSUMPTIONS.md` in this folder.

---

## What this pipeline does

Given a network model and a set of TSO-submitted remedial-action data, it decides how to move phase-shifting transformers (PSTs), redispatch generation (RD), shift generation inside bidding zones (countertrade) and move the active-power set points of HVDC links to resolve overloads — both under normal conditions and, optionally, under a list of contingencies (N-X security analysis) — at the lowest total penalty cost.

## Running it

```bash
python src/rao/run_pipeline.py
```

Reads its configuration from two required YAML files (below), reads the network and remedial-action data from `input/`, and writes every output file to `output/<CGM time>/` (see Output folder).

### Input folder

`input/` (in the repo root) must contain exactly one CGM zip and exactly one NCP zip. A file counts as the CGM zip if its name starts with `cgm`, and as the NCP zip if it starts with `ncp` (upper or lower case, `.zip`), e.g. `cgm.zip` and `NCP_sample_generic_2_4.zip`. Zero or several matches stop the run with a clear message. The zips are unpacked to `input/_extracted_cgm` and `input/_extracted_ncp`. The NCP files of a profile are read as one pool, whatever the TSO named in their header or file name, so the files of several TSOs may sit under one creator; the same object id in two files of a profile stops the run with an error naming both files. The TSO of an assessed element or a remedial action is its operator in the file (an EIC, or an id that the Organisation file resolves); without one it is the TSO of the file. Per-TSO settings and the TSO columns of the outputs use that TSO. The log has one line per profile with the files read and the objects per TSO.

### Output folder

Every run writes into its own folder `output/<CGM time>/`: the scenario time of the CGM in UTC as `YYYYMMDDTHHMMZ`, for example `output/20250506T0030Z/`. The folder holds every output file of the run and `run_log.txt`. A rerun with the same CGM time empties that folder before the run starts and fills it again; no other folder in `output/` is touched. A CGM without a scenario time stops the run. A run that stops before the CGM time is known writes the log lines it has to `output/run_log_failed.txt`. Runs go one after the other, not at the same time.

---

## Configuration

Two files, both required — the pipeline will not start without them:

### `src/rao/config/rao_config.yaml`

Grouped into the sections below:

- **`workflow_toggles`** — `calculation_mode` and `ra_types` (see "Calculation mode and RA types" below), whether contingency (N-X) analysis runs at all, and a few lower-level solve behaviors.
- **`thresholds`** — cutoffs for which branches get modeled at all, and how tightly the solver has to converge before it stops iterating. `sensitivity_threshold_pct_rd_nx` (N-X, redispatch and countertrade; unit: percent of the branch limit per 100 MW, so an entry whose effect of 100 MW is below it is dropped as each contingency is read, in every calculation mode; 0.0 drops nothing) is the same key for countertrade, judged per unit before the sum. `milp_limit_factor_patl`, `milp_limit_factor_tatl` and `milp_limit_factor_scanned` (default 1.0, number with 0 < factor <= 1) put a margin on the limits inside the MILP only (see below).
- **`iteration_caps`** — how many times the two internal solve loops are allowed to repeat before giving up (ignored by `ac_single_pass`, except `incremental_ac_fallback_max_steps`).
- **`ra_limits`** — optional per-TSO caps on how many remedial actions can be used at once. The run uses one timestamp, the CGM scenario time; the per-timeframe key `max_ra_count_per_timeframe_tso` was removed, and a config that still sets it to a value gets one warning "no longer used, ignored".
- **`penalty_costs`** — the cost weights the solver uses to decide what's "worth" doing. None of these are finalized real-world values — every one is explicitly marked as a placeholder in the file itself.
- **`bids`** - `default_price_eur_per_mwh` (EUR per MWh, number >= 0, default 0.0): the price of a redispatch or countertrade bid that has a volume but no price at the run time (no price on its time point, or no time point there). One warning per file gives the count, the price used and the first 5 ids.
- **`lead_time`** - `decision_point_hours_before_run` (hours, number >= 0, default 1.0): the time between the decision point and the run time (it may fall on the previous day). A redispatch or countertrade bid, preventive or curative, is usable when its lead time is shorter than this distance (strict: a lead time that ends exactly at the run time blocks the bid); a blocked bid has its volume bounds fixed to 0. One INFO line per run and scope gives the decision point, the count of blocked bids, the first 5 ids (all at DEBUG). `rd_bids.csv` and `ct_bids.csv` list only the usable bids (the lead time of each is in `lead_time_h`); the blocked ones are in the log.
- **`nx_sensitivity`** - `contingency_batch_size` (integer >= 1, default 200): contingencies per pypowsybl analysis in the N-X sensitivity step (PST, redispatch, countertrade units, HVDC). pypowsybl keeps the result of every contingency of an analysis until it is released; with a batch the result is read, filtered and released before the next analysis, so the peak memory falls with the batch size. The result is the same as with one analysis; each batch costs one more base-case solve. A value at or above the number of contingencies is one analysis.
- **`nx_sensitivity.contingency_min_loading_pct`** (number >= 0, default 0 = off): with a value above 0 the N-X sensitivities and N-X rows of the MILP are made only for the contingencies where at least one monitored branch side has, after the contingency, a loading (N-X security analysis) of at least that percentage of its reduced limit and higher than its N-0 loading by at least `nx_sensitivity.contingency_min_increase_pct` percentage points. The reduced limits, for the N-0 and the post-contingency loading alike, are PATL x `milp_limit_factor_patl` and TATL x `milp_limit_factor_tatl` (the smaller) for a secured branch and PATL x `milp_limit_factor_scanned` for a scanned one. A contingency that is not selected stays in the N-X security analysis, the final AC check and `loadings_nx.csv`, but has no N-X sensitivities and no N-X constraints. In `ac_iterative` a contingency that is not selected and overloads at the AC state is selected from the next iteration on. The log has one line with the selected and not selected contingencies and, after the run, the overloads of the final AC check that occur in contingencies that were not selected (count and total A).
- **`nx_sensitivity.contingency_min_increase_pct`** (number >= 0, default 1.0, percentage points; used only with `contingency_min_loading_pct` above 0): the minimum by which the loading of a branch side after a contingency must exceed its N-0 loading for the side to select the contingency, so a side that is already loaded in N-0 and not raised by the contingency does not select it. The selection log line gives both values and the contingencies selected by secured and by scanned branch sides.
- **`nx_sensitivity.countertrade_weighted_variables`** (true / false, default false): false computes each countertrade RA and direction from one pypowsybl variable per generating unit and sums them with the weights; true makes it one pypowsybl weighted variable set per RA and direction (fewer variables, less memory in the N-X sensitivity step). The values are the same, except that pypowsybl leaves a member that is out of service in a contingency (islanded by it) out of the set and renormalises the weights, which the weighted sum does not; so the contingencies that trip a unit of the RA, a unit that is disconnected in the network and the sensitivity thresholds above 0 keep the per-unit variables, and the default stays false.
- **`curative_ra`** — how a curative PST group is treated when one of its members is itself an outage element of a contingency (`blockedGroup` or `reducedGroup`, optionally per TSO). `tatl_fallback_duration_s` (seconds, integer >= 1, default 600) is the TATL duration of a branch side without a TATL in the CGM; `tatl_fallback_factor` (number >= 1, default 1.0) sets its TATL value: TATL = PATL x factor. With 1.0 the TATL equals the PATL and the side gets no TATL constraint; with a factor above 1 it gets one against PATL x factor. TATLs from the CGM (the longest of several, raised to the PATL when below it) are not changed. The log gives the number of branch sides with a fallback TATL and the number of TATL constraints added.
- **`logging_options`** — `debug_log_mode`: how much INFO-level detail is logged. Warnings are never hidden.
- **`performance`** — `lf_thread_count` (threads of the N-X security and sensitivity analyses, default 1), `solver_time_limit_seconds` and `solver_mip_rel_gap` (HiGHS time limit per solve and MIP gap, default null = not set). A solve stopped at the time limit ends the run with the status `SOLVER_NON_OPTIMAL`.
- **`nx_constraint_filter`** — `enabled` (default true) leaves out N-X flow rows (PATL, TATL, scanned) that can never bind, with their slack variables; the result is the same, the model is smaller. `margin_ampere` (default 1.0, >= 0) is the margin kept between the largest possible flow and the limit. A log line per build gives the rows considered, added and skipped.
- **`sensitivity_guard`** — `absolute_floor_ampere` (default 5.0, number >= 0): a pair deviates only when its relative gap exceeds the tolerance (1 %, DC 5 %) and its absolute gap exceeds this value; `max_dropped_share` (default 0.01, 0 to 1): the run stops when more than this share of all monitored (branch, contingency) pairs was left out by the guard. See the sensitivity guard paragraph under the DC mode.
- **`outputs`** — `loadings_n0_min_loading_pct` and `loadings_nx_min_loading_pct` (percent, number >= 0, default 80): `loadings_n0.csv` and `loadings_nx.csv` list a branch side, or a branch side and contingency, when its loading before any remedial action or after them is at least that percent of its limit; `write_loadings_nx` (default true): false does not write `loadings_nx.csv`; `write_sensitivity_csvs` (default false): true writes the six `sensitivity_{pst,rd,ct}_{n0,nx}.csv` files, the N-X ones with one row per contingency, branch and remedial action (tens of GB on a real-size network). `thresholds.sensitivity_threshold_pct_pst_nx` drops the N-X PST sensitivities whose effect per tap (A per degree x degrees per tap of the PST) is below that percentage of the branch limit while they are read, in every calculation mode; `sensitivity_threshold_pct_pst` is the same for the N-0 PST sensitivities (unit for both: percent of the branch limit per tap). The RD and countertrade thresholds are in A per MW. The sensitivity files are in A per tap and A per MW.
- **`dc_mode`** — used by `calculation_mode: dc` only: `current_factor_by_nominal_voltage_kv`, the correction factors of the DC currents by nominal voltage (see "DC mode" below).

Details of some keys (the comments in the file are short, the GUI shows them as help text):

- **Convergence of the linearisation loop** (`thresholds`): the loop stops as soon as any one criterion holds, after the solution was applied and its load flow converged. Besides these there are `max_linearisation_iterations` and the cyclic-repetition exit. (1) `max_change_ra_sum_threshold`: the sum over PSTs of the absolute tap change and, separately, the sum over generating units of the absolute MW change of the last solve are both below this number (the functional spec adds the two in one value; that is not built). (2) `max_change_ra`: the largest tap change and the largest unit change are below this number; it is also the tolerance of the cyclic-repetition exit (the cumulative solution after iteration k is compared with those after iterations 0 to k-2; if the largest difference to one of them is below the value the loop stops with `CYCLIC_REPETITION` and keeps the last applied state). (3) `max_change_overload` (ampere): the sum over the monitored elements of the absolute change of `max(0, I - limit)` between two iterations, on the AC state; the elements are the N-0 branches and the (branch, contingency) pairs of the N-X PATL and TATL rows (for these, the current plus the linearised effect of the curative actions). It is not evaluated when the N-X load flow of the applied state could not be computed. The spec gives no numeric default; 1.0 is a starting value.
- **`scanned_element_constraint_hard`**: a base-case overload on a scanned element is the only overload with a hard mode. When it is true and no action can bring an already overloaded scanned element under its limit, the whole solve can be infeasible. When it is false a slack variable is penalised with `scanned_element_penalty_eur_per_a`. Every other overload type is always soft.
- **MILP margin on the limits** (`thresholds.milp_limit_factor_*`): the MILP rows are built against limit x factor, so the solution keeps a distance to the limit that the linearisation cannot guarantee. `milp_limit_factor_patl` applies to the N-0 and N-X PATL rows, `milp_limit_factor_tatl` to the N-X TATL rows, `milp_limit_factor_scanned` to the N-0 and N-X rows of scanned elements (on their effective limit). The N-X constraint filter uses the same reduced limit, so it never drops a row that can now bind. Everything else keeps the real limit: the final AC check, the output files, the sensitivity thresholds, the overload diagnosis, the convergence check and the loading thresholds (`min_loading_threshold_pct*`, `loadings_*_min_loading_pct`). One INFO line per run gives the three factors. A scanned factor below 1 with `scanned_element_constraint_hard` true logs a warning: the solve can become infeasible. With all three at 1.0 the results are unchanged.
- **`incremental_ac_fallback_max_steps`**: when the direct AC solve of the full MILP change fails, the change is applied in this many intermediate steps, each warm-started from the previous converged state. On the case that needed it, only warm start and steps together converged (2 steps were enough); the log reports how many steps were needed.
- **`penalty_costs`**: the values are placeholders for the objective, not real costs. The cost of a remedial action is its NCP penalty factor (default 1.0) multiplied by the reference value of the config.
- **`debug_log_mode`**: false logs the HiGHS trace and the static per-iteration lines (RD curative-bid split, N-X constraint pair count) once, and repeats them only when the value changes; true logs everything every iteration. The one-line iteration summary and every warning are always shown.

A missing key stops the run with a `ConfigKeyError` that names the key and the file. The removed keys `enable_pst_remedial_actions` and `enable_rd_remedial_actions` stop the run with a message that names `ra_types`. Values are range-checked when the pipeline starts: the thresholds (`min_loading_threshold_pct*`, `sensitivity_threshold_pct_*`, `max_change_ra_sum_threshold`, `max_change_ra`, `max_change_overload`) must be numbers ≥ 0, and `max_linearisation_iterations`, `max_completeness_iterations` and `incremental_ac_fallback_max_steps` must be integers ≥ 1; otherwise the run stops with a message naming the key, the value and the file. A TSO named in `max_taps_per_tso_overrides` that is not a TSO of the run gets a warning, because the entry would be unused.

Every setting has its own explanatory comment directly in the file — that's the authoritative description of what each one does, not this guide.

#### Calculation mode and RA types

Both are in `workflow_toggles`, are independent of each other, and are also chosen per run on the GUI main page.

- **`ra_types`** (default `[pst, rd]`): the remedial action types the optimisation may use. A non-empty list, no duplicates, values `pst`, `rd`, `hvdc` and `countertrade` (see "HVDC remedial actions" and "Countertrade remedial actions" below). Any other value stops the run at startup with a "not yet supported" message, before any file is read. A type that is not listed is not parsed, gets no sensitivities, no MILP block and no output file (for example `pst_ra.csv` and `pst_results.csv` with PST off, and `rd_bids.csv` and `rd_results.csv` with RD off). Its summary metrics are left out. Curative-only RD with N-X on still opens the RD workflow.
- **`ae_contingency_combination`** (default `standard`; also in `workflow_toggles`): `standard` applies `isCombinableWithContingency` and the `AssessedElementWithContingency` links as the profile says (see "Assessed-element switches"). `all_contingencies` combines every assessed element with all must-study contingencies, as if `isCombinableWithContingency` were true (links of kind `included` add nothing, links of kind `excluded` still exclude); it applies to the N-X monitoring, the N-X constraints and the curative availability, and the run log carries one warning when it is active. Any other value stops the run at startup with a `ConfigKeyError`; a config file without the key means `standard`.
- **`calculation_mode`** (default `ac_iterative`):
  - `ac_iterative`: the workflow of the functional specification. Sensitivities are recomputed in the linearisation and completeness loops until they converge.
  - `ac_single_pass`: AC load flow, N-X analysis and sensitivities once at the initial state, one MILP build and solve, one applied solution with its AC load flow, then a final check (N-X security analysis at the applied state and the remaining overloads against PATL and TATL, N-0 and N-X, including the linearised curative effect). The pairs in the model are the ones the first build selects (`min_loading_threshold_pct_nx`, default 0 = all usable pairs); the final check only reports, it adds nothing and starts no second pass. The iteration caps and convergence thresholds are ignored (one log line says so). The linearisation is not refreshed, so overloads can remain that the iterative mode would remove; they are reported. Status `SINGLE_PASS`; if the final load flow does not converge, the original network is reported as in the iterative mode.
  - `dc`: DC load flow, DC N-X security analysis and DC sensitivities (active power only), one MILP build and solve, one applied solution, one final AC check that only reports. The initial AC load flow is not run. A DC load flow that does not converge stops the run. See "DC mode" below.

The summary shows `calculation_mode` and `ra_types`. In `ac_single_pass` and `dc` the final-check rows (`overloaded_branches_n0`, `overload_n0_a`, `overloaded_xnecs_nx`, `overloaded_branches_nx`, `overload_nx_a`, `overloaded_xnecs_scanned`, `overloaded_branches_scanned`, `overload_scanned_a`; counts of overloaded branches or (branch, contingency) pairs and the sum in ampere) describe the applied state; the N-X rows are empty if N-X is off or the N-X load flow of the applied state could not be computed. The N-X metrics cover every pair of the N-X analysis at the applied state, also pairs the model did not hold (for example below `min_loading_threshold_pct_nx`); such pairs are reported, not added to the model.

#### DC mode (`calculation_mode: dc`)

The DC load flow, DC security analysis and DC sensitivities give active power (MW); the model works in ampere against PATL and TATL. Every conversion uses one rule (`pre_milp/dc_conversion.py`):

- Flow: `I = f * |P| * 1000 / (sqrt(3) * V_nom,side * pf)`, with P in MW, V_nom in kV (the nominal voltage of the voltage level on that side of the branch; a transformer has two), `pf` = `dc_power_factor` of `load_flow_config.yaml` (the only power-factor setting, default 1.0, must be > 0) and `f` the correction factor of that nominal voltage.
- Sensitivity: `dI/dx = sign(P_ref) * f * dP/dx * 1000 / (sqrt(3) * V_nom,side * pf)`, in A per degree (PST) or A per MW (redispatch), the units of the AC modes. `P_ref` is the DC reference flow of the same branch side (per contingency for N-X); below 1e-6 MW the sign is +1.
- Correction factors: `dc_mode.current_factor_by_nominal_voltage_kv` in `rao_config.yaml`: `default: 1.0` (required) plus optional entries by nominal voltage in kV, for example `400: 1.1`. A branch side uses the entry of its nominal voltage (exact match), else `default`. The same factor applies to flows and sensitivities. All values must be numbers > 0; keys are `default` or a number (the validation names the key). The table and `dc_power_factor` are checked only when `calculation_mode` is `dc`; the other modes ignore them (a missing `dc_mode` section means every factor 1.0). The table is edited in the config file only, not in the GUI. The calibration of the factors is left to the user.
- The current of the pypowsybl DC security analysis is not used, because it cannot apply the factors and is not documented.

The run: load the CGM, DC load flow (distributed slack as configured; `target_p` of the generators is not changed by it), N-0 and N-X currents and sensitivities converted to ampere, GLSK, costs, TATL data and availability as before, one MILP build and solve, the solution applied once, then one AC load flow (with the incremental fallback) and one AC N-X security analysis at the applied state. The final check reports the remaining overloads in the `overload*` rows of `summary.csv`, as `ac_single_pass` does; it adds no pair and starts nothing. No iteration caps, convergence thresholds, completeness loop or refresh are used (ignored, one log line says so). Status `SINGLE_PASS`; the same files as `ac_single_pass`. If the final AC load flow does not converge (also after the incremental fallback), the DC solution stays the result: the log says that the final AC check is not evaluated, the overload rows of the summary are left out of what the AC check could not give, and the state after the preventive RAs in `loadings_n0.csv` is the initial one.

The currents of the original network in the files are DC currents in ampere in this mode (`loadings_n0.csv`, `loadings_nx.csv`, `assessed_elements.csv`). All currents in the result files are the converted currents. The factors used are not rows of `summary.csv`.

If the final AC load flow does not converge (also after the incremental fallback), the DC solution stays the result: the PST and RD rows are those of the solved model, the final-check rows are left out, and the run does not stop. (`ac_single_pass` reports the original network instead; the DC solution has no AC state to revert to.) A DC load flow leaves no bus voltages, so when the direct AC jump fails the apply step runs one extra AC load flow at the unmodified state to obtain the start voltages of the incremental fallback; the normal path has no extra calculation. A solve that is not optimal reports the original network without any AC calculation (`SOLVER_NON_OPTIMAL`).

The sensitivity guard also runs in the DC mode. Its N-X deviation check uses a tolerance of 5 % instead of 1 %: after a contingency that disconnects generation or load, the DC security analysis and the DC sensitivity analysis redistribute the distributed slack differently (up to a few MW, 1.1 % of the current on the fixture; with `distributed_slack` off they agree to 1e-12 MW). The checks for all-zero sensitivities stay exact; so does the check for a zero reference, with one exception: a (branch, contingency) pair whose reference current is exactly 0 A while its load-flow current is not, but at most `sensitivity_guard.absolute_floor_ampere`, is kept, and one summary warning counts these pairs. Above the floor the contingency is invalid as before. The AC modes and the N-0 check do not change.

A monitored branch with a load-flow current but no reference current in the sensitivity analysis (for example a line open at one end) is not a guard failure. It is left out for that state only, as a branch missing after a network split: one warning gives the pairs, the contingencies and the first 5 ids (all ids at DEBUG level), and no constraint is built for them (N-0: the branch is left out of the model). A pair whose reference differs from the security-analysis current (relative gap above the tolerance and absolute gap above `sensitivity_guard.absolute_floor_ampere`) is left out the same way, with one warning (pairs, contingencies, maximum and median absolute gap, first 5 ids, all at DEBUG level); in N-0 the branch is left out. The two analyses distribute the post-contingency imbalance slightly differently, so a few ampere on lightly loaded branches is expected. A zero reference and all-zero sensitivities still make the contingency invalid (the last valid set is reused, or at the first computation the run stops). The run stops with `SENSITIVITY_INVALID` when no contingency has valid N-X data, or when the pairs left out by the guard (no reference current, deviation) exceed `sensitivity_guard.max_dropped_share` of all monitored pairs; the message gives the share, the counts per cause and the first 5 ids. One INFO line per run gives the coverage: monitored pairs, pairs left out per cause (no reference current, deviation, network split) and the share (log only, not in `summary.csv`). The warning of the guard lists the count and the first 5 invalid items (all at DEBUG level).

Known limits of the DC mode (read before trusting its result):

- Reactive flow is ignored. Currents on transformers with high reactive flow (generator step-up transformers) are underestimated, so overloads there can be missed. The correction factors are the lever; the final AC check shows what the DC optimisation missed. On the fixture at factor 1.0 the current error is about 8 % (median) and 15-17 % (mean), and DC found 1 of 3 N-0 overloads and missed 11-13 post-contingency violation pairs per fixture.
- Sensitivities are overestimated (median error about 9 %, mean 15-19 %) while flows are underestimated; one factor per voltage level is applied to both.
- Losses are ignored (slack 954 MW in DC against 511 MW in AC) and voltage violations are not seen.
- Per-branch factors and time coupling are not part of the mode. HVDC set points are supported (`ra_types: hvdc`, see below); their sensitivities come from the DC sensitivity analysis. A DC run whose DC model sees no overload leaves the set points where they are, even when the AC network is overloaded.

#### HVDC remedial actions (`ra_types: [.., hvdc]`)

An HVDC link is modelled as two generating-like units on two EquivalentInjections (the two converters of the link), moved against each other: the pair keeps the sum of the set points constant (`dg1 + dg2 = 0`, equal change, opposite direction). Losses are not modelled, so a lossless pair leaves a small mismatch that goes into the slack and shows in the final AC check. Without `hvdc` in `ra_types` nothing HVDC is read, calculated or written.

**NCP data.**
- One `GridStateAlterationRemedialAction` per unit with one `EquivalentInjectionAction` pointing to the EI of the CGM; preventive or curative; optional contingency links and reaction time (curative); `RemedialAction.penaltyFactor`; `RangeConstraint`s.
- The two units of a link are in a `RemedialActionGroup` with a `balanced` `RemedialActionDependency` (both predicate names are read). A group with an HVDC unit has exactly two HVDC units and nothing else; a `balanced` group without any HVDC unit belongs to another RA type and is skipped with a log line. Errors (the run stops with a message naming the RA, group or EI): another number of units, a foreign RA in the group, a unit without a group, a unit in two groups (also when one of them is dropped for an unavailable unit), preventive and curative mixed in one group, the same EI twice in a group, two preventive units on one EI, an EI that is also a unit of an RD GLSK, a unit whose EI is not in the CGM or not in the solved main network, a unit with no bound on a side. Warnings: an EI whose description (on the EI, its terminal or its connectivity node) does not start with "HVDC"; an EI without technical limits (minP/maxP); a missing `penaltyFactor`. A group with an unavailable unit is dropped with both units.
- Range of a unit: the most restrictive `RangeConstraint` per side wins (the lowest maximum, the highest minimum: for absolute down ranges that is the highest value), capped by the technical limits of the EI. If the set point of the CGM lies outside the resulting range, the range is widened to include it (the unit may stay where it is) and a warning names the unit, its EI and the original and widened bounds. `absolute` values are literal (generation sign, "up" = more injection into the AC grid); `incremental` values are magnitudes added to / subtracted from the original set point of the CGM; `upAndDown` with one value is symmetric. Only static ranges count.

**Cost.** `penalty_costs.penalty_reference_hvdc_pra` and `penalty_reference_hvdc_cra` (EUR/MW, default 100 = the RD reference; also on the GUI settings page; read only when `hvdc` is on) times the `penaltyFactor` of each unit times the change. Preventive: the cumulative change against the original network, both units. Curative: the largest curative change of the unit over all contingencies (as curative RD). A missing `penaltyFactor` is 0 with a warning. **A factor of 0 means non-costly: the pair may move anywhere inside its range and the solver may end at the edge of the range. To limit the use, set a small factor above 0.**

**Curative HVDC** needs N-X analysis (with N-X off it is ignored with a log line). A curative unit without a contingency link acts in every contingency; its reaction time is compared with the TATL duration of each branch (as curative RD); it is unavailable in a contingency that removes its EI (or whose sensitivities are exactly zero), and then its partner is unavailable too. It uses the ranges of the preventive unit on the same EI when it has none of its own. The bound is exact per contingency (set point after the preventive actions plus the curative change within the range). Curative actions are never written to the network: the post-contingency result is the MILP prediction (the AC N-X current at the applied state plus the linearised curative effect), there is no AC N-X load flow of the curative state.

**Results.** Preventive set points are written to the network (unrounded) and checked by the AC load flow like redispatch. HVDC MW counts in `rd_ct_change_sum_mw` of `iterations.csv` and in convergence criteria 1 and 3. `summary.csv` has `hvdc_penalty_eur` (the PRA and CRA terms added) and `hvdc_change_mw` only when `hvdc` is on; the penalty is part of the objective. The files are `hvdc_ra.csv` (inputs) and `hvdc_results.csv`. An HVDC link contingency (converter or DC line) is not modelled; a contingency makes the RA unavailable only when the EI itself is an outage element.

#### Countertrade remedial actions (`ra_types: [.., countertrade]`)

A countertrade (CT) RA is a power bid of a bidding zone (volume and price, up and down) that shifts generation inside that zone: the volume is spread over the generators of the zone by their remaining capacity (up: Pmax - production, down: production - Pmin, both from the original set points, so the weights never change during a run). The cross-border effect comes from the balance: the CT volumes are balanced together with the redispatch bids, so an up bid in one zone needs a down bid in another zone (or an RD bid). CT can be used alone (`ra_types: [countertrade]`) or with any other type, preventive and curative, in all three calculation modes. Without `countertrade` in `ra_types` nothing CT is read, calculated or written (a CT RA in the NCP is then ignored with a warning, as before).

**NCP data.**
- One `nc:CountertradeRemedialAction` per zone and kind, with `PowerRemedialAction.BiddingZone`, `RemedialAction.kind`, `normalAvailable`, `penaltyFactor`, optional contingency links and `timeToImplement` (curative), and no strategy attribute: a CT RA without one is read with the strategy `proportionalForRemainingCapacity`, assumed (with a warning). The old-form `nc:CountertradeRemedialAction.gLSKStrategy` (optionally also `nc:PowerBidSchedule.gLSKStrategy` on its bids) is still read, with a deprecation warning; `powerShiftKey` and `method` are warned about and not read. Another strategy (also `generatorPmax`) or different strategies on the RA and its bids: the RA is ignored with a warning. A RA without a bidding zone is ignored too.
- Bids: the `PowerBidSchedule` objects of the RA (direction, price, volume at the run timestamp, activation cost, lead time; curative bids also a reservation price). A bid without volume has volume 0 with a warning.
- The zone's units come from the Organisation profile (`BiddingZone` <- `SchedulingArea` -> `ControlArea`) and the `ControlAreaGeneratingUnit` objects of the CGM EQ files. A zone that is not in the profile, or has no unit that can take part, drops its RA with a warning. Units that take part: generators (no EquivalentInjection, no external grid), connected, in the main synchronous component, with finite limits, on by the F2 rule, with production not above Pmax and with room in the direction; generators without a unit id or area are dropped from every zone (one log line). A direction with no unit left gets volume 0 (a warning).
- Restrictive RA groups (maxRegulatingUp/Down) and the per-TSO RA-count limits work for CT RAs as for RD; bid dependencies are not implemented (for RD neither).

**Model.** CT bids are RD bids with their own weights per direction: the same variables, the same balance (global in N-0, per contingency for the curative bids), hard Pmin/Pmax rows on the total of RD and CT per unit, and for a unit that RD can shut down one-sided rows so that CT never moves it while it is off. CT never starts or stops a unit and a unit may be in an RD and a CT bid. Curative CT acts like curative RD (R2, R4, R7, R9, R15) and is never applied to the network.

**Cost.** `penalty_costs.penalty_reference_ct_pra` and `penalty_reference_ct_cra` (EUR/MW, default 100 = the RD reference; also on the GUI settings page; read only when `countertrade` is on) times the `penaltyFactor` times the volume, plus bid price times volume and the activation cost of a used bid; curative: the largest curative volume over the contingencies, plus the reservation price (`reservePrice`, else the energy price). A missing `penaltyFactor` is 1.0 with a log line.

**Results.** The set points are written to the network like redispatch and checked by the AC load flow; CT MW counts in `rd_ct_change_sum_mw` of `iterations.csv` and convergence criteria 1 and 3. `ac_single_pass` leaves a linearisation residual (the weights are fixed, the load flow is not linear); `ac_iterative` converges. The result files of RD, PST and HVDC contain no CT rows. The files are `ct_bids.csv`, `ct_results.csv`, `zone_net_positions.csv` and the countertrade shares in `generating_units.csv`.

**Test data.** The ReliCapGrid data has no valid CT RA; the feature is tested on a generated mock (`tests/mock_builders/ct_mock.py`).

### The GUI

`src/app.py` runs the GUI (Streamlit); it lists the three RAO pages (Main, Load Flow Settings, RAO Settings) and nothing else. The Main page loads the CGM and NCP packages, offers the per-run choices (N-X analysis, RA types, calculation mode) and runs the pipeline in a temporary folder. When a CGM is loaded it shows its scenario time (read from the headers of the package; the network is not loaded) and the files of `output/<CGM time>/`, in tabs: Summary, Results, Loadings, Inputs and Debug files. A run from the GUI writes `output/<CGM time>/` of the repository directly, as a run from the command line does (the pipeline is the one in `src/rao`; the temporary folder of the GUI run holds only the uploaded inputs and the config of the run, and the run is pointed at them and at the repository `output/` with the optional environment variables `RAO_INPUT_DIR`, `RAO_CONFIG_DIR` and `RAO_OUTPUT_DIR`, which also work for a run from the command line), so the page shows the same folder either way. There is no folder picker. Without a folder the page says "no run for this CGM time yet"; a file that the run did not write says "not written in this run". Columns are shown as they are in the files, with their units.

The **RAO Settings** page shows every key of `src/rao/config/rao_config.yaml`, section by section, with the comment of the file as help text. Saving writes that file: only the value on the key line changes, every comment and every key the page does not change stay as they are. The values are checked by the pipeline's own config check before anything is written; a rejected value shows the pipeline's message and the file stays as it was. Lists and tables (`max_taps_per_tso_overrides`, `pst_group_kind_per_tso`, the `dc_mode` table) are shown on the page and edited in the file; `ra_types` is edited on the page. The linearisation and completeness caps and the convergence thresholds are greyed out in `ac_single_pass` and `dc`. The Load Flow Settings page keeps its settings in `.rao_gui_settings.json`, which no longer holds RAO settings.

---

### `src/rao/config/load_flow_config.yaml`

Physical solver settings passed to the underlying power-flow engine (voltage initialization, slack distribution, and similar). Most of these can be left at their defaults; the one worth knowing about specifically is `use_reactive_limits`, which is deliberately off by default — turning it on has been confirmed to cause widespread solve failures on this dataset. `dc_power_factor` (default 1.0, must be > 0 in `calculation_mode: dc`; the load flow page does not accept 0, and a value not > 0 saved by an earlier version is replaced by 1.0 with a note on the pages) converts current limits to power limits in the DC security analysis; it is not an HVDC setting. In `calculation_mode: dc` the same value converts the DC active power to ampere.

### If something goes wrong after changing a setting

Both config files have a matching `.default.yaml` copy (`rao_config.default.yaml`, `load_flow_config.default.yaml`) that's never meant to be edited — a known-good baseline. If a change to the active file causes a failure or produces results that don't make sense, copy the `.default.yaml` over the active file to get back to a state that's been verified to work.

---

## Output files

The files, their columns, their units and the rules for their rows are in `docs/specs/output_files_specs.md`; this guide does not repeat them.

- A file is written only when its feature is on in the run: its RA type is in `ra_types`, N-X is on, or its config switch is on (`outputs.*`). A file that is not in the folder was not written in this run; that is not an error.
- A file lists what the run used. What was left out (excluded assessed elements, skipped or invalid contingencies, ignored RAs and bids) and why is in `run_log.txt`, one summary line per reason, together with one curative-availability summary per RA type and one line per restrictive RA group.
- A file with only a header row is a checked result ("there was nothing to report here"), not a sign that something failed.
- `iterations.csv` exists only in `ac_iterative`; the single solve of `ac_single_pass` and `dc` is in `summary.csv`.
- Units are in the column names (`_a`, `_mw`, `_eur`, `_eur_per_mw`, `_pct`, `_s`, `_min`, `_h`, `_a_per_tap`, `_a_per_mw`); `tso` is the first column wherever there is one.

### How the run ended (status)

The `status` row of `summary.csv` says how the AC verification ended:

| Status | Meaning |
|---|---|
| `CONVERGED` | A convergence criterion held; the last solution is applied. |
| `MAX_ITERATIONS_REACHED` | The iteration cap ended the loop; the last solution is applied. |
| `CYCLIC_REPETITION` | A solution repeated an earlier one; the best member of the cycle is applied. |
| `REVERTED_NON_CONVERGENT` | A load flow failed and nothing was applied in the run: the files show the original network (no change, no objective). |
| `REVERTED_TO_LAST_CONVERGED_STATE` | A load flow failed later: the files show the last applied solution. |
| `SENSITIVITY_INVALID` | Invalid sensitivities with no earlier valid set: the run stops with an error and the summary says so. |
| `SOLVER_NON_OPTIMAL` | A MILP solve was infeasible or otherwise not optimal: the files show the last applied solution, or the original network when nothing was applied. |
| `SINGLE_PASS` | `ac_single_pass` and `dc`: one solve, one applied solution, one AC check; there is no convergence criterion. |
| `NOT_APPLICABLE` | Nothing was optimised (no usable remedial action and no N-X). |

The files never show a solution that was not applied to the network.

---

### NCP files in the standard form

The NCP files should follow the ENTSO-E profiles RemedialAction 2.5 and StateInstructionSchedule 2.5. Redispatch is an `nc:RedispatchRemedialAction`; its generating units are the units of its shift keys
(`PowerShiftKeySchedule`, linked from its bids or from a `PowerShiftKeyStrategy`), and each bid must carry its direction (`MarketRegulationDirectionKind.up` / `.down`; a bid without a direction is skipped
with a warning; up bids have p > 0, down bids p < 0). The `RotatingMachineAction` form of the official 2.4 sample is read as well. Elements that no official source has (the bid attributes `penaltyFactor`, `minEnergyBid`, `maxEnergyBid`, `stepSizeCTRD`; a generator id as the unit of a shift key; countertrade `powerShiftKey` and `method`; a group limit linked directly from the time point; the plain dependency predicate `RemedialActionGroup`) are not read: one summary warning "not supported, ignored" per file names them with their count.

## NCP test data: where and how to run

**Zips** (all in `tests/fixtures/`). All three belong with the same CGM, `tests\fixtures\CGM_package.zip`.

| Name | Path | Profile versions in the headers | Files inside | Used by |
|---|---|---|---|---|
| P, standard form | `tests\fixtures\NCP_mock_standard.zip` | RA 2.5, SIS 2.5 (the `nc` namespace string still says 2.4), AE 2.4 (Belgovia_AE.xml has an older header without a profile version), CO 2.3, SHS 1.1 (Belgovia only), EquipmentReliability 2.4 and ObjectRegistry 2.2 | AE, CO, RA, SIS for Belgovia, Espheim, Galia, Svedala (SHS for Belgovia only; no SSI), plus `Org-NineRealms_CD.xml` and `Org-NineRealms_CD_OR.xml` | the mock case of the test suite (`_MOCK_NX_NCP_ZIP`, 15 test files), the golden matrix cases `mock__*`, and the base every mock builder copies (`ct_mock`, `hvdc_mock`, `ncp_dataset`) |
| P base, standard form | `tests\fixtures\NCP_mock_standard_base.zip` (P without the 8 countertrade RAs, frozen) | as P | the same 19 files | the base every mock builder copies (`tests/mock_builders/standard.py`) |
| G, official sample | `tests\fixtures\NCP_sample_generic_2_4.zip` | RA 2.4, SIS 2.4, AE 2.4 (Espheim_AE.xml: CIM100 namespaces in the header), CO 2.3, SHS 1.1, SSI 2.4, EquipmentReliability 2.4, ObjectRegistry 2.2 | AE, CO, RA, SHS (Belgovia), SIS (Belgovia, Espheim, Svedala), SSI (Espheim) and the cross-TSO CO files `DC-Espheim-Svedala_CO.xml`, `Svedala-Belgovia_CO.xml`, plus the two Org files | the golden matrix cases `generic__*`, 12 test files; it is never changed |

**Run the pipeline** (PowerShell, from the repo folder). The pipeline reads `input/` and writes `output/` of the repo, and its options are in `src\rao\config\rao_config.yaml`. To leave `input/` alone, run it the way the tests do, in a work folder, with the usual options (N-X on, `ra_types` pst+rd, `ac_iterative`):

```powershell
$env:PYTHONHASHSEED = '0'
$run = "import sys, pathlib; sys.path[:0] = ['tests', 'src/rao', '.']; import helpers; r = helpers.run_pipeline_on_fixture_inputs(pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[1]), enable_nx_analysis=True, ra_types=('pst', 'rd'), calculation_mode='ac_iterative'); print(r.output_dir)"
.venv\Scripts\python.exe -c $run tests\fixtures\NCP_mock_standard.zip        C:\Temp\rao_run_standard
.venv\Scripts\python.exe -c $run tests\fixtures\NCP_mock_standard_base.zip C:\Temp\rao_run_base
.venv\Scripts\python.exe -c $run tests\fixtures\NCP_sample_generic_2_4.zip                      C:\Temp\rao_run_generic
```

Results and `run_log.txt` appear in `C:\Temp\rao_run_standard\output\<CGM time>`, `...\rao_run_legacy\output\<CGM time>` and `...\rao_run_generic\output\<CGM time>` (change the folder as you like; each run takes about 10 s). For `ra_types` add e.g. `'hvdc'` or `'countertrade'` to the tuple (the mock builders in `tests` make the NCP zips for those). Comparing the two P runs: of the 30 files in `output`, only `summary.csv` (the run time and memory rows), `iterations.csv` (the seconds columns) and `run_log.txt` differ (the others are byte-identical):

```powershell
Get-ChildItem C:\Temp\rao_run_standard\output | ForEach-Object { $o = "C:\Temp\rao_run_legacy\output\$($_.Name)"; if ((Get-FileHash $_.FullName).Hash -ne (Get-FileHash $o).Hash) { "differs: $($_.Name)" } }
```

The plain way (`python src\rao\run_pipeline.py`) needs exactly one CGM zip and one NCP zip in `input/`: now the HVDC pair `CGM_package_hvdc.zip` and `NCP_mock_hvdc.zip` (see "HVDC use case" below). The previous pair (`CGM_package.zip` and `NCP_mock_standard.zip`, the standard P) is in `tests/fixtures/`; to use it again, move the two HVDC zips out of `input/` and copy the two old zips in. Put non-public data there by hand instead; results go to `output\` and are overwritten by the next run.

### HVDC use case (the pair in `input/`)

`CGM_package_hvdc.zip` is the upstream CGM with the Espheim-Svedala DC link replaced by two equivalent injections (about +543 / -545 MW); `NCP_mock_hvdc.zip` is P plus the two HVDC remedial actions. With the default config (`ra_types: [pst, rd]`, N-1 off) the run shows nothing: objective 0, no RA activated, and the HVDC RA is not even read. To see the HVDC RA work, in `src/rao/config/rao_config.yaml` set `ra_types: [pst, rd, countertrade, hvdc]` (or `[pst, rd, hvdc]`) and `enable_nx_analysis: true`. Measured with `[pst, rd, hvdc]` and N-1 on: objective 158,953 (AC iterative) and 101,820 (DC), the Espheim unit moves from 542.7 to about 123 MW (AC) and the Svedala unit by the same amount in the opposite direction; with countertrade also on the objective is lower (99,954 AC, 97,621 DC) because countertrade is a cheaper way to relieve the same overloads, so the HVDC moves less (about 256 MW in AC). The two HVDC RA files are merged into `Espheim_RA.xml` and `Svedala_RA.xml` of the NCP zip, because extra files named `HVDC-*_RA.xml` would be classified as a Country-Neighbour export and ignored.

**Extract the standard P to read the XML:**

```powershell
Expand-Archive tests\fixtures\NCP_mock_standard.zip C:\Temp\ncp_p_standard -Force
```

`{Belgovia,Espheim,Galia,Svedala}_RA.xml` hold the `nc:RedispatchRemedialAction` elements (8 each) and the `nc:PowerShiftKeyStrategy` elements; `{Belgovia,Espheim,Galia,Svedala}_SIS.xml` hold the `nc:PowerBidSchedule`, `PowerBidScheduleTimePoint`, `PowerShiftKeyDistribution`, `PowerShiftKeySchedule` and `ParticipationFactorTimePoint` elements (8 bids each). P has 8 `nc:CountertradeRemedialAction` (a preventive and a curative one per region, bids with a supply function in Espheim; section 2 below); G has one in `Belgovia_RA.xml`; the mocks built by `tests/mock_builders/ct_mock.py` start from the base of P without them. Org files: `Org-NineRealms_CD.xml`.

**Warnings to expect in `run_log.txt`** (this run: N-X on, `ac_iterative`, pst+rd; ids and numbers differ in your log):

- *Standard P* (the normal state, 13 kinds of warning, none about the NCP form): `optional profile SHS not found` for Espheim, Galia, Svedala; `CurrentLimit ... sequenceNumber 3 outside {1,2}`; four `SHS PATL ... differs >10% from CGM static` for Belgovia; `PST ... tap steps are not uniformly spaced` (3 PSTs, each twice); `compute_tatl_data: 18 of 29 TATL value(s) were LOWER than PATL ... corrected`; `N-X PATL: contingency ...: 1 pair(s) skipped` (4 lines). Plus, because `countertrade` is not in the default `ra_types`, one line per countertrade RA (8) saying `nc:CountertradeRemedialAction ... is not used and is IGNORED` and, in a run with `countertrade`, one `has no strategy ... proportionalForRemainingCapacity assumed` line per RA. **No** `deprecated` or `no BaseTimeSeries.interpolationKind` line, and no other `IGNORED` line: if one appears, the file is not in the standard form or is wrong.
- *P base* (the same without the countertrade RAs): the standard P warnings, none about the NCP form.
- *G* (many, all known, the sample is incomplete): missing SHS and Galia SIS; `no PATL in NCP ... using CGM static PATL`; `AE ... has none of ConductingEquipment, Line, ...`; `RemedialAction.penaltyFactor ... defaulted to 1.0`; `curative PST ... missing reaction_time_minutes`; the old `RotatingMachineAction` deprecation for Belgovia; `nc:RedispatchRemedialAction ... (RD RA1) is not used and is IGNORED` and the same for the countertrade RA `RA18` (no generating unit in a shift key); `bid ... has no direction - skipped`; `AssessedElementTimePoint ... enabled=false - not read`; `PowerBidDependency ... not read`; `RD RA ... no PowerShiftKeySchedule/participationFactor resolved for timestamp 1030Z ... GLSK is empty` (twice, the second Belgovia redispatch RA is recognised without participation, DECISIONS 116); `RD block skipped - preventive bid_list has 0 entries`; contingency equipment not found in the CGM.
- Wrong in every run: a Python traceback, `Using CGM zip` / NCP zip not unique, a `ValueError` about participation factors or a group, or a run that ends without `summary.csv`.

## NCP test datasets: names and content

All numbers below were counted on the files (RDF parse of every XML in the zip), not taken from the docs. "P" is `tests\fixtures\NCP_mock_standard.zip` (standard form), "G" is `tests\fixtures\NCP_sample_generic_2_4.zip`.

### 1. Why the mock was called `NCP_pst_fallback_scenario.zip` (now `NCP_mock_standard.zip`), and where "P" and "G" come from

- **Origin of the name.** It is the fixture of one regression test, `test_incremental_fallback_resolves_real_non_convergent_scenario` (today in `tests/test_rao_ac_convergence_loop.py`). The scenario: one real overload (about 173 A on one branch and contingency) needs two PSTs to go to their hard tap limits in opposite directions in one MILP solve; applying it in one AC load flow does not converge, only the incremental fallback (DECISIONS 8, `incremental_ac_fallback_max_steps`) does. "pst_fallback" = the PST / incremental AC fallback scenario. The comment in the test says the same ("a purpose-built NCP set that reproduces a two-PST opposite-limits non-convergence (not NCP_generic.zip)").
- **What it became.** Since then it is the base of everything: the shared mock case of the suite (`conftest.py`, `helpers._MOCK_NX_NCP_ZIP`), the golden matrix cases `mock__*`, and the zip every builder (`hvdc_mock`, `ct_mock`, `ncp_dataset`) copies. The name no longer describes that use.
- **"P" and "G".** They are defined in the documents: `docs/specs/ncp_data_requirements.md` ("Fixture codes": G, P, H, Hc, C, Cc, CH, `m:x`) (`NCP_generic.zip` ("G"), `NCP_pst_fallback_scenario.zip` ("P")). They are a shorthand of this project's documents, not an ENTSO-E term and not used in the code. G follows the file name `NCP_generic.zip`; P follows the PST fallback scenario file (the documents do not explain the letters).
- **Third name.** `input/NCP_mock_cleaned.zip` was a third name for the legacy P (same bytes as `NCP_pst_fallback_scenario_legacy.zip`); it was removed from `input/` on 24 Oct 2026. On the same day the zips got the names of section 5.

### 2. Content of P (standard form)

P is a generated mock for the four TSOs of the CGM. Every redispatch RA is one generating unit and one direction. No file contains non-public data.

| Item | Belgovia | Espheim | Galia | Svedala | Total |
|---|---|---|---|---|---|
| PST RAs preventive (`GridStateAlterationRemedialAction` + `TapPositionAction`) | 2 | 2 | 2 | 0 | 6 |
| PST RAs curative (timeToImplement PT5M) | 2 | 2 | 2 | 0 | 6 |
| PST RAs with a group / `RemedialActionGroup` | 0 | 0 | 0 | 0 | 0 |
| `RedispatchRemedialAction` preventive | 4 | 4 | 4 | 4 | 16 |
| `RedispatchRemedialAction` curative | 4 | 4 | 4 | 4 | 16 |
| `CountertradeRemedialAction` (one preventive, one curative per region) | 2 | 2 | 2 | 2 | 8 |
| HVDC RAs (`EquivalentInjectionAction`), preventive / curative / groups | 0 | 0 | 0 | 0 | 0 |
| `PowerBidSchedule` of the redispatch RAs, up / down | 4 / 4 | 4 / 4 | 4 / 4 | 4 / 4 | 16 / 16 |
| `PowerBidSchedule` of the countertrade RAs, up / down (100 MW each; Belgovia and Galia 50, Svedala 60, Espheim 40 / 70 / 110 EUR/MW) | 2 / 2 | 6 / 6 | 2 / 2 | 2 / 2 | 12 / 12 |
| contingency links of the curative countertrade RAs (all `included`, all contingencies of the region) | 2 | 5 | 1 | 8 | 16 |
| bid size (MW, sign as in the profile: down negative) and price | 50-60 at 90-100 | 50-60 at 85-95 | 40-100 at 50-92 | 500-600 at 40-45 | one time point each |
| `PowerShiftKeyStrategy` (one per redispatch RA) | 8 | 8 | 8 | 8 | 32 |
| `PowerShiftKeySchedule` (two per RA: bid route and strategy route) / `ParticipationFactorTimePoint` | 16 / 16 | 16 / 16 | 16 / 16 | 16 / 16 | 64 / 64 |
| `ContingencyWithRemedialAction` (all `included`) | 6 | 30 | 6 | 32 | 74 |
| contingencies that the curative RAs are linked to (of those in the file) | 1 of 2 | 5 of 5 | 1 of 1 | 8 of 8 | |
| contingencies: ordinary / out of range / exceptional | 2 / 0 / 0 | 3 / 2 / 0 | 1 / 0 / 0 | 6 / 1 / 1 | 12 / 3 / 1 = 16 |
| `ContingencyEquipment` (all `outOfService`) | 2 | 7 | 1 | 10 | 20 |
| `AssessedElement` (all `inBaseCase`, combinable, enabled, `SecuredForRegion`; none scanned-only) | 9 | 6 | 5 | 9 | 29 |
| PATL in the NCP (`BaseCaseCurrentLimit`, A) | 1062-1876 | 1000-2000 | 1233.9-2000 | 600-2000 | 29 values |
| TATL | none in the NCP (it comes from the CGM) | | | | |
| SHS (`CurrentLimitSchedule`) | present: 2 schedules, 97 time points (96 on 22 Jul 2023, 350-1854 A) | missing | missing | missing | Belgovia only |

Other facts of P:
- All bids and key time points are at the run time stamp `2022-06-15T10:30:00Z`; `leadTime` zero, `activationCost` 0, `priority` 1, `participationFactor` 1.0 everywhere, so each key is one unit. Bid interpolation `next` everywhere; key interpolation `next` for Belgovia and `none` for the others.
- Down bids have p < 0 and up bids p > 0 (decision 24).
- No `penaltyFactor` is missing (all 1.0), no RA is unavailable, no contingency link is `excluded`, `considered` or has no kind, no range is inverted, no bid lacks a direction.
- **Features that stand out in the files** (not necessarily deliberate): the SHS only for Belgovia (the other three TSOs give the "optional profile SHS not found" warning), with values more than 10 % away from the CGM PATL (four warnings); one Belgovia AE without `AssessedSystemOperator`; a Belgovia AE file with an older header; Svedala with redispatch only (no PST); curative RAs linked to one contingency only in Belgovia and Galia; out-of-range and exceptional contingencies with two equipment each. No document lists the special cases of P as a design list; the rest of the edge cases (inverted range, missing penalty factor, zero penalty factor, several units, groups, and so on) are in the builders, not in P (see 4).

### 3. Content of G (`NCP_sample_generic_2_4.zip`, profile 2.4, a third-party sample)

| Item | Belgovia | Espheim | Galia | Svedala | Total |
|---|---|---|---|---|---|
| PST RAs (`TapPositionAction`) preventive / curative | 0 / 1 | 0 / 2 | 0 / 0 | 0 / 0 | 0 / 3 |
| PST groups | 0 | 0 | 0 | 0 | 0 |
| `RedispatchRemedialAction` | 2, both curative, same name | 0 | 0 | 0 | 2 |
| old redispatch GSARA with 2 `RotatingMachineAction` (preventive) | 1 | 0 | 0 | 0 | 1 |
| `CountertradeRemedialAction` | 1 curative (`powerShiftKey` + `method`, no strategy, no `penaltyFactor`) | 0 | 0 | 0 | 1 |
| HVDC RAs | 0 | 0 | 0 | 0 | 0 (two `EquivalentInjectionAction` of +10 / -10 MW exist, inside a remedial action scheme, not an HVDC RA) |
| other RA types, not used by the RAO | shunt 1, a GSARA without any action 1 (same name as the PST RA) | topology 4, regulating control 1 | load 1 | topology 8, regulating control 2, static var compensator 1, availability RA 1, scheme RA 1, a GSARA without any action 1 | 22 |
| `RemedialActionGroup` / `RemedialActionDependency` (exclusive) | 0 | 0 | 0 | 1 / 2 | 1 / 2 |
| `RemedialActionScheme` / `StaticPropertyRange` | 5 / 7 | 0 | 0 | 3 / 15 | 8 / 22 |
| `PowerBidSchedule` up / down / without direction | 2 CT / 1 CT / 1 RD | 0 | 0 | 0 | 4 bids (no up/down pair for redispatch) |
| `PowerBidDependency` (restrictive, inclusive; delay PT1H) | 2 | 0 | 0 | 0 | 2 |
| bid time points | 1 (the RD bid: p = -125.4625, price 325, 22 Feb 2024); the three CT bids have none | | | | 1 |
| `PowerShiftKeyStrategy` / `PowerShiftKeySchedule` / participation factors | 1 / 2 / 2 (0.5 each; one key has no generating unit) | 0 | 0 | 0 | |
| `ContingencyWithRemedialAction` (all `included`) | 3 | 6 | 1 | 4 | 14 |
| `AssessedElement` | 7 | 7 | 2 | 10 | 26 |
| `AssessedElementWithContingency` (14 `included`, 1 `excluded`) / `AssessedElementWithRemedialAction` / `CrossBorderRelevance` | 3 / 1 / 1 | 6 / 0 / 0 | 1 / 0 / 0 | 5 / 1 / 1 | 15 / 2 / 2 |
| AE classes (total column only) | | | | | secured 2 (one of them also scanned), scanned 23, neither 2; 2 with `exclusionReason` (`non`, `sys`); 1 `inBaseCase=false`; 1 `isCombinableWithContingency=false` |
| `AssessedElementSchedule` with a time point `enabled=false` (22 Jul 2023 16:00Z) | 1 | 0 | 0 | 0 | 1 |
| contingencies: ordinary / out of range / exceptional | 4 / 0 / 0 | 5 / 2 / 0 | 2 / 0 / 0 | 7 / 1 / 2 | 18 + 6 ordinary in the two cross-TSO files = 24 / 3 / 2 |
| `ContingencyEquipment` | | | | | 34 |
| PATL in the NCP | none: the 18 limits an AE refers to are in the CGM; 8 AEs have none | | | | PATL from the CGM |
| SHS | same file as P (Belgovia, 97 time points) | missing | missing | missing | |
| other files | `Espheim_SSI.xml` (a `TopologyAction`, an `EquivalentGeneratingUnit`); `Espheim_SIS.xml` and `Svedala_SIS.xml` with `GridStateAlterationSchedule` only | | | | |

G has no PST group, no up / down pair of redispatch bids, no standard-form redispatch units (its second redispatch RA has no generating unit, DECISIONS 116) and no time-dependent data other than the SHS, the one bid time point and the one disabled AE time point.

### 4. Gaps: what P does not cover, and where it is covered

| Feature / form | In P | Where it is covered |
|---|---|---|
| Countertrade RA: strategies, zones, volumes, penalty factors, groups, bids without volume | one preventive and one curative RA per region with 1 or 3 bids per direction (cheapest first, curative activated in a run with `countertrade`); no strategy attribute, no group | `ct_mock.py` and `ncp_dataset.py` (they start from the base of P without countertrade and write the old forms on top of it); G has one CT RA in the old form |
| HVDC RA: absolute `upAndDown` range, incremental up / down, curative, balanced and restrictive groups | none | `hvdc_mock.py` (default RAs have `upAndDown` absolute 450 and incremental up / down), `ncp_dataset.py`, `test_rao_hvdc_parser.py` |
| Group limits in the standard SIS chain (`RemedialActionGroupTimePoint` -> `RemedialActionGroupSchedule` -> group) | none | `ct_mock.py`, inline XML in `test_rao_ncp_parser.py` and `test_rao_ncp_standard_equivalence.py` |
| `RemedialActionGroup` of PSTs | none | G (Svedala, topology RAs, exclusive dependencies, not used by the RAO); PST groups in `ncp_dataset.py` |
| `upAndDown` and `stable` bids (skipped with a warning) | none | `test_rao_ncp_parser.py` (parametrised, inline XML) |
| bid without direction | none | G (the Belgovia RD bid) |
| several units in one key, factors not 1.0, factor without `atTime`, a unit with several generators | none (every key is one unit, factor 1.0) | `ncp_dataset.py` ("GLSK over several units"), `test_rao_redispatch_standard.py`, G (two factors 0.5) |
| several bids per RA, lead time, activation cost on the time point, reservation price | none (one bid per RA, one time point) | `ncp_dataset.py`, `ct_mock.py` |
| disabled `AssessedElementTimePoint` (`enabled=false`) | none | G only; the behaviour is not implemented yet (OPEN-29, strict xfail in `test_rao_ncp_standard_equivalence.py`) |
| `AssessedElementWithContingency` / `WithRemedialAction` / `CrossBorderRelevance` | none (P uses `inBaseCase` and `isCombinableWithContingency`) | G; `ncp_dataset.py` |
| contingency link kinds `excluded`, `considered`, missing, unknown | all `included` | `test_rao_ncp_combination_kind.py` and `ncp_dataset.py` (inline changes of P) |
| missing / zero `penaltyFactor`, unavailable RA, inverted or empty ranges | none | `ncp_dataset.py` variants, `hvdc_mock.py`, `ct_mock.py` |
| `PowerBidDependency` (G) / `PeerTemporalDependency` (official name) | none | G for the first; the second is only in inline test XML (`test_rao_ncp_parser.py`) |
| Non-PST GSARA types (topology, shunt, load, regulating control, SVC), schemes | none | G only (not used by the RAO) |
| SSI profile file, profile version 2.4 of RA / SIS | none (RA / SIS are 2.5) | G (SSI 2.4, RA / SIS 2.4) |
| elements no official source has (generator ids in keys, old bid attributes, old group-limit form, `powerShiftKey`, `method`) | none | `test_rao_unsupported_elements.py` writes them into small files |
| `RotatingMachineAction` redispatch (official 2.4 sample form) | none | G |
| SHS for other TSOs than Belgovia | Belgovia only | `hvdc_mock.py` (writes a Svedala SHS), `ct_mock.py` (patches the Belgovia SHS) |

### 5. Names (renamed on 24 Oct 2026)

| Was | Is |
|---|---|
| `tests/fixtures/NCP_pst_fallback_scenario.zip` (P) | `tests/fixtures/NCP_mock_standard.zip` |
| `tests/fixtures/NCP_pst_fallback_scenario_legacy.zip` and `input/NCP_mock_cleaned.zip` | gone (the old form is removed; the standard base is `tests/fixtures/NCP_mock_standard_base.zip`) |
| `tests/fixtures/NCP_generic.zip` (G) | `tests/fixtures/NCP_sample_generic_2_4.zip` |
| `tests/ct_mock.py`, `hvdc_mock.py`, `ncp_dataset.py`, `convert_ncp_to_standard.py` (the former `tools` folder) | `tests/mock_builders/` (see `tests/tools/README.md`) |

The names are set in one place, `tests/mock_builders/paths.py`; the tests use `tests/helpers.py` constants (`_MOCK_NX_NCP_ZIP` and the others, names unchanged). `input/` holds the HVDC pair `CGM_package_hvdc.zip` and `NCP_mock_hvdc.zip`. No test reads `input/`. The fixture codes G and P of `specs/ncp_data_requirements.md` keep their letters.

## Run time: the CGM selects the data

The run time (date and hour) is the scenario time of the CGM (`md:Model.scenarioTime` of its model files). If that date and hour lie inside a time-point series (`atTime`) of the NCP files, the run starts at that hour and every time-dependent NCP value (bids, current limits, participation factors, unit costs, group limits) is taken from the points of that date and hour; an hour after midnight takes the next day. Files that cover 24 hours or several days need nothing else. If the CGM has no scenario time, or it lies inside no time-point series of the NCP files (the mock and the samples), the run keeps the start hour `1030Z` of `run_pipeline.py`, matches time points by clock time as before (a bid on several days takes its earliest day); the run log says which case applies (`Run time: ...`).

## Assessed-element switches

An absent switch means enabled. `AssessedElement.normalEnabled=false`, or an `AssessedElementTimePoint` with `enabled=false` at the run time, takes the element out of the monitoring. `inBaseCase=false` removes its N-0 row (the contingency states stay). `AssessedElementWithContingency` links restrict the element to the `included` contingencies or take it out of the `excluded` ones. Every element switched off or restricted is named in the run log (one line per element and one summary line per TSO). `isCombinableWithContingency=false` restricts the element to the contingencies with an `included` link (none: after no contingency); a `considered` link is not allowed and counts as absent (warning). With `workflow_toggles.ae_contingency_combination: all_contingencies` the combination switches are not applied (see "Calculation mode and RA types"). `isCombinableWithRemedialAction=false` and the links to remedial actions are not applied (warning only, ASSUMPTIONS OPEN-33).

## Shared-bid redispatch use cases (A, D_espheim)

Redispatch RAs whose bid is shared by 2 or 3 generators with participation factors, as test data on the standard-form mock P (nothing in `input/` or in the fixtures changes).
- **A** (Espheim, preventive): Breed SM 0.6 and Philo SM 0.4, bid route, bids of 100 MW at 90 EUR/MW; **A_strategy**: through the strategy route.
- **B_preventive** / **C_preventive** (Galia, preventive): GA-G1 0.5, GA-G2 0.3, GA-G3 0.2, bids of 150 MW (GA-G2 reaches Pmax exactly) / 200 MW (GA-G2 limits the total to 150 MW; the rest of the bid is not used and not passed on to the other units, no warning).
- **D_espheim** (Espheim, the four generators at four substations): two preventive downs (3 and 2 units, bid route) and two curative downs (3 and 2 units, strategy route, linked to the 5 Espheim contingencies); the curative ups of CabinCrk and Claytor of P are the balance partners. All four are activated in the full run. The Svedala version of D (units at one substation) is a model-level example only.
- What the tests check: the weights of the units, each generator's move = factor x the total, the cost = (penalty factor x reference + price) x the total bid volume, one price per bid, up and down symmetric, the unit limit, the scope of the balances (preventive: one row over the whole network; curative: per contingency over the RAs of all TSOs) and the warning below.
- **Warning to know:** `curative redispatch in contingency ...: no net movement is possible` - in a contingency where curative RD RAs act, only one direction exists, or every up and every down RA has the same key; they can never move. Add a curative RA of the other direction with another key.

Run the tests: `.venv\Scripts\python.exe -m pytest tests\test_rao_rd_shared_bid.py -q`. Build a variant zip and run the pipeline on it (PowerShell, from the repo folder; `$run` is the string of the section "NCP test data: where and how to run"):

```powershell
.venv\Scripts\python.exe -c "import sys; sys.path[:0]=['tests','src/rao','.']; import ncp_dataset; ncp_dataset.build_shared_bid_ncp(sys.argv[2], sys.argv[1])" D_espheim C:\Temp\ncp_D.zip
.venv\Scripts\python.exe -c $run C:\Temp\ncp_D.zip C:\Temp\rao_run_D
```

Result files to look at in `C:\Temp\rao_run_D\output\<CGM time>`: `rd_results.csv` (RA volume and cost, preventive and curative rows), `rd_bids.csv` (the bids, their units and the factors), `generating_units.csv` (the units).
