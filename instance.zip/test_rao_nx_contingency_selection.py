"""tests/test_rao_nx_contingency_selection.py - nx_sensitivity.contingency_min_loading_pct: only the contingencies with a branch
side at or above the percentage of its lowest MILP limit get N-X sensitivities and N-X rows."""

import logging
from pathlib import Path

import pytest

import run_pipeline
from data_model import AEType, LfNx
from helpers import _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs
from milp.milp_builder import MilpLimitFactors
from pre_milp.nx_contingency_selection import ContingencySelection, lowest_limits_ampere

SIDES = {"B1": 1, "B2": 1}
LIMITS = {"B1": 1000.0, "B2": 500.0}


def _selection(pct):
    return ContingencySelection(pct, dict(LIMITS), dict(LIMITS), SIDES)


def _lf_nx():
    lf_nx = LfNx({
        "co-high": {"B1": {1: 900.0}, "B2": {1: 100.0}},       # B1 at 90 %
        "co-low": {"B1": {1: 100.0}, "B2": {1: 100.0}},        # 10 % and 20 %
        "co-over": {"B1": {1: 100.0}, "B2": {1: 600.0}},       # B2 over its limit
    })
    lf_nx.tripped = {"co-low": ["B2"]}
    return lf_nx


def test_a_contingency_with_a_branch_above_the_threshold_is_kept_and_one_with_all_below_is_not(caplog):
    selection = _selection(50.0)
    with caplog.at_level(logging.INFO):
        selection.select_from(_lf_nx())
    assert selection.selected == {"co-high", "co-over"} and selection.not_selected == {"co-low"}
    assert "1 of 3 contingencies not selected" in caplog.text and "co-low" in caplog.text


def _rule_selection(pct=90.0, increase=1.0):
    """B1 secured (limit 1000 A x PATL factor 1.0), B2 scanned (PATL 800 A x scanned factor 0.9 = 720 A; its effective limit
    is 1000 A, which must not be used); both at 10 % of their limits in N-0."""
    factors = MilpLimitFactors(patl=1.0, tatl=1.0, scanned=0.9)
    types = {"B1": AEType.SECURED, "B2": AEType.SCANNED}
    lowest = lowest_limits_ampere({"B1": 1000.0, "B2": 1000.0}, types, None, factors, scanned_patl={"B2": 800.0})
    assert lowest == {"B1": 1000.0, "B2": pytest.approx(720.0)}
    return ContingencySelection(
        pct, lowest, {"B1": 1000.0, "B2": 1000.0}, SIDES, branch_ae_types=types,
        lf_n0={"B1": {1: 100.0}, "B2": {1: 72.0}}, min_increase_pct=increase)


def _decide(selection, **contingencies):
    selection.select_from(LfNx({name: {"B1": {1: b1}, "B2": {1: b2}} for name, (b1, b2) in contingencies.items()}))
    return selection.selected


def test_a_contingency_raising_a_secured_branch_from_below_to_above_the_threshold_is_selected():
    assert _decide(_rule_selection(), raised=(900.0, 72.0)) == {"raised"}


def test_a_contingency_leaving_a_secured_branch_at_a_loading_it_already_has_in_n0_is_not_selected():
    selection = ContingencySelection(
        90.0, {"B1": 1000.0}, {"B1": 1000.0}, SIDES, lf_n0={"B1": {1: 920.0}}, min_increase_pct=1.0)
    selection.select_from(LfNx({"same": {"B1": {1: 920.0}}, "slightly": {"B1": {1: 925.0}}, "raised": {"B1": {1: 931.0}}}))
    assert selection.selected == {"raised"} and selection.not_selected == {"same", "slightly"}   # 0 and 0.5 points: not enough


def test_a_contingency_raising_a_scanned_branch_to_the_threshold_of_its_patl_is_selected_and_one_already_there_in_n0_is_not():
    # 90 % of the scanned PATL limit (720 A) is 648 A: B2 is at 648 A or more after the contingency
    assert _decide(_rule_selection(), raised=(100.0, 700.0)) == {"raised"}
    already = _rule_selection()
    already.lf_n0["B2"] = {1: 700.0}
    assert _decide(already, same=(100.0, 700.0)) == set()


def test_a_scanned_branch_below_the_threshold_of_its_patl_does_not_select_the_contingency():
    assert _decide(_rule_selection(), low=(100.0, 600.0)) == set()          # 600 A is 83 % of 720 A


def test_a_threshold_of_zero_selects_every_contingency_even_with_nothing_raised():
    selection = _rule_selection(pct=0.0)
    assert _decide(selection, a=(100.0, 72.0), b=(0.0, 0.0)) == {"a", "b"} and not selection.not_selected


def test_the_selection_log_gives_the_threshold_the_minimum_increase_and_the_counts_by_secured_and_scanned_sides(caplog):
    selection = _rule_selection()
    with caplog.at_level(logging.INFO):
        _decide(selection, by_secured=(900.0, 72.0), by_scanned=(100.0, 700.0), by_both=(950.0, 720.0), neither=(100.0, 72.0))
    assert "contingency_min_loading_pct 90" in caplog.text and "contingency_min_increase_pct 1" in caplog.text
    assert "1 of 4 contingencies not selected" in caplog.text and "neither" in caplog.text
    assert "3 selected (2 by secured branch sides, 2 by scanned branch sides)" in caplog.text


def test_a_threshold_of_zero_keeps_every_contingency():
    selection = _selection(0.0)
    selection.select_from(_lf_nx())
    assert selection.selected == set(_lf_nx()) and not selection.not_selected


def test_the_restricted_lf_nx_has_the_selected_contingencies_and_keeps_the_gap_records():
    selection = _selection(50.0)
    selection.select_from(_lf_nx())
    restricted = selection.restricted(_lf_nx_with_records := _lf_nx())
    assert set(restricted) == {"co-high", "co-over"} and restricted.tripped == _lf_nx_with_records.tripped
    assert selection.restricted(None) is None


def test_an_overload_in_a_contingency_that_was_not_selected_selects_it_and_is_counted(caplog):
    selection = _selection(150.0)                     # nothing reaches 150 % of the lowest limit except co-over (120 %: no)
    selection.select_from(_lf_nx())
    assert selection.selected == set()
    assert selection.overloads_outside(_lf_nx()) == {("B2", "co-over"): pytest.approx(100.0)}
    with caplog.at_level(logging.INFO):
        assert selection.select_overloaded(_lf_nx(), 1) == {"co-over"}
        selection.log_final_overloads(_lf_nx())
    assert selection.selected == {"co-over"} and "co-low" in selection.not_selected | {"co-low"}
    assert "from the next iteration on" in caplog.text
    assert "0 overload(s)" in caplog.text                 # co-over is selected now: nothing is left outside


def test_the_final_check_counts_the_overloads_of_contingencies_that_stay_unselected(caplog):
    selection = _selection(50.0)
    selection.select_from(_lf_nx())
    lf_nx = _lf_nx()
    lf_nx["co-low"] = {"B1": {1: 1100.0}, "B2": {1: 100.0}}           # overloaded at the final state, not selected
    with caplog.at_level(logging.INFO):
        selection.log_final_overloads(lf_nx)
    assert "1 overload(s) (100.0 A in total) in 1 contingency(ies)" in caplog.text


def test_the_lowest_limit_is_the_smaller_of_the_patl_and_the_tatl_row_and_the_scanned_factor_applies():
    factors = MilpLimitFactors(patl=1.0, tatl=0.5, scanned=0.9)
    types = {"S": AEType.SECURED, "T": AEType.SECURED, "C": AEType.SCANNED}
    lowest = lowest_limits_ampere(
        {"S": 1000.0, "T": 1000.0, "C": 400.0}, types, {"T": {"tatl_limit_ampere": 1200.0}}, factors)
    assert lowest == {"S": 1000.0, "T": 600.0, "C": pytest.approx(360.0)}       # without its PATL: the effective limit
    with_patl = lowest_limits_ampere(
        {"S": 1000.0, "C": 400.0}, types, None, factors, scanned_patl={"C": 300.0})
    assert with_patl["C"] == pytest.approx(270.0)                              # PATL x scanned factor, not the effective limit


def test_the_minimum_increase_key_is_1_by_default_in_both_files_and_must_be_a_number_of_at_least_zero():
    config_dir = Path(run_pipeline.__file__).parent / "config"
    for name in ("rao_config.yaml", "rao_config.default.yaml"):
        text = (config_dir / name).read_text(encoding="utf-8")
        assert "contingency_min_increase_pct: 1.0\n" in text.replace("\r\n", "\n")
    config = run_pipeline.yaml.safe_load((config_dir / "rao_config.yaml").read_text(encoding="utf-8"))
    for bad in (-0.5, "1", True):
        config["nx_sensitivity"]["contingency_min_increase_pct"] = bad
        with pytest.raises(ValueError, match="nx_sensitivity.contingency_min_increase_pct"):
            run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))
    config["nx_sensitivity"]["contingency_min_increase_pct"] = 0
    run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))


def test_the_config_key_is_off_by_default_in_both_files_and_must_be_a_number_of_at_least_zero():
    config_dir = Path(run_pipeline.__file__).parent / "config"
    for name in ("rao_config.yaml", "rao_config.default.yaml"):
        text = (config_dir / name).read_text(encoding="utf-8")
        assert "contingency_min_loading_pct: 0\n" in text.replace("\r\n", "\n")
    config = run_pipeline.yaml.safe_load((config_dir / "rao_config.yaml").read_text(encoding="utf-8"))
    for bad in (-1, "5", True):
        config["nx_sensitivity"]["contingency_min_loading_pct"] = bad
        with pytest.raises(ValueError, match="nx_sensitivity.contingency_min_loading_pct"):
            run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))
    config["nx_sensitivity"]["contingency_min_loading_pct"] = 12.5
    run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))


def _run(tmp_path, pct):
    def customize(rp, monkeypatch):
        monkeypatch.setattr(rp, "NX_CONTINGENCY_MIN_LOADING_PCT", pct)
    return run_pipeline_on_fixture_inputs(tmp_path, _MOCK_NX_NCP_ZIP, enable_nx_analysis=True, customize_pipeline=customize)


def test_a_mock_run_with_a_threshold_selects_by_loading_and_keeps_the_nx_loadings(tmp_path):
    run = _run(tmp_path, 50.0)
    log = (run.output_dir / "run_log.txt").read_text(encoding="utf-8")
    assert "N-X contingency selection (contingency_min_loading_pct 50, contingency_min_increase_pct 1)" in log
    assert "Final AC check:" in log and "not selected for N-X" in log
    assert (run.output_dir / "loadings_nx.csv").is_file()


def test_a_mock_run_where_nothing_reaches_the_threshold_selects_the_overloaded_contingencies_in_the_loop(tmp_path):
    run = _run(tmp_path, 1e9)
    log = (run.output_dir / "run_log.txt").read_text(encoding="utf-8")
    assert "contingencies not selected" in log or "not selected (no N-X sensitivities" in log
    assert "overload at the AC state - selected from the next iteration on" in log
